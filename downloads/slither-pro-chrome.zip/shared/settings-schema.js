/**
 * Slither Pro — Default settings schema and keys.
 * Used by both popup and injected script.
 */
(function () {
  'use strict';

  var SETTINGS_DEFAULTS = {
    visual: {
      skin: 'default',
      customColors: ['#39ff14', '#006600'],
      aura: 'none',
      background: 'default',
      backgroundColor: '#111111',
      gameBackgroundEnabled: false,
      gameBackgroundColor: '#0a0a2e',
      gridEnabled: false,
      gridColor: '#333333',
      gridOpacity: 0.3
    },
    food: {
      style: 'default',
      glowEnabled: true,
      scaleCorrection: true,
      customImage: ''
    },
    zoom: {
      enabled: true,
      level: 0.9,
      sensitivity: 0.05,
      smoothing: true
    },
    hud: {
      enabled: true,
      minimapEnabled: true,
      minimapSize: 200,
      minimapPosition: 'bottom-right',
      fpsCounter: true,
      pingDisplay: true,
      scoreDisplay: true,
      killCounter: true,
      sessionTimer: true,
      coordinates: false,
      serverInfo: false,
      deathRecap: true
    },
    bot: {
      enabled: false,
      foodSeeker: true,
      collisionAvoidance: true,
      autoBoost: true,
      autoPlay: false,
      inputLock: false,
      mode: 'balanced',
      killAttempts: true,
      smartWander: true,
      coilDetection: true
    },
    gameplay: {
      graphicsQuality: 'normal',
      deathEffects: true,
      boostEffects: true,
      autoRespawn: false,
      saveNickname: true,
      nickname: '',
      clanTag: ''
    },
    nameTag: {
      enabled: true,
      style: 'rainbow',
      animationSpeed: 'normal',
      glowIntensity: 'medium',
      fontSize: 'normal',
      useSnakeColors: true,
      color1: '#39ff14',
      color2: '#00cc00'
    },
    subscription: {
      active: false
    }
  };

  var SKIN_PRESETS = {
    'default': null,
    // Static skins
    'neon-green': ['#39ff14', '#00cc00'],
    'neon-pink': ['#ff1493', '#ff69b4', '#ff00ff'],
    'neon-blue': ['#00f0ff', '#0080ff', '#00bfff'],
    'neon-purple': ['#bf00ff', '#8a2be2', '#da70d6'],
    'fire': ['#ff4500', '#ff8c00', '#ffd700'],
    'ice': ['#00bfff', '#87ceeb', '#e0f7ff'],
    'galaxy': ['#4b0082', '#8a2be2', '#da70d6'],
    'toxic': ['#39ff14', '#ccff00', '#80ff00'],
    'lava': ['#ff2020', '#ff6600', '#ff0000'],
    'ocean': ['#0000ff', '#00bfff', '#20f0f0'],
    'sunset': ['#ff4500', '#ff1493', '#8a2be2'],
    'stealth': ['#1a1a1a', '#333333'],
    // Animated skins
    'rainbow': ['#ff0000', '#ff4500', '#ff8c00', '#ffd700', '#ffff00', '#7fff00', '#00ff00', '#00fa9a', '#00bfff', '#4169e1', '#8a2be2', '#ff00ff'],
    'aurora': ['#00ff88', '#00ffcc', '#00e5ff', '#4488ff', '#6644ff', '#aa44ff'],
    'plasma': ['#ff0040', '#ff4400', '#ff8800', '#ffcc00', '#ffffff'],
    'pulse-fire': ['#ff0000', '#ff6600', '#ffcc00'],
    'pulse-ice': ['#0044ff', '#00aaff', '#88ffff'],
    'candy': ['#ff69b4', '#ffccf9', '#88bbff', '#88ffcc', '#ffff77'],
    'lightning': ['#0044ff', '#0088ff', '#ffffff'],
    'vaporwave': ['#ff71ce', '#01cdfe', '#05ffa1', '#b967ff', '#fffb96'],
    'neon-pulse': ['#39ff14', '#00ffff', '#ff00ff'],
    'inferno': ['#ff0000', '#ff4400', '#ff8800', '#ffcc00', '#ffffff'],
    'frozen': ['#0044ff', '#00aaff', '#88ffff', '#ffffff'],
    // Glowing skins
    'neon-emerald': ['#00ff88', '#00cc66', '#39ff14'],
    'neon-crimson': ['#ff0044', '#ff2266', '#ff4488'],
    'neon-cyan': ['#00ffff', '#00ddff', '#00bbff'],
    'neon-gold': ['#ffd700', '#ffaa00', '#ff8800'],
    'solar-flare': ['#ff4400', '#ff8800', '#ffcc00', '#ffffff'],
    'deep-space': ['#0a0030', '#1a0050', '#3300aa', '#6600ff'],
    'radioactive': ['#00ff00', '#33ff33', '#66ff00', '#ccff00'],
    'holographic': ['#ff00ff', '#00ffff', '#ffff00', '#ff00ff', '#00ffff'],
    'ember': ['#330000', '#660000', '#ff2200', '#ff6600'],
    'crystal': ['#aaddff', '#cceeff', '#ffffff', '#eef8ff'],
    'void': ['#1a0033', '#330066', '#6600cc', '#9900ff'],
    'electric-storm': ['#0044ff', '#0088ff', '#00ccff', '#ffffff', '#0088ff'],
    'blood-moon': ['#440000', '#880000', '#cc0000', '#ff2200'],
    'arctic': ['#004466', '#0088aa', '#00ccee', '#aaeeff', '#ffffff'],
    'cherry-blossom': ['#ff69b4', '#ffb7d5', '#ffffff', '#ff69b4'],
    'matrix': ['#003300', '#006600', '#00cc00', '#00ff00']
  };

  // Expose on the namespace
  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.SETTINGS_DEFAULTS = SETTINGS_DEFAULTS;
  window.SlitherPro.SKIN_PRESETS = SKIN_PRESETS;
})();
