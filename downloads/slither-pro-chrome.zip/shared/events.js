/**
 * Slither Pro — Shared event type constants for message passing.
 */
(function () {
  'use strict';

  var EVENTS = {
    SETTINGS_UPDATE: 'SETTINGS_UPDATE',
    SETTINGS_REQUEST: 'SETTINGS_REQUEST',
    SETTINGS_RESPONSE: 'SETTINGS_RESPONSE',
    // Dedicated subscription channel — only content script should emit this
    SUB_STATUS: 'SP_SUB_7f3a',
    GAME_STATE: 'GAME_STATE',
    STATS_UPDATE: 'STATS_UPDATE',
    DEATH_EVENT: 'DEATH_EVENT',
    BOT_TOGGLE: 'BOT_TOGGLE',
    MOD_READY: 'MOD_READY',
    // Bot integrity gate — content script emits after verifying bot files
    // against the shipped integrity manifest. Failure blocks bot start.
    INTEGRITY_STATUS: 'SP_INT_b9c1'
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.EVENTS = EVENTS;
})();
