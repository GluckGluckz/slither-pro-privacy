/**
 * Slither Pro — Subscription Manager.
 * Handles Stripe checkout, email-based verification, and feature gating.
 *
 * Flow:
 *   1. User clicks "Subscribe" → opens Stripe Checkout in new tab
 *   2. After payment, user enters the email they used at checkout
 *   3. Extension calls the verification API to confirm active subscription
 *   4. On success, subscription status is stored locally
 */
(function () {
  'use strict';

  // ─── Configuration ────────────────────────────────────────
  var STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/cNieVf1PNgctgiAaiT8og00';
  var VALIDATION_API = 'https://slither-pro-api.anthany2024.workers.dev/verify';
  var PLAN_NAME = 'Slither Pro';

  // ─── Storage keys ─────────────────────────────────────────
  var STORAGE_KEY = 'sp_subscription';

  // ─── State ────────────────────────────────────────────────
  var _subscriptionData = null;
  var _listeners = [];

  var Subscription = {

    /**
     * Initialize: load subscription data from storage, then re-verify.
     * v8: Always re-verify with server before showing "active" status.
     * Shows UI as inactive until server confirms — prevents stale state
     * after reinstall or Chrome Sync restore.
     *
     * @param {function} callback - called with {active: boolean}
     */
    init: function (callback) {
      var self = this;
      chrome.storage.sync.get(STORAGE_KEY, function (data) {
        _subscriptionData = data[STORAGE_KEY] || null;

        // Check local expiry first
        if (_subscriptionData && _subscriptionData.expiresAt) {
          if (Date.now() > _subscriptionData.expiresAt) {
            _subscriptionData.active = false;
          }
        }

        // v8: If we have a stored email, re-verify with server FIRST.
        // Don't trust local state until server confirms.
        if (_subscriptionData && _subscriptionData.email && _subscriptionData.active) {
          // Show as inactive while verifying
          if (callback) callback({ active: false, verifying: true });

          self.refresh(function (isValid) {
            // Now update UI with real status from server
            self._notifyListeners();
          });
        } else {
          if (callback) callback(self.getStatus());
        }
      });
    },

    /**
     * Get current subscription status.
     */
    getStatus: function () {
      if (!_subscriptionData) {
        return { active: false, plan: null, expiresAt: 0, email: null };
      }
      return {
        active: !!_subscriptionData.active,
        plan: _subscriptionData.plan || null,
        expiresAt: _subscriptionData.expiresAt || 0,
        email: _subscriptionData.email || null
      };
    },

    /**
     * Check if bot features are unlocked.
     */
    isBotUnlocked: function () {
      return this.getStatus().active;
    },

    /**
     * Open Stripe Checkout in a new tab.
     */
    openCheckout: function () {
      chrome.tabs.create({ url: STRIPE_PAYMENT_LINK });
    },

    /**
     * Activate subscription by verifying email against Stripe.
     * @param {string} email - the email used at Stripe checkout
     * @param {function} callback - called with {success: boolean, error: string}
     */
    activate: function (email, callback) {
      if (!email || email.trim().length === 0) {
        if (callback) callback({ success: false, error: 'Please enter your email.' });
        return;
      }

      email = email.trim().toLowerCase();

      if (email.indexOf('@') === -1 || email.indexOf('.') === -1) {
        if (callback) callback({ success: false, error: 'Please enter a valid email address.' });
        return;
      }

      this._verifyWithAPI(email, callback);
    },

    /**
     * Re-verify the current subscription with the server.
     * v8: Revokes on server rejection AND on network failure.
     * The server (Stripe) is the source of truth — if we can't reach it,
     * we don't trust stale local data.
     */
    refresh: function (callback) {
      if (!_subscriptionData || !_subscriptionData.email) {
        if (callback) callback(false);
        return;
      }

      var self = this;
      this._verifyWithAPI(_subscriptionData.email, function (result) {
        if (result.success) {
          // Server confirmed — subscription is valid
          if (callback) callback(true);
        } else {
          // Server rejected OR network failed — revoke local state
          if (_subscriptionData) {
            _subscriptionData.active = false;
            self._storeSubscription(_subscriptionData);
            self._notifyListeners();
          }
          if (callback) callback(false);
        }
      });
    },

    /**
     * Deactivate / sign out of subscription.
     */
    deactivate: function (callback) {
      _subscriptionData = null;
      var update = {};
      update[STORAGE_KEY] = null;
      chrome.storage.sync.set(update, function () {
        if (callback) callback();
      });
      this._notifyListeners();
    },

    /**
     * Register a listener for subscription changes.
     */
    onChange: function (fn) {
      _listeners.push(fn);
    },

    // ─── Private ────────────────────────────────────────────

    _verifyWithAPI: function (email, callback) {
      var self = this;

      fetch(VALIDATION_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
      })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.valid) {
          self._storeSubscription({
            active: true,
            plan: PLAN_NAME,
            email: data.email || email,
            expiresAt: data.expiresAt || (Date.now() + 30 * 24 * 60 * 60 * 1000),
            activatedAt: Date.now()
          });
          if (callback) callback({ success: true });
        } else {
          if (callback) callback({ success: false, error: data.message || 'No active subscription found.' });
        }
      })
      .catch(function () {
        if (callback) callback({ success: false, error: 'Could not reach server. Check your connection.' });
      });
    },

    _storeSubscription: function (data) {
      _subscriptionData = data;
      var update = {};
      update[STORAGE_KEY] = data;
      chrome.storage.sync.set(update);
      this._notifyListeners();
    },

    _notifyListeners: function () {
      var status = this.getStatus();
      for (var i = 0; i < _listeners.length; i++) {
        try { _listeners[i](status); } catch (e) {}
      }
    }
  };

  // Export
  window.SlitherProSubscription = Subscription;

})();
