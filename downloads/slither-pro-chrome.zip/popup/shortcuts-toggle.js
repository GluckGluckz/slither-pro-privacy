/* Collapsible shortcuts bar — no dependency on popup.js */
(function () {
  var bar = document.getElementById('shortcuts-bar');
  var btn = document.getElementById('shortcuts-toggle');
  if (bar && btn) {
    btn.addEventListener('click', function () {
      bar.classList.toggle('open');
    });
  }
})();
