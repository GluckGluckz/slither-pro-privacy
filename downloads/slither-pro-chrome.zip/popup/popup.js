/**
 * Slither Pro — Popup script.
 * Handles settings UI, reads/writes chrome.storage, and communicates with the service worker.
 */
(function () {
  'use strict';

  // ─── Settings Map ──────────────────────────────────────────
  // Maps DOM element IDs to their storage path and type.
  var SETTING_MAP = {
    // Visual
    'opt-skin':              { path: 'visual.skin', type: 'select' },
    'opt-customColor1':      { path: 'visual.customColors.0', type: 'color' },
    'opt-customColor2':      { path: 'visual.customColors.1', type: 'color' },
    'opt-aura':              { path: 'visual.aura', type: 'select' },
    'opt-background':        { path: 'visual.background', type: 'select' },
    'opt-backgroundColor':   { path: 'visual.backgroundColor', type: 'color' },
    'opt-gameBackgroundEnabled': { path: 'visual.gameBackgroundEnabled', type: 'checkbox' },
    'opt-gameBackgroundColor':   { path: 'visual.gameBackgroundColor', type: 'color' },
    // Name Tag
    'opt-nameTagEnabled':    { path: 'nameTag.enabled', type: 'checkbox' },
    'opt-nameTagStyle':      { path: 'nameTag.style', type: 'select' },
    'opt-nameTagUseSnakeColors': { path: 'nameTag.useSnakeColors', type: 'checkbox' },
    'opt-nameTagAnimationSpeed': { path: 'nameTag.animationSpeed', type: 'select' },
    'opt-nameTagGlowIntensity': { path: 'nameTag.glowIntensity', type: 'select' },
    'opt-nameTagFontSize':      { path: 'nameTag.fontSize', type: 'select' },
    'opt-nameTagColor1':     { path: 'nameTag.color1', type: 'color' },
    'opt-nameTagColor2':     { path: 'nameTag.color2', type: 'color' },
    // Food
    'opt-foodStyle':         { path: 'food.style', type: 'select' },
    'opt-foodGlowEnabled':   { path: 'food.glowEnabled', type: 'checkbox' },
    'opt-foodScaleCorrection': { path: 'food.scaleCorrection', type: 'checkbox' },
    // Effects
    'opt-gridEnabled':       { path: 'visual.gridEnabled', type: 'checkbox' },
    'opt-gridColor':         { path: 'visual.gridColor', type: 'color' },
    'opt-gridOpacity':       { path: 'visual.gridOpacity', type: 'range', display: 'val-gridOpacity' },
    // Gameplay (zoom + performance + QoL)
    'opt-zoomEnabled':       { path: 'zoom.enabled', type: 'checkbox' },
    'opt-zoomLevel':         { path: 'zoom.level', type: 'range', display: 'val-zoomLevel' },
    'opt-zoomSensitivity':   { path: 'zoom.sensitivity', type: 'range', display: 'val-zoomSensitivity' },
    'opt-zoomSmoothing':     { path: 'zoom.smoothing', type: 'checkbox' },
    'opt-graphicsQuality':   { path: 'gameplay.graphicsQuality', type: 'select' },
    'opt-autoRespawn':       { path: 'gameplay.autoRespawn', type: 'checkbox' },
    'opt-saveNickname':      { path: 'gameplay.saveNickname', type: 'checkbox' },
    // HUD
    'opt-hudEnabled':        { path: 'hud.enabled', type: 'checkbox' },
    'opt-minimapEnabled':    { path: 'hud.minimapEnabled', type: 'checkbox' },
    'opt-minimapSize':       { path: 'hud.minimapSize', type: 'range', display: 'val-minimapSize' },
    'opt-minimapPosition':   { path: 'hud.minimapPosition', type: 'select' },
    'opt-hideNativeMinimap': { path: 'hud.hideNativeMinimap', type: 'checkbox' },
    'opt-fpsCounter':        { path: 'hud.fpsCounter', type: 'checkbox' },
    'opt-pingDisplay':       { path: 'hud.pingDisplay', type: 'checkbox' },
    'opt-scoreDisplay':      { path: 'hud.scoreDisplay', type: 'checkbox' },
    'opt-killCounter':       { path: 'hud.killCounter', type: 'checkbox' },
    'opt-sessionTimer':      { path: 'hud.sessionTimer', type: 'checkbox' },
    'opt-coordinates':       { path: 'hud.coordinates', type: 'checkbox' },
    'opt-serverInfo':        { path: 'hud.serverInfo', type: 'checkbox' },
    'opt-deathRecap':        { path: 'hud.deathRecap', type: 'checkbox' },
    // Bot
    'opt-botEnabled':        { path: 'bot.enabled', type: 'checkbox' },
    'opt-botMode':           { path: 'bot.mode', type: 'select' },
    'opt-foodSeeker':        { path: 'bot.foodSeeker', type: 'checkbox' },
    'opt-collisionAvoidance': { path: 'bot.collisionAvoidance', type: 'checkbox' },
    'opt-autoBoost':         { path: 'bot.autoBoost', type: 'checkbox' },
    'opt-autoPlay':          { path: 'bot.autoPlay', type: 'checkbox' },
    'opt-inputLock':         { path: 'bot.inputLock', type: 'checkbox' },
    'opt-killAttempts':      { path: 'bot.killAttempts', type: 'checkbox' },
    'opt-smartWander':       { path: 'bot.smartWander', type: 'checkbox' },
    'opt-coilDetection':     { path: 'bot.coilDetection', type: 'checkbox' },
  };

  // ─── Tab Switching ─────────────────────────────────────────
  var tabs = document.querySelectorAll('.sp-tab');
  var panels = document.querySelectorAll('.sp-panel');

  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      tabs.forEach(function (t) { t.classList.remove('active'); });
      panels.forEach(function (p) { p.classList.remove('active'); });
      tab.classList.add('active');
      var panel = document.getElementById('panel-' + tab.dataset.tab);
      if (panel) panel.classList.add('active');
    });
  });

  // ─── Conditional UI Visibility ─────────────────────────────
  var skinSelect = document.getElementById('opt-skin');
  var customColorsRow = document.getElementById('custom-colors-row');
  if (skinSelect && customColorsRow) {
    skinSelect.addEventListener('change', function () {
      customColorsRow.style.display = skinSelect.value === 'custom' ? 'flex' : 'none';
    });
  }

  var bgSelect = document.getElementById('opt-background');
  var customBgRow = document.getElementById('custom-bg-row');
  if (bgSelect && customBgRow) {
    bgSelect.addEventListener('change', function () {
      customBgRow.style.display = bgSelect.value === 'custom' ? 'flex' : 'none';
    });
  }

  var gameBgToggle = document.getElementById('opt-gameBackgroundEnabled');
  var gameBgRow = document.getElementById('game-bg-row');
  if (gameBgToggle) {
    gameBgToggle.addEventListener('change', function () {
      if (gameBgRow) gameBgRow.style.display = gameBgToggle.checked ? 'flex' : 'none';
    });
  }

  // Name tag: show custom colors only when "Use Snake Colors" is off
  var nameTagSnakeColorsToggle = document.getElementById('opt-nameTagUseSnakeColors');
  var nameTagColorsRow = document.getElementById('nametag-colors-row');
  if (nameTagSnakeColorsToggle) {
    nameTagSnakeColorsToggle.addEventListener('change', function () {
      if (nameTagColorsRow) nameTagColorsRow.style.display = nameTagSnakeColorsToggle.checked ? 'none' : 'flex';
    });
  }

  // Food style → show/hide upload row
  var foodStyleSelect = document.getElementById('opt-foodStyle');
  var foodUploadRow = document.getElementById('food-upload-row');
  var foodGlowToggle = document.getElementById('opt-foodGlowEnabled');
  if (foodStyleSelect) {
    foodStyleSelect.addEventListener('change', function () {
      if (foodUploadRow) foodUploadRow.style.display = foodStyleSelect.value === 'custom' ? 'flex' : 'none';
    });
  }

  // ─── Local Settings Cache ────────────────────────────────────
  // v8: Maintain a local copy so toggle changes are synchronous.
  // Eliminates the read-modify-write race that caused lost settings
  // when two toggles in the same category fired back-to-back.
  var _localSettings = {};

  // ─── Load Settings ─────────────────────────────────────────
  chrome.storage.sync.get(null, function (data) {
    if (!data || Object.keys(data).length === 0) return;
    _localSettings = data;

    for (var id in SETTING_MAP) {
      var el = document.getElementById(id);
      if (!el) continue;

      var meta = SETTING_MAP[id];
      var value = getNestedValue(data, meta.path);
      if (value === undefined) continue;

      switch (meta.type) {
        case 'checkbox':
          el.checked = !!value;
          break;
        case 'range':
          el.value = value;
          updateSliderDisplay(meta, value);
          break;
        case 'select':
          el.value = value;
          break;
        case 'select-number':
          el.value = String(value);
          break;
        case 'color':
          el.value = value;
          break;
        case 'text':
          el.value = value || '';
          break;
      }
    }

    // Update conditional visibility
    if (skinSelect) customColorsRow.style.display = skinSelect.value === 'custom' ? 'flex' : 'none';
    if (bgSelect) customBgRow.style.display = bgSelect.value === 'custom' ? 'flex' : 'none';
    if (gameBgToggle && gameBgRow) gameBgRow.style.display = gameBgToggle.checked ? 'flex' : 'none';
    if (foodStyleSelect && foodUploadRow) foodUploadRow.style.display = foodStyleSelect.value === 'custom' ? 'flex' : 'none';
    if (nameTagSnakeColorsToggle && nameTagColorsRow) nameTagColorsRow.style.display = nameTagSnakeColorsToggle.checked ? 'none' : 'flex';

    // Load custom food image preview from local storage
    chrome.storage.local.get('sp_food_image', function (localData) {
      if (localData && localData.sp_food_image) {
        var prev = document.getElementById('food-img-preview');
        if (prev) {
          var foodImg = localData.sp_food_image;
          if (foodImg && typeof foodImg === 'string' && foodImg.indexOf('data:image/') === 0) {
            prev.style.backgroundImage = 'url(' + foodImg + ')';
            prev.classList.add('has-img');
          }
        }
      }
    });

    // Sync custom color picker previews with loaded values
    var cpPreviews = document.querySelectorAll('.sp-cpick-preview');
    for (var p = 0; p < cpPreviews.length; p++) {
      var targetId = cpPreviews[p].getAttribute('data-for');
      var targetInput = document.getElementById(targetId);
      if (targetInput) cpPreviews[p].style.background = targetInput.value;
    }
  });

  // ─── Attach Change Listeners ───────────────────────────────
  for (var id in SETTING_MAP) {
    (function (elementId, meta) {
      var el = document.getElementById(elementId);
      if (!el) return;

      var eventType = (meta.type === 'range') ? 'input' : 'change';

      el.addEventListener(eventType, function () {
        var value;
        switch (meta.type) {
          case 'checkbox':
            value = el.checked;
            break;
          case 'range':
            value = parseFloat(el.value);
            updateSliderDisplay(meta, value);
            break;
          case 'select':
            value = el.value;
            break;
          case 'select-number':
            value = parseInt(el.value, 10);
            break;
          case 'color':
            value = el.value;
            break;
          case 'text':
            value = el.value;
            break;
        }

        // v8: Use local cache instead of async read-modify-write.
        // Mutate the in-memory copy and write it directly — no race window.
        var parts = meta.path.split('.');
        var category = parts[0]; // e.g. 'visual', 'zoom', 'hud'

        if (!_localSettings[category] || typeof _localSettings[category] !== 'object') {
          _localSettings[category] = {};
        }

        // Set the value at the right depth within the category
        if (parts.length === 2) {
          _localSettings[category][parts[1]] = value;
        } else if (parts.length === 3) {
          // e.g. visual.customColors.0
          if (!_localSettings[category][parts[1]]) _localSettings[category][parts[1]] = [];
          _localSettings[category][parts[1]][parts[2]] = value;
        }

        var storageUpdate = {};
        storageUpdate[category] = _localSettings[category];
        chrome.storage.sync.set(storageUpdate);

        // Notify the game via service worker
        chrome.runtime.sendMessage({
          type: 'SETTINGS_UPDATE',
          payload: storageUpdate
        });
      });
    })(id, SETTING_MAP[id]);
  }

  // ─── Subscription / Paywall Wiring ─────────────────────────
  var paywallEl = document.getElementById('bot-paywall');
  var botContentEl = document.getElementById('bot-content');
  var subscribeBtnEl = document.getElementById('btn-subscribe');
  var activateBtnEl = document.getElementById('btn-activate');
  var licenseInputEl = document.getElementById('license-email-input');
  var licenseMsgEl = document.getElementById('license-msg');
  var manageBtnEl = document.getElementById('btn-manage-sub');

  function updatePaywallUI(status) {
    if (!paywallEl || !botContentEl) return;
    if (status && status.active) {
      paywallEl.classList.add('sp-hidden');
      botContentEl.classList.add('sp-unlocked');
    } else {
      paywallEl.classList.remove('sp-hidden');
      botContentEl.classList.remove('sp-unlocked');
    }
  }

  function showLicenseMsg(text, isError) {
    if (!licenseMsgEl) return;
    licenseMsgEl.textContent = text;
    licenseMsgEl.className = 'sp-license-msg ' + (isError ? 'sp-msg-error' : 'sp-msg-success');
  }

  // Initialize subscription system
  if (window.SlitherProSubscription) {
    window.SlitherProSubscription.init(function (status) {
      updatePaywallUI(status);
    });

    window.SlitherProSubscription.onChange(function (status) {
      updatePaywallUI(status);
    });
  }

  // Subscribe button → opens Stripe checkout
  if (subscribeBtnEl) {
    subscribeBtnEl.addEventListener('click', function () {
      if (window.SlitherProSubscription) {
        window.SlitherProSubscription.openCheckout();
      }
    });
  }

  // Verify email subscription
  if (activateBtnEl) {
    activateBtnEl.addEventListener('click', function () {
      var email = licenseInputEl ? licenseInputEl.value : '';
      if (!email.trim()) {
        showLicenseMsg('Please enter your email.', true);
        return;
      }
      activateBtnEl.disabled = true;
      activateBtnEl.textContent = '...';

      if (!window.SlitherProSubscription) {
        activateBtnEl.disabled = false;
        activateBtnEl.textContent = 'Verify';
        showLicenseMsg('Subscription system unavailable.', true);
        return;
      }

      window.SlitherProSubscription.activate(email, function (result) {
        activateBtnEl.disabled = false;
        activateBtnEl.textContent = 'Verify';

        if (result.success) {
          showLicenseMsg('Verified! Bot features unlocked.', false);
          if (licenseInputEl) licenseInputEl.value = '';
        } else {
          showLicenseMsg(result.error || 'Verification failed.', true);
        }
      });
    });
  }

  // License input: allow Enter key to submit
  if (licenseInputEl) {
    licenseInputEl.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (activateBtnEl) activateBtnEl.click();
      }
    });
  }

  // Manage subscription → open Stripe Customer Portal
  var PORTAL_API = 'https://slither-pro-api.anthany2024.workers.dev/portal';
  var PORTAL_FALLBACK = 'https://billing.stripe.com/p/login/cNieVf1PNgctgiAaiT8og00';

  if (manageBtnEl) {
    manageBtnEl.addEventListener('click', function () {
      var sub = window.SlitherProSubscription ? window.SlitherProSubscription.getStatus() : null;
      if (!sub || !sub.email) {
        // No email stored — fall back to static portal login
        chrome.tabs.create({ url: PORTAL_FALLBACK });
        return;
      }

      manageBtnEl.disabled = true;
      manageBtnEl.textContent = '...';

      fetch(PORTAL_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: sub.email })
      })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        manageBtnEl.disabled = false;
        manageBtnEl.textContent = 'Manage';
        if (data.url) {
          chrome.tabs.create({ url: data.url });
        } else {
          // API didn't return a session — fall back to static portal
          chrome.tabs.create({ url: PORTAL_FALLBACK });
        }
      })
      .catch(function () {
        // Network error — fall back to static portal
        manageBtnEl.disabled = false;
        manageBtnEl.textContent = 'Manage';
        chrome.tabs.create({ url: PORTAL_FALLBACK });
      });
    });
  }

  // Sign out of subscription on this device
  var signOutBtnEl = document.getElementById('btn-signout-sub');
  if (signOutBtnEl) {
    signOutBtnEl.addEventListener('click', function () {
      if (!confirm('Sign out of your Pro subscription on this device?')) return;
      if (window.SlitherProSubscription) {
        window.SlitherProSubscription.deactivate(function () {
          updatePaywallUI({ active: false });
        });
      }
    });
  }

  // ─── Play Slither.io Button ─────────────────────────────────
  var playBtn = document.getElementById('btn-play');
  if (playBtn) {
    playBtn.addEventListener('click', function (e) {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://slither.io' });
    });
  }

  // ─── Reset to Defaults ─────────────────────────────────────
  var resetBtn = document.getElementById('btn-reset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      if (!confirm('Reset all Slither Pro settings to defaults?')) return;

      chrome.storage.sync.get('sp_subscription', function (subData) {
        chrome.storage.sync.clear(function () {
          // Restore subscription
          if (subData && subData.sp_subscription) {
            chrome.storage.sync.set({ sp_subscription: subData.sp_subscription });
          }
          // Trigger reinstall of defaults
          chrome.runtime.sendMessage({ type: 'RESET_DEFAULTS' });
          // Reload popup to reflect defaults
          window.location.reload();
        });
      });
    });
  }

  // ─── Bot Mode Description ────────────────────────────────────
  var MODE_DESCRIPTIONS = {
    aggressive: 'Maximum kills. Pursues intercepts aggressively with high boost usage. Lower safety margins.',
    balanced: 'Balanced mix of survival and scoring. Seeks kills when safe, avoids risks when threatened.',
    defensive: 'Survival-focused. Avoids all fights, hugs safe zones, and prioritizes longevity over score.'
  };

  var botModeEl = document.getElementById('opt-botMode');
  var modeDescEl = document.getElementById('mode-desc');
  if (botModeEl && modeDescEl) {
    botModeEl.addEventListener('change', function () {
      modeDescEl.textContent = MODE_DESCRIPTIONS[botModeEl.value] || '';
    });
  }

  // ─── Helpers ───────────────────────────────────────────────

  function getNestedValue(obj, path) {
    var parts = path.split('.');
    var current = obj;
    for (var i = 0; i < parts.length; i++) {
      if (current === undefined || current === null) return undefined;
      current = current[parts[i]];
    }
    return current;
  }

  function updateSliderDisplay(meta, value) {
    if (!meta.display) return;
    var displayEl = document.getElementById(meta.display);
    if (!displayEl) return;

    if (meta.format === 'percent') {
      displayEl.textContent = Math.round(value * 100) + '%';
    } else {
      displayEl.textContent = value;
    }
  }

  // ─── Custom Inline Color Picker ────────────────────────────
  (function () {
    var PRESETS = [
      '#000000', '#1a1a1a', '#333333', '#555555', '#888888', '#ffffff',
      '#0a0a2e', '#0d1117', '#1a0a2e', '#0a1a0a', '#1a0000', '#0a1a2a',
      '#ff0000', '#ff4400', '#ff8800', '#ffcc00', '#ff69b4', '#ff00ff',
      '#39ff14', '#00ff88', '#00e5ff', '#0088ff', '#4444ff', '#8844ff'
    ];

    var previews = document.querySelectorAll('.sp-cpick-preview');
    var activePanel = null;

    for (var i = 0; i < previews.length; i++) {
      (function (preview) {
        var targetId = preview.getAttribute('data-for');
        var hiddenInput = document.getElementById(targetId);
        if (!hiddenInput) return;

        // Build dropdown panel
        var panel = document.createElement('div');
        panel.className = 'sp-cpick-panel';

        var grid = document.createElement('div');
        grid.className = 'sp-cpick-grid';

        for (var j = 0; j < PRESETS.length; j++) {
          (function (color) {
            var swatch = document.createElement('div');
            swatch.className = 'sp-cpick-swatch';
            swatch.style.background = color;
            swatch.setAttribute('data-color', color);
            swatch.addEventListener('click', function (e) {
              e.stopPropagation();
              pickColor(preview, hiddenInput, color, panel);
            });
            grid.appendChild(swatch);
          })(PRESETS[j]);
        }

        panel.appendChild(grid);

        // Hex input row
        var hexRow = document.createElement('div');
        hexRow.className = 'sp-cpick-hex-row';

        var hexInput = document.createElement('input');
        hexInput.type = 'text';
        hexInput.className = 'sp-cpick-hex';
        hexInput.placeholder = '#000000';
        hexInput.maxLength = 7;
        hexInput.value = hiddenInput.value;

        var hexBtn = document.createElement('button');
        hexBtn.type = 'button';
        hexBtn.className = 'sp-cpick-hex-ok';
        hexBtn.textContent = 'OK';

        hexBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          var val = hexInput.value.trim();
          if (/^#[0-9a-fA-F]{6}$/.test(val)) {
            pickColor(preview, hiddenInput, val, panel);
          }
        });

        hexInput.addEventListener('keydown', function (e) {
          e.stopPropagation();
          if (e.key === 'Enter') {
            var val = hexInput.value.trim();
            if (/^#[0-9a-fA-F]{6}$/.test(val)) {
              pickColor(preview, hiddenInput, val, panel);
            }
          }
        });

        hexRow.appendChild(hexInput);
        hexRow.appendChild(hexBtn);
        panel.appendChild(hexRow);

        // Append to body so it escapes overflow:hidden containers
        document.body.appendChild(panel);

        // Toggle panel on preview click
        preview.addEventListener('click', function (e) {
          e.stopPropagation();
          if (activePanel === panel) {
            closePanel();
          } else {
            closePanel();
            // Position the panel above the preview trigger
            var rect = preview.getBoundingClientRect();
            panel.style.position = 'fixed';
            panel.style.right = (document.body.clientWidth - rect.right) + 'px';
            panel.style.bottom = (document.body.clientHeight - rect.top + 6) + 'px';
            panel.style.left = 'auto';
            panel.style.top = 'auto';
            panel.classList.add('open');
            activePanel = panel;
            hexInput.value = hiddenInput.value;
            // Highlight active swatch
            var swatches = grid.querySelectorAll('.sp-cpick-swatch');
            for (var k = 0; k < swatches.length; k++) {
              var isActive = swatches[k].getAttribute('data-color') === hiddenInput.value;
              swatches[k].classList.toggle('active', isActive);
            }
          }
        });
      })(previews[i]);
    }

    function pickColor(preview, input, color, panel) {
      preview.style.background = color;
      input.value = color;
      input.dispatchEvent(new Event('change'));
      closePanel();
    }

    function closePanel() {
      if (activePanel) {
        activePanel.classList.remove('open');
        activePanel = null;
      }
    }

    document.addEventListener('click', function () {
      closePanel();
    });

    // Close picker when scrollable content scrolls
    var spContent = document.querySelector('.sp-content');
    if (spContent) {
      spContent.addEventListener('scroll', function () {
        closePanel();
      });
    }
  })();

  // ─── Custom Food Image Upload ───────────────────────────────
  (function () {
    var MAX_SIZE = 128 * 1024; // 128 KB max
    var fileInput = document.getElementById('food-img-input');
    var previewEl = document.getElementById('food-img-preview');
    var clearBtn  = document.getElementById('food-img-clear');
    if (!fileInput) return;

    fileInput.addEventListener('change', function () {
      var file = fileInput.files && fileInput.files[0];
      if (!file) return;

      if (file.size > MAX_SIZE) {
        alert('Image must be under 128 KB. Try a smaller PNG.');
        fileInput.value = '';
        return;
      }

      var reader = new FileReader();
      reader.onload = function (e) {
        var dataUrl = e.target.result;

        // Store in local storage (sync has 8KB per-item limit, images are larger)
        chrome.storage.local.set({ sp_food_image: dataUrl });

        // Show preview
        if (previewEl) {
          previewEl.style.backgroundImage = 'url(' + dataUrl + ')';
          previewEl.classList.add('has-img');
        }

        // Send image directly to game via dedicated message (too large for sync)
        chrome.runtime.sendMessage({
          type: 'FOOD_IMAGE_UPDATE',
          payload: { customImage: dataUrl }
        });
      };
      reader.readAsDataURL(file);
    });

    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        chrome.storage.local.remove('sp_food_image');
        if (previewEl) {
          previewEl.style.backgroundImage = '';
          previewEl.classList.remove('has-img');
        }
        if (fileInput) fileInput.value = '';

        // Notify game to clear custom image
        chrome.runtime.sendMessage({
          type: 'FOOD_IMAGE_UPDATE',
          payload: { customImage: '' }
        });
      });
    }
  })();

})();
