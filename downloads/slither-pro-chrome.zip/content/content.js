/**
 * Slither Pro — Content script (isolated world).
 * Injects mod scripts into the page's MAIN world sequentially and bridges
 * messages between the extension and the injected scripts.
 */
(function () {
  'use strict';

  var SOURCE_TAG = 'slither-pro';
  var HANDSHAKE_TYPE = 'SP_PRIV_HS_a1b7';
  var PRIV_SUB_STATUS = 'SP_SUB_7f3a';

  // Per-page-load nonce for the privileged channel. Generated here in the
  // extension's isolated world and transferred to the MAIN world via
  // MessagePort so page scripts can't see it on the window channel.
  var privilegedNonce = null;
  (function generateNonce() {
    var bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    var hex = '';
    for (var i = 0; i < bytes.length; i++) {
      hex += (bytes[i] < 16 ? '0' : '') + bytes[i].toString(16);
    }
    privilegedNonce = hex;
  })();

  var privilegedChannel = null;
  var privilegedQueue = [];

  function sendPrivileged(type, payload) {
    var msg = { type: type, payload: payload, nonce: privilegedNonce };
    if (!privilegedChannel) {
      privilegedQueue.push(msg);
      return;
    }
    try { privilegedChannel.port1.postMessage(msg); }
    catch (e) { /* port disconnected */ }
  }

  function flushPrivilegedQueue() {
    if (!privilegedChannel) return;
    while (privilegedQueue.length) {
      try { privilegedChannel.port1.postMessage(privilegedQueue.shift()); }
      catch (e) { return; }
    }
  }

  // ─── Script Injection ───────────────────────────────────────
  // Scripts MUST load in this exact order (each depends on earlier ones).
  var SCRIPTS = [
    'shared/settings-schema.js',
    'shared/events.js',
    'inject/utils/constants.js',
    'inject/utils/math.js',
    'inject/utils/message-bus.js',
    'inject/game-api.js',
    'inject/overlay/overlay-manager.js',
    'inject/overlay/grid.js',
    'inject/overlay/hud.js',
    'inject/overlay/minimap.js',
    'inject/overlay/hud-manager.js',
    'inject/overlay/chat-widget.js',
    'inject/overlay/death-recap.js',
    'inject/overlay/debug-overlay.js',
    'inject/mods/zoom.js',
    'inject/mods/skins.js',
    'inject/mods/auras.js',
    'inject/mods/visual-effects.js',
    'inject/mods/food-renderer.js',
    'inject/bot/snake-tracker.js',
    'inject/bot/strategy-manager.js',
    'inject/bot/food-seeker.js',
    'inject/bot/threat-map.js',
    'inject/bot/auto-boost.js',
    'inject/bot/coil-detector.js',
    'inject/bot/bot-controller.js',
    'inject/inject.js'
  ];

  /**
   * Inject scripts sequentially — each waits for the previous to finish
   * loading before the next begins. This guarantees dependency order.
   *
   * After the last script loads, perform the privileged-channel handshake:
   * transfer port2 to the MAIN world so future SUB_STATUS messages can
   * only come from this (isolated-world) content script.
   */
  function injectScripts() {
    var container = document.head || document.documentElement;
    var index = 0;

    function loadNext() {
      if (index >= SCRIPTS.length) {
        performPrivilegedHandshake();
        return;
      }

      var path = SCRIPTS[index];
      var script = document.createElement('script');
      script.src = chrome.runtime.getURL(path);
      script.dataset.slitherPro = 'true';

      script.onload = function () {
        script.remove();
        index++;
        loadNext();
      };

      script.onerror = function () {
        console.error('[SlitherPro] Failed to load: ' + path);
        script.remove();
        // Don't load dependent scripts
      };

      container.appendChild(script);
    }

    loadNext();
  }

  function performPrivilegedHandshake() {
    privilegedChannel = new MessageChannel();
    // Post port2 to the MAIN world. Handshake carries NO secret — the nonce
    // is sent over the port itself (below) so it isn't exposed to any
    // listener on the window channel. message-bus.js has a capture-phase
    // listener registered at script load time and will claim the port.
    window.postMessage(
      { source: SOURCE_TAG, type: HANDSHAKE_TYPE },
      window.location.origin,
      [privilegedChannel.port2]
    );
    // Send the session nonce through the port as the first message.
    privilegedChannel.port1.postMessage({ type: '__init', nonce: privilegedNonce });
    // Flush any privileged messages that queued up while scripts loaded.
    flushPrivilegedQueue();
  }

  // ─── Message Bridge ─────────────────────────────────────────
  // Forward messages from injected script (MAIN world) -> extension
  window.addEventListener('message', function (event) {
    if (event.source !== window) return;
    if (!event.data || event.data.source !== SOURCE_TAG) return;

    var type = event.data.type;
    var payload = event.data.payload;

    // Handle settings request from injected script
    if (type === 'SETTINGS_REQUEST') {
      chrome.storage.sync.get(null, function (items) {
        items = items || {};
        // Convert sp_subscription storage key into a subscription settings category.
        // lastVerifiedAt drives the 24h offline grace window enforced by bot-controller.
        var subData = items.sp_subscription;
        if (subData && subData.active) {
          if (subData.expiresAt && Date.now() > subData.expiresAt) {
            items.subscription = { active: false, lastVerifiedAt: 0 };
          } else {
            items.subscription = {
              active: true,
              lastVerifiedAt: subData.activatedAt || 0
            };
          }
        } else {
          items.subscription = { active: false, lastVerifiedAt: 0 };
        }
        // Remove the raw storage key so it doesn't pollute settings
        delete items.sp_subscription;

        window.postMessage({
          source: SOURCE_TAG,
          type: 'SETTINGS_RESPONSE',
          payload: items
        }, window.location.origin);

        // Also load custom food image from local storage (too large for sync)
        chrome.storage.local.get('sp_food_image', function (localData) {
          if (localData && localData.sp_food_image) {
            window.postMessage({
              source: SOURCE_TAG,
              type: 'FOOD_IMAGE_UPDATE',
              payload: { customImage: localData.sp_food_image }
            }, window.location.origin);
          }
        });
      });
      return;
    }

    // Forward other messages to the service worker
    try {
      chrome.runtime.sendMessage({ type: type, payload: payload });
    } catch (e) {
      // Extension context may have been invalidated
    }
  });

  // Forward messages from extension -> injected script (MAIN world)
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message && message.type) {
      window.postMessage({
        source: SOURCE_TAG,
        type: message.type,
        payload: message.payload
      }, window.location.origin);
    }
  });

  // ─── Subscription Change Listener ───────────────────────────
  // When subscription status changes in storage, notify the inject world
  chrome.storage.onChanged.addListener(function (changes, areaName) {
    if (areaName !== 'sync') return;
    if (changes.sp_subscription) {
      var newVal = changes.sp_subscription.newValue;
      var active = false;
      var lastVerifiedAt = 0;
      if (newVal && newVal.active) {
        if (!newVal.expiresAt || Date.now() <= newVal.expiresAt) {
          active = true;
          lastVerifiedAt = newVal.activatedAt || 0;
        }
      }
      // Privileged channel — routed through MessageChannel + nonce so page
      // scripts cannot forge a SUB_STATUS via window.postMessage.
      sendPrivileged(PRIV_SUB_STATUS, {
        active: active, lastVerifiedAt: lastVerifiedAt
      });
    }
  });

  // ─── Subscription Verification on Page Load ─────────────────
  // v8: Every time slither.io loads, verify subscription with server.
  // v9: Fetch moved to service worker (content script fetch is blocked by page CSP).
  // The service worker sends VERIFY_SUB_RESULT back here.

  function revokeLocalSubscription() {
    chrome.storage.sync.get('sp_subscription', function (data) {
      var subData = data.sp_subscription;
      if (subData) {
        subData.active = false;
        chrome.storage.sync.set({ sp_subscription: subData });
      }
    });
    // Immediately notify inject world so bot stops — privileged channel.
    sendPrivileged(PRIV_SUB_STATUS, { active: false, lastVerifiedAt: 0 });
  }

  function verifySubscriptionOnLoad() {
    // Delegate the actual fetch to the service worker (no CSP restrictions there)
    try {
      chrome.runtime.sendMessage({ type: 'VERIFY_SUBSCRIPTION' });
    } catch (e) { /* extension context invalidated */ }
  }

  // Handle verification result from service worker
  chrome.runtime.onMessage.addListener(function (message) {
    if (message && message.type === 'VERIFY_SUB_RESULT' && !message.valid) {
      revokeLocalSubscription();
    }
  });

  // ─── Bot Integrity Verification ─────────────────────────────
  // Hashes every shipped bot file against the signed integrity manifest
  // baked in at build time. Tampering triggers INTEGRITY_STATUS=fail and
  // the bot refuses to start. Fail-open on network/fetch errors so
  // legitimate offline installs still work.
  function verifyBotIntegrity() {
    var manifestUrl = chrome.runtime.getURL('.slither-pro-integrity.json');

    fetch(manifestUrl).then(function (res) {
      if (!res.ok) throw new Error('manifest ' + res.status);
      return res.json();
    }).then(function (manifest) {
      if (!manifest || !manifest.bot || !manifest.bot.files) {
        throw new Error('manifest malformed');
      }

      var files = manifest.bot.files;
      var names = Object.keys(files).sort();
      var tasks = [];

      for (var i = 0; i < names.length; i++) {
        (function (name) {
          var url = chrome.runtime.getURL('inject/bot/' + name);
          tasks.push(
            fetch(url)
              .then(function (r) { return r.arrayBuffer(); })
              .then(function (buf) { return crypto.subtle.digest('SHA-256', buf); })
              .then(function (digest) {
                var bytes = new Uint8Array(digest);
                var hex = '';
                for (var j = 0; j < bytes.length; j++) {
                  hex += (bytes[j] < 16 ? '0' : '') + bytes[j].toString(16);
                }
                return { name: name, ok: hex === files[name], got: hex, want: files[name] };
              })
          );
        })(names[i]);
      }

      return Promise.all(tasks);
    }).then(function (results) {
      var tampered = [];
      for (var i = 0; i < results.length; i++) {
        if (!results[i].ok) tampered.push(results[i].name);
      }

      var status = tampered.length === 0 ? 'ok' : 'fail';
      window.postMessage({
        source: SOURCE_TAG,
        type: 'SP_INT_b9c1',
        payload: { status: status, tampered: tampered }
      }, window.location.origin);
    }).catch(function () {
      // Fail-open: broadcast a 'skipped' status so bot doesn't wait forever.
      // Network or fetch failures shouldn't break legitimate users.
      window.postMessage({
        source: SOURCE_TAG,
        type: 'SP_INT_b9c1',
        payload: { status: 'skipped' }
      }, window.location.origin);
    });
  }

  // ─── Initialize ─────────────────────────────────────────────
  injectScripts();
  verifySubscriptionOnLoad();
  verifyBotIntegrity();
  /* content script loaded */

})();
