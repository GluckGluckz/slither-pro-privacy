/**
 * Slither Pro -- Bot Controller (v6 — Priority-Tier Commitment).
 *
 * Scored goals compete each frame.  Every scorer runs, returns a
 * score + direction, and the highest score wins.  A gentle safety/border
 * nudge (max 20%) keeps mild threats in play without corrupting direction.
 *
 * Goal scorers:
 *   1. scoreBorderAvoid   — edge repulsion (score up to 20)
 *   2. scoreSafety        — collision / encirclement / giant flee / crowd
 *   3. scoreKillOpportunity — cut-off kill + head trap
 *   4. scoreDeathFood     — dead-snake food bursts
 *   5. scoreFoodCluster   — regular food + wander fallback
 *   6. scoreOffensiveCoil — orbit small targets
 *
 * Priority-tier commitment engine:
 *   Tier 0 (EMERGENCY) — border/safety emergency: always interrupts.
 *   Tier 1 (ACTIVE)    — safety/kill/coil/deathFood/border: only T0 interrupts.
 *   Tier 2 (PASSIVE)   — food/wander: anything can preempt.
 *
 * Boost is decoupled: AutoBoost.shouldBoost(context) receives the chosen
 * goal and decides boost independently.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI;
  var settings = null;
  var _active = false;
  var _autoPlayRetryTimer = null;
  var _wasEnabled = false;
  var _subCTAFired = false;
  // Integrity gate: 'pending' (unknown), 'ok' (verified), 'fail' (tampered),
  // 'skipped' (verification couldn't run). 'fail' is the only blocking state —
  // 'pending' and 'skipped' allow bot to start so offline installs aren't broken.
  var _integrity = 'pending';

  // Offline grace window: subscription must have been server-verified within
  // the last 24h. Beyond that, bot refuses to start and a running bot stops
  // on the next staleness tick. Popup-open and slither.io page-load both
  // trigger a fresh verify, so legitimate online users never hit this.
  var MAX_VERIFY_AGE_MS = 24 * 60 * 60 * 1000;
  var STALENESS_CHECK_INTERVAL_FRAMES = 300; // ~5s at 60fps

  /* ── State machine (tag-based) ─────────────────────────── */
  var STATE = {
    IDLE:       'IDLE',
    FOOD:       'FOOD',
    KILL:       'KILL',
    SAFETY:     'SAFETY',
    BORDER:     'BORDER',
    DEATH_FOOD: 'DEATH_FOOD',
    COIL:       'COIL',
    WANDER:     'WANDER'
  };

  var TAG_TO_STATE = {
    border:    STATE.BORDER,
    safety:    STATE.SAFETY,
    kill:      STATE.KILL,
    deathFood: STATE.DEATH_FOOD,
    food:      STATE.FOOD,
    coil:      STATE.COIL,
    wander:    STATE.WANDER
  };

  var _state = STATE.IDLE;

  /* ── Smooth steering ───────────────────────────────────── */
  var _mouseX = 0;
  var _mouseY = 0;
  var STEER_LERP_NORMAL    = 0.18;
  var STEER_LERP_AVOID     = 0.35;
  var STEER_LERP_EMERGENCY = 0.65;
  var STEER_LERP_KILL      = 0.40;

  /* ── Mouse output range ────────────────────────────────── */
  var MOUSE_RANGE = 400;

  /* ── Goal weight constants ─────────────────────────────── */
  var BORDER_BASE_SCORE       = 20.0;
  var SAFETY_BASE_SCORE       = 4.0;    // v13: was 12.0 — way too high, food/deathfood could never compete
  var KILL_WEIGHT             = 7.0;    // v13: was 5.5 — kills must outscore food to be attempted
  var HEAD_TRAP_WEIGHT        = 6.0;    // v13: was 5.0 — head traps are reliable kills
  var DEATH_FOOD_WEIGHT       = 10.0;   // v13: was 6.0 — dead snake piles are #1 growth source
  var FOOD_WEIGHT             = 1.5;    // v13: was 2.5 — food is fallback, not priority
  var COIL_WEIGHT             = 6.5;    // v9: Coil kills outscore cut-off kills
  var SAFETY_MAG_LOG_DIVISOR  = 1.79;   // v9: ln(6) — magnitude 5.0 maps to 1.0
  var SAFETY_MAG_CAP          = 1.5;    // v9: max normalized magnitude

  /* ── Food score normalization (v10) ────────────────────── */
  var FOOD_LOG_DIVISOR        = 1.0;    // v10: log normalization for food scores
  var FOOD_SCORE_CAP          = 3.0;    // v13: was 4.0 — compress food range so it can't dominate
  var DEATH_FOOD_LOG_DIVISOR  = 1.0;    // v10: log normalization for death food
  var DEATH_FOOD_SCORE_CAP    = 5.0;    // v13: was 3.0 — let death food score much higher

  /* ── Kill safety via ThreatMap (v2 — directional) ─────── */
  var KILL_DIR_THREAT_REJECT  = 0.7;    // reject kill if direction threat exceeds this
  var KILL_DIR_THREAT_DAMPEN  = 0.5;    // dampen score if direction threat exceeds this
  var KILL_DIR_DAMPEN_FACTOR  = 0.5;    // 50% score reduction in dampen zone
  var KILL_CLEAR_BONUS        = 1.25;   // bonus for kills in very clear directions
  var KILL_CLEAR_THRESHOLD    = 0.15;   // directional threat below this = "clear"
  var KILL_PATH_WIDTH         = 140;    // corridor width for ThreatMap.isPathClear

  /* ── Crowd danger (v12) ────────────────────────────────── */
  var CROWD_DANGER_COUNT      = 8;      // v13: was 6 — 6 is normal density. 8+ is truly crowded
  var CROWD_SAFETY_BONUS      = 1.0;    // v13: was 2.0 — let food compete at moderate crowd levels

  /* ── Food threat dampening (v11) ───────────────────────── */
  var FOOD_THREAT_DAMPING     = 0.15;   // v11: Food score reduction per unit avoidance magnitude

  /* ── Priority tiers ──────────────────────────────────────── */
  var TIER_EMERGENCY = 0;    // border emergency, survival mode, giant flee
  var TIER_ACTIVE    = 1;    // safety, kill, coil, death food, border
  var TIER_PASSIVE   = 2;    // food, wander

  /* ── Commitment durations (base frames, ~16ms each) ─────── */
  var COMMIT_KILL       = 20;    // 333ms — stay on intercept course
  var COMMIT_COIL       = 20;    // 333ms — orbit stability
  var COMMIT_DEATH_FOOD = 30;    // v5b: was 12 (200ms). Now 500ms — give bot time to actually reach the pile
  var COMMIT_SAFETY     = 8;     // 133ms — navigate around obstacle
  var COMMIT_BORDER     = 6;     // 100ms — gentle edge correction
  var COMMIT_FOOD       = 6;     // 100ms — re-evaluate often
  var COMMIT_WANDER     = 4;     // 67ms — very flexible
  var COMMIT_EMERGENCY  = 1;     // 17ms — react every frame

  var KILL_COOLDOWN_FRAMES = 15;   // v3c: was 45 — recover faster after interrupted kills

  /* ── Safety / border nudge caps ─────────────────────────── */
  var SAFETY_NUDGE_CAP = 0.20;  // v2: max 20% direction override (was 55%)
  var BORDER_NUDGE_CAP = 0.20;  // v2: max 20% direction override (was 85%)

  /* ── Giant avoidance ───────────────────────────────────── */
  var GIANT_FLEE_SCORE        = 16.0;   // v11: Stronger giant flee (was 14.0)
  var DANGER_RADIUS           = 550;    // v11: Detect giants further (was 400)

  /* ── Death food ────────────────────────────────────────── */
  var DEATH_FOOD_RADIUS       = 1200;  // v4d: was 800. View range ~1000, go for visible piles

  /* ── Map edge avoidance thresholds ────────────────────��── */
  var EDGE_GENTLE_DIST    = 1400;
  var EDGE_STRONG_DIST    = 700;
  var EDGE_EMERGENCY_DIST = 350;
  var WALL_EMERGENCY_FRAMES = 30;   // v9: Velocity-aware emergency (0.5s at 60fps)
  var WALL_STRONG_FRAMES    = 90;   // v9: Velocity-aware strong avoidance (1.5s)

  /* ── Anti-circling (v11) ────────────────────────────────── */
  var CIRCLE_CHECK_INTERVAL = 90;     // v11: Compare position every 90 frames (1.5s)
  var CIRCLE_MIN_TRAVEL     = 200;    // v11: Must travel at least 200 units per interval
  var _posHistory = [];               // v11: Recent position snapshots [{x,y,frame}]
  var _isCircling = false;
  var _circleBreakAngle = 0;          // v11: Forced straight-line angle when circling

  /* ── Threat memory ─────────────────────────────────────── */
  var THREAT_MEMORY_SIZE   = 10;
  var THREAT_MEMORY_DECAY  = 40;
  var THREAT_MEMORY_RADIUS = 500;
  var _threatMemory = [];

  /* ── Safety stuck detection (v12) ────────────────────────── */
  var _consecutiveSafetyFrames = 0;     // v12: Track how long we've been stuck in safety
  var SAFETY_STUCK_FRAMES     = 10;     // v13: was 5 — too aggressive, wasted boost. 10 frames = 167ms
  var SAFETY_STUCK_MIN_MAG    = 2.5;    // v13: was 1.0 — only stuck-boost for real squeeze danger

  /* ── Coil cooldown (v12) ─────────────────────────────────── */
  var COIL_COOLDOWN_FRAMES    = 90;     // v12: 1.5s cooldown after coil aborted by safety
  var _coilCooldown           = 0;      // v12: Frames remaining before coil can re-engage

  /* ── Unified heading commitment ────────────────────────── */
  var _lockedTag       = '';
  var _lockedTier      = TIER_PASSIVE;
  var _commitTicksLeft = 0;

  /* v4: Sticky commitment — persist direction when goal scorer returns null.
   * Kill/coil/deathFood targets are transient (in/out of detection range).
   * Instead of breaking commitment when the scorer returns null, continue
   * with the last known direction until timer expires or EMERGENCY interrupts. */
  var _commitDirX      = 0;
  var _commitDirY      = 0;
  var _commitLerpRate  = STEER_LERP_NORMAL;
  var _commitBoost     = false;
  var _killCooldown    = 0;

  var _frameCounter = 0;

  var BotController = {

    init: function (s) {
      GameAPI = SP.GameAPI;
      settings = s;
      _wasEnabled = !!(s && s.bot && s.bot.enabled);

      // Integrity gate: content script posts result after hashing bot files.
      if (SP.MessageBus && SP.EVENTS && SP.EVENTS.INTEGRITY_STATUS) {
        SP.MessageBus.on(SP.EVENTS.INTEGRITY_STATUS, function (payload) {
          if (!payload || !payload.status) return;
          _integrity = payload.status;
          if (payload.status === 'fail' && _active) {
            _active = false;
            if (GameAPI) GameAPI.setBoost(false);
          }
        });
      }

      // Initialize sub-modules
      if (SP.SnakeTracker && SP.SnakeTracker.init) SP.SnakeTracker.init();
      if (SP.StrategyManager && SP.StrategyManager.init) SP.StrategyManager.init(s);
      if (SP.CoilDetector && SP.CoilDetector.init) SP.CoilDetector.init(s);
    },

    updateSettings: function (s) {
      settings = s;
      var nowEnabled = !!(settings && settings.bot && settings.bot.enabled);

      if (nowEnabled && !_active) {
        this.start();
      }
      if (!nowEnabled && _active) {
        this.stop();
      }
      _wasEnabled = nowEnabled;

      if (SP.StrategyManager && SP.StrategyManager.updateSettings) {
        SP.StrategyManager.updateSettings(s);
      }
      if (SP.CoilDetector && SP.CoilDetector.updateSettings) {
        SP.CoilDetector.updateSettings(s);
      }

      // v8: Input lock toggle
      if (GameAPI) {
        if (_active && s.bot && s.bot.inputLock) {
          GameAPI.blockUserInput();
        } else {
          GameAPI.unblockUserInput();
        }
      }
    },

    start: function () {
      _subCTAFired = false; // Allow CTA on new attempt
      // Subscription gate — refuse to start without valid subscription
      if (!settings || !settings.subscription || !settings.subscription.active) {
        _active = false;
        return false;
      }
      // Freshness gate — reject stale verifications (offline > 24h).
      // lastVerifiedAt === 0 means we never received a fresh timestamp; treat
      // as stale so offline bypass via storage manipulation is caught.
      var lastVerified = settings.subscription.lastVerifiedAt || 0;
      if (!lastVerified || (Date.now() - lastVerified) > MAX_VERIFY_AGE_MS) {
        _active = false;
        return false;
      }
      // Integrity gate — refuse to start if bot files were tampered.
      // 'pending' and 'skipped' are allowed (offline / slow verify); only
      // a confirmed 'fail' blocks.
      if (_integrity === 'fail') {
        _active = false;
        return false;
      }
      _active = true;
      _state = STATE.FOOD;
      _mouseX = 0;
      _mouseY = 0;
      _lockedTag = '';
      _lockedTier = TIER_PASSIVE;
      _commitTicksLeft = 0;
      _commitDirX = 0;
      _commitDirY = 0;
      _commitBoost = false;
      _killCooldown = 0;
      _threatMemory = [];
      _frameCounter = 0;
      _posHistory = [];
      _isCircling = false;
      _circleBreakAngle = 0;
      _consecutiveSafetyFrames = 0;
      _coilCooldown = 0;

      if (SP.AutoBoost && SP.AutoBoost.reset) SP.AutoBoost.reset();
      if (SP.FoodSeeker && SP.FoodSeeker.resetWaypoints) SP.FoodSeeker.resetWaypoints();
      if (SP.SnakeTracker && SP.SnakeTracker.reset) SP.SnakeTracker.reset();
      if (SP.StrategyManager && SP.StrategyManager.reset) SP.StrategyManager.reset();
      if (SP.CoilDetector && SP.CoilDetector.reset) SP.CoilDetector.reset();

      // v8: Input lock — block user mouse when bot starts
      if (settings && settings.bot && settings.bot.inputLock && GameAPI) {
        GameAPI.blockUserInput();
      }
      return true;
    },

    stop: function () {
      _active = false;
      _state = STATE.IDLE;
      if (GameAPI) GameAPI.setBoost(false);
      // v8: Always unblock input when bot stops
      if (GameAPI) GameAPI.unblockUserInput();
      if (_autoPlayRetryTimer) {
        clearTimeout(_autoPlayRetryTimer);
        _autoPlayRetryTimer = null;
      }
    },

    isActive: function () { return _active; },
    getState: function () { return _state; },

    /* ══════════════════════════════════════════════════════════
     *  Main update — called each frame
     * ══════════════════════════════════════════════════════════ */
    update: function () {
      if (!_active || !settings || !settings.bot || !settings.bot.enabled) return;
      // v8: Subscription check — auto-stop + CTA if somehow active without subscription
      if (!settings.subscription || !settings.subscription.active) {
        _active = false;
        settings.bot.enabled = false;
        if (GameAPI) {
          GameAPI.setBoost(false);
          GameAPI.unblockUserInput();
        }
        // Rate-limited CTA (toast + chat) — only fire once per activation attempt
        if (!_subCTAFired) {
          _subCTAFired = true;
          var _toast = document.querySelector('.slither-pro-toast');
          if (!_toast) {
            _toast = document.createElement('div');
            _toast.className = 'slither-pro-toast';
            document.body.appendChild(_toast);
          }
          var _t = document.createElement('div');
          _t.className = 'slither-pro-toast-item';
          _t.textContent = 'Pro subscription required';
          _toast.appendChild(_t);
          setTimeout(function () {
            _t.classList.add('sp-toast-fade-out');
            setTimeout(function () { if (_t.parentNode) _t.parentNode.removeChild(_t); }, 300);
          }, 2000);
          if (SP.ChatWidget && SP.ChatWidget._addSystemMsg) {
            SP.ChatWidget._addSystemMsg('AI Bot requires a Pro subscription ($2.99/mo). Open the extension popup to subscribe.');
          }
        }
        return;
      }
      _subCTAFired = false; // Reset so next invalid attempt shows CTA again

      _frameCounter++;
      // Periodic staleness check — if the last server verification is older
      // than MAX_VERIFY_AGE_MS, stop the bot even if `active` is still true
      // in local storage. Catches offline-cache bypass + stale-tab abuse.
      if (_frameCounter % STALENESS_CHECK_INTERVAL_FRAMES === 0) {
        var lastVerified = settings.subscription.lastVerifiedAt || 0;
        if (!lastVerified || (Date.now() - lastVerified) > MAX_VERIFY_AGE_MS) {
          _active = false;
          settings.bot.enabled = false;
          if (GameAPI) {
            GameAPI.setBoost(false);
            GameAPI.unblockUserInput();
          }
          if (SP.ChatWidget && SP.ChatWidget._addSystemMsg) {
            SP.ChatWidget._addSystemMsg('Subscription needs a refresh — open the extension popup while online to keep the bot running.');
          }
          return;
        }
      }
      if (_killCooldown > 0) _killCooldown--;
      if (_coilCooldown > 0) _coilCooldown--;

      // AutoPlay
      if (!GameAPI.isPlaying()) {
        if (settings.bot.autoPlay) {
          this._tryAutoPlay();
        }
        return;
      }

      var playerSnake = GameAPI.getPlayerSnake();
      var playerPos = GameAPI.getPlayerPosition();
      if (!playerSnake || !playerPos) return;

      var nearbySnakes = GameAPI.getNearbySnakes();
      var foods = GameAPI.getFoods();
      var mapRadius = GameAPI.getMapRadius();

      var avoidanceRadius = 200;    // v2: base value, mode scales via avoidanceRadiusMult
      var foodSearchRadius = 600;  // v2: base value, mode scales via foodSearchRadiusMult

      var Strategy = SP.StrategyManager;
      var params = null;
      if (Strategy) {
        params = Strategy.getParams();
        if (params) {
          if (params.avoidanceRadiusScale) {
            avoidanceRadius *= params.avoidanceRadiusScale;
          }
          if (params.foodSearchRadiusScale) {
            foodSearchRadius *= params.foodSearchRadiusScale;
          }
        }
      }

      // v10: Boost-aware avoidance — scan further when moving fast
      if (playerSnake.speed && playerSnake.speed > 10) {
        avoidanceRadius *= (1.0 + (playerSnake.speed - 10) * 0.05);
      }

      /* ── Step 1: SnakeTracker update ───────────────────────── */
      if (SP.SnakeTracker && SP.SnakeTracker.update) {
        SP.SnakeTracker.update(nearbySnakes, playerPos.x, playerPos.y, _frameCounter);
      }

      /* ── Step 2: StrategyManager update ────────────────────── */
      if (Strategy && Strategy.update) {
        var trackedAll = SP.SnakeTracker ? SP.SnakeTracker.getAllTracked() : [];
        var foodBursts = SP.SnakeTracker ? SP.SnakeTracker.getFoodBursts() : [];
        Strategy.update(playerSnake, trackedAll, foodBursts);
        params = Strategy.getParams(); // refresh after update
      }

      /* ── Step 2b: Anti-circling detection (v11) ────────────── */
      if (_frameCounter % 15 === 0) {  // Sample every 15 frames (4x/sec)
        _posHistory.push({ x: playerPos.x, y: playerPos.y, frame: _frameCounter });
        if (_posHistory.length > 8) _posHistory.shift();  // Keep last ~2 seconds
      }
      if (_posHistory.length >= 6) {
        var oldest = _posHistory[0];
        var traveled = SP.MathUtil.distance(oldest.x, oldest.y, playerPos.x, playerPos.y);
        var elapsed = _frameCounter - oldest.frame;
        if (elapsed > CIRCLE_CHECK_INTERVAL && traveled < CIRCLE_MIN_TRAVEL) {
          if (!_isCircling) {
            // Pick a break-out angle: toward map center with some randomness
            var centerX = mapRadius;
            var centerY = mapRadius;
            _circleBreakAngle = SP.MathUtil.angle(playerPos.x, playerPos.y, centerX, centerY);
            _circleBreakAngle += (Math.random() - 0.5) * 1.0;  // ±0.5 rad jitter
            _isCircling = true;
          }
        } else {
          _isCircling = false;
        }
      }

      /* ── Step 3: Collision avoidance ───────────────────────── */
      var avoidance = null;
      if (settings.bot.collisionAvoidance && SP.CollisionAvoidance) {
        avoidance = SP.CollisionAvoidance.computeAvoidance(
          playerSnake, nearbySnakes, avoidanceRadius
        );
      }

      /* ���─ Step 4: CoilDetector update ───────────────────────── */
      var coilResult = { defensive: null, offensive: null };
      if (SP.CoilDetector && SP.CoilDetector.update) {
        coilResult = SP.CoilDetector.update(
          playerSnake, nearbySnakes, avoidance, _frameCounter
        );
      }

      /* ── Step 5: Food target ───────────────────────────────── */
      var foodTarget = null;
      if (settings.bot.foodSeeker && SP.FoodSeeker) {
        // v9: Pass player speed so FoodSeeker can compute TOD
        // v11: Pass player angle so FoodSeeker can compute forward bias
        // v12: Create copy to avoid mutating shared GameAPI.getPlayerPosition() object
        var foodPos = {
          x: playerPos.x, y: playerPos.y,
          speed: playerSnake.speed || 8,
          angle: playerSnake.angle || 0
        };
        foodTarget = SP.FoodSeeker.findTarget(
          foodPos, foods, foodSearchRadius, nearbySnakes, mapRadius
        );
      }

      /* ── Step 6: Edge avoidance (graduated) ────────────────── */
      var edgeResult = this._computeEdgeAvoidance(playerPos, mapRadius, playerSnake);

      /* ── Step 7: Run all goal scorers ──────────────────────── */
      var candidates = [];
      var borderGoal = this._scoreBorderAvoid(edgeResult);
      var safetyGoal = this._scoreSafety(playerSnake, avoidance, coilResult, params, playerPos, nearbySnakes);
      var killGoal   = this._scoreKillOpportunity(playerSnake, nearbySnakes, params, avoidance, edgeResult);
      var deathGoal  = this._scoreDeathFood(playerPos, params, nearbySnakes, mapRadius);
      var foodGoal   = this._scoreFoodCluster(playerPos, playerSnake, foodTarget, edgeResult, params, mapRadius, avoidance);
      var coilGoal   = this._scoreOffensiveCoil(playerPos, coilResult, edgeResult, params);

      if (borderGoal) candidates.push(borderGoal);
      if (safetyGoal) candidates.push(safetyGoal);
      if (killGoal)   candidates.push(killGoal);
      if (deathGoal)  candidates.push(deathGoal);
      if (foodGoal)   candidates.push(foodGoal);
      if (coilGoal)   candidates.push(coilGoal);

      /* ── Step 8: Heading commitment + hybrid selection ─────── */
      var chosen = this._evaluateGoals(candidates, safetyGoal, borderGoal, avoidance, params);

      /* ── Debug: report goal scores ─────────────────────────── */
      if (SP.Debug && SP.Debug.reportGoals) {
        SP.Debug.reportGoals({
          border:    borderGoal ? { score: borderGoal.score, tag: 'border' } : { score: 0, tag: 'border' },
          safety:    safetyGoal ? { score: safetyGoal.score, tag: 'safety' } : { score: 0, tag: 'safety' },
          kill:      killGoal   ? { score: killGoal.score,   tag: 'kill' }   : { score: 0, tag: 'kill' },
          deathFood: deathGoal  ? { score: deathGoal.score,  tag: 'deathFood' } : { score: 0, tag: 'deathFood' },
          food:      foodGoal   ? { score: foodGoal.score,   tag: 'food' }   : { score: 0, tag: 'food' },
          coil:      coilGoal   ? { score: coilGoal.score,   tag: 'coil' }   : { score: 0, tag: 'coil' }
        }, {
          tag: chosen.tag,
          dirX: chosen.dirX,             // v10: for trajectory drawing
          dirY: chosen.dirY,
          lockedTag: _lockedTag,
          commitLeft: _commitTicksLeft,
          avoidMag: avoidance ? avoidance.magnitude : 0,
          avoidX: avoidance ? avoidance.x : 0,  // v10: avoidance direction
          avoidY: avoidance ? avoidance.y : 0,
          emergency: avoidance ? !!avoidance.emergency : false
        });
        SP.Debug.reportCoil(coilResult);
        SP.Debug.reportFood(foodTarget);
        SP.Debug.reportEdge(edgeResult);
      }

      /* ── Step 8b: Forward collision gate (v3 — head-on detector) ─── */
      // Two-layer protection, independent of safety score:
      // Layer 0: Body proximity emergency — runs ALWAYS (even during safety/border).
      // v5c: Aggregates repulsion from ALL body parts within lethal range (not just
      // the single closest). Deaths 2-3 showed the bot oscillating between two body
      // walls because single-point escape pushed it toward the other side each frame.
      // Aggregating forces finds the GAP between walls.
      var overrideDir = null;
      if (nearbySnakes) {
        var proxDist = 25;
        var proxDistSq = proxDist * proxDist;
        var proxForceX = 0, proxForceY = 0;
        var proxHitCount = 0;

        for (var pi = 0; pi < nearbySnakes.length; pi++) {
          var pSnake = nearbySnakes[pi];
          if (!pSnake || !pSnake.bodyParts) continue;
          for (var pj = 0; pj < pSnake.bodyParts.length; pj += 2) {
            var pPart = pSnake.bodyParts[pj];
            if (!pPart) continue;
            var pdx = pPart.x - playerSnake.x;
            var pdy = pPart.y - playerSnake.y;
            var pdSq = pdx * pdx + pdy * pdy;
            if (pdSq < proxDistSq && pdSq > 1) {
              // Repulsion force: inverse-square, pointing AWAY from body part
              var pInvSq = 1.0 / pdSq;
              var pMag = Math.sqrt(pdSq);
              proxForceX += (-pdx / pMag) * pInvSq;
              proxForceY += (-pdy / pMag) * pInvSq;
              proxHitCount++;
            }
          }
          // Also check head proximity (non-kill-target)
          var isKillTgt = (chosen.tag === 'kill' || chosen.tag === 'coil') && chosen.meta && chosen.meta.targetId === pSnake.id;
          if (!isKillTgt) {
            var phdx = pSnake.x - playerSnake.x;
            var phdy = pSnake.y - playerSnake.y;
            var phdSq = phdx * phdx + phdy * phdy;
            if (phdSq < proxDistSq && phdSq > 1) {
              var phInvSq = 1.0 / phdSq;
              var phMag = Math.sqrt(phdSq);
              proxForceX += (-phdx / phMag) * phInvSq;
              proxForceY += (-phdy / phMag) * phInvSq;
              proxHitCount++;
            }
          }
        }

        if (proxHitCount > 0) {
          // Normalize the aggregate escape vector
          var proxForceMag = Math.sqrt(proxForceX * proxForceX + proxForceY * proxForceY);
          if (proxForceMag > 0.001) {
            overrideDir = {
              dirX: proxForceX / proxForceMag,
              dirY: proxForceY / proxForceMag,
              lerpRate: STEER_LERP_EMERGENCY,
              commitMin: COMMIT_EMERGENCY,
              meta: { bodyProximity: true, proxHits: proxHitCount }
            };
          }
        }
      }

      // Layers 1–3: Head-on, crossing, corridor scan, kill abort
      // v5c: Allow Layers 1–3 to run even when Layer 0 fired (bodyProximity).
      // Death analysis: head closing at 10 units/frame from 61→5, Layer 0 fired
      // for body at 24 units and BLOCKED Layer 1 from detecting the head-on.
      // Body proximity is dangerous but head-on is MORE dangerous — let Layer 1
      // override Layer 0 when a head collision is imminent.
      var layer0Fired = overrideDir && overrideDir.meta && overrideDir.meta.bodyProximity;
      if ((!overrideDir || layer0Fired) && chosen.tag !== 'safety' && chosen.tag !== 'border') {

        // Layer 1: Head-on approach detector — most dangerous, react immediately
        // v4c: Skip if the approaching head IS our kill/coil target.
        // During kill pursuit we WANT to approach the target — the detector
        // would abort every kill right when it's about to connect.
        var headOn = this._findApproachingHead(playerSnake, nearbySnakes);
        if (headOn) {
          var isKillTarget = false;
          if ((chosen.tag === 'kill' || chosen.tag === 'coil') && chosen.meta && headOn.enemy) {
            isKillTarget = (chosen.meta.targetId === headOn.enemy.id);
          }

          if (!isKillTarget) {
            var escLeft = headOn.escapeAngle;
            var escRight = headOn.escapeAngle - Math.PI;
            var TM = SP.ThreatMap;
            var leftThreat = TM ? TM.getDirectionThreat(escLeft) : 0;
            var rightThreat = TM ? TM.getDirectionThreat(escRight) : 0;
            var escAngle = leftThreat <= rightThreat ? escLeft : escRight;

            overrideDir = {
              dirX: Math.cos(escAngle),
              dirY: Math.sin(escAngle),
              lerpRate: STEER_LERP_EMERGENCY,
              commitMin: COMMIT_EMERGENCY,
              meta: { headOnEscape: true }
            };
          }
        }

        // Layer 1b: v5c — Crossing path detector (perpendicular interceptions).
        // _findApproachingHead only catches head-on. Perpendicular crossings
        // (enemy cuts across our path at ~90°) are the #1 reported death cause.
        // This runs for ALL goals including kill/coil (with target exception).
        // v5c: Also run if only Layer 0 (body proximity) fired — crossing is more urgent.
        if (!overrideDir || layer0Fired) {
          var crossing = this._findCrossingPath(playerSnake, nearbySnakes);
          if (crossing) {
            var isCrossKillTarget = false;
            if ((chosen.tag === 'kill' || chosen.tag === 'coil') && chosen.meta && crossing.enemy) {
              isCrossKillTarget = (chosen.meta.targetId === crossing.enemy.id);
            }

            if (!isCrossKillTarget) {
              // Use escape angle, but verify with ThreatMap for safer side
              var cEscLeft = crossing.escapeAngle;
              var cEscRight = crossing.escapeAngle + Math.PI;
              var TMc = SP.ThreatMap;
              var cLeftThreat = TMc ? TMc.getDirectionThreat(cEscLeft) : 0;
              var cRightThreat = TMc ? TMc.getDirectionThreat(cEscRight) : 0;
              var cEscAngle = cLeftThreat <= cRightThreat ? cEscLeft : cEscRight;

              // Urgency scales with time to crossing — under 10 frames = emergency
              var crossUrgent = crossing.ourFrames <= 10;
              overrideDir = {
                dirX: Math.cos(cEscAngle),
                dirY: Math.sin(cEscAngle),
                lerpRate: crossUrgent ? STEER_LERP_EMERGENCY : STEER_LERP_AVOID,
                commitMin: crossUrgent ? COMMIT_EMERGENCY : COMMIT_SAFETY,
                meta: { crossingEscape: true, crossFrames: crossing.ourFrames }
              };
            }
          }
        }

        // Layer 2: Forward corridor scan (body walls, slower threats)
        // v4e: Skip during kill/coil — deflection approach caused more deaths.
        // The kill scorer already checks path safety via ThreatMap.
        if (!overrideDir && chosen.tag !== 'kill' && chosen.tag !== 'coil' &&
            SP.CollisionAvoidance && SP.CollisionAvoidance.scanForward) {
          // v5b: Scan BOTH chosen direction AND actual heading.
          // Bot mid-turn might be aimed differently from chosen direction.
          var fwdAngle = Math.atan2(chosen.dirY, chosen.dirX);
          var actualAngle = playerSnake.angle || fwdAngle;
          var fwdHits = SP.CollisionAvoidance.scanForward(
            playerSnake.x, playerSnake.y, fwdAngle,
            nearbySnakes, 300, 120
          );
          // v5b: Also scan actual heading if different from chosen
          var angDiff = fwdAngle - actualAngle;
          while (angDiff > Math.PI) angDiff -= Math.PI * 2;
          while (angDiff < -Math.PI) angDiff += Math.PI * 2;
          if (Math.abs(angDiff) > 0.15 && fwdHits === 0) {
            fwdHits = SP.CollisionAvoidance.scanForward(
              playerSnake.x, playerSnake.y, actualAngle,
              nearbySnakes, 250, 100
            );
          }

          if (fwdHits > 0) {
            // v5b: Escalate response based on density of body parts ahead.
            // fwdHits >= 3 = dense body wall (head-cut, crossing snake) → emergency steer
            // fwdHits 1-2 = sparse (tail end, single segment) → avoid steer
            var fwdIsEmergency = fwdHits >= 3;
            var fwdLerp = fwdIsEmergency ? STEER_LERP_EMERGENCY : STEER_LERP_AVOID;
            var fwdCommit = fwdIsEmergency ? COMMIT_EMERGENCY : COMMIT_SAFETY;

            // v5b: Fallback when safetyGoal is null — compute perpendicular escape.
            // Previously the abort was silently skipped when no safety direction existed,
            // causing the bot to plow straight into tail ends in low-threat areas.
            if (safetyGoal && safetyGoal.dirX !== undefined) {
              overrideDir = {
                dirX: safetyGoal.dirX,
                dirY: safetyGoal.dirY,
                lerpRate: fwdLerp,
                commitMin: fwdCommit,
                meta: safetyGoal.meta || {}
              };
            } else {
              // No safety direction available — dodge perpendicular to heading.
              // Pick the side with less threat (use ThreatMap if available).
              var dodgeAng = actualAngle + Math.PI * 0.5;
              var dodgeAngAlt = actualAngle - Math.PI * 0.5;
              var TM2 = SP.ThreatMap;
              if (TM2 && TM2.getDirectionThreat) {
                var leftT = TM2.getDirectionThreat(dodgeAng);
                var rightT = TM2.getDirectionThreat(dodgeAngAlt);
                if (rightT < leftT) dodgeAng = dodgeAngAlt;
              }
              overrideDir = {
                dirX: Math.cos(dodgeAng),
                dirY: Math.sin(dodgeAng),
                lerpRate: fwdLerp,
                commitMin: fwdCommit,
                meta: { fwdDodge: true }
              };
            }
          }
        }

        // Layer 3: v5 — Imminent collision abort for kill/coil.
        // Unlike the reverted scanForward (wide corridor + deflection which caused
        // MORE deaths by deflecting into other snakes), this uses a narrow cone
        // (60 units wide, 120 deep) and ABORTS to safety instead of deflecting.
        if (!overrideDir && (chosen.tag === 'kill' || chosen.tag === 'coil')) {
          var killTargetId = (chosen.meta && chosen.meta.targetId) ? chosen.meta.targetId : null;
          if (this._checkImminentCollision(playerSnake, nearbySnakes, killTargetId)) {
            var abortDirX, abortDirY;
            if (safetyGoal && safetyGoal.dirX !== undefined) {
              abortDirX = safetyGoal.dirX;
              abortDirY = safetyGoal.dirY;
            } else {
              // Perpendicular escape from current heading
              var perpAng = (playerSnake.angle || 0) + Math.PI * 0.5;
              abortDirX = Math.cos(perpAng);
              abortDirY = Math.sin(perpAng);
            }
            overrideDir = {
              dirX: abortDirX,
              dirY: abortDirY,
              lerpRate: STEER_LERP_EMERGENCY,
              commitMin: COMMIT_SAFETY,
              meta: { killAbort: true }
            };
          }
        }

      } // close Layers 1–3 gate

      // Apply override (from ANY layer including Layer 0 body proximity)
      if (overrideDir) {
        var prevTag = chosen.tag;
        if (prevTag === 'coil') {
          _coilCooldown = COIL_COOLDOWN_FRAMES;
          if (SP.CoilDetector && SP.CoilDetector.abortCoilAttack) {
            SP.CoilDetector.abortCoilAttack();
          }
        }
        // v3: Use shorter cooldown for kill override — 20 frames instead of 45
        // The old 45-frame cooldown meant no kills for 0.75s after every blocked attempt
        if (prevTag === 'kill') {
          _killCooldown = 20;
        }
        chosen = {
          dirX: overrideDir.dirX,
          dirY: overrideDir.dirY,
          lerpRate: overrideDir.lerpRate,
          boost: false,
          tag: 'safety',
          commitMin: overrideDir.commitMin,
          meta: overrideDir.meta,
          score: safetyGoal ? safetyGoal.score : 1.0
        };
        _commitTicksLeft = 0;
        _lockedTag = 'safety';
      }

      /* ── Step 9: Apply state ───────────────────────────────── */
      _state = TAG_TO_STATE[chosen.tag] || STATE.IDLE;

      /* ── Step 9b: Safety stuck detection (v12) ────────────── */
      // Track consecutive safety frames. If stuck in safety for 5+ updates
      // with real avoidance vectors, force boost — steering alone isn't enough.
      // This catches gradual squeezes where magnitude stays in 1-3 range
      // (too low for safety_escape threshold but still lethal).
      if (chosen.tag === 'safety' && avoidance && avoidance.magnitude > SAFETY_STUCK_MIN_MAG) {
        _consecutiveSafetyFrames++;
        if (_consecutiveSafetyFrames >= SAFETY_STUCK_FRAMES) {
          chosen.boost = true;
          if (!chosen.meta) chosen.meta = {};
          chosen.meta.stuckEscape = true;
        }
      } else {
        _consecutiveSafetyFrames = 0;
      }

      /* ── Step 10: Decoupled boost ──────────────────────────── */
      var boostOn = false;
      if (settings.bot.autoBoost && SP.AutoBoost) {
        var boostResult = SP.AutoBoost.shouldBoost({
          playerSnake: playerSnake,
          nearbySnakes: nearbySnakes,
          chosenGoal: chosen,
          avoidance: avoidance,
          mapRadius: mapRadius,
          params: params
        });
        boostOn = boostResult.boost;
        if (SP.Debug && SP.Debug.reportBoost) {
          SP.Debug.reportBoost({ active: boostOn, reason: boostResult.reason });
        }
      }
      GameAPI.setBoost(boostOn);

      /* ── Step 11: Smooth steering (lerp mouse position) ────── */
      var targetX = chosen.dirX * MOUSE_RANGE;
      var targetY = chosen.dirY * MOUSE_RANGE;
      _mouseX = this._lerp(_mouseX, targetX, chosen.lerpRate);
      _mouseY = this._lerp(_mouseY, targetY, chosen.lerpRate);
      GameAPI.setMousePosition(_mouseX, _mouseY);

      /* ── Step 12: Decay threat memory ──────────────────────── */
      this._decayThreatMemory();
    },

    /* ══════════════════════════════════════════════════════════
     *  Goal Scorers
     * ══════════════════════════════════════════════════════════ */

    /**
     * 1. Border avoidance — wraps _computeEdgeAvoidance.
     */
    _scoreBorderAvoid: function (edgeResult) {
      if (!edgeResult || edgeResult.strength <= 0) return null;

      var score = edgeResult.strength * BORDER_BASE_SCORE;
      // Normalize edge direction
      var emag = Math.sqrt(edgeResult.x * edgeResult.x + edgeResult.y * edgeResult.y);
      var dx = emag > 0 ? edgeResult.x / emag : 0;
      var dy = emag > 0 ? edgeResult.y / emag : 0;

      return {
        score: score,
        dirX: dx,
        dirY: dy,
        lerpRate: edgeResult.emergency ? STEER_LERP_EMERGENCY : STEER_LERP_AVOID,
        boost: false,
        tag: 'border',
        commitMin: edgeResult.emergency ? COMMIT_EMERGENCY : COMMIT_BORDER,
        meta: { emergency: edgeResult.emergency, strength: edgeResult.strength }
      };
    },

    /**
     * 2. Safety — collision avoidance, encirclement, giant flee.
     */
    _scoreSafety: function (playerSnake, avoidance, coilResult, params, playerPos, nearbySnakes) {
      var MathUtil = SP.MathUtil;
      var bestScore = 0;
      var dirX = 0;
      var dirY = 0;
      var lerpRate = STEER_LERP_AVOID;
      var wantBoost = false;
      var commitMin = COMMIT_SAFETY;
      var meta = { giantFlee: false, encirclement: false, survivalMode: false };

      // --- Collision avoidance score ---
      // v3: Mode-aware threshold — aggressive ignores low-mag traffic, defensive reacts earlier
      var safetyMagThreshold = (params && params.safetyMagThreshold != null) ? params.safetyMagThreshold : 5.0;
      if (avoidance && avoidance.magnitude > safetyMagThreshold) {
        // v9: Normalize raw magnitude (can be 0-200+) to 0-1.5 range via log scale
        // mag 0.5→score 3, mag 1→5, mag 2→8, mag 5→12, mag 10+→capped at 18
        var normalizedMag = Math.min(SAFETY_MAG_CAP, Math.log(1 + avoidance.magnitude) / SAFETY_MAG_LOG_DIVISOR);
        var avoidScore = normalizedMag * SAFETY_BASE_SCORE;
        if (avoidance.emergency) {
          avoidScore *= 4.0;  // v13: was 1.5 — with lower base score, emergency needs stronger mult
          lerpRate = STEER_LERP_EMERGENCY;
          wantBoost = true;
        }

        // v13: Boost only for genuine squeeze danger. Was 3.0, but avg game mag is ~14.
        // Magnitude 15+ means body parts are truly close and closing.
        if (!wantBoost && avoidance.magnitude > 15.0) {
          wantBoost = true;
          lerpRate = STEER_LERP_AVOID;
        }

        // v13: Emergency steering at high magnitude (was 12.0, but avg is 14)
        if (avoidance.magnitude > 25.0) {
          lerpRate = STEER_LERP_EMERGENCY;
        }

        if (avoidScore > bestScore) {
          bestScore = avoidScore;
          // Adjust for threat memory
          var adjusted = this._adjustForThreatMemory(avoidance.x, avoidance.y, playerPos);
          var amag = Math.sqrt(adjusted.x * adjusted.x + adjusted.y * adjusted.y);
          dirX = amag > 0 ? adjusted.x / amag : avoidance.x;
          dirY = amag > 0 ? adjusted.y / amag : avoidance.y;
          // Dynamic commit: higher threat = longer hold, mode-scaled
          var safeCommitMult = (params && params.safetyCommitMult) ? params.safetyCommitMult : 1;
          commitMin = Math.round(
            (COMMIT_SAFETY + 12 * Math.min(1, avoidance.magnitude / 25.0)) * safeCommitMult
          );
        }

        // Record threat for memory
        if (avoidance.magnitude > 3.0) {  // v13: was 0.4 — only real threats
          this._recordThreat(playerPos);
        }
      }

      // --- v11: Crowd danger — too many snakes nearby = unsafe area ---
      if (nearbySnakes && nearbySnakes.length >= CROWD_DANGER_COUNT) {
        var crowdScore = CROWD_SAFETY_BONUS + (nearbySnakes.length - CROWD_DANGER_COUNT) * 0.8;
        if (crowdScore > bestScore && !dirX && !dirY) {
          // Steer away from centroid of nearby snake heads
          var centX = 0;
          var centY = 0;
          var centCount = 0;
          for (var ci = 0; ci < nearbySnakes.length; ci++) {
            if (nearbySnakes[ci]) {
              centX += nearbySnakes[ci].x;
              centY += nearbySnakes[ci].y;
              centCount++;
            }
          }
          if (centCount > 0) {
            centX /= centCount;
            centY /= centCount;
            var cdx = playerPos.x - centX;
            var cdy = playerPos.y - centY;
            var cMag = Math.sqrt(cdx * cdx + cdy * cdy);
            if (cMag > 0) {
              dirX = cdx / cMag;
              dirY = cdy / cMag;
            }
          }
        }
        // Only take over if we actually set a direction (or had one from avoidance)
        if (crowdScore > bestScore && (dirX || dirY)) {
          bestScore = crowdScore;
          // v12: Don't boost for crowd — steer away but conserve length.
          // Boosting in crowds wastes food for no survival benefit.
          wantBoost = false;
          lerpRate = STEER_LERP_AVOID;
          commitMin = COMMIT_FOOD;
        }
      }

      // --- Encirclement / coil defense ---
      if (coilResult.defensive) {
        var defCoil = coilResult.defensive;
        // v8: Exponential scoring — mild=6, moderate=17, severe=31
        var encircleScore = Math.pow(defCoil.severity || 1, 1.5) * 6.0;

        // v9: Rapidly closing coils score exponentially higher
        if (defCoil.tightnessRate && defCoil.tightnessRate > 0.02) {
          encircleScore *= (1.0 + defCoil.tightnessRate * 10);
        }

        if (encircleScore > bestScore) {
          bestScore = encircleScore;
          meta.encirclement = true;
          lerpRate = STEER_LERP_EMERGENCY;

          if (defCoil.survivalMode) {
            meta.survivalMode = true;
            var survAng = defCoil.survivalAngle;
            dirX = Math.cos(survAng);
            dirY = Math.sin(survAng);
            wantBoost = false;
            commitMin = COMMIT_EMERGENCY;  // react EVERY frame in survival
            lerpRate = STEER_LERP_EMERGENCY; // v8: fastest possible response
          } else {
            dirX = Math.cos(defCoil.escapeAngle);
            dirY = Math.sin(defCoil.escapeAngle);
            wantBoost = defCoil.shouldBoost;
            commitMin = COMMIT_SAFETY;
          }
        }
      }

      // --- Giant flee ---
      if (nearbySnakes && playerSnake.length > 0) {
        for (var gi = 0; gi < nearbySnakes.length; gi++) {
          var giant = nearbySnakes[gi];
          if (!giant) continue;
          var giantRatio = (giant.length || 10) / playerSnake.length;
          // v2: Mode-scaled giant flee: defensive flees earlier, aggressive later
          var giantFleeThreshold = 2.5 / ((params && params.giantFleeRatioMult) ? params.giantFleeRatioMult : 1.0);
          if (giantRatio < giantFleeThreshold) continue;
          var giantDist = MathUtil.distance(playerSnake.x, playerSnake.y, giant.x, giant.y);
          if (giantDist < DANGER_RADIUS) {
            var giantAngleToUs = MathUtil.angle(giant.x, giant.y, playerSnake.x, playerSnake.y);
            var giantHeading = giant.angle || 0;
            var giantApproach = Math.abs(this._angleDiff(giantHeading, giantAngleToUs));
            if (giantApproach < Math.PI * 0.5 && GIANT_FLEE_SCORE > bestScore) {
              bestScore = GIANT_FLEE_SCORE;
              // Flee direction: away from giant
              var fleeAng = MathUtil.angle(giant.x, giant.y, playerSnake.x, playerSnake.y);
              dirX = Math.cos(fleeAng);
              dirY = Math.sin(fleeAng);
              lerpRate = STEER_LERP_EMERGENCY;
              wantBoost = true;
              meta.giantFlee = true;
              commitMin = COMMIT_SAFETY;
            }
          }
        }
      }

      // v5: Giant proximity — orbiting/circling giants that aren't heading toward us.
      // Giant flee (above) only fires when the giant is approaching within 90°.
      // Once a giant starts circling at stable distance, it's no longer "approaching"
      // but it's actually MORE dangerous (encirclement in progress).
      if (nearbySnakes && playerSnake.length > 0 && SP.SnakeTracker) {
        var GIANT_PROX_SCORE = 10.0;
        var GIANT_PROX_RADIUS = 500;
        var Tracker = SP.SnakeTracker;
        for (var gpi = 0; gpi < nearbySnakes.length; gpi++) {
          var gProx = nearbySnakes[gpi];
          if (!gProx) continue;
          var gProxRatio = (gProx.length || 10) / playerSnake.length;
          // v5b: Use LOWER threshold than giant flee for orbiting detection.
          // A snake actively circling at 2x size is far more dangerous than one
          // just passing nearby. Cap at 3.0 even in aggressive mode (was 6.25).
          var gProxFleeRaw = 2.5 / ((params && params.giantFleeRatioMult) ? params.giantFleeRatioMult : 1.0);
          var gProxFleeThreshold = Math.min(3.0, gProxFleeRaw);
          if (gProxRatio < gProxFleeThreshold) continue;

          var gProxDist = MathUtil.distance(playerSnake.x, playerSnake.y, gProx.x, gProx.y);
          if (gProxDist >= GIANT_PROX_RADIUS) continue;

          var tracked = Tracker.getTracked(gProx.id);
          var gProxIsOrbiting = tracked && tracked.isOrbiting;
          var gProxIsCircling = tracked && tracked.behavior === 'CIRCLING';

          if ((gProxIsOrbiting || gProxIsCircling) && GIANT_PROX_SCORE > bestScore) {
            bestScore = GIANT_PROX_SCORE;
            var gProxFleeAng = MathUtil.angle(gProx.x, gProx.y, playerSnake.x, playerSnake.y);
            dirX = Math.cos(gProxFleeAng);
            dirY = Math.sin(gProxFleeAng);
            lerpRate = STEER_LERP_AVOID;
            wantBoost = true;
            meta.giantFlee = true;
            meta.giantProximity = true;
            commitMin = COMMIT_SAFETY;
          }
        }
      }

      if (bestScore <= 0) return null;

      // v3c: Mode-aware safety score — applies to ALL safety including emergencies.
      var safetyScoreMult = (params && params.safetyScoreMult != null) ? params.safetyScoreMult : 1.0;
      bestScore *= safetyScoreMult;

      // v3c: Mode-aware emergency tier gate.
      // In aggressive mode, only genuine squeezes (magnitude > 40) and survival mode
      // earn TIER_EMERGENCY. This lets kills/deathFood compete during mild emergencies.
      // Average game mag is ~14, so 40 = truly surrounded, not just passing traffic.
      var isAggressiveMode = params && params.mode === 'aggressive';
      if (isAggressiveMode) {
        meta.emergency = meta.survivalMode ||
          (avoidance && avoidance.emergency && avoidance.magnitude > 40);
      } else {
        meta.emergency = (avoidance && avoidance.emergency) || meta.survivalMode;
      }

      return {
        score: bestScore,
        dirX: dirX,
        dirY: dirY,
        lerpRate: lerpRate,
        boost: wantBoost,
        tag: 'safety',
        commitMin: commitMin,
        meta: meta
      };
    },

    /**
     * 3. Kill opportunity — cut-off kill + head trap.
     * v2: Uses ThreatMap directional safety instead of global avoidance magnitude.
     */
    _scoreKillOpportunity: function (playerSnake, nearbySnakes, params, avoidance, edgeResult) {
      if (!settings.bot.autoBoost || !SP.AutoBoost) return null;
      if (!settings.bot.killAttempts && settings.bot.killAttempts !== undefined) return null;
      if (_killCooldown > 0) return null;
      if (edgeResult && edgeResult.strength > 0.65) return null;

      var Strategy = SP.StrategyManager;
      var killSizeRatio = (params && params.killSizeRatio != null) ? params.killSizeRatio : 0;
      var minLengthToKill = (params && params.minLengthToKill != null) ? params.minLengthToKill : 10;
      var aggressionLevel = (params && params.aggressionLevel != null) ? params.aggressionLevel : 0;
      var phase = Strategy ? Strategy.getPhase() : 'HATCHLING';

      // v2: ThreatMap for directional safety
      var TM = SP.ThreatMap;

      var bestScore = 0;
      var bestDirX = 0;
      var bestDirY = 0;
      var bestMeta = null;

      var MathUtil = SP.MathUtil;
      var px = playerSnake.x;
      var py = playerSnake.y;

      var killGate = 3.0; // default gate for head traps
      var killDampen = killGate * 0.7; // default dampen zone

      // --- Cut-off kill ---
      if (killSizeRatio > 0 && playerSnake.length >= minLengthToKill) {
        var killInfo = SP.AutoBoost.findCutOffOpportunity(
          playerSnake, nearbySnakes, killSizeRatio, aggressionLevel
        );
        if (killInfo) {
          var kdx = killInfo.interceptX - px;
          var kdy = killInfo.interceptY - py;
          var kMag = Math.sqrt(kdx * kdx + kdy * kdy);
          if (kMag > 0) { kdx = kdx / kMag; kdy = kdy / kMag; }

          // v2: Check intercept direction + path via ThreatMap
          var killAngle = Math.atan2(kdy, kdx);
          var dirThreat = TM ? TM.getDirectionThreat(killAngle) : 0;
          var pathClear = TM ? TM.isPathClear(px, py, killInfo.interceptX, killInfo.interceptY, KILL_PATH_WIDTH) : true;

          // v2: Mode-aware kill gating — aggressive accepts higher risk
          killGate = (params && params.killThreatGate != null) ? params.killThreatGate : KILL_DIR_THREAT_REJECT;
          killDampen = killGate * 0.7;  // dampen zone starts at 70% of gate

          if (pathClear && dirThreat < killGate) {
            var killScore = killInfo.score * KILL_WEIGHT;
            // Dampen score when intercept direction has moderate threat
            if (dirThreat > killDampen) {
              killScore *= KILL_DIR_DAMPEN_FACTOR;
            }
            if (killScore > bestScore) {
              bestScore = killScore;
              // Edge blend (always relevant during kill pursuit)
              if (edgeResult && edgeResult.strength > 0.4) {
                var edgeMix = edgeResult.strength * 0.55;
                kdx = kdx * (1 - edgeMix) + edgeResult.x * edgeMix;
                kdy = kdy * (1 - edgeMix) + edgeResult.y * edgeMix;
              }
              bestDirX = kdx;
              bestDirY = kdy;
              bestMeta = {
                targetId: killInfo.targetSnake ? killInfo.targetSnake.id : null,
                interceptX: killInfo.interceptX,
                interceptY: killInfo.interceptY,
                isHeadTrap: false,
                isCutOff: true,
                killInfo: killInfo
              };
            }
          }
        }
      }

      // --- Head trap ---
      if (phase === 'APEX' || phase === 'PREDATOR' || phase === 'CONTENDER' || phase === 'GROWING') {
        if (playerSnake.length >= 30 && aggressionLevel >= 0.20) {
          var trapInfo = SP.AutoBoost.findHeadTrapOpportunity(playerSnake, nearbySnakes);
          if (trapInfo) {
            var htAng = trapInfo.boostAngle;
            var htDirThreat = TM ? TM.getDirectionThreat(htAng) : 0;

            if (htDirThreat < killGate) {
              var trapScore = trapInfo.score * HEAD_TRAP_WEIGHT;
              if (htDirThreat > killDampen) {
                trapScore *= KILL_DIR_DAMPEN_FACTOR;
              }
              if (trapScore > bestScore) {
                bestScore = trapScore;
                var htx = Math.cos(htAng);
                var hty = Math.sin(htAng);
                if (edgeResult && edgeResult.strength > 0.4) {
                  var eMix = edgeResult.strength * 0.3;
                  htx = htx * (1 - eMix) + edgeResult.x * eMix;
                  hty = hty * (1 - eMix) + edgeResult.y * eMix;
                }
                bestDirX = htx;
                bestDirY = hty;
                bestMeta = {
                  targetId: trapInfo.targetSnake ? trapInfo.targetSnake.id : null,
                  interceptX: trapInfo.bodyX,
                  interceptY: trapInfo.bodyY,
                  isHeadTrap: true,
                  isCutOff: false,
                  trapInfo: trapInfo
                };
              }
            }
          }
        }
      }

      if (bestScore <= 0 || !bestMeta) return null;

      // Bonus for kills in very clear directions
      var finalAngle = Math.atan2(bestDirY, bestDirX);
      var finalThreat = TM ? TM.getDirectionThreat(finalAngle) : 0;
      if (finalThreat < KILL_CLEAR_THRESHOLD) {
        bestScore *= KILL_CLEAR_BONUS;
      }

      // Normalize direction
      var nMag = Math.sqrt(bestDirX * bestDirX + bestDirY * bestDirY);
      if (nMag > 0) { bestDirX = bestDirX / nMag; bestDirY = bestDirY / nMag; }

      // v4c: Kill ALWAYS boosts — cut-offs require speed to outrun the target.
      // Boost conservation comes from: sticky no-boost, budget system, small-snake gate.
      return {
        score: bestScore,
        dirX: bestDirX,
        dirY: bestDirY,
        lerpRate: STEER_LERP_KILL,
        boost: true,
        tag: 'kill',
        commitMin: Math.round(COMMIT_KILL * (params && params.killCommitMult ? params.killCommitMult : 1)),
        meta: bestMeta
      };
    },

    /**
     * 4. Death food — dead-snake food bursts from SnakeTracker.
     */
    _scoreDeathFood: function (playerPos, params, nearbySnakes, mapRadius) {
      if (!SP.SnakeTracker || !SP.SnakeTracker.getFoodBursts) return null;

      var bursts = SP.SnakeTracker.getFoodBursts();
      if (!bursts || bursts.length === 0) return null;

      var MathUtil = SP.MathUtil;
      var fc = SP.SnakeTracker.getFrameCounter ? SP.SnakeTracker.getFrameCounter() : _frameCounter;
      var bestScore = 0;
      var bestDirX = 0;
      var bestDirY = 0;
      var bestDist = 0;
      var bestBurstX = 0;
      var bestBurstY = 0;

      for (var i = 0; i < bursts.length; i++) {
        var burst = bursts[i];
        if (!burst) continue;

        var dist = MathUtil.distance(playerPos.x, playerPos.y, burst.x, burst.y);
        if (dist > DEATH_FOOD_RADIUS || dist < 10) continue;

        var age = fc - (burst.frame || 0);
        var decayFactor = Math.max(0, 1.0 - age / 900);
        if (decayFactor <= 0) continue;

        var value = (burst.estimatedValue || 30) * decayFactor;

        // v5b: Softer safety penalty — death piles always attract other snakes,
        // heavy penalty makes death food unwinnable in the most common scenario.
        var safety = 1.0;
        if (nearbySnakes) {
          for (var j = 0; j < nearbySnakes.length; j++) {
            var s = nearbySnakes[j];
            if (!s) continue;
            var eDist = MathUtil.distance(burst.x, burst.y, s.x, s.y);
            if (eDist < 300) {
              var closeness = 1 - (eDist / 300);
              var dangerMult = 1.0;
              if ((s.speed || 0) > 8) dangerMult += 0.3;
              if ((s.length || 0) > 50) dangerMult += 0.3;
              safety -= 0.12 * closeness * dangerMult;  // v5b: was 0.25 — halved penalty per snake
            }
          }
          safety = Math.max(0.2, safety);  // v5b: was 0.1 — higher floor so death food stays viable
        }

        // v10: Log-normalize death food to prevent spike scores
        var rawDeathVal = value * safety / dist;
        var normalizedDeathVal = Math.min(DEATH_FOOD_SCORE_CAP, Math.log(1 + rawDeathVal) / DEATH_FOOD_LOG_DIVISOR);
        var score = normalizedDeathVal * DEATH_FOOD_WEIGHT;
        if (score > bestScore) {
          bestScore = score;
          bestDist = dist;
          bestBurstX = burst.x;
          bestBurstY = burst.y;
          var ddx = burst.x - playerPos.x;
          var ddy = burst.y - playerPos.y;
          var dMag = Math.sqrt(ddx * ddx + ddy * ddy);
          if (dMag > 0) { ddx = ddx / dMag; ddy = ddy / dMag; }
          bestDirX = ddx;
          bestDirY = ddy;
        }
      }

      if (bestScore <= 0) return null;

      // v5b: When close to burst, scan actual food items and aim at the densest
      // nearby cluster instead of the static burst center. This lets the bot
      // sweep through the food cloud rather than just hitting one point.
      if (bestDist < 250 && SP.GameAPI && SP.GameAPI.getFoods) {
        var foods = SP.GameAPI.getFoods();
        if (foods && foods.length > 0) {
          var bestFoodDirX = 0, bestFoodDirY = 0;
          var bestFoodVal = 0;
          // Scan food items near burst, find the densest reachable cluster
          for (var fi = 0; fi < foods.length; fi++) {
            var f = foods[fi];
            if (!f) continue;
            var fDistToBurst = MathUtil.distance(f.x, f.y, bestBurstX, bestBurstY);
            if (fDistToBurst > 350) continue;  // only food near the burst
            var fDistToPlayer = MathUtil.distance(f.x, f.y, playerPos.x, playerPos.y);
            if (fDistToPlayer < 15 || fDistToPlayer > 400) continue;
            // Weight: value / distance — prefer close, high-value food
            var fVal = (f.value || f.sz || 1) / fDistToPlayer;
            // Cluster bonus: count nearby food within 80 units
            var clusterCount = 0;
            for (var fk = fi + 1; fk < foods.length && fk < fi + 30; fk++) {
              var fNear = foods[fk];
              if (fNear && MathUtil.distanceSq(f.x, f.y, fNear.x, fNear.y) < 6400) {
                clusterCount++;
              }
            }
            fVal *= (1 + clusterCount * 0.3);
            if (fVal > bestFoodVal) {
              bestFoodVal = fVal;
              var fddx = f.x - playerPos.x;
              var fddy = f.y - playerPos.y;
              var fMag = Math.sqrt(fddx * fddx + fddy * fddy);
              if (fMag > 0) { fddx /= fMag; fddy /= fMag; }
              bestFoodDirX = fddx;
              bestFoodDirY = fddy;
            }
          }
          // If we found good food near the burst, aim there instead
          if (bestFoodVal > 0) {
            bestDirX = bestFoodDirX;
            bestDirY = bestFoodDirY;
          }
        }
      }

      return {
        score: bestScore,
        dirX: bestDirX,
        dirY: bestDirY,
        lerpRate: 0.30,  // v5b: was 0.25 — steer faster toward death food
        boost: true,
        tag: 'deathFood',
        commitMin: Math.round(COMMIT_DEATH_FOOD * (params && params.deathFoodCommitMult ? params.deathFoodCommitMult : 1)),
        meta: {}
      };
    },

    /**
     * 5. Food cluster + wandering fallback.
     */
    _scoreFoodCluster: function (playerPos, playerSnake, foodTarget, edgeResult, params, mapRadius, avoidance) {
      if (foodTarget) {
        // v10: Log-normalize food score to prevent overwhelming safety goals
        // raw 1→1.7, raw 5→4.5, raw 20→7.6, raw 47→9.7, cap 10.0
        var normalizedFood = Math.min(FOOD_SCORE_CAP, Math.log(1 + foodTarget.score) / FOOD_LOG_DIVISOR);
        var score = normalizedFood * FOOD_WEIGHT;

        // v11: Ultra defensive — dampen food when threats exist
        if (avoidance && avoidance.magnitude > 1.0) {
          var threatDamp = Math.max(0.3, 1.0 - (avoidance.magnitude - 1.0) * FOOD_THREAT_DAMPING);
          score *= threatDamp;
        }
        var fdx = foodTarget.x - playerPos.x;
        var fdy = foodTarget.y - playerPos.y;
        var fMag = Math.sqrt(fdx * fdx + fdy * fdy);
        if (fMag > 0) { fdx = fdx / fMag; fdy = fdy / fMag; }

        // Gentle edge blend
        if (edgeResult) {
          var edgeBlend = edgeResult.strength * 0.5;
          fdx = fdx * (1 - edgeBlend) + edgeResult.x * edgeBlend;
          fdy = fdy * (1 - edgeBlend) + edgeResult.y * edgeBlend;
        }

        // Re-normalize
        var fnMag = Math.sqrt(fdx * fdx + fdy * fdy);
        if (fnMag > 0) { fdx = fdx / fnMag; fdy = fdy / fnMag; }

        // v11: Anti-circling override — break out when eating own trail
        if (_isCircling) {
          fdx = Math.cos(_circleBreakAngle);
          fdy = Math.sin(_circleBreakAngle);
        }

        return {
          score: score,
          dirX: fdx,
          dirY: fdy,
          lerpRate: STEER_LERP_NORMAL,
          boost: false, // boost decided by AutoBoost
          tag: 'food',
          commitMin: _isCircling ? 10 : COMMIT_FOOD,
          meta: { foodTarget: foodTarget }
        };
      }

      // Wandering fallback
      var Strategy = SP.StrategyManager;
      var wanderTarget = null;
      if (Strategy && Strategy.getWanderTarget && settings.bot.smartWander !== false) {
        var wanderBursts = SP.SnakeTracker ? SP.SnakeTracker.getFoodBursts() : [];
        wanderTarget = Strategy.getWanderTarget(
          playerPos.x, playerPos.y, mapRadius, wanderBursts
        );
      }

      var wdx, wdy;
      if (wanderTarget) {
        wdx = wanderTarget.x - playerPos.x;
        wdy = wanderTarget.y - playerPos.y;
        var wMag = Math.sqrt(wdx * wdx + wdy * wdy);
        if (wMag > 0) { wdx = wdx / wMag; wdy = wdy / wMag; }

        if (edgeResult) {
          var wEdge = edgeResult.strength * 0.5;
          wdx = wdx * (1 - wEdge) + edgeResult.x * wEdge;
          wdy = wdy * (1 - wEdge) + edgeResult.y * wEdge;
        }
      } else {
        // Fallback: drift at current angle
        var wanderAngle = playerSnake.angle || 0;
        wdx = Math.cos(wanderAngle);
        wdy = Math.sin(wanderAngle);
        if (edgeResult) {
          var wanderBlend = edgeResult.strength * 0.3;
          wdx = wdx * (1 - wanderBlend) + edgeResult.x * wanderBlend;
          wdy = wdy * (1 - wanderBlend) + edgeResult.y * wanderBlend;
        }
      }

      // v11: Anti-circling override — force straight-line travel
      if (_isCircling) {
        wdx = Math.cos(_circleBreakAngle);
        wdy = Math.sin(_circleBreakAngle);
      }

      // Normalize
      var wnMag = Math.sqrt(wdx * wdx + wdy * wdy);
      if (wnMag > 0) { wdx = wdx / wnMag; wdy = wdy / wnMag; }

      return {
        score: 0.5,
        dirX: wdx,
        dirY: wdy,
        lerpRate: STEER_LERP_NORMAL,
        boost: false,
        tag: 'wander',
        commitMin: COMMIT_WANDER,
        meta: {}
      };
    },

    /**
     * 6. Offensive coil.
     */
    _scoreOffensiveCoil: function (playerPos, coilResult, edgeResult, params) {
      if (!coilResult.offensive || !coilResult.offensive.isActive) return null;
      // v12: Coil cooldown — prevent oscillation between coil and safety
      if (_coilCooldown > 0) return null;

      var coilAtk = coilResult.offensive;
      var score = (coilAtk.score || 1.0) * COIL_WEIGHT;

      var cdx = coilAtk.orbitX - playerPos.x;
      var cdy = coilAtk.orbitY - playerPos.y;
      var cMag = Math.sqrt(cdx * cdx + cdy * cdy);
      if (cMag > 0) { cdx = cdx / cMag; cdy = cdy / cMag; }

      if (edgeResult && edgeResult.strength > 0.4) {
        var eMix = edgeResult.strength * 0.4;
        cdx = cdx * (1 - eMix) + edgeResult.x * eMix;
        cdy = cdy * (1 - eMix) + edgeResult.y * eMix;
      }

      var cnMag = Math.sqrt(cdx * cdx + cdy * cdy);
      if (cnMag > 0) { cdx = cdx / cnMag; cdy = cdy / cnMag; }

      return {
        score: score,
        dirX: cdx,
        dirY: cdy,
        lerpRate: STEER_LERP_KILL,
        boost: coilAtk.shouldBoost,
        tag: 'coil',
        commitMin: Math.round(COMMIT_COIL * (params && params.coilCommitMult ? params.coilCommitMult : 1)),
        meta: { targetId: coilAtk.targetId || null }
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Priority-Tier Goal Selection + Commitment Engine (v2)
     *
     *  Tier 0 (EMERGENCY) always interrupts.  Tier 1 (ACTIVE) can only
     *  be interrupted by Tier 0.  Tier 2 (PASSIVE) can be interrupted
     *  by anything.  Within the same tier, score competition decides.
     *
     *  Safety/border nudge is capped at 20% (was 55%) — emergencies
     *  win outright via tier, no blending needed.
     * ══════════════════════════════════════════════════════════ */

    /**
     * Assign a priority tier to a goal candidate.
     */
    _getGoalTier: function (goal) {
      var meta = goal.meta || {};

      // Emergency: immediate reaction, nothing can interrupt
      if (goal.tag === 'border' && meta.emergency) return TIER_EMERGENCY;
      if (goal.tag === 'safety' && meta.emergency) return TIER_EMERGENCY;

      // Active: important goals, only emergency interrupts
      if (goal.tag === 'safety')    return TIER_ACTIVE;
      if (goal.tag === 'kill')      return TIER_ACTIVE;
      if (goal.tag === 'coil')      return TIER_ACTIVE;
      if (goal.tag === 'deathFood') return TIER_ACTIVE;
      if (goal.tag === 'border')    return TIER_ACTIVE;

      // Passive: food, wander — anything can preempt
      return TIER_PASSIVE;
    },

    /**
     * Clean up when breaking a commitment (cooldowns, coil abort).
     */
    _breakCommitment: function () {
      if (_lockedTag === 'kill') {
        _killCooldown = KILL_COOLDOWN_FRAMES;
      }
      if (_lockedTag === 'coil') {
        _coilCooldown = COIL_COOLDOWN_FRAMES;
        if (SP.CoilDetector && SP.CoilDetector.abortCoilAttack) {
          SP.CoilDetector.abortCoilAttack();
        }
      }
      // v2: End boost budget when commitment is interrupted
      if (SP.AutoBoost && SP.AutoBoost.endBudget) {
        SP.AutoBoost.endBudget();
      }
      _lockedTag = '';
      _lockedTier = TIER_PASSIVE;
      _commitTicksLeft = 0;
      _commitDirX = 0;
      _commitDirY = 0;
      _commitBoost = false;
    },

    _evaluateGoals: function (candidates, safetyGoal, borderGoal, avoidance, params) {
      if (candidates.length === 0) {
        return {
          dirX: 0, dirY: 1, lerpRate: STEER_LERP_NORMAL,
          boost: false, tag: 'wander', commitMin: COMMIT_WANDER, meta: {}
        };
      }

      // Sort descending by score
      candidates.sort(function (a, b) { return b.score - a.score; });

      // Assign tier to each candidate
      var highestTier = TIER_PASSIVE;
      for (var ci = 0; ci < candidates.length; ci++) {
        candidates[ci]._tier = this._getGoalTier(candidates[ci]);
        if (candidates[ci]._tier < highestTier) {
          highestTier = candidates[ci]._tier;
        }
      }

      // --- Active commitment: check whether to continue or interrupt ---
      if (_commitTicksLeft > 0 && _lockedTag) {
        // Tier-based interruption check: only a HIGHER tier (lower number) can interrupt
        if (highestTier < _lockedTier) {
          this._breakCommitment();
          // Fall through to normal selection
        } else {
          // Find the locked goal in current candidates
          var lockedCandidate = null;
          for (var c = 0; c < candidates.length; c++) {
            if (candidates[c].tag === _lockedTag) {
              lockedCandidate = candidates[c];
              break;
            }
          }

          if (lockedCandidate) {
            // Goal still active — continue with updated direction
            _commitTicksLeft--;
            // v4: Store direction for sticky persistence
            _commitDirX = lockedCandidate.dirX;
            _commitDirY = lockedCandidate.dirY;
            _commitLerpRate = lockedCandidate.lerpRate;
            _commitBoost = lockedCandidate.boost;
            var chosen = this._applyNudge(lockedCandidate, safetyGoal, borderGoal, params);
            return chosen;
          }

          // v5: Abort sticky kill/coil if imminent collision detected.
          // During sticky frames the bot continues blindly in last known direction.
          // If a body has moved into that path, we need to break before hitting it.
          if (_lockedTier <= TIER_ACTIVE &&
              (_lockedTag === 'kill' || _lockedTag === 'coil') &&
              this._checkImminentCollision) {
            var stPlayer = GameAPI.getPlayerSnake();
            var stNearby = GameAPI.getNearbySnakes();
            if (stPlayer && stNearby &&
                this._checkImminentCollision(stPlayer, stNearby, null)) {
              this._breakCommitment();
              // Fall through to normal selection below
            }
          }

          // v4: Sticky commitment — goal scorer returned null but timer still active.
          // For action-oriented goals (kill, coil, deathFood), continue with last
          // known direction instead of breaking. Targets are transient — they flicker
          // in/out of detection range frame-to-frame. Breaking immediately means
          // the bot never holds course long enough to complete a kill.
          // v4b: DON'T boost during sticky frames — target is out of sight,
          // boosting blindly toward last position wastes length for nothing.
          if (_lockedTier <= TIER_ACTIVE &&
              (_lockedTag === 'kill' || _lockedTag === 'coil' || _lockedTag === 'deathFood')) {
            _commitTicksLeft--;
            var stickyGoal = {
              dirX: _commitDirX,
              dirY: _commitDirY,
              lerpRate: _commitLerpRate,
              boost: false,
              tag: _lockedTag,
              commitMin: 0,
              meta: {},
              score: 1.0
            };
            var chosen = this._applyNudge(stickyGoal, safetyGoal, borderGoal, params);
            return chosen;
          }

          // Non-sticky goal disappeared — break commitment
          this._breakCommitment();
          // Fall through to normal selection
        }
      }

      // --- Normal selection: tier-aware (v3b) ---
      // Pick the highest-score candidate from the highest-priority tier.
      // TIER_EMERGENCY always wins over TIER_ACTIVE regardless of score.
      // Within the same tier, highest score wins (candidates already sorted).
      var winner = candidates[0]; // fallback
      for (var wi = 0; wi < candidates.length; wi++) {
        if (candidates[wi]._tier === highestTier) {
          winner = candidates[wi];
          break; // first match = highest score in that tier (pre-sorted)
        }
      }
      var chosen = this._applyNudge(winner, safetyGoal, borderGoal, params);

      // Start new commitment
      _lockedTag = winner.tag;
      _lockedTier = winner._tier !== undefined ? winner._tier : this._getGoalTier(winner);
      _commitTicksLeft = winner.commitMin;

      // v4: Store direction for sticky persistence
      _commitDirX = winner.dirX;
      _commitDirY = winner.dirY;
      _commitLerpRate = winner.lerpRate;
      _commitBoost = winner.boost;

      // v2: Start boost budget for new commitment
      if (SP.AutoBoost && SP.AutoBoost.startBudget) {
        var pSnake = GameAPI.getPlayerSnake();
        var pLen = pSnake ? (pSnake.length || 10) : 10;
        SP.AutoBoost.startBudget(winner.tag, pLen, params);
      }

      return chosen;
    },

    /**
     * Apply gentle safety + border nudge to the winning goal's direction.
     * Capped at 20% (was 55%) — emergencies win outright via tier system.
     */
    _applyNudge: function (winner, safetyGoal, borderGoal, params) {
      var dx = winner.dirX;
      var dy = winner.dirY;

      // v2: Mode-aware nudge cap (aggressive=10%, balanced=20%, defensive=30%)
      var modeNudgeCap = (params && params.safetyNudgeCap != null) ? params.safetyNudgeCap : SAFETY_NUDGE_CAP;

      // v5: Kill-specific safety floor — even aggressive mode needs minimum dodge ability.
      // Without this, aggressive safetyNudgeCap=0.10 can still be too low during kills.
      if ((winner.tag === 'kill' || winner.tag === 'coil') && safetyGoal && safetyGoal.score > 0) {
        modeNudgeCap = Math.max(modeNudgeCap, 0.08);
      }

      // Safety nudge (if winner is not safety itself)
      if (winner.tag !== 'safety' && safetyGoal && safetyGoal.score > 0) {
        // Skip nudge if safety is in survival mode (it would win via tier anyway)
        if (!safetyGoal.meta || !safetyGoal.meta.survivalMode) {
          var safeNudge = (safetyGoal.score / Math.max(winner.score, 1)) * 0.15;
          safeNudge = Math.min(safeNudge, modeNudgeCap);
          if (safeNudge > 0.02 && safetyGoal.dirX !== undefined) {
            dx = dx * (1 - safeNudge) + safetyGoal.dirX * safeNudge;
            dy = dy * (1 - safeNudge) + safetyGoal.dirY * safeNudge;
          }
        }
      }

      // Border nudge (if winner is not border itself)
      if (winner.tag !== 'border' && borderGoal && borderGoal.meta && borderGoal.meta.strength > 0.3) {
        // Emergency border wins via tier — only nudge for non-emergency
        if (!borderGoal.meta.emergency) {
          var borderNudge = (borderGoal.score / Math.max(winner.score, 1)) * 0.15;
          borderNudge = Math.min(borderNudge, BORDER_NUDGE_CAP);
          if (borderNudge > 0.02) {
            dx = dx * (1 - borderNudge) + borderGoal.dirX * borderNudge;
            dy = dy * (1 - borderNudge) + borderGoal.dirY * borderNudge;
          }
        }
      }

      // Normalize
      var mag = Math.sqrt(dx * dx + dy * dy);
      if (mag > 0) { dx = dx / mag; dy = dy / mag; }

      return {
        dirX: dx,
        dirY: dy,
        lerpRate: winner.lerpRate,
        boost: winner.boost,
        tag: winner.tag,
        commitMin: winner.commitMin,
        meta: winner.meta,
        score: winner.score
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Map Edge Avoidance (graduated) — unchanged from v3
     * ══════════════════════════════════════════════════════════ */

    _computeEdgeAvoidance: function (playerPos, mapRadius, playerSnake) {
      if (!playerPos || !SP.MathUtil) return null;

      var MathUtil = SP.MathUtil;
      var centerX = mapRadius;
      var centerY = mapRadius;
      var distFromCenter = MathUtil.distance(centerX, centerY, playerPos.x, playerPos.y);
      var distToEdge = mapRadius - distFromCenter;

      if (distToEdge >= EDGE_GENTLE_DIST || distFromCenter <= 0) return null;

      var dx = centerX - playerPos.x;
      var dy = centerY - playerPos.y;
      var mag = Math.sqrt(dx * dx + dy * dy);
      if (mag <= 0) return null;

      var nx = dx / mag;
      var ny = dy / mag;
      var isEmergency = false;
      var strength = 0;

      if (distToEdge < EDGE_EMERGENCY_DIST) {
        strength = 1.0;
        isEmergency = true;
      } else if (distToEdge < EDGE_STRONG_DIST) {
        strength = 0.5 + 0.5 * (1 - (distToEdge - EDGE_EMERGENCY_DIST) / (EDGE_STRONG_DIST - EDGE_EMERGENCY_DIST));
      } else {
        strength = 0.5 * (1 - (distToEdge - EDGE_STRONG_DIST) / (EDGE_GENTLE_DIST - EDGE_STRONG_DIST));
      }

      // v9: Velocity-toward-edge amplification + TOD frame prediction
      if (playerSnake && MathUtil && distToEdge < EDGE_GENTLE_DIST) {
        var pAngle = playerSnake.angle || 0;
        var pSpeed = playerSnake.speed || 8;
        var isBoosting = pSpeed > 10;

        // Heading-toward-wall factor
        var outwardAngle = Math.atan2(playerPos.y - centerY, playerPos.x - centerX);
        var headingDiff = pAngle - outwardAngle;
        while (headingDiff > Math.PI) headingDiff -= 2 * Math.PI;
        while (headingDiff < -Math.PI) headingDiff += 2 * Math.PI;
        var towardWallFactor = Math.cos(headingDiff);

        if (towardWallFactor > 0) {
          // Heading toward wall: amplify strength up to 2x
          strength = Math.min(1.0, strength * (1.0 + towardWallFactor));
          // Fast approach in strong zone → emergency
          if (towardWallFactor > 0.7 && distToEdge < EDGE_STRONG_DIST) {
            isEmergency = true;
          }
        } else {
          // Heading away: reduce strength by up to 40%
          strength = Math.max(0, strength * (1.0 + towardWallFactor * 0.4));
        }

        // Frame prediction: how many frames until wall collision?
        var framesToWall = MathUtil.framesToWallCollision(
          playerPos.x, playerPos.y, pAngle, pSpeed, mapRadius, isBoosting
        );
        if (framesToWall < WALL_EMERGENCY_FRAMES && distToEdge < EDGE_STRONG_DIST) {
          strength = 1.0;
          isEmergency = true;
        } else if (framesToWall < WALL_STRONG_FRAMES && distToEdge < EDGE_GENTLE_DIST) {
          var velStrength = 0.5 + 0.5 * (1 - framesToWall / WALL_STRONG_FRAMES);
          strength = Math.max(strength, velStrength);
        }

        // Turn feasibility: can we turn 90° toward center before hitting the wall?
        var framesToTurn90 = MathUtil.framesToTurn(Math.PI / 2, playerSnake.length || 10);
        if (framesToWall < framesToTurn90 * 1.5 && distToEdge < EDGE_STRONG_DIST) {
          strength = Math.max(strength, 0.8);
          if (framesToWall < framesToTurn90) {
            strength = 1.0;
            isEmergency = true;
          }
        }
      }

      return {
        x: nx * strength,
        y: ny * strength,
        strength: strength,
        emergency: isEmergency
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Threat Memory — unchanged from v3
     * ══════════════════════════════════════════════════════════ */

    _recordThreat: function (pos) {
      _threatMemory.push({
        x: pos.x,
        y: pos.y,
        frame: _frameCounter
      });
      if (_threatMemory.length > THREAT_MEMORY_SIZE) {
        _threatMemory.shift();
      }
    },

    _decayThreatMemory: function () {
      var cutoff = _frameCounter - THREAT_MEMORY_DECAY;
      while (_threatMemory.length > 0 && _threatMemory[0].frame < cutoff) {
        _threatMemory.shift();
      }
    },

    _adjustForThreatMemory: function (ax, ay, playerPos) {
      if (_threatMemory.length === 0) return { x: ax, y: ay };

      var biasX = 0;
      var biasY = 0;

      for (var i = 0; i < _threatMemory.length; i++) {
        var mem = _threatMemory[i];
        var dx = playerPos.x - mem.x;
        var dy = playerPos.y - mem.y;
        var dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 0 && dist < THREAT_MEMORY_RADIUS) {
          biasX += (dx / dist) * 0.2;
          biasY += (dy / dist) * 0.2;
        }
      }

      return { x: ax + biasX, y: ay + biasY };
    },

    /* ══════════════════════════════════════════════════════════
     *  Utility
     * ══════════════════════════════════════════════════════════ */

    _lerp: function (current, target, rate) {
      return current + (target - current) * rate;
    },

    _angleDiff: function (a, b) {
      var d = b - a;
      while (d > Math.PI)  d -= 2 * Math.PI;
      while (d < -Math.PI) d += 2 * Math.PI;
      return d;
    },

    /**
     * v3: Detect approaching snake heads on a collision course.
     * Independent of safety scoring — hard safety gate.
     * Returns the most dangerous approaching head, or null.
     */
    _findApproachingHead: function (playerSnake, nearbySnakes) {
      if (!nearbySnakes || nearbySnakes.length === 0) return null;

      var MathUtil = SP.MathUtil;
      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;
      var pSpeed = playerSnake.speed || 8;

      var bestDanger = 0;
      var bestResult = null;

      for (var i = 0; i < nearbySnakes.length; i++) {
        var enemy = nearbySnakes[i];
        if (!enemy) continue;

        var dist = MathUtil.distance(px, py, enemy.x, enemy.y);
        if (dist > 350 || dist < 10) continue;

        var eAng = enemy.angle || 0;
        var eSpeed = enemy.speed || 8;

        // Use tracked data if available for more accurate angle
        var Tracker = SP.SnakeTracker;
        if (Tracker) {
          var tracked = Tracker.getTracked(enemy.id);
          if (tracked && tracked.avgSpeed > 0) {
            eSpeed = tracked.avgSpeed;
            var latestPos = tracked.positions && tracked.positions.get ? tracked.positions.get(0) : null;
            if (latestPos) eAng = latestPos.angle;
          }
        }

        // Check if enemy is heading toward us (within 50°)
        var enemyAngleToUs = MathUtil.angle(enemy.x, enemy.y, px, py);
        var enemyApproachDiff = Math.abs(this._angleDiff(eAng, enemyAngleToUs));
        if (enemyApproachDiff > 0.87) continue; // ~50 degrees

        // Check if WE are heading toward THEM (within 50°)
        var ourAngleToEnemy = MathUtil.angle(px, py, enemy.x, enemy.y);
        var ourApproachDiff = Math.abs(this._angleDiff(pAng, ourAngleToEnemy));
        if (ourApproachDiff > 0.87) continue;

        // Closing speed — must be positive (getting closer)
        var closingSpeed = pSpeed * Math.cos(ourApproachDiff) + eSpeed * Math.cos(enemyApproachDiff);
        if (closingSpeed <= 2) continue;

        // Time to collision (frames)
        var timeToCollision = dist / closingSpeed;
        if (timeToCollision > 25) continue; // >0.4s — not imminent

        var danger = closingSpeed / Math.max(dist, 1);
        if (danger > bestDanger) {
          bestDanger = danger;
          // Escape perpendicular to approach line
          var escapeAngle = ourAngleToEnemy + Math.PI * 0.5;
          bestResult = {
            enemy: enemy,
            dist: dist,
            closingSpeed: closingSpeed,
            timeToCollision: timeToCollision,
            escapeAngle: escapeAngle
          };
        }
      }

      return bestResult;
    },

    /**
     * v5c: Detect snake heads on a CROSSING path (perpendicular interceptions).
     *
     * _findApproachingHead only catches head-on collisions where both snakes
     * aim at each other within 50°. A perpendicular interception (enemy crosses
     * our path from the side at ~90°) is completely missed — the approach angle
     * check fails because the enemy isn't heading AT us, it's heading ACROSS us.
     *
     * Uses ray-ray intersection: project both snakes' heading as rays, find
     * where they cross, and check if both snakes arrive at the crossing point
     * at roughly the same time.
     *
     * @returns {object|null} { enemy, crossX, crossY, ourFrames, theirFrames, escapeAngle }
     */
    _findCrossingPath: function (playerSnake, nearbySnakes) {
      if (!nearbySnakes || nearbySnakes.length === 0) return null;

      var MathUtil = SP.MathUtil;
      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;
      var pSpeed = playerSnake.speed || 8;
      var pCos = Math.cos(pAng);
      var pSin = Math.sin(pAng);

      // Player thickness estimate for overlap window
      var pThick = playerSnake.thickness || 15;

      var bestDanger = 0;
      var bestResult = null;

      for (var i = 0; i < nearbySnakes.length; i++) {
        var enemy = nearbySnakes[i];
        if (!enemy) continue;

        // Quick distance check — skip far snakes
        var rawDist = MathUtil.distance(px, py, enemy.x, enemy.y);
        if (rawDist > 500 || rawDist < 10) continue;

        var eAng = enemy.angle || 0;
        var eSpeed = enemy.speed || 8;
        var eCos = Math.cos(eAng);
        var eSin = Math.sin(eAng);

        // Use tracked data for more accurate heading/speed
        var Tracker = SP.SnakeTracker;
        if (Tracker) {
          var tracked = Tracker.getTracked(enemy.id);
          if (tracked && tracked.avgSpeed > 0) {
            eSpeed = tracked.avgSpeed;
            var latestPos = tracked.positions && tracked.positions.get ? tracked.positions.get(0) : null;
            if (latestPos) {
              eAng = latestPos.angle;
              eCos = Math.cos(eAng);
              eSin = Math.sin(eAng);
            }
          }
        }

        // Filter: skip near-parallel paths. sin(angle difference) near 0 = parallel.
        // We want crossing paths where angle difference is 30°–150° (sin > 0.5).
        var det = pCos * (-eSin) - pSin * (-eCos); // = sin(eAng - pAng)
        if (Math.abs(det) < 0.5) continue; // < ~30° difference — near-parallel, not a crossing

        // Also skip if _findApproachingHead would catch this (both heading at each other).
        // Check: is enemy heading toward us AND are we heading toward them?
        var enemyAngleToUs = MathUtil.angle(enemy.x, enemy.y, px, py);
        var enemyApproachDiff = Math.abs(this._angleDiff(eAng, enemyAngleToUs));
        var ourAngleToEnemy = MathUtil.angle(px, py, enemy.x, enemy.y);
        var ourApproachDiff = Math.abs(this._angleDiff(pAng, ourAngleToEnemy));
        if (enemyApproachDiff < 0.87 && ourApproachDiff < 0.87) continue; // head-on detector handles this

        // Ray-ray intersection (Cramer's rule):
        // Our ray:   P(t) = (px + t*pCos, py + t*pSin)       t = distance along our path
        // Enemy ray: E(s) = (ex + s*eCos, ey + s*eSin)       s = distance along their path
        // Solve: t*pCos - s*eCos = dx,  t*pSin - s*eSin = dy
        var dx = enemy.x - px;
        var dy = enemy.y - py;
        var t = (-dx * eSin + dy * eCos) / det;  // our distance to crossing point
        var s = (dy * pCos - dx * pSin) / det;   // their distance to crossing point

        // Both must be positive (crossing is AHEAD of both snakes)
        if (t <= 0 || s <= 0) continue;

        // Convert distance to frames
        var ourFrames = t / pSpeed;
        var theirFrames = s / eSpeed;

        // Both must arrive within 25 frames (~420ms)
        if (ourFrames > 25 || theirFrames > 25) continue;

        // Do they arrive at roughly the same time?
        // Account for snake thickness — even a few frames apart can collide
        var eThick = enemy.thickness || 15;
        var overlapRadius = pThick + eThick;
        var overlapFrames = overlapRadius / Math.max(pSpeed, eSpeed);
        var timeDiff = Math.abs(ourFrames - theirFrames);

        if (timeDiff > overlapFrames + 2) continue; // won't overlap — safe

        // Danger score: closer arrival = more dangerous
        var danger = (1.0 / Math.max(ourFrames, 1)) * (1.0 / Math.max(timeDiff + 1, 1));

        if (danger > bestDanger) {
          bestDanger = danger;

          // Escape direction: turn away from the crossing point.
          // Specifically, dodge to the side AWAY from the enemy (behind where they'll pass).
          var crossX = px + t * pCos;
          var crossY = py + t * pSin;
          var toCrossAng = Math.atan2(crossY - py, crossX - px);

          // Pick perpendicular escape — away from enemy's approach side
          var enemySide = this._angleDiff(pAng, ourAngleToEnemy);
          var escapeAngle = (enemySide > 0)
            ? pAng - Math.PI * 0.5   // enemy on left → dodge right
            : pAng + Math.PI * 0.5;  // enemy on right → dodge left

          bestResult = {
            enemy: enemy,
            crossX: Math.round(crossX),
            crossY: Math.round(crossY),
            ourFrames: Math.round(ourFrames),
            theirFrames: Math.round(theirFrames),
            escapeAngle: escapeAngle
          };
        }
      }

      return bestResult;
    },

    /**
     * v5: Lightweight imminent body collision check for kill/coil commitment.
     *
     * Unlike the reverted scanForward approach (v4d, wide corridor + deflection),
     * this uses a NARROW cone and returns a boolean abort signal:
     *   - 60 units wide (not 160) -- only catches things directly in front
     *   - 120 units deep (not 450) -- only truly imminent collisions (~8 frames)
     *   - Checks target BODY (hitting target body kills us) but excludes target HEAD
     *   - Returns boolean abort signal -- no deflection direction
     *
     * @param {object} playerSnake
     * @param {Array}  nearbySnakes
     * @param {string|null} targetId -- kill/coil target ID (exclude their head, not body)
     * @returns {boolean} true if imminent collision -- abort recommended
     */
    _checkImminentCollision: function (playerSnake, nearbySnakes, targetId) {
      if (!nearbySnakes || nearbySnakes.length === 0) return false;

      var TM = SP.ThreatMap;
      var inCorridor = TM && TM._pointInCorridor;
      if (!inCorridor) return false;

      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;
      var checkDist = 120;
      var checkHalfW = 30;  // 60 units total width

      // Boost-aware: scan further when boosting
      if (playerSnake.speed > 10) {
        checkDist = 160;
        checkHalfW = 40;
      }

      for (var i = 0; i < nearbySnakes.length; i++) {
        var snake = nearbySnakes[i];
        if (!snake) continue;

        // Check enemy heads (but NOT the kill target's head -- we want to be near it)
        if (snake.id !== targetId) {
          if (inCorridor(snake.x, snake.y, px, py, pAng, checkDist, checkHalfW)) {
            return true;
          }
        }

        // Check body parts (ALL snakes including target -- running into target body kills us)
        if (snake.bodyParts) {
          var step = 3; // sample every 3rd part for performance
          for (var j = 0; j < snake.bodyParts.length; j += step) {
            var part = snake.bodyParts[j];
            if (!part) continue;
            if (inCorridor(part.x, part.y, px, py, pAng, checkDist, checkHalfW)) {
              return true;
            }
          }
        }
      }

      return false;
    },

    /*══════════════════════════════════════════════════════════
     *  Auto Play — unchanged
     * ══════════════════════════════════════════════════════════ */

    _tryAutoPlay: function () {
      if (_autoPlayRetryTimer) return;

      try {
        // v3c: Set default nickname
        var nickEl = document.getElementById('nick');
        if (nickEl && !nickEl.value) {
          nickEl.value = 'SLITHERPRO.XYZ';
        }

        if (typeof window.connect === 'function') {
          window.connect();
        } else {
          var enterEvent = new KeyboardEvent('keydown', {
            key: 'Enter', keyCode: 13, which: 13, bubbles: true
          });
          document.dispatchEvent(enterEvent);

          var playBtn = document.querySelector('.nsi') ||
                        document.querySelector('[onclick*="play"]') ||
                        document.querySelector('.sadg1');
          if (playBtn && typeof playBtn.click === 'function') {
            playBtn.click();
          }
        }
      } catch (e) {
        console.error('[SlitherPro] AutoPlay error:', e);
      }

      _autoPlayRetryTimer = setTimeout(function () {
        _autoPlayRetryTimer = null;
      }, 3000);
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.BotController = BotController;
})();
