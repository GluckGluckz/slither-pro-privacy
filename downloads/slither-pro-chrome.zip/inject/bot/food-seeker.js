/**
 * Slither Pro -- Food Seeker Bot Module (v3).
 *
 * Safety-weighted food targeting with v2 upgrades:
 *   1. Multi-waypoint routing (2-3 sector chains for optimal paths).
 *   2. Food burst integration from SnakeTracker (dead snake drops).
 *   3. Strategy-aware filtering (phase-dependent radius/safety thresholds).
 *   4. Center-bias bonus (food concentrates at map center).
 *   5. Sector-based clustering with safety scoring + path safety.
 *   6. Edge penalty + large food bonus.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  /* ── Tuning knobs ──────────────────────────────────────── */
  var SECTOR_SIZE          = 120;    // Game units per sector
  var MIN_TARGET_DIST      = 30;     // Ignore food closer than this
  var LARGE_FOOD_THRESHOLD = 5;      // sz above this = dead snake remains
  var LARGE_FOOD_BONUS     = 2.5;    // Multiplier for large food value
  var ENEMY_SAFETY_RADIUS  = 350;    // v8: Detect danger further away
  var ENEMY_SAFETY_PENALTY = 0.3;    // v8: Faster safety accumulation
  var MIN_SAFETY_FACTOR    = 0.25;   // v8: Don't chase food through near-certain death
  var EDGE_PENALTY_START   = 1500;   // Distance from edge where penalty begins
  var PATH_CHECK_STEPS     = 10;     // v7: More path samples for safety
  var PATH_CHECK_RADIUS    = 120;    // v7: Wider danger detection

  // v3: Multi-waypoint routing
  var MAX_WAYPOINTS               = 3;
  var WAYPOINT_ARRIVAL_DIST       = 80;    // How close to arrive at a waypoint
  var ROUTE_DISCOUNT              = 0.6;   // Value discount per additional waypoint
  var ROUTE_IMPROVEMENT_THRESHOLD = 1.3;   // Route must be 30% better than single

  // v3: Food burst integration
  var FOOD_BURST_VALUE_MULT  = 5.0;  // Multiplier for dead-snake food zones

  // v3: Center bias
  var CENTER_BONUS_5000 = 1.2;       // Bonus for sectors within 5000 of center
  var CENTER_BONUS_3000 = 1.4;       // Bonus for sectors within 3000 of center

  // v3: Top sectors to consider for route planning
  var TOP_SECTORS_FOR_ROUTING = 5;

  // v9: TOD (Time over Distance) decay — penalise food that takes many frames to reach
  var TOD_DECAY_FRAMES    = 120;   // frames before decay kicks in
  var TOD_DECAY_RATE      = 0.005; // multiplier loss per extra frame
  var TOD_MIN_MULTIPLIER  = 0.3;   // floor: distant food keeps 30% value

  // Waypoint state
  var _waypoints      = [];   // [{x, y, score}]
  var _waypointIndex  = 0;
  var _waypointScore  = 0;    // v10: stored route score for replacement comparison

  var FoodSeeker = {

    /**
     * Find the best food target with multi-waypoint routing.
     *
     * @param {object}  playerPos     - {x, y}
     * @param {Array}   foods         - food items from GameAPI
     * @param {number}  searchRadius  - max distance to consider
     * @param {Array}   snakes        - nearby snakes (for safety weighting)
     * @param {number}  mapRadius     - map radius for edge penalty
     * @returns {{x, y, score, sectorKey, safety, hasLargeFood, isWaypoint}|null}
     */
    findTarget: function (playerPos, foods, searchRadius, snakes, mapRadius) {
      if (!playerPos || !foods || foods.length === 0) return null;

      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;
      var Strategy = SP.StrategyManager;

      // v3: Strategy-aware radius scaling
      var params = Strategy ? Strategy.getParams() : null;
      var effectiveRadius = searchRadius;
      if (params && params.foodSearchRadiusScale) {
        effectiveRadius = searchRadius * params.foodSearchRadiusScale;
      }
      var searchRadiusSq = effectiveRadius * effectiveRadius;
      var minSafety = (params && params.minSafetyForFood != null)
        ? params.minSafetyForFood : 0.6;  // v7: Higher default safety floor

      var sectors = {};

      // ── 1. Bin food into sectors ───────────────────────────────
      for (var i = 0; i < foods.length; i++) {
        var f = foods[i];
        var dSq = MathUtil.distanceSq(playerPos.x, playerPos.y, f.x, f.y);
        if (dSq > searchRadiusSq) continue;
        if (dSq < MIN_TARGET_DIST * MIN_TARGET_DIST) continue;

        var sectorX = Math.floor(f.x / SECTOR_SIZE);
        var sectorY = Math.floor(f.y / SECTOR_SIZE);
        var key = sectorX + ',' + sectorY;

        if (!sectors[key]) {
          sectors[key] = {
            totalValue: 0,
            count: 0,
            centerX: (sectorX + 0.5) * SECTOR_SIZE,
            centerY: (sectorY + 0.5) * SECTOR_SIZE,
            hasLargeFood: false
          };
        }

        var value = f.sz || 1;
        if (value > LARGE_FOOD_THRESHOLD) {
          value *= LARGE_FOOD_BONUS;
          sectors[key].hasLargeFood = true;
        }
        sectors[key].totalValue += value;
        sectors[key].count++;
      }

      // ── 1b. Inject food burst synthetic sectors ────────────────
      if (Tracker) {
        var bursts = Tracker.getFoodBursts();
        for (var b = 0; b < bursts.length; b++) {
          var burst = bursts[b];
          var bDist = MathUtil.distanceSq(playerPos.x, playerPos.y, burst.x, burst.y);
          if (bDist > searchRadiusSq) continue;

          var bSectorX = Math.floor(burst.x / SECTOR_SIZE);
          var bSectorY = Math.floor(burst.y / SECTOR_SIZE);
          var bKey = bSectorX + ',' + bSectorY;

          // Time decay for burst value
          var frameCounter = Tracker.getFrameCounter();
          var burstAge = frameCounter - burst.frame;
          if (burstAge < 0 || burstAge >= 900) continue;  // stale or from previous life
          var decayFactor = 1.0 - (burstAge / 900); // 900 frames = ~15 sec

          var burstValue = burst.estimatedValue * FOOD_BURST_VALUE_MULT * decayFactor;

          if (!sectors[bKey]) {
            sectors[bKey] = {
              totalValue: 0,
              count: 0,
              centerX: (bSectorX + 0.5) * SECTOR_SIZE,
              centerY: (bSectorY + 0.5) * SECTOR_SIZE,
              hasLargeFood: true
            };
          }
          sectors[bKey].totalValue += burstValue;
          sectors[bKey].hasLargeFood = true;
        }
      }

      // ── 2. Pre-compute snake head positions for safety checks ──
      var enemyHeads = [];
      if (snakes) {
        for (var s = 0; s < snakes.length; s++) {
          var snake = snakes[s];
          if (snake) {
            enemyHeads.push({
              x: snake.x,
              y: snake.y,
              speed: snake.speed || 8,
              angle: snake.angle || 0,
              length: snake.length || 10
            });
          }
        }
      }

      // ── 3. Score each sector ───────────────────────────────────
      var scoredSectors = [];

      for (var key in sectors) {
        if (!sectors.hasOwnProperty(key)) continue;
        var sector = sectors[key];

        var dist = MathUtil.distance(playerPos.x, playerPos.y, sector.centerX, sector.centerY);
        if (dist < 1) dist = 1;

        // Safety factor
        var safety = this._computeSafety(sector.centerX, sector.centerY, enemyHeads);

        // v8: All food must pass the same safety threshold — no bypass
        if (safety < minSafety) continue;

        // Map edge penalty
        var edgePenalty = 1.0;
        if (mapRadius) {
          var distFromCenter = MathUtil.distance(mapRadius, mapRadius, sector.centerX, sector.centerY);
          var distToEdge = mapRadius - distFromCenter;
          if (distToEdge < EDGE_PENALTY_START) {
            edgePenalty = Math.max(0.1, distToEdge / EDGE_PENALTY_START);
          }
        }

        // v3: Center bias bonus
        var centerBonus = 1.0;
        if (mapRadius) {
          var distFromMapCenter = MathUtil.distance(mapRadius, mapRadius, sector.centerX, sector.centerY);
          if (distFromMapCenter < 3000) {
            centerBonus = CENTER_BONUS_3000;
          } else if (distFromMapCenter < 5000) {
            centerBonus = CENTER_BONUS_5000;
          }
        }

        // Path safety
        var pathSafe = this._checkPathSafety(
          playerPos.x, playerPos.y,
          sector.centerX, sector.centerY,
          enemyHeads
        );

        // v9: TOD decay — distant food scores lower
        var todMult = 1.0;
        if (MathUtil.framesToReach) {
          var framesToReach = MathUtil.framesToReach(dist, playerPos.speed || 8, false);
          if (isNaN(framesToReach)) framesToReach = TOD_DECAY_FRAMES;
          todMult = Math.max(TOD_MIN_MULTIPLIER, Math.min(1.0,
            1.0 - (framesToReach - TOD_DECAY_FRAMES) * TOD_DECAY_RATE));
        }

        // v11: Forward bias — prefer food ahead of travel direction, penalize U-turns
        var forwardBias = 1.0;
        if (playerPos.angle !== undefined) {
          var angleToFood = Math.atan2(
            sector.centerY - playerPos.y,
            sector.centerX - playerPos.x
          );
          var headDiff = angleToFood - playerPos.angle;
          while (headDiff > Math.PI) headDiff -= 2 * Math.PI;
          while (headDiff < -Math.PI) headDiff += 2 * Math.PI;
          // cos(0)=1.0 ahead, cos(PI)=-1.0 behind → maps to 1.0 ahead, 0.4 behind
          forwardBias = 0.7 + 0.3 * Math.cos(headDiff);
        }

        // Final score
        var score = (sector.totalValue * safety * edgePenalty * pathSafe * centerBonus * todMult * forwardBias) / dist;

        // Cluster density bonus
        if (sector.count >= 5) {
          score *= 1.3;
        }

        scoredSectors.push({
          x: sector.centerX,
          y: sector.centerY,
          score: score,
          sectorKey: key,
          safety: safety,
          hasLargeFood: sector.hasLargeFood,
          dist: dist
        });
      }

      if (scoredSectors.length === 0) {
        return null;
      }

      // Sort by score descending
      scoredSectors.sort(function (a, b) { return b.score - a.score; });

      // ── 4. Multi-waypoint route planning ───────────────────────
      var best = scoredSectors[0];
      var topN = Math.min(TOP_SECTORS_FOR_ROUTING, scoredSectors.length);

      // Try 2-sector routes
      var bestRoute = null;
      var bestRouteScore = best.score; // must beat single best

      for (var r1 = 0; r1 < topN; r1++) {
        var s1 = scoredSectors[r1];
        for (var r2 = r1 + 1; r2 < topN; r2++) {
          var s2 = scoredSectors[r2];

          // Route: player → s1 → s2
          var legDist = MathUtil.distance(s1.x, s1.y, s2.x, s2.y);
          var routeScore = s1.score + s2.score * ROUTE_DISCOUNT;

          // v7: Skip routes through dangerous intermediate sectors
          if (s1.safety < minSafety) continue;

          // Penalize long detours
          var directDist = MathUtil.distance(playerPos.x, playerPos.y, s2.x, s2.y);
          var detour = (s1.dist + legDist) / (directDist || 1);
          if (detour > 2.0) continue; // too much detour

          if (routeScore > bestRouteScore * ROUTE_IMPROVEMENT_THRESHOLD) {
            bestRoute = [s1, s2];
            bestRouteScore = routeScore;
          }
        }
      }

      // ── 5. Waypoint management ─────────────────────────────────
      if (bestRoute) {
        // Check if we've arrived at current waypoint
        if (_waypoints.length > 0 && _waypointIndex < _waypoints.length) {
          var wp = _waypoints[_waypointIndex];
          var wpDist = MathUtil.distance(playerPos.x, playerPos.y, wp.x, wp.y);
          if (wpDist < WAYPOINT_ARRIVAL_DIST) {
            _waypointIndex++;
          }
        }

        // Update route if significantly better or old route completed
        if (_waypointIndex >= _waypoints.length || bestRouteScore > _waypointScore * 1.5) {
          _waypoints = bestRoute;
          _waypointIndex = 0;
          _waypointScore = bestRouteScore;
        }

        // Return current waypoint
        if (_waypointIndex < _waypoints.length) {
          var target = _waypoints[_waypointIndex];
          target.isWaypoint = true;
          return target;
        }
      }

      // No route better than single — reset waypoints
      _waypoints = [];
      _waypointIndex = 0;
      _waypointScore = 0;

      best.isWaypoint = false;
      return best;
    },

    /**
     * Compute safety factor for a position based on nearby enemy heads.
     * Returns 0.1 .. 1.0.
     * @private
     */
    _computeSafety: function (x, y, enemyHeads) {
      var safety = 1.0;
      var MathUtil = SP.MathUtil;

      for (var i = 0; i < enemyHeads.length; i++) {
        var e = enemyHeads[i];
        var dist = MathUtil.distance(x, y, e.x, e.y);
        if (dist < ENEMY_SAFETY_RADIUS) {
          var closeness = 1 - (dist / ENEMY_SAFETY_RADIUS);
          var dangerMult = 1.0 + (e.speed > 8 ? 0.3 : 0) + (e.length > 50 ? 0.3 : 0);
          safety -= ENEMY_SAFETY_PENALTY * closeness * dangerMult;
        }
      }

      return Math.max(MIN_SAFETY_FACTOR, safety);
    },

    /**
     * Check if the straight-line path from player to target is safe.
     * Returns a factor 0.2 .. 1.0 (1.0 = completely safe).
     * @private
     */
    _checkPathSafety: function (px, py, tx, ty, enemyHeads) {
      var MathUtil = SP.MathUtil;
      var pathSafety = 1.0;

      for (var step = 1; step <= PATH_CHECK_STEPS; step++) {
        var t = step / (PATH_CHECK_STEPS + 1);
        var checkX = px + (tx - px) * t;
        var checkY = py + (ty - py) * t;

        for (var i = 0; i < enemyHeads.length; i++) {
          var e = enemyHeads[i];
          var futureEX = e.x + Math.cos(e.angle) * e.speed * 3 * t;
          var futureEY = e.y + Math.sin(e.angle) * e.speed * 3 * t;

          var dist = MathUtil.distance(checkX, checkY, futureEX, futureEY);
          if (dist < PATH_CHECK_RADIUS) {
            pathSafety -= 0.25;
          } else if (dist < PATH_CHECK_RADIUS * 2) {
            pathSafety -= 0.08;
          }
        }
      }

      return Math.max(0.2, pathSafety);
    },

    /**
     * Reset waypoint state (call on death/restart).
     */
    resetWaypoints: function () {
      _waypoints = [];
      _waypointIndex = 0;
      _waypointScore = 0;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.FoodSeeker = FoodSeeker;
})();
