/**
 * Slither Pro -- Coil Detector Bot Module (v2 — Hardened Survival).
 *
 * Detects enemy coil/encirclement attempts and finds offensive coil
 * opportunities:
 *
 *   DEFENSIVE (v8 rework):
 *     1. Uses CollisionAvoidance 16-sector data + minDist for tightness.
 *     2. Adaptive survival orbit: turn rate scales with coil tightness.
 *     3. Validated orbit direction with hysteresis (prevents thrashing).
 *     4. Gap opportunity detection: pivots to escape when gap widens.
 *     5. Urgency escalation: after 2s, lowers escape threshold.
 *     6. Wall-validated escape: probes 7 angles for clearest corridor.
 *     7. Gap-first escape: uses sector gap center, not "away from head".
 *
 *   OFFENSIVE (CONTENDER+ phase only):
 *     1. Target enemies < 55% our length within 450 units.
 *     2. Orbit at targetLength * 0.3 radius while boosting.
 *     3. Abandon conditions: third snake enters 250 units,
 *        our length drops below 2x target, or 10 seconds elapsed.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  /* ── Defensive tuning (v8 — hardened survival) ──────────── */
  var COIL_DETECT_ENCIRCLE_LEVEL  = 1;    // Minimum encirclement level to consider
  var COIL_CIRCLING_DIST          = 600;  // v8: Detect coilers earlier (was 500)
  var COIL_ESCAPE_BIAS            = 0.3;  // v8: Gap-based vector dominates (was 0.7)
  var COIL_BOOST_ESCAPE           = true; // Always boost when escaping a coil
  var COIL_SURVIVAL_GAP_THRESH    = 3;    // v8: Require 67.5° gap for escape (was 2)
  var COIL_SURVIVAL_TURN_RATE_MIN = 0.06; // v8: Loose coil orbit speed
  var COIL_SURVIVAL_TURN_RATE_MAX = 0.18; // v8: Tight coil orbit speed (3x faster)
  var COIL_GAP_PIVOT_THRESHOLD    = 4;    // v8: Pivot to escape when gap widens to 4 sectors (90°)
  var COIL_WALL_PROBE_ANGLES      = [0, 0.26, -0.26, 0.52, -0.52, 0.78, -0.78]; // 7 probes ~15° apart
  var COIL_SURVIVAL_URGENCY_FRAMES = 120; // v8: After 2s in survival, increase escape aggression
  var COIL_TIGHTNESS_ESCAPE_BOOST  = 0.6; // v8: If tightness > this, lower gap threshold by 1

  /* ── Offensive tuning ──────────────────────────────────── */
  var COIL_TARGET_SIZE_RATIO    = 0.55;  // v9: Target up to 55% our length (was 40%)
  var COIL_TARGET_MAX_DIST      = 450;   // v9: Start coil from further away (was 300)
  var COIL_TARGET_MIN_DIST      = 30;
  var COIL_ORBIT_RADIUS_FACTOR  = 0.40;  // v5c: wider orbit (was 0.35) — body clip deaths at 0.35
  var COIL_ORBIT_RADIUS_MIN     = 70;    // v5c: safer minimum (was 50) — 50 is inside body at tight orbits
  var COIL_ORBIT_RADIUS_MAX     = 220;   // v9: Accommodate larger targets (was 180)
  var COIL_MAX_DURATION         = 600;
  var COIL_THIRD_PARTY_DIST     = 250;   // v9: Only abort for close threats (was 400)
  var COIL_MIN_LENGTH_RATIO     = 2.0;
  var COIL_ORBIT_SPEED_MULT     = 0.07;  // v9: Full orbit in 1.5s (was 0.04)
  var COIL_ORBIT_CORRECTION_GAIN = 0.15;  // v9: Orbit position feedback correction
  var COIL_EARLY_WARNING_SECTORS = 4;     // v9: 4 consecutive sectors = developing coil
  var COIL_EARLY_WARNING_DIST    = 400;   // v9: Max distance for early warning snakes
  var COIL_TIGHTNESS_RATE_THRESHOLD = 0.02;  // v9: Rate above this = coil closing fast
  var COIL_TIGHTNESS_RATE_URGENCY   = 0.05;  // v9: Rate above this = extreme urgency

  /* ── Counter-kill tuning (v10) ──────────────────────────── */
  var COIL_COUNTER_KILL_MAX_ANGLE  = 2.2;    // ~126° max turn to attempt counter-kill
  var COIL_COUNTER_KILL_LEAD       = 10;     // Frames ahead to project coiler's head
  var COIL_COUNTER_KILL_MAX_FRAMES = 25;     // Must reach intercept within this many frames
  var COIL_COUNTER_KILL_MIN_SURVIVAL = 15;   // Min frames in coil before attempting (~0.25s)

  /* ── State ─────────────────────────────────────────────── */

  // Defensive state
  var _coilThreat = null;   // {coilerId, escapeAngle, severity}
  var _survivalOrbitDir   = 0;    // v8: 1=CCW, -1=CW, 0=unset
  var _survivalFrameCount = 0;    // v8: frames spent in survival mode (urgency timer)
  var _prevTightness   = 0;    // v9: Previous frame tightness for rate tracking
  var _tightnessRate   = 0;    // v9: How fast the coil is closing

  // Offensive state
  var _coilAttack = null;   // {targetId, orbitAngle, startFrame, orbitRadius}

  var _settings = {};

  var CoilDetector = {

    /**
     * Initialize the module.
     */
    init: function (settings) {
      _settings = (settings && settings.bot) ? settings.bot : {};
      _coilThreat = null;
      _coilAttack = null;
    },

    /**
     * Update settings.
     */
    updateSettings: function (settings) {
      _settings = (settings && settings.bot) ? settings.bot : {};
    },

    /**
     * Reset all state (call on death/restart).
     */
    reset: function () {
      _coilThreat = null;
      _coilAttack = null;
      _survivalOrbitDir = 0;
      _survivalFrameCount = 0;
      _prevTightness = 0;
      _tightnessRate = 0;
    },

    /**
     * v12: Force-abort an active coil attack (called when safety breaks coil commitment).
     */
    abortCoilAttack: function () {
      _coilAttack = null;
    },

    /**
     * Main update — check for defensive coil threats and offensive opportunities.
     *
     * @param {object} playerSnake    - from GameAPI
     * @param {Array}  nearbySnakes   - from GameAPI
     * @param {object} avoidanceResult - from CollisionAvoidance (may be null)
     * @param {number} frameCounter   - current frame
     * @returns {{defensive: object|null, offensive: object|null}}
     */
    update: function (playerSnake, nearbySnakes, avoidanceResult, frameCounter) {
      if (!playerSnake) {
        return { defensive: null, offensive: null };
      }

      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;
      var Strategy = SP.StrategyManager;
      var coilEnabled = _settings.coilDetection !== false;

      // ── DEFENSIVE: detect enemy coil attempts ──────────────
      _coilThreat = null;
      if (coilEnabled && Tracker && avoidanceResult) {
        _coilThreat = this._detectCoilThreat(
          playerSnake, nearbySnakes, avoidanceResult, frameCounter
        );
      }

      // ── OFFENSIVE: find coil opportunities ─────────────────
      // Only for PREDATOR/APEX phases, and only if not under threat
      var canCoilAttack = false;
      if (coilEnabled && Strategy && !_coilThreat) {
        var phase = Strategy.getPhase();
        var params = Strategy.getParams();
        if ((phase === 'CONTENDER' || phase === 'PREDATOR' || phase === 'APEX') && params && params.aggressionLevel >= 0.4) {
          canCoilAttack = true;
        }
      }

      if (canCoilAttack) {
        _coilAttack = this._updateCoilAttack(
          playerSnake, nearbySnakes, frameCounter
        );
      } else {
        _coilAttack = null;
      }

      return {
        defensive: _coilThreat,
        offensive: _coilAttack
      };
    },

    /**
     * Get current defensive coil threat (for external consumers).
     */
    getCoilThreat: function () {
      return _coilThreat;
    },

    /**
     * Get current offensive coil attack (for external consumers).
     */
    getCoilAttack: function () {
      return _coilAttack;
    },

    /* ═══════════════════════════════════════════════════════════
     *  DEFENSIVE: Detect enemy coil attempts
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Detect if we're being encircled.
     *
     * v6: No longer requires SnakeTracker CIRCLING classification —
     * encirclement sector data alone is enough. Reacts immediately.
     *
     * Two modes:
     *   ESCAPE: Gap exists (>= 2 empty sectors) → boost through widest gap
     *   SURVIVAL: No gap (< 2 empty sectors) → orbit in place to survive
     *
     * @private
     * @returns {object|null} {escapeAngle, severity, shouldBoost, survivalMode, survivalAngle}
     */
    _detectCoilThreat: function (playerSnake, nearbySnakes, avoidResult, frameCounter) {
      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;

      // Need at least some encirclement signal
      var encircleLevel = avoidResult.encircleLevel || 0;
      if (encircleLevel < COIL_DETECT_ENCIRCLE_LEVEL) {
        // v9: Check for developing coil before full encirclement
        var earlyWarning = this._checkEarlyCoilWarning(avoidResult, nearbySnakes, playerSnake);
        if (!earlyWarning) return null;
      }

      var severity = encircleLevel; // 1-3

      // v6: Check gap width from encirclement sector data
      var gapWidth = this._getGapWidth(avoidResult);

      // v6: Boost CIRCLING classification to increase severity if present
      if (Tracker) {
        var allTracked = Tracker.getAllTracked();
        for (var i = 0; i < allTracked.length; i++) {
          var entry = allTracked[i];
          if (entry.behavior !== 'CIRCLING') continue;
          var pos = entry.positions.get(0);
          if (!pos) continue;
          var dist = MathUtil.distance(playerSnake.x, playerSnake.y, pos.x, pos.y);
          if (dist < COIL_CIRCLING_DIST) {
            severity = Math.max(severity, 2);
            if (entry.behaviorConfidence > 0.7) severity = 3;
            break;
          }
        }
      }

      // v8: Find closest coiler (used by both survival and escape)
      var coilerX = null;
      var coilerY = null;
      var coilerAngle = 0;
      var hasCoiler = false;

      for (var ci = 0; ci < nearbySnakes.length; ci++) {
        var snake = nearbySnakes[ci];
        if (!snake) continue;
        if ((snake.length || 10) > (playerSnake.length || 10) * 1.5) {
          var cdist = MathUtil.distance(playerSnake.x, playerSnake.y, snake.x, snake.y);
          if (cdist < COIL_CIRCLING_DIST) {
            coilerX = snake.x;
            coilerY = snake.y;
            coilerAngle = snake.angle || 0;
            hasCoiler = true;
            break;
          }
        }
      }

      // v8: Check for gap opportunity BEFORE committing to survival
      // Even if gap is below normal threshold, urgency/tightness can lower it
      var gapOpp = this._checkGapOpportunity(playerSnake, avoidResult);
      if (gapOpp && gapOpp.shouldPivot) {
        // Upgrade to ESCAPE mode — gap found!
        _survivalFrameCount = 0;
        _survivalOrbitDir = 0;
        var pivotAngle = this._wallValidatedEscape(
          playerSnake.x, playerSnake.y,
          gapOpp.escapeAngle, avoidResult
        );
        return {
          coilerId: null,
          escapeAngle: pivotAngle,
          severity: severity,
          shouldBoost: true,
          survivalMode: false,
          tightnessRate: _tightnessRate,
          gapWidth: gapOpp.gapWidth,
          coilerX: coilerX,
          coilerY: coilerY
        };
      }

      // v10: Counter-kill — boost across the coiler's path to kill it
      // When enclosed with no gap, try to cross in front of the coiler's
      // head so it runs into our trailing body. This is the most effective
      // slither.io defense against coiling.
      if (hasCoiler && _survivalFrameCount >= COIL_COUNTER_KILL_MIN_SURVIVAL) {
        var counterKill = this._checkCounterKill(playerSnake, nearbySnakes);
        if (counterKill) {
          _survivalOrbitDir = 0;
          return {
            coilerId: counterKill.coilerId,
            escapeAngle: counterKill.interceptAngle,
            severity: Math.max(severity, 2),
            shouldBoost: true,
            survivalMode: false,
            counterKill: true,
            tightnessRate: _tightnessRate,
            gapWidth: gapWidth,
            coilerX: coilerX,
            coilerY: coilerY
          };
        }
      }

      // ── SURVIVAL MODE: Fully enclosed (no usable gap) ──────
      if (gapWidth < COIL_SURVIVAL_GAP_THRESH && encircleLevel >= 2) {
        _survivalFrameCount++;

        var survivalAngle = this._computeSurvivalCircle(
          playerSnake, avoidResult
        );

        return {
          coilerId: null,
          escapeAngle: survivalAngle,
          severity: severity,
          shouldBoost: false,
          survivalMode: true,
          survivalAngle: survivalAngle,
          tightnessRate: _tightnessRate,
          gapWidth: gapWidth,
          coilerX: coilerX,
          coilerY: coilerY
        };
      }

      // ── ESCAPE MODE: Gap exists → boost through it ─────────
      _survivalFrameCount = 0;
      _survivalOrbitDir = 0;

      var escapeAngle;
      if (hasCoiler) {
        escapeAngle = this._computeCoilEscape(
          playerSnake.x, playerSnake.y,
          coilerX, coilerY, coilerAngle,
          avoidResult
        );
      } else {
        escapeAngle = Math.atan2(avoidResult.y || 0, avoidResult.x || 0);
      }

      return {
        coilerId: null,
        escapeAngle: escapeAngle,
        severity: severity,
        shouldBoost: COIL_BOOST_ESCAPE || severity >= 2,
        survivalMode: false,
        tightnessRate: _tightnessRate,
        gapWidth: gapWidth,
        coilerX: coilerX,
        coilerY: coilerY
      };
    },

    /**
     * Get the widest gap (in sectors) from collision avoidance data.
     * @private
     * @returns {number} number of empty contiguous sectors in widest gap
     */
    _getGapWidth: function (avoidResult) {
      // Try to get encircle data from CollisionAvoidance
      var CA = SP.CollisionAvoidance;
      if (!CA || !CA.getLastEncircleData) return 16; // no data = assume open

      var data = CA.getLastEncircleData();
      if (!data || !data.sectors) return 16;

      var N = data.sectors.length;
      var bestLen = 0;
      var curLen = 0;

      for (var i = 0; i < N * 2; i++) {
        var idx = i % N;
        if (data.sectors[idx] === 0) {
          curLen++;
          if (curLen > bestLen) bestLen = curLen;
        } else {
          curLen = 0;
        }
      }

      return Math.min(bestLen, N);
    },

    /**
     * v8: Adaptive survival orbit with validated direction and urgency.
     *
     * 1. Estimate coil tightness from occupied sectors + minDist data.
     * 2. Scale turn rate inversely with available space.
     * 3. Validate orbit direction (CW vs CCW) by counting clear sectors ahead.
     * 4. Lock direction with 2-sector hysteresis to prevent thrashing.
     *
     * @private
     * @returns {number} target angle for survival orbit
     */
    _computeSurvivalCircle: function (playerSnake, avoidResult) {
      var pAng = playerSnake.angle || 0;
      var CA = SP.CollisionAvoidance;
      var data = CA && CA.getLastEncircleData ? CA.getLastEncircleData() : null;

      if (!data || !data.sectors) {
        return pAng + COIL_SURVIVAL_TURN_RATE_MIN * 8;
      }

      var N = data.sectors.length;

      // ── Step 1: Estimate tightness ──────────────────────────
      var occupied = 0;
      var totalMinDist = 0;
      var minDistCount = 0;
      for (var ti = 0; ti < N; ti++) {
        if (data.sectors[ti] > 0) {
          occupied++;
          if (data.minDist && data.minDist[ti] < Infinity) {
            totalMinDist += data.minDist[ti];
            minDistCount++;
          }
        }
      }
      var sectorTightness = occupied / N; // 0-1
      // Distance tightness: closer walls = tighter (scale 0-1 over 200 units)
      var avgWallDist = minDistCount > 0 ? totalMinDist / minDistCount : 200;
      var distTightness = Math.max(0, Math.min(1, 1 - (avgWallDist / 200)));
      // Combined tightness (weight both signals)
      var tightness = sectorTightness * 0.6 + distTightness * 0.4;

      // v9: Track tightness rate — how fast is the coil closing?
      _tightnessRate = tightness - _prevTightness;
      _prevTightness = tightness;
      if (_tightnessRate > COIL_TIGHTNESS_RATE_THRESHOLD) {
        _survivalFrameCount = Math.max(
          _survivalFrameCount,
          Math.floor(COIL_SURVIVAL_URGENCY_FRAMES * 0.7)
        );
      }
      if (_tightnessRate > COIL_TIGHTNESS_RATE_URGENCY) {
        _survivalFrameCount = COIL_SURVIVAL_URGENCY_FRAMES;
      }

      // ── Step 2: Adaptive turn rate ──────────────────────────
      var turnRate = COIL_SURVIVAL_TURN_RATE_MIN +
        (COIL_SURVIVAL_TURN_RATE_MAX - COIL_SURVIVAL_TURN_RATE_MIN) * tightness;

      // v9: Cap to physical max turn rate
      var MathUtil = SP.MathUtil;
      if (MathUtil && MathUtil.maxTurnRate) {
        var physicalMax = MathUtil.maxTurnRate(playerSnake.length || 10);
        turnRate = Math.min(turnRate, physicalMax);
        // If capped at physical max and coil is tight, force urgency
        if (turnRate >= physicalMax * 0.95 && tightness > COIL_TIGHTNESS_ESCAPE_BOOST) {
          _survivalFrameCount = Math.max(_survivalFrameCount, COIL_SURVIVAL_URGENCY_FRAMES);
        }
      }

      // ── Step 3: Validate orbit direction ────────────────────
      // Find which sector the player is heading into
      var headingSector = Math.floor(((pAng + Math.PI) / (2 * Math.PI)) * N) % N;

      // Count clear sectors in CCW arc (ahead-left: +1..+4)
      var leftClear = 0;
      for (var cl = 1; cl <= 4; cl++) {
        var sIdxL = (headingSector + cl) % N;
        if (data.sectors[sIdxL] === 0) leftClear++;
      }
      // Count clear sectors in CW arc (ahead-right: -1..-4)
      var rightClear = 0;
      for (var cr = 1; cr <= 4; cr++) {
        var sIdxR = (headingSector - cr + N) % N;
        if (data.sectors[sIdxR] === 0) rightClear++;
      }

      // ── Step 4: Lock direction with hysteresis ──────────────
      var preferredDir;
      if (_survivalOrbitDir === 0) {
        // First frame: pick best direction
        preferredDir = (leftClear >= rightClear) ? 1 : -1;
      } else {
        // Subsequent frames: only switch if other side is 2+ sectors better
        var currentClear = (_survivalOrbitDir === 1) ? leftClear : rightClear;
        var otherClear = (_survivalOrbitDir === 1) ? rightClear : leftClear;
        if (otherClear > currentClear + 2) {
          preferredDir = -_survivalOrbitDir;
        } else {
          preferredDir = _survivalOrbitDir;
        }
      }
      _survivalOrbitDir = preferredDir;

      // Target heading: look ahead 8 frames, but clamp output to one turn-step
      var targetAng = pAng + preferredDir * turnRate * 8;
      var delta = targetAng - pAng;
      while (delta > Math.PI) delta -= 2 * Math.PI;
      while (delta < -Math.PI) delta += 2 * Math.PI;
      delta = Math.max(-turnRate, Math.min(turnRate, delta));
      return pAng + delta;
    },

    /**
     * v8: Check if a gap opportunity exists for escape pivot.
     * Considers urgency (time in survival) and tightness (how enclosed).
     *
     * @private
     * @returns {object|null} {shouldPivot, escapeAngle, gapWidth}
     */
    _checkGapOpportunity: function (playerSnake, avoidResult) {
      var CA = SP.CollisionAvoidance;
      if (!CA || !CA.getLastEncircleData) return null;

      var data = CA.getLastEncircleData();
      if (!data || !data.sectors) return null;

      var gapWidth = this._getGapWidth(avoidResult);
      var N = data.sectors.length;

      // Compute tightness for dynamic threshold
      var occupied = 0;
      for (var ti = 0; ti < N; ti++) {
        if (data.sectors[ti] > 0) occupied++;
      }
      var tightness = occupied / N;

      // Dynamic pivot threshold — lower when urgent or tight
      var pivotThreshold = COIL_GAP_PIVOT_THRESHOLD;
      if (_survivalFrameCount > COIL_SURVIVAL_URGENCY_FRAMES) {
        pivotThreshold = Math.max(2, pivotThreshold - 1);
      }
      if (tightness > COIL_TIGHTNESS_ESCAPE_BOOST) {
        pivotThreshold = Math.max(2, pivotThreshold - 1);
      }

      // v9: Closing fast → lower threshold
      if (_tightnessRate > COIL_TIGHTNESS_RATE_THRESHOLD) {
        pivotThreshold = Math.max(2, pivotThreshold - 1);
      }

      if (gapWidth >= pivotThreshold) {
        var gapAngle = CA._findEncircleEscape(data, playerSnake.x, playerSnake.y, playerSnake.angle || 0);
        if (gapAngle !== null && gapAngle !== undefined) {
          return {
            shouldPivot: true,
            escapeAngle: gapAngle,
            gapWidth: gapWidth
          };
        }
      }

      return null;
    },

    /**
     * v10: Counter-kill — when enclosed, check if we can cross the coiler's
     * path and let it run into our body. In slither.io, this is the most
     * effective defense against coiling: boost across the coiler's heading
     * so our trailing body blocks its path.
     *
     * @private
     * @returns {object|null} {interceptAngle, coilerId, framesToReach}
     */
    _checkCounterKill: function (playerSnake, nearbySnakes) {
      var MathUtil = SP.MathUtil;
      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;
      var pSpeed = playerSnake.speed || 8;

      // Find the closest large snake that's encircling us
      var coiler = null;
      var coilerDist = Infinity;
      for (var i = 0; i < nearbySnakes.length; i++) {
        var s = nearbySnakes[i];
        if (!s) continue;
        if ((s.length || 10) <= (playerSnake.length || 10) * 1.5) continue;
        var d = MathUtil.distance(px, py, s.x, s.y);
        if (d < COIL_CIRCLING_DIST && d < coilerDist) {
          coiler = s;
          coilerDist = d;
        }
      }
      if (!coiler) return null;

      var cSpeed = coiler.speed || 8;
      var cAng = coiler.angle || 0;
      var cx = coiler.x;
      var cy = coiler.y;

      // Project the coiler's head position forward N frames
      var leadX = cx + Math.cos(cAng) * cSpeed * COIL_COUNTER_KILL_LEAD * 0.3;
      var leadY = cy + Math.sin(cAng) * cSpeed * COIL_COUNTER_KILL_LEAD * 0.3;

      // Aim to cross the coiler's path at the projected point
      var interceptAngle = Math.atan2(leadY - py, leadX - px);

      // Check turn feasibility — can we turn to that angle?
      var angleDiff = interceptAngle - pAng;
      while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
      while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
      if (Math.abs(angleDiff) > COIL_COUNTER_KILL_MAX_ANGLE) return null;

      // Check distance feasibility — can we reach while boosting?
      var distToLead = MathUtil.distance(px, py, leadX, leadY);
      var boostSpeed = pSpeed * 2;
      var framesToReach = distToLead / (boostSpeed * 0.3);
      if (framesToReach > COIL_COUNTER_KILL_MAX_FRAMES) return null;

      // Check physical turn radius — can the snake actually make this turn?
      if (MathUtil.framesToTurn) {
        var turnFrames = MathUtil.framesToTurn(Math.abs(angleDiff), playerSnake.length || 10);
        if (turnFrames > framesToReach * 0.8) return null;
      }

      return {
        interceptAngle: interceptAngle,
        coilerId: coiler.id,
        framesToReach: framesToReach
      };
    },

    /**
     * v8: Wall-validated escape direction.
     * Probes multiple angles around the candidate and picks the clearest corridor.
     *
     * @private
     * @param {number} px, py          - player position
     * @param {number} candidateAngle  - initial escape angle
     * @param {object} avoidResult     - from CollisionAvoidance
     * @returns {number} validated escape angle
     */
    _wallValidatedEscape: function (px, py, candidateAngle, avoidResult) {
      var CA = SP.CollisionAvoidance;
      var data = CA && CA.getLastEncircleData ? CA.getLastEncircleData() : null;
      if (!data || !data.sectors) return candidateAngle;

      var N = data.sectors.length;
      var bestAngle = candidateAngle;
      var bestClear = -1;

      for (var oi = 0; oi < COIL_WALL_PROBE_ANGLES.length; oi++) {
        var testAngle = candidateAngle + COIL_WALL_PROBE_ANGLES[oi];

        // Find the sector this angle maps to
        var sectorIdx = Math.floor(((testAngle + Math.PI) / (2 * Math.PI)) * N) % N;
        if (sectorIdx < 0) sectorIdx += N;

        // Count clear consecutive sectors centered on this direction (-2..+2)
        var clearCount = 0;
        for (var ci = -2; ci <= 2; ci++) {
          var idx = (sectorIdx + ci + N) % N;
          if (data.sectors[idx] === 0) clearCount++;
        }

        if (clearCount > bestClear) {
          bestClear = clearCount;
          bestAngle = testAngle;
        }

        // Perfect corridor found — stop searching
        if (clearCount === 5) break;
      }

      return bestAngle;
    },

    /**
     * v8: Compute escape angle using gap-first approach with wall validation.
     *
     * Primary direction: widest gap from CollisionAvoidance sector data.
     * Secondary bias: lightly blend "away from coiler head" (30%).
     * Final: wall-validate the blended angle for safest corridor.
     *
     * @private
     * @param {number} px, py         - player position
     * @param {number} cx, cy, cAngle - coiler position and heading
     * @param {object} avoidResult    - from CollisionAvoidance
     * @returns {number} escape angle in radians
     */
    _computeCoilEscape: function (px, py, cx, cy, cAngle, avoidResult) {
      var CA = SP.CollisionAvoidance;
      var data = CA && CA.getLastEncircleData ? CA.getLastEncircleData() : null;

      // Primary: gap center angle from sector data
      var gapAngle;
      if (data) {
        gapAngle = CA._findEncircleEscape(data, px, py, 0);
      }
      if (gapAngle === null || gapAngle === undefined) {
        gapAngle = Math.atan2(avoidResult.y || 0, avoidResult.x || 0);
      }

      // Secondary: light coiler-head bias (only 30% now)
      var coilerForwardX = Math.cos(cAngle);
      var coilerForwardY = Math.sin(cAngle);
      var idealX = -coilerForwardX;
      var idealY = -coilerForwardY;

      var gapX = Math.cos(gapAngle);
      var gapY = Math.sin(gapAngle);

      // Blend: gap dominates (70%), coiler-head bias is secondary (30%)
      var blendX = idealX * COIL_ESCAPE_BIAS + gapX * (1 - COIL_ESCAPE_BIAS);
      var blendY = idealY * COIL_ESCAPE_BIAS + gapY * (1 - COIL_ESCAPE_BIAS);
      var blendAngle = Math.atan2(blendY, blendX);

      // Wall-validate the blended direction
      return this._wallValidatedEscape(px, py, blendAngle, avoidResult);
    },

    /**
     * v9: Detect developing coil threat before full encirclement.
     * Looks for consecutive occupied sectors + CIRCLING enemy nearby.
     * @private
     */
    _checkEarlyCoilWarning: function (avoidResult, nearbySnakes, playerSnake) {
      var CA = SP.CollisionAvoidance;
      if (!CA || !CA.getLastEncircleData) return false;
      var data = CA.getLastEncircleData();
      if (!data || !data.sectors) return false;

      var N = data.sectors.length;
      var bestRun = 0;
      var curRun = 0;
      for (var i = 0; i < N * 2; i++) {
        var idx = i % N;
        if (data.sectors[idx] > 0) {
          curRun++;
          if (curRun > bestRun) bestRun = curRun;
        } else {
          curRun = 0;
        }
      }
      bestRun = Math.min(bestRun, N);
      if (bestRun < COIL_EARLY_WARNING_SECTORS) return false;

      // Verify: is there a nearby snake with CIRCLING behavior?
      var Tracker = SP.SnakeTracker;
      var MathUtil = SP.MathUtil;
      if (!Tracker || !MathUtil) return false;
      var allTracked = Tracker.getAllTracked();
      for (var ti = 0; ti < allTracked.length; ti++) {
        var entry = allTracked[ti];
        if (entry.behavior !== 'CIRCLING') continue;
        var pos = entry.positions ? entry.positions.get(0) : null;
        if (!pos) continue;
        var dist = MathUtil.distance(playerSnake.x, playerSnake.y, pos.x, pos.y);
        if (dist < COIL_EARLY_WARNING_DIST) return true;
      }
      return false;
    },

    /* ═══════════════════════════════════════════════════════════
     *  OFFENSIVE: Coil attack on small enemies
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Find or continue a coil attack on a smaller enemy.
     *
     * @private
     * @returns {object|null} {targetId, targetX, targetY, orbitX, orbitY,
     *                         orbitAngle, shouldBoost, isActive}
     */
    _updateCoilAttack: function (playerSnake, nearbySnakes, frameCounter) {
      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;
      var px = playerSnake.x;
      var py = playerSnake.y;

      // ── Check if existing coil attack should continue ──────
      if (_coilAttack && _coilAttack.isActive) {
        var shouldAbort = this._checkCoilAbort(
          playerSnake, nearbySnakes, _coilAttack, frameCounter
        );
        if (shouldAbort) {
          _coilAttack = null;
        } else {
          // Continue orbit
          return this._advanceOrbit(playerSnake, _coilAttack, frameCounter);
        }
      }

      // ── Look for new coil target ───────────────────────────
      if (!_settings.killAttempts) return null;

      var bestTarget = null;
      var bestScore = 0;

      for (var i = 0; i < nearbySnakes.length; i++) {
        var enemy = nearbySnakes[i];
        if (!enemy) continue;

        // Size check: must be much smaller
        if (enemy.length >= playerSnake.length * COIL_TARGET_SIZE_RATIO) continue;

        // Distance check
        var dist = MathUtil.distance(px, py, enemy.x, enemy.y);
        if (dist > COIL_TARGET_MAX_DIST || dist < COIL_TARGET_MIN_DIST) continue;

        // Check behavior — don't coil aggressive or erratic snakes (unpredictable)
        if (Tracker) {
          var tracked = Tracker.getTracked(enemy.id);
          if (tracked) {
            if (tracked.behavior === 'AGGRESSIVE') continue;
            if (tracked.behavior === 'ERRATIC') continue;
          }
        }

        // Check for third-party snakes nearby (makes coil risky)
        var thirdPartyClose = false;
        for (var j = 0; j < nearbySnakes.length; j++) {
          if (j === i) continue;
          var other = nearbySnakes[j];
          if (!other) continue;
          var otherDist = MathUtil.distance(other.x, other.y, enemy.x, enemy.y);
          if (otherDist < COIL_THIRD_PARTY_DIST) {
            thirdPartyClose = true;
            break;
          }
        }
        if (thirdPartyClose) continue;

        // v9: Score: size advantage 65%, closeness 35%, TOD 30% blend
        var closeness = 1 - (dist / COIL_TARGET_MAX_DIST);
        var sizeAdvantage = 1 - (enemy.length / (playerSnake.length * COIL_TARGET_SIZE_RATIO));

        // TOD factor — penalize distant targets based on time to reach
        var todFactor = 1.0;
        if (MathUtil.framesToReach) {
          var framesToTarget = MathUtil.framesToReach(dist, playerSnake.speed || 8, false);
          todFactor = Math.max(0.3, 1.0 - framesToTarget / 120);
        }

        var baseScore = closeness * 0.35 + sizeAdvantage * 0.65;
        var score = baseScore * 0.7 + todFactor * 0.3;

        // Bonus for overwhelming size advantage (4x+)
        if (enemy.length > 0 && (playerSnake.length / enemy.length) >= 4.0) {
          score *= 1.3;
        }

        if (score > bestScore) {
          bestScore = score;
          var orbitRadius = MathUtil.clamp(
            (enemy.length || 10) * COIL_ORBIT_RADIUS_FACTOR,
            COIL_ORBIT_RADIUS_MIN,
            COIL_ORBIT_RADIUS_MAX
          );

          // v9: Floor orbit radius to minimum turning radius
          if (MathUtil.minTurningRadius) {
            var pBoostSpeed = (playerSnake.speed || 8) * 2.0;
            var minOrbitRadius = MathUtil.minTurningRadius(pBoostSpeed, playerSnake.length || 10) * 1.2;
            orbitRadius = Math.max(orbitRadius, minOrbitRadius);
            // If required orbit is too wide, skip this target
            if (orbitRadius > COIL_ORBIT_RADIUS_MAX * 1.5) continue;
          }

          // Initial orbit angle: from target to player
          var initAngle = MathUtil.angle(enemy.x, enemy.y, px, py);

          bestTarget = {
            targetId: enemy.id,
            targetX: enemy.x,
            targetY: enemy.y,
            orbitRadius: orbitRadius,
            orbitAngle: initAngle,
            startFrame: frameCounter,
            isActive: true,
            shouldBoost: true,
            orbitX: enemy.x + Math.cos(initAngle) * orbitRadius,
            orbitY: enemy.y + Math.sin(initAngle) * orbitRadius,
            score: score
          };
        }
      }

      return bestTarget;
    },

    /**
     * Check if we should abort the current coil attack.
     *
     * Abort conditions:
     *   1. Third snake enters 400 units of the target
     *   2. Our length drops below 2x target's length
     *   3. Duration exceeds 10 seconds
     *   4. Target disappeared or got too far
     *
     * @private
     * @returns {boolean} true = should abort
     */
    _checkCoilAbort: function (playerSnake, nearbySnakes, coilAttack, frameCounter) {
      var MathUtil = SP.MathUtil;

      // Duration limit
      if (frameCounter - coilAttack.startFrame > COIL_MAX_DURATION) return true;

      // Find target snake
      var target = null;
      for (var i = 0; i < nearbySnakes.length; i++) {
        if (nearbySnakes[i] && nearbySnakes[i].id === coilAttack.targetId) {
          target = nearbySnakes[i];
          break;
        }
      }

      // Target disappeared
      if (!target) return true;

      // Target too far
      var dist = MathUtil.distance(playerSnake.x, playerSnake.y, target.x, target.y);
      if (dist > COIL_TARGET_MAX_DIST * 2) return true;

      // Our length too small relative to target
      if (playerSnake.length < target.length * COIL_MIN_LENGTH_RATIO) return true;

      // v9: Abort if orbit has tightened below minimum turning radius
      if (MathUtil && MathUtil.minTurningRadius) {
        var elapsed = frameCounter - coilAttack.startFrame;
        var tightenFactor = Math.max(0.75, 1.0 - (elapsed / COIL_MAX_DURATION) * 0.25); // v5c: safer orbit floor
        var currentRadius = coilAttack.orbitRadius * tightenFactor;
        var pSpeed = (playerSnake.speed || 8) * 2.0;
        var minRadius = MathUtil.minTurningRadius(pSpeed, playerSnake.length || 10);
        if (currentRadius < minRadius) return true;
      }

      // Third-party snake check
      for (var j = 0; j < nearbySnakes.length; j++) {
        var other = nearbySnakes[j];
        if (!other || other.id === coilAttack.targetId) continue;
        var otherDist = MathUtil.distance(other.x, other.y, target.x, target.y);
        if (otherDist < COIL_THIRD_PARTY_DIST) return true;
      }

      // v5c: Body proximity abort — check body parts along our orbit path.
      // During coil the bot follows a curved path. Straight-line corridor scans
      // miss body parts that the curved path will hit. Check body parts within
      // 40 units of our head — wider than Layer 0 (25) because we're actively
      // curving toward the inner side of the orbit.
      var coilProxDist = 40;
      var coilProxDistSq = coilProxDist * coilProxDist;
      for (var bp = 0; bp < nearbySnakes.length; bp++) {
        var bpSnake = nearbySnakes[bp];
        if (!bpSnake || !bpSnake.bodyParts) continue;
        for (var bk = 0; bk < bpSnake.bodyParts.length; bk += 3) {
          var bPart = bpSnake.bodyParts[bk];
          if (!bPart) continue;
          var bpdx = bPart.x - playerSnake.x;
          var bpdy = bPart.y - playerSnake.y;
          var bpdSq = bpdx * bpdx + bpdy * bpdy;
          if (bpdSq < coilProxDistSq && bpdSq > 4) return true;
        }
      }

      return false;
    },

    /**
     * Advance the orbit for an active coil attack.
     * Updates the orbit position to circle around the target.
     *
     * @private
     * @returns {object} updated coil attack state
     */
    _advanceOrbit: function (playerSnake, coilAttack, frameCounter) {
      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;

      // Get latest target position
      var targetX = coilAttack.targetX;
      var targetY = coilAttack.targetY;

      if (Tracker) {
        var tracked = Tracker.getTracked(coilAttack.targetId);
        if (tracked) {
          var pos = tracked.positions.get(0);
          if (pos) {
            targetX = pos.x;
            targetY = pos.y;
          }
        }
      }

      // v9: Cap orbit speed to physical max turn rate
      var orbitSpeed = COIL_ORBIT_SPEED_MULT;
      if (MathUtil && MathUtil.maxTurnRate) {
        var physicalMaxTurn = MathUtil.maxTurnRate(playerSnake.length || 10);
        orbitSpeed = Math.min(orbitSpeed, physicalMaxTurn * 0.9);
      }

      coilAttack.orbitAngle += orbitSpeed;
      if (coilAttack.orbitAngle > Math.PI * 2) {
        coilAttack.orbitAngle -= Math.PI * 2;
      }

      var elapsed = frameCounter - coilAttack.startFrame;
      var tightenFactor = Math.max(0.75, 1.0 - (elapsed / COIL_MAX_DURATION) * 0.25); // v5c: safer orbit floor
      var currentRadius = coilAttack.orbitRadius * tightenFactor;

      // v9: Turn-radius-aware orbit radius floor
      if (MathUtil && MathUtil.minTurningRadius) {
        var pSpeed = (playerSnake.speed || 8) * 2.0; // boosting during coil
        var minRadius = MathUtil.minTurningRadius(pSpeed, playerSnake.length || 10) * 1.2;
        currentRadius = Math.max(currentRadius, minRadius);
      }

      // v9: Position correction feedback loop
      var idealOrbitX = targetX + Math.cos(coilAttack.orbitAngle) * currentRadius;
      var idealOrbitY = targetY + Math.sin(coilAttack.orbitAngle) * currentRadius;

      if (MathUtil) {
        var actualDistToTarget = MathUtil.distance(playerSnake.x, playerSnake.y, targetX, targetY);
        var radiusError = actualDistToTarget - currentRadius;
        var correctionRadius = currentRadius - radiusError * COIL_ORBIT_CORRECTION_GAIN;
        correctionRadius = MathUtil.clamp(correctionRadius, currentRadius * 0.6, currentRadius * 1.5);
        coilAttack.orbitX = targetX + Math.cos(coilAttack.orbitAngle) * correctionRadius;
        coilAttack.orbitY = targetY + Math.sin(coilAttack.orbitAngle) * correctionRadius;
      } else {
        coilAttack.orbitX = idealOrbitX;
        coilAttack.orbitY = idealOrbitY;
      }

      // Update target position
      coilAttack.targetX = targetX;
      coilAttack.targetY = targetY;
      coilAttack.shouldBoost = true;

      return coilAttack;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.CoilDetector = CoilDetector;
})();
