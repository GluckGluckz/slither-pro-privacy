/**
 * Slither Pro -- ThreatMap (Bot AI v2).
 *
 * 16-sector directional threat grid replacing CollisionAvoidance's single
 * repulsion vector.  Every head prediction and body sample is binned into
 * the angular sector it occupies, giving all consumers (kill scorer, food
 * scorer, commitment engine) directional awareness.
 *
 * Preserves ALL existing computation from CollisionAvoidance v4:
 *   - 28-frame curved head prediction via SnakeTracker
 *   - Body sampling with dynamic step sizing
 *   - Behavior-aware weighting (AGGRESSIVE / PASSIVE / CIRCLING)
 *   - Size-based threat scaling (giant / large / bigger)
 *   - 16-sector encirclement with graduated response
 *   - Forward corridor body-wall detection
 *   - Perpendicular emergency escape with left/right mass
 *
 * New capabilities:
 *   - Per-sector head / body / total threat values (normalized 0–1)
 *   - Directional threat queries — getDirectionThreat(angle)
 *   - Arbitrary corridor checks — isPathClear(x1,y1,x2,y2,width)
 *   - Safest direction — getSafestDirection()
 *
 * Backward-compatible: also registers as SP.CollisionAvoidance with
 * computeAvoidance(), getLastEncircleData(), scanForward(), THREAT.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP || !SP.MathUtil) {
    console.error('[SlitherPro] ThreatMap: missing dependencies');
    return;
  }

  /* ── Threat type constants ──────────────────────────────── */
  var THREAT = {
    HEAD_ON:      'HEAD_ON',
    CROSSING:     'CROSSING',
    FLANKING:     'FLANKING',
    BODY_WALL:    'BODY_WALL',
    ENCIRCLEMENT: 'ENCIRCLEMENT'
  };

  /* ── Sector constants ──────────────────────────────────── */
  var SECTOR_COUNT = 16;                   // 22.5° per sector
  var TWO_PI       = 2 * Math.PI;
  var SECTOR_ANGLE = TWO_PI / SECTOR_COUNT;

  /* ── Normalization references ──────────────────────────── */
  // Raw accumulated strengths per sector vary widely.  These references
  // map to normalized 1.0 — values above are clamped.
  var HEAD_THREAT_REF = 50.0;
  var BODY_THREAT_REF = 30.0;

  /* ── Tuning knobs (identical to CollisionAvoidance v4) ── */
  var HEAD_LOOK_AHEAD_FRAMES = 28;
  var FORWARD_SCAN_DISTANCE  = 450;
  var FORWARD_SCAN_WIDTH     = 160;
  var EMERGENCY_DISTANCE     = 140;
  var HEAD_WEIGHT            = 6.0;
  var BODY_WEIGHT            = 1.5;
  var SPEED_DANGER_SCALE     = 0.3;
  var BODY_WALL_SAMPLE_STEP  = 2;
  var CLOSE_BODY_PANIC_MULT  = 4.0;
  var CLOSE_BODY_THRESHOLD   = 0.35;

  var ENCIRCLE_SECTOR_COUNT     = 16;
  var ENCIRCLE_CAUTION_SECTORS  = 7;
  var ENCIRCLE_DANGER_SECTORS   = 10;
  var ENCIRCLE_EMERGENCY_SECTORS = 12;

  var AGGRESSIVE_THREAT_MULT   = 2.2;
  var PASSIVE_THREAT_REDUCTION = 0.7;

  var SIZE_GIANT_RATIO       = 3.0;
  var SIZE_LARGE_RATIO       = 2.0;
  var SIZE_BIGGER_RATIO      = 1.5;
  var SIZE_GIANT_MULT        = 2.5;
  var SIZE_LARGE_MULT        = 1.8;
  var SIZE_BIGGER_MULT       = 1.3;
  var SIZE_GIANT_RADIUS_MULT = 2.0;

  var PLAYER_STEER_RATE = 0.1;

  var EMERGENCY_MAG_THRESHOLD = 25.0;

  /* ══════════════════════════════════════════════════════════
   *  Helper functions (same as CollisionAvoidance v4)
   * ══════════════════════════════════════════════════════════ */

  function angleDiff(a, b) {
    var d = b - a;
    while (d > Math.PI)  d -= TWO_PI;
    while (d < -Math.PI) d += TWO_PI;
    return d;
  }

  function pointInCorridor(px, py, ox, oy, ang, len, halfW) {
    var dx = px - ox;
    var dy = py - oy;
    var cosA = Math.cos(ang);
    var sinA = Math.sin(ang);
    var forward = dx * cosA + dy * sinA;
    var lateral = -dx * sinA + dy * cosA;
    return forward > 0 && forward < len && Math.abs(lateral) < halfW;
  }

  function predictPlayerPos(px, py, pAng, wantedAngle, pSpeed, frames) {
    var x = px;
    var y = py;
    var ang = pAng;
    var turnRate = angleDiff(pAng, wantedAngle || pAng) * PLAYER_STEER_RATE;
    for (var f = 0; f < frames; f++) {
      ang += turnRate;
      x += Math.cos(ang) * pSpeed;
      y += Math.sin(ang) * pSpeed;
      turnRate *= 0.9;
    }
    return { x: x, y: y, angle: ang };
  }

  function getBehaviorMult(snakeId) {
    var Tracker = SP.SnakeTracker;
    if (!Tracker) return 1.0;
    var entry = Tracker.getTracked(snakeId);
    if (!entry) return 1.0;
    if (entry.behavior === Tracker.BEHAVIOR.AGGRESSIVE) return AGGRESSIVE_THREAT_MULT;
    if (entry.behavior === Tracker.BEHAVIOR.PASSIVE) return PASSIVE_THREAT_REDUCTION;
    if (entry.behavior === Tracker.BEHAVIOR.CIRCLING) return 1.3;
    return 1.0;
  }

  /**
   * Map an angle (any range) to a sector index 0..15.
   * Uses the same convention as the old encirclement code:
   *   sector = floor(((angle + PI) / (2 PI)) * 16) % 16
   * Sector 0 ≈ angle -PI (left), sector 8 ≈ angle 0 (right).
   */
  function angleToSector(angle) {
    var raw = Math.floor(((angle + Math.PI) / TWO_PI) * SECTOR_COUNT) % SECTOR_COUNT;
    return ((raw % SECTOR_COUNT) + SECTOR_COUNT) % SECTOR_COUNT;
  }

  /**
   * Center angle of a sector (range -PI .. +PI).
   */
  function sectorToAngle(sector) {
    return ((sector + 0.5) / SECTOR_COUNT) * TWO_PI - Math.PI;
  }

  /**
   * Check if snakeId is already in the array (simple linear scan — cheap for ≤30 snakes).
   */
  function addUniqueId(arr, id) {
    for (var k = 0; k < arr.length; k++) {
      if (arr[k] === id) return;
    }
    arr.push(id);
  }

  /* ══════════════════════════════════════════════════════════
   *  Internal state
   * ══════════════════════════════════════════════════════════ */
  var _lastResult         = null;
  var _lastCompatVector   = null;
  var _lastEncircleData   = null;
  var _lastNearbySnakes   = null;
  var _lastPlayerX        = 0;
  var _lastPlayerY        = 0;

  /* ══════════════════════════════════════════════════════════
   *  ThreatMap module
   * ══════════════════════════════════════════════════════════ */
  var ThreatMap = {

    /* ── Sector initialization ─────────────────────────────── */

    _initSectors: function () {
      var sectors = [];
      for (var i = 0; i < SECTOR_COUNT; i++) {
        sectors.push({
          headThreat:   0.0,    // raw accumulated head strength
          bodyThreat:   0.0,    // raw accumulated body strength
          totalThreat:  0.0,    // normalized 0–1 after finalization
          closestDist:  Infinity,
          closingSpeed: 0.0,
          threatType:   null,
          snakeIds:     []
        });
      }
      return sectors;
    },

    _initEncircleData: function () {
      var sectors = [];
      var minDist = [];
      for (var i = 0; i < ENCIRCLE_SECTOR_COUNT; i++) {
        sectors.push(0);
        minDist.push(Infinity);
      }
      return { sectors: sectors, minDist: minDist, totalNear: 0 };
    },

    /* ══════════════════════════════════════════════════════════
     *  compute() — main entry point, called once per frame
     * ══════════════════════════════════════════════════════════ */

    /**
     * Build the 16-sector threat map from all nearby snakes.
     *
     * @param {object} playerSnake    - from GameAPI.getPlayerSnake()
     * @param {Array}  nearbySnakes   - from GameAPI.getNearbySnakes()
     * @param {number} avoidanceRadius
     * @returns {object} threat map result (never null)
     */
    compute: function (playerSnake, nearbySnakes, avoidanceRadius) {
      var snakes = nearbySnakes;

      // Always return a valid result even with no data
      if (!playerSnake || !snakes || snakes.length === 0) {
        var empty = this._buildEmptyResult();
        _lastResult = empty;
        _lastCompatVector = null;
        _lastEncircleData = this._initEncircleData();
        _lastNearbySnakes = snakes || [];
        return empty;
      }

      var MathUtil = SP.MathUtil;
      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;
      var pWant = playerSnake.wantedAngle || pAng;
      var pSpeed = playerSnake.speed || 8;
      var pThick = playerSnake.thickness || 1;
      var playerLength = playerSnake.length || 10;
      var avoidSq = avoidanceRadius * avoidanceRadius;

      var cosP = Math.cos(pAng);
      var sinP = Math.sin(pAng);

      // ── Initialize sector grid + compat accumulators ──────
      var sectors = this._initSectors();
      var encircleData = this._initEncircleData();

      // Compat: old-style single repulsion vector
      var repX = 0, repY = 0;
      var threatCount = 0;
      var emergency = false;
      var dominantThreat = null;
      var dominantWeight = 0;
      var leftThreats = 0, rightThreats = 0;

      // Boost-aware forward scan
      var effectiveScanDist = FORWARD_SCAN_DISTANCE;
      var effectiveScanWidth = FORWARD_SCAN_WIDTH;
      if (pSpeed > 10) {
        var boostScale = 1.0 + (pSpeed - 10) * 0.1;
        effectiveScanDist = Math.round(effectiveScanDist * boostScale);
        effectiveScanWidth = Math.round(effectiveScanWidth * boostScale);
      }

      // ── Per-snake evaluation ──────────────────────────────
      for (var i = 0; i < snakes.length; i++) {
        var snake = snakes[i];
        if (!snake || snake.x == null || snake.y == null) continue;

        var eSpeed = snake.speed || 8;
        var eAng   = snake.angle || 0;
        var eThick = snake.thickness || 1;

        var speedMult = 1.0 + Math.max(0, (eSpeed - 6) * SPEED_DANGER_SCALE);
        var behaviorMult = getBehaviorMult(snake.id);

        // Size-based threat scaling
        var sizeRatio = (snake.length || 10) / playerLength;
        var sizeMult = 1.0;
        var effectiveAvoidRadius = avoidanceRadius;
        var effectiveAvoidSq = avoidSq;
        if (sizeRatio >= SIZE_GIANT_RATIO) {
          sizeMult = SIZE_GIANT_MULT;
          effectiveAvoidRadius = avoidanceRadius * SIZE_GIANT_RADIUS_MULT;
          effectiveAvoidSq = effectiveAvoidRadius * effectiveAvoidRadius;
        } else if (sizeRatio >= SIZE_LARGE_RATIO) {
          sizeMult = SIZE_LARGE_MULT;
          effectiveAvoidRadius = avoidanceRadius * 1.3;
          effectiveAvoidSq = effectiveAvoidRadius * effectiveAvoidRadius;
        } else if (sizeRatio >= SIZE_BIGGER_RATIO) {
          sizeMult = SIZE_BIGGER_MULT;
        }

        // ── 1. HEAD THREAT ────────────────────────────────
        var headResults = this._evaluateHead(
          sectors, snake.id,
          px, py, pAng, pWant, pSpeed, pThick,
          snake, eSpeed, eAng, eThick,
          effectiveAvoidRadius, effectiveAvoidSq,
          speedMult * sizeMult, behaviorMult,
          cosP, sinP
        );

        if (headResults) {
          repX += headResults.rx;
          repY += headResults.ry;
          threatCount += headResults.count;
          if (headResults.emergency) emergency = true;
          if (headResults.weight > dominantWeight) {
            dominantWeight = headResults.weight;
            dominantThreat = headResults.type;
          }
          leftThreats  += headResults.leftMass;
          rightThreats += headResults.rightMass;
        }

        // ── 2. BODY PARTS ─────────────────────────────────
        if (snake.bodyParts) {
          var bodyResults = this._evaluateBody(
            sectors, encircleData, snake.id,
            px, py, pAng, pThick,
            snake.bodyParts, eThick,
            effectiveAvoidRadius, effectiveAvoidSq,
            cosP, sinP,
            behaviorMult * sizeMult,
            effectiveScanDist, effectiveScanWidth
          );

          if (bodyResults) {
            repX += bodyResults.rx;
            repY += bodyResults.ry;
            threatCount += bodyResults.count;
            if (bodyResults.weight > dominantWeight) {
              dominantWeight = bodyResults.weight;
              dominantThreat = bodyResults.type;
            }
            leftThreats  += bodyResults.leftMass;
            rightThreats += bodyResults.rightMass;
          }
        }
      }

      // Guard: no threats at all
      if (threatCount === 0) {
        var emptyRes = this._buildEmptyResult();
        _lastResult = emptyRes;
        _lastCompatVector = null;
        _lastEncircleData = encircleData;
        _lastNearbySnakes = snakes;
        _lastPlayerX = px;
        _lastPlayerY = py;
        return emptyRes;
      }

      // ── 3. ENCIRCLEMENT CHECK (graduated) ─────────────────
      var encircleLevel = this._checkEncirclement(encircleData, sectors);
      if (encircleLevel > 0) {
        var escapeAngle = this._findEncircleEscape(encircleData, px, py, pAng);
        if (escapeAngle !== null) {
          var encirclePush;
          if (encircleLevel >= 3) {
            encirclePush = 8.0;          // v5: was 4.0 — strong escape override
            emergency = true;
          } else if (encircleLevel >= 2) {
            encirclePush = 5.0;          // v5: was 2.5 — meaningful escape force
            emergency = true;            // v5: danger encirclement = emergency tier
          } else {
            encirclePush = 3.0;          // v5: was 2.0
          }
          repX += Math.cos(escapeAngle) * encirclePush;
          repY += Math.sin(escapeAngle) * encirclePush;
          if (encircleLevel >= 2) {
            dominantThreat = THREAT.ENCIRCLEMENT;
          }
        }
      }

      // ── 4. COMPAT: Emergency perpendicular escape ─────────
      if (emergency && dominantThreat !== THREAT.ENCIRCLEMENT) {
        var escapeSign = (leftThreats <= rightThreats) ? -1 : 1;
        var perpX = -sinP * escapeSign;
        var perpY =  cosP * escapeSign;
        var mag = Math.sqrt(repX * repX + repY * repY);
        if (mag > 0) {
          repX = perpX * 0.7 + (repX / mag) * 0.3;
          repY = perpY * 0.7 + (repY / mag) * 0.3;
        } else {
          repX = perpX;
          repY = perpY;
        }
      }

      var magnitude = Math.sqrt(repX * repX + repY * repY);

      // Magnitude-based emergency escalation
      if (!emergency && magnitude > EMERGENCY_MAG_THRESHOLD) {
        emergency = true;
      }

      // ── 5. FINALIZE SECTORS ───────────────────────────────
      var maxSectorThreat = 0;
      var dominantSectorIdx = 0;
      for (var s = 0; s < SECTOR_COUNT; s++) {
        var sec = sectors[s];
        // Normalize to 0–1 range
        var nh = Math.min(1.0, sec.headThreat / HEAD_THREAT_REF);
        var nb = Math.min(1.0, sec.bodyThreat / BODY_THREAT_REF);
        sec.headThreat = nh;
        sec.bodyThreat = nb;
        sec.totalThreat = Math.max(nh, nb);

        if (sec.totalThreat > maxSectorThreat) {
          maxSectorThreat = sec.totalThreat;
          dominantSectorIdx = s;
        }
      }

      // Emergency flag from sector data: any sector with closestDist < EMERGENCY_DISTANCE
      if (!emergency) {
        for (var se = 0; se < SECTOR_COUNT; se++) {
          if (sectors[se].closestDist < EMERGENCY_DISTANCE) {
            emergency = true;
            break;
          }
        }
      }

      // ── 6. BUILD ENCIRCLEMENT RESULT ──────────────────────
      var filledSectors = 0;
      for (var ef = 0; ef < SECTOR_COUNT; ef++) {
        if (sectors[ef].totalThreat > 0.1) filledSectors++;
      }
      var gapInfo = this._findWidestGapFromSectors(sectors);

      var encirclement = {
        filledSectors: filledSectors,
        level: encircleLevel === 0 ? 'none' :
               encircleLevel === 1 ? 'caution' :
               encircleLevel === 2 ? 'danger' : 'emergency',
        gapCenter: gapInfo.angle,
        gapWidth: gapInfo.width
      };

      // ── 7. BUILD RESULT ───────────────────────────────────
      var result = {
        sectors: sectors,
        encirclement: encirclement,
        emergency: emergency,
        dominantThreatAngle: sectorToAngle(dominantSectorIdx),
        maxSectorThreat: maxSectorThreat
      };

      // ── 8. CACHE FOR QUERIES ──────────────────────────────
      _lastResult = result;
      _lastEncircleData = encircleData;
      _lastNearbySnakes = snakes;
      _lastPlayerX = px;
      _lastPlayerY = py;

      // Compat vector
      _lastCompatVector = {
        x: repX,
        y: repY,
        magnitude: magnitude,
        emergency: emergency,
        threats: threatCount,
        dominantThreat: dominantThreat || THREAT.FLANKING,
        encircleLevel: encircleLevel
      };

      return result;
    },

    _buildEmptyResult: function () {
      return {
        sectors: this._initSectors(),
        encirclement: {
          filledSectors: 0,
          level: 'none',
          gapCenter: 0,
          gapWidth: SECTOR_COUNT
        },
        emergency: false,
        dominantThreatAngle: 0,
        maxSectorThreat: 0
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Head evaluation — curved prediction, bins into sectors
     * ══════════════════════════════════════════════════════════ */

    _evaluateHead: function (
      sectors, snakeId,
      px, py, pAng, pWant, pSpeed, pThick,
      snake, eSpeed, eAng, eThick,
      avoidRadius, avoidSq, speedMult, behaviorMult,
      cosP, sinP
    ) {
      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;
      var rx = 0, ry = 0;
      var count = 0;
      var maxWeight = 0;
      var type = THREAT.FLANKING;
      var isEmergency = false;
      var leftMass = 0, rightMass = 0;

      var boostEmergency = EMERGENCY_DISTANCE + Math.max(0, pSpeed - 8) * 8;

      var steps = HEAD_LOOK_AHEAD_FRAMES;
      for (var t = 0; t <= steps; t++) {
        // Curved prediction from SnakeTracker
        var futureEX, futureEY, futureEAng;
        var predicted = Tracker ? Tracker.predictPosition(snake.id, t) : null;
        if (predicted) {
          futureEX = predicted.x;
          futureEY = predicted.y;
          futureEAng = predicted.angle;
        } else {
          var eDelta = snake.wantedAngle !== undefined
            ? angleDiff(eAng, snake.wantedAngle) * 0.08 : 0;
          var stepAng = eAng;
          futureEX = snake.x;
          futureEY = snake.y;
          for (var ft = 0; ft < t; ft++) {
            stepAng += eDelta;
            futureEX += Math.cos(stepAng) * eSpeed * 0.3;
            futureEY += Math.sin(stepAng) * eSpeed * 0.3;
          }
          futureEAng = stepAng;
        }

        // Predict player position with steering
        var playerFuture = predictPlayerPos(px, py, pAng, pWant, pSpeed, t);
        var futurePX = playerFuture.x;
        var futurePY = playerFuture.y;

        var dSq = MathUtil.distanceSq(futurePX, futurePY, futureEX, futureEY);
        var lookSq = avoidSq * (t === 0 ? 1 : 1.5);

        if (dSq < lookSq && dSq > 0) {
          var dist = Math.sqrt(dSq);
          var baseStrength = 1 - (dist / (avoidRadius * (t === 0 ? 1 : 1.22)));
          if (baseStrength <= 0) continue;

          var threatType = this._classifyHeadThreat(
            futurePX, futurePY, pAng,
            futureEX, futureEY, futureEAng
          );

          var timeFactor;
          if (threatType === THREAT.HEAD_ON) {
            timeFactor = 1.0 - (t / (steps + 1)) * 0.25;
          } else {
            timeFactor = 1.0 - (t / (steps + 1)) * 0.5;
          }
          var strength = baseStrength * HEAD_WEIGHT * speedMult * timeFactor;
          strength *= behaviorMult;

          if (threatType === THREAT.HEAD_ON) {
            strength *= 2.5;
            if (t <= 4 && dist < boostEmergency) {
              isEmergency = true;
            }
          } else if (threatType === THREAT.CROSSING) {
            strength *= 1.5;
            if (t <= 2 && dist < boostEmergency * 0.8) {
              isEmergency = true;
            }
          }

          // ── Compat: repulsion vector ──────────────────
          var dvx = px - futureEX;
          var dvy = py - futureEY;
          var dvMag = Math.sqrt(dvx * dvx + dvy * dvy);
          if (dvMag > 0) {
            rx += (dvx / dvMag) * strength;
            ry += (dvy / dvMag) * strength;
          }

          // Compat: left/right mass
          var latDx = futureEX - px;
          var latDy = futureEY - py;
          var lateral = -latDx * sinP + latDy * cosP;
          if (lateral < 0) {
            leftMass += strength;
          } else {
            rightMass += strength;
          }

          if (strength > maxWeight) {
            maxWeight = strength;
            type = threatType;
          }
          count++;

          // ── NEW: Bin into sector ──────────────────────
          var threatAngle = Math.atan2(futureEY - py, futureEX - px);
          var secIdx = angleToSector(threatAngle);
          var sec = sectors[secIdx];
          sec.headThreat += strength;
          if (dist < sec.closestDist) {
            sec.closestDist = dist;
            sec.threatType = threatType;
          }
          // Closing speed: use current-frame distance change
          if (t === 0 && dist > 0) {
            var relVelX = Math.cos(eAng) * eSpeed - Math.cos(pAng) * pSpeed;
            var relVelY = Math.sin(eAng) * eSpeed - Math.sin(pAng) * pSpeed;
            var closing = -(relVelX * (futureEX - px) + relVelY * (futureEY - py)) / dist;
            if (closing > sec.closingSpeed) {
              sec.closingSpeed = closing;
            }
          }
          addUniqueId(sec.snakeIds, snakeId);
        }
      }

      if (count === 0) return null;

      return {
        rx: rx,
        ry: ry,
        count: count,
        weight: maxWeight,
        type: type,
        emergency: isEmergency,
        leftMass: leftMass,
        rightMass: rightMass
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Body evaluation — sampled parts, bins into sectors
     * ══════════════════════════════════════════════════════════ */

    _evaluateBody: function (
      sectors, encircleData, snakeId,
      px, py, pAng, pThick,
      bodyParts, eThick,
      avoidRadius, avoidSq,
      cosP, sinP,
      behaviorMult,
      scanDist, scanWidth
    ) {
      var MathUtil = SP.MathUtil;
      var rx = 0, ry = 0;
      var count = 0;
      var maxWeight = 0;
      var type = THREAT.FLANKING;
      var leftMass = 0, rightMass = 0;

      var corridorHits = 0;
      var panicThreshold = avoidRadius * CLOSE_BODY_THRESHOLD;

      var sampleStep = BODY_WALL_SAMPLE_STEP;
      if (bodyParts.length > 200) sampleStep = 3;
      if (bodyParts.length > 400) sampleStep = 4;

      for (var j = 0; j < bodyParts.length; j += sampleStep) {
        var part = bodyParts[j];
        if (!part) continue;

        var dSq = MathUtil.distanceSq(px, py, part.x, part.y);
        if (dSq >= avoidSq || dSq <= 0) continue;

        var dist = Math.sqrt(dSq);
        var baseStrength = 1 - (dist / avoidRadius);

        // Encirclement compat data
        if (encircleData && dist < avoidRadius) {
          var eAngle = Math.atan2(part.y - py, part.x - px);
          var eSectorRaw = Math.floor(((eAngle + Math.PI) / TWO_PI) * ENCIRCLE_SECTOR_COUNT) % ENCIRCLE_SECTOR_COUNT;
          var eSector = ((eSectorRaw % ENCIRCLE_SECTOR_COUNT) + ENCIRCLE_SECTOR_COUNT) % ENCIRCLE_SECTOR_COUNT;
          encircleData.sectors[eSector]++;
          encircleData.totalNear++;
          if (dist < encircleData.minDist[eSector]) {
            encircleData.minDist[eSector] = dist;
          }
        }

        var inCorridor = pointInCorridor(
          part.x, part.y, px, py, pAng,
          scanDist || FORWARD_SCAN_DISTANCE,
          (scanWidth || FORWARD_SCAN_WIDTH) + eThick * 5
        );

        var strength = baseStrength * BODY_WEIGHT * behaviorMult;

        if (inCorridor) {
          strength *= 3.5;
          corridorHits++;
          if (strength > maxWeight) {
            type = THREAT.CROSSING;
          }
        }

        // Panic zone
        if (dist < panicThreshold) {
          strength *= CLOSE_BODY_PANIC_MULT;
        } else if (dist < avoidRadius * 0.4) {
          strength *= 2.0;
        }

        // ── Compat: repulsion vector ──────────────────
        var dvx = px - part.x;
        var dvy = py - part.y;
        if (dist > 0) {
          rx += (dvx / dist) * strength;
          ry += (dvy / dist) * strength;
        }

        var latDx = part.x - px;
        var latDy = part.y - py;
        var lateralVal = -latDx * sinP + latDy * cosP;
        if (lateralVal < 0) {
          leftMass += strength;
        } else {
          rightMass += strength;
        }

        if (strength > maxWeight) {
          maxWeight = strength;
        }
        count++;

        // ── NEW: Bin into sector ──────────────────────
        var bodyAngle = Math.atan2(part.y - py, part.x - px);
        var secIdx = angleToSector(bodyAngle);
        var sec = sectors[secIdx];
        sec.bodyThreat += strength;
        if (dist < sec.closestDist) {
          sec.closestDist = dist;
          if (!sec.threatType) {
            sec.threatType = THREAT.BODY_WALL;
          }
        }
        addUniqueId(sec.snakeIds, snakeId);
      }

      // Body wall detection
      if (corridorHits >= 2) {
        type = THREAT.BODY_WALL;
        rx *= 2.2;
        ry *= 2.2;
        maxWeight *= 2.2;
      }

      if (count === 0) return null;

      return {
        rx: rx,
        ry: ry,
        count: count,
        weight: maxWeight,
        type: type,
        leftMass: leftMass,
        rightMass: rightMass
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Threat classification
     * ══════════════════════════════════════════════════════════ */

    _classifyHeadThreat: function (px, py, pAng, ex, ey, eAng) {
      var angleToEnemy = Math.atan2(ey - py, ex - px);
      var angleDiffToEnemy = Math.abs(angleDiff(pAng, angleToEnemy));
      var angleFromEnemy = Math.atan2(py - ey, px - ex);
      var enemyApproachDiff = Math.abs(angleDiff(eAng, angleFromEnemy));

      if (angleDiffToEnemy < Math.PI * 0.4 && enemyApproachDiff < Math.PI * 0.4) {
        return THREAT.HEAD_ON;
      }
      if (angleDiffToEnemy < Math.PI * 0.5) {
        return THREAT.CROSSING;
      }
      return THREAT.FLANKING;
    },

    /* ══════════════════════════════════════════════════════════
     *  Encirclement (same algorithm as CollisionAvoidance v4)
     * ══════════════════════════════════════════════════════════ */

    _checkEncirclement: function (data, threatSectors) {
      if (!data || data.totalNear < 3) return 0;
      var occupied = 0;
      for (var i = 0; i < data.sectors.length; i++) {
        if (data.sectors[i] > 0) occupied++;
      }

      // Standard thresholds
      if (occupied >= ENCIRCLE_EMERGENCY_SECTORS) return 3;
      if (occupied >= ENCIRCLE_DANGER_SECTORS)    return 2;

      // v5: Single-giant detection — lower thresholds when one snake dominates.
      // A single snake filling 6+ sectors is ~135° of arc — extremely dangerous.
      // Use ThreatMap sectors (which track snakeIds) to detect single-snake dominance.
      if (threatSectors && occupied >= 6) {
        var sectorSnakeCounts = {};
        var maxBySnake = 0;
        for (var si = 0; si < SECTOR_COUNT; si++) {
          var sec = threatSectors[si];
          if (sec && sec.snakeIds) {
            for (var sk = 0; sk < sec.snakeIds.length; sk++) {
              var sid = sec.snakeIds[sk];
              sectorSnakeCounts[sid] = (sectorSnakeCounts[sid] || 0) + 1;
              if (sectorSnakeCounts[sid] > maxBySnake) {
                maxBySnake = sectorSnakeCounts[sid];
              }
            }
          }
        }
        // If one snake fills 6+ threat sectors, lower thresholds by 2
        if (maxBySnake >= 6) {
          if (occupied >= ENCIRCLE_EMERGENCY_SECTORS - 2) return 3; // 10 instead of 12
          if (occupied >= ENCIRCLE_DANGER_SECTORS - 2)    return 2; // 8 instead of 10
        }
      }

      if (occupied >= ENCIRCLE_CAUTION_SECTORS)   return 1;
      return 0;
    },

    _findEncircleEscape: function (data, px, py, pAng) {
      if (!data) return null;
      var N = ENCIRCLE_SECTOR_COUNT;
      var bestStart = 0;
      var bestLen = 0;
      var curStart = -1;
      var curLen = 0;

      for (var i = 0; i < N * 2; i++) {
        var idx = i % N;
        if (data.sectors[idx] === 0) {
          if (curStart < 0) curStart = i;
          curLen++;
          if (curLen > bestLen) {
            bestLen = curLen;
            bestStart = curStart;
          }
        } else {
          curStart = -1;
          curLen = 0;
        }
      }
      if (bestLen > N) bestLen = N;

      var midIndex = (bestStart + bestLen / 2) % N;
      var sectorAngle = ((midIndex + 0.5) / N) * TWO_PI - Math.PI;
      return sectorAngle;
    },

    /**
     * Find widest contiguous gap in the ThreatMap sectors (low-threat run).
     * Used for the new encirclement.gapCenter/gapWidth result fields.
     */
    _findWidestGapFromSectors: function (sectors) {
      var N = SECTOR_COUNT;
      var threshold = 0.1; // sectors below this are "empty"
      var bestStart = 0;
      var bestLen = 0;
      var curStart = -1;
      var curLen = 0;

      for (var i = 0; i < N * 2; i++) {
        var idx = i % N;
        if (sectors[idx].totalThreat < threshold) {
          if (curStart < 0) curStart = i;
          curLen++;
          if (curLen > bestLen) {
            bestLen = curLen;
            bestStart = curStart;
          }
        } else {
          curStart = -1;
          curLen = 0;
        }
      }
      if (bestLen > N) bestLen = N;

      var midIndex = (bestStart + bestLen / 2) % N;
      return {
        angle: sectorToAngle(midIndex),
        width: bestLen
      };
    },

    /* ══════════════════════════════════════════════════════════
     *  Query API — operate on last compute() result
     * ══════════════════════════════════════════════════════════ */

    /**
     * Find the safest direction to steer toward.
     * Uses 3-sector smoothed safety (current + neighbors).
     * @returns {{angle: number, safety: number}}
     */
    getSafestDirection: function () {
      if (!_lastResult) return { angle: 0, safety: 1.0 };

      var sectors = _lastResult.sectors;
      var bestSafety = -1;
      var bestIdx = 0;

      for (var i = 0; i < SECTOR_COUNT; i++) {
        var prev = (i - 1 + SECTOR_COUNT) % SECTOR_COUNT;
        var next = (i + 1) % SECTOR_COUNT;
        // Weighted average: center counts double
        var smoothed = 1.0 - (
          sectors[prev].totalThreat * 0.25 +
          sectors[i].totalThreat    * 0.50 +
          sectors[next].totalThreat * 0.25
        );
        if (smoothed > bestSafety) {
          bestSafety = smoothed;
          bestIdx = i;
        }
      }

      return {
        angle: sectorToAngle(bestIdx),
        safety: Math.max(0, bestSafety)
      };
    },

    /**
     * Get the threat level at a specific angle (interpolated between sectors).
     * @param {number} angle — radians
     * @returns {number} 0–1 (0 = safe, 1 = dangerous)
     */
    getDirectionThreat: function (angle) {
      if (!_lastResult) return 0;

      var sectors = _lastResult.sectors;
      // Fractional sector index — ensure positive via modular wrap
      var frac = ((angle % TWO_PI + TWO_PI + Math.PI) / TWO_PI) * SECTOR_COUNT;
      var idx = Math.floor(frac) % SECTOR_COUNT;
      if (idx < 0) idx += SECTOR_COUNT;
      var nextIdx = (idx + 1) % SECTOR_COUNT;
      var t = frac - Math.floor(frac);

      // Linear interpolation between adjacent sectors
      return sectors[idx].totalThreat * (1 - t) + sectors[nextIdx].totalThreat * t;
    },

    /**
     * Check if a corridor between two points is clear of threats.
     * Uses cached snake data from last compute() call.
     *
     * @param {number} fromX, fromY — start point
     * @param {number} toX, toY     — end point
     * @param {number} [width=140]  — corridor width
     * @returns {boolean} true if no snake heads or body parts in corridor
     */
    isPathClear: function (fromX, fromY, toX, toY, width) {
      var snakes = _lastNearbySnakes;
      if (!snakes || snakes.length === 0) return true;

      var dx = toX - fromX;
      var dy = toY - fromY;
      var dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 1) return true;

      var angle = Math.atan2(dy, dx);
      var halfW = (width || 140) / 2;

      for (var i = 0; i < snakes.length; i++) {
        var snake = snakes[i];
        if (!snake) continue;

        // Check head
        if (pointInCorridor(snake.x, snake.y, fromX, fromY, angle, dist, halfW)) {
          return false;
        }

        // Check body (sample every 4th for speed)
        if (snake.bodyParts) {
          for (var j = 0; j < snake.bodyParts.length; j += 4) {
            var part = snake.bodyParts[j];
            if (part && pointInCorridor(part.x, part.y, fromX, fromY, angle, dist, halfW)) {
              return false;
            }
          }
        }
      }
      return true;
    },

    /**
     * Get encirclement info from last compute().
     * @returns {object} {filledSectors, level, gapCenter, gapWidth}
     */
    getEncirclement: function () {
      if (!_lastResult) {
        return { filledSectors: 0, level: 'none', gapCenter: 0, gapWidth: SECTOR_COUNT };
      }
      return _lastResult.encirclement;
    },

    /**
     * Get the sector data for a specific angle.
     * @param {number} angle — radians
     * @returns {object} sector data or empty sector
     */
    getSectorByAngle: function (angle) {
      if (!_lastResult) {
        return {
          headThreat: 0, bodyThreat: 0, totalThreat: 0,
          closestDist: Infinity, closingSpeed: 0, threatType: null, snakeIds: []
        };
      }
      var idx = angleToSector(angle);
      return _lastResult.sectors[idx];
    },

    /**
     * Get all sector data from last compute().
     * @returns {Array} 16 sector objects
     */
    getSectors: function () {
      if (!_lastResult) return this._initSectors();
      return _lastResult.sectors;
    },

    /**
     * Get last compute result.
     * @returns {object|null}
     */
    getLastResult: function () {
      return _lastResult;
    },

    /* ══════════════════════════════════════════════════════════
     *  Backward-compat API (CollisionAvoidance drop-in)
     * ══════════════════════════════════════════════════════════ */

    /**
     * COMPAT: Returns the old-format single avoidance vector.
     * Identical output to CollisionAvoidance.computeAvoidance().
     * Called by bot-controller.js and auto-boost.js in compat mode.
     *
     * @param {object} playerSnake
     * @param {Array}  snakes
     * @param {number} avoidanceRadius
     * @returns {object|null} {x, y, magnitude, emergency, threats, dominantThreat, encircleLevel}
     */
    computeAvoidance: function (playerSnake, snakes, avoidanceRadius) {
      this.compute(playerSnake, snakes, avoidanceRadius);
      return _lastCompatVector;
    },

    /**
     * COMPAT: Encircle sector data for CoilDetector.
     * Returns the old-format {sectors: [counts], minDist: [dists], totalNear}.
     */
    getLastEncircleData: function () {
      return _lastEncircleData || null;
    },

    /**
     * COMPAT: Forward-path safety check.
     * Identical to CollisionAvoidance.scanForward().
     */
    scanForward: function (px, py, pAng, snakes, distance, width) {
      var hits = 0;
      distance = distance || FORWARD_SCAN_DISTANCE;
      width = width || FORWARD_SCAN_WIDTH;

      for (var i = 0; i < snakes.length; i++) {
        var snake = snakes[i];
        if (!snake) continue;

        if (pointInCorridor(snake.x, snake.y, px, py, pAng, distance, width)) {
          hits += 3;
        }

        if (snake.bodyParts) {
          // v5b: Sample every 2nd part (was 4th). Tail ends have few visible
          // segments — skipping 4 at a time misses them entirely.
          for (var j = 0; j < snake.bodyParts.length; j += 2) {
            var part = snake.bodyParts[j];
            if (part && pointInCorridor(part.x, part.y, px, py, pAng, distance, width)) {
              hits++;
            }
          }
        }
      }
      return hits;
    },

    // Expose threat types
    THREAT: THREAT,

    // v5: Expose corridor check for imminent collision detection in bot-controller
    _pointInCorridor: pointInCorridor
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.ThreatMap = ThreatMap;
  // Backward compat: register as CollisionAvoidance so existing consumers work
  window.SlitherPro.CollisionAvoidance = ThreatMap;
})();
