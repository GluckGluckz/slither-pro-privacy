/**
 * Slither Pro -- Auto Boost Bot Module (v6 — Budget System).
 *
 * Boost is decoupled from kill/trap detection.  Kill and head-trap
 * detection are exposed as public utility methods called by the goal
 * scorers in BotController.  shouldBoost() receives the already-chosen
 * goal context and decides only boost on/off.
 *
 * v6: Action-scoped boost budgets tied to the commitment engine.
 * Each committed action gets a length budget (% of current length).
 * Emergency/safety/border are unlimited.  Kill/coil/deathFood/food
 * are capped.  BotController calls startBudget() on new commitment
 * and endBudget() when interrupted.
 *
 * Public API:
 *   shouldBoost(context)           — pure boost decision
 *   startBudget(tag, playerLength) — start budget for committed action
 *   endBudget()                    — reset budget (commitment broken)
 *   getBoostSpent()                — length spent in current action
 *   findCutOffOpportunity(...)     — returns kill info or null
 *   findHeadTrapOpportunity(...)   — returns trap info or null
 *   isAreaSafe(...)                — area safety check
 *   reset()                        — reset internal state
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  /* ── General tuning ──────────────────────────────────── */
  var MIN_LENGTH_TO_BOOST    = 10;      // v9: Lower so early game can boost
  var COOLDOWN_FRAMES        = 10;
  var SAFE_DISTANCE          = 220;
  var FOOD_SCORE_THRESHOLD   = 8.0;     // v13: was 3.0 — almost never boost for food, preserve length
  var EDGE_NO_BOOST_DIST     = 900;     // v9: Don't boost into strong avoidance zone
  var BOOST_DURATION_MIN     = 12;      // v9: Shorter min duration for responsiveness
  var LARGE_FOOD_SCORE_MULT  = 1.5;
  var BOOST_SPEED_MULT       = 2.0;

  /* ── Kill / Cut-off tuning ────────────────────────────── */
  var KILL_DISTANCE           = 500;    // v4c: was 900 — too far, bot chased from behind. Close range = real kills
  var KILL_MIN_DISTANCE       = 20;
  var KILL_ANGLE_THRESHOLD    = 2.2;    // v4c: was 1.8 — wider angle allows side/flanking approaches

  var INTERCEPT_DIST_MIN      = 60;     // v5: was 30 — keep intercept off target body (30 too close, inside body)
  var INTERCEPT_DIST_MAX      = 250;    // v4c: was 500 — tighter predictions, intercept 250 max ahead of target
  var INTERCEPT_DIST_FACTOR   = 1.0;    // v4c: was 1.3 — less overshoot
  var INTERCEPT_TIME_RATIO    = 0.85;   // v4c: was 0.95 — allow slightly later arrival (crossing, not racing)

  var INTERCEPT_DANGER_RADIUS = 150;    // v5: was 80 — catch body parts near intercept, not just heads

  var KILL_PATH_CLEAR_DIST    = 400;    // v8: Scan further for kill path obstacles
  var KILL_PATH_CLEAR_WIDTH   = 140;   // v8: Wider corridor catches nearby body walls

  var CROSS_ANGLE_IDEAL       = Math.PI * 0.5;
  var CROSS_ANGLE_PENALTY_NARROW  = 0.20;
  var CROSS_ANGLE_PENALTY_WIDE    = 0.10;

  /* ── Head Trap tuning ─────────────────────────────────── */
  var HEAD_TRAP_MIN_LENGTH    = 120;
  var HEAD_TRAP_ENEMY_DIST    = 350;
  var HEAD_TRAP_ANGLE_THRESH  = 0.7;
  var HEAD_TRAP_BODY_SAMPLES  = 25;
  var HEAD_TRAP_SCORE_THRESH  = 0.3;

  /* ── Boost budget constants (v2) ────────────────────── */
  var BOOST_COST_PER_FRAME  = 0.15;   // ~0.15 length lost per boost frame at typical speed
  var BUDGET_KILL           = 0.05;   // 5% of current length
  var BUDGET_COIL           = 0.04;   // 4% of current length
  var BUDGET_DEATH_FOOD     = 0.08;   // v5b: was 0.03 — death food is #1 growth source, worth spending length to reach
  var BUDGET_FOOD           = 0.00;   // 0% default (Aggressive mode overrides to 0.01)
  var BUDGET_UNLIMITED      = -1;     // sentinel: no budget limit

  /* ── Internal state ────────────────────────────────── */
  var _lastBoostState     = false;
  var _framesSinceToggle  = 999;
  var _boostFrames        = 0;

  /* ── Budget state (v2) ─────────────────────────────── */
  var _boostBudget        = BUDGET_UNLIMITED;  // max length allowed for current action
  var _boostSpent         = 0;                 // length spent so far
  var _currentBudgetTag   = '';

  var AutoBoost = {

    reset: function () {
      _lastBoostState = false;
      _framesSinceToggle = 999;
      _boostFrames = 0;
      _boostBudget = BUDGET_UNLIMITED;
      _boostSpent = 0;
      _currentBudgetTag = '';
    },

    /**
     * v2: Start a boost budget for a new committed action.
     * Called by BotController when starting a new commitment.
     *
     * @param {string} tag          - goal tag (kill, coil, deathFood, food, etc.)
     * @param {number} playerLength - current snake length
     * @param {object} [params]     - from StrategyManager (mode multipliers)
     */
    startBudget: function (tag, playerLength, params) {
      _currentBudgetTag = tag;
      _boostSpent = 0;

      var len = playerLength || 10;
      var p = params || {};

      if (tag === 'kill') {
        _boostBudget = len * BUDGET_KILL * (p.killBoostBudgetMult || 1.0);
      } else if (tag === 'coil') {
        _boostBudget = len * BUDGET_COIL * (p.coilCommitMult || 1.0);
      } else if (tag === 'deathFood') {
        _boostBudget = len * BUDGET_DEATH_FOOD * (p.deathFoodCommitMult || 1.0);
      } else if (tag === 'food') {
        // foodBoostBudgetMult: 0=none, 1.0=1% of length (Aggressive)
        var foodPct = (p.foodBoostBudgetMult || 0) * 0.01;
        _boostBudget = foodPct > 0 ? len * foodPct : 0;
      } else {
        // safety, border, emergency, wander — unlimited
        _boostBudget = BUDGET_UNLIMITED;
      }
    },

    /**
     * v2: End the current boost budget (commitment finished/broken).
     */
    endBudget: function () {
      _boostBudget = BUDGET_UNLIMITED;
      _boostSpent = 0;
      _currentBudgetTag = '';
    },

    /**
     * v2: Get the length spent on boost in the current action.
     */
    getBoostSpent: function () {
      return _boostSpent;
    },

    /**
     * Decide whether to boost this frame.
     *
     * @param {object} context
     * @param {object} context.playerSnake
     * @param {Array}  context.nearbySnakes
     * @param {object} context.chosenGoal   - winning GoalResult from BotController
     * @param {object} context.avoidance    - from CollisionAvoidance (may be null)
     * @param {number} context.mapRadius
     * @param {object} context.params       - from StrategyManager (may be null)
     * @returns {{boost: boolean, reason: string}}
     */
    shouldBoost: function (context) {
      var playerSnake = context.playerSnake;
      var snakes = context.nearbySnakes;
      var goal = context.chosenGoal;
      var avoidance = context.avoidance;
      var mapRadius = context.mapRadius;
      var params = context.params;

      if (!playerSnake) return { boost: false, reason: 'no_player' };

      var MathUtil = SP.MathUtil;
      _framesSinceToggle++;

      // ── 0. Small-snake protection (v3b) ──────────────────
      // Below length 50, boosting for safety/emergency is almost always wrong:
      //   - Faster = hit things sooner, less time to steer
      //   - Each boost frame costs 0.15 length (~0.75% at length 20)
      //   - Steering alone handles avoidance fine at small sizes
      // ONLY exception: encirclement escape (need speed to break through gap)
      var isSmallSnake = playerSnake.length < 50;

      // ── 1. Encirclement escape ───────────────────────────
      // Always allowed even for small snakes — encirclement is lethal without speed.
      if (avoidance && avoidance.encircleLevel >= 2) {
        if (goal && goal.meta && !goal.meta.survivalMode) {
          return this._setBoost(true, 'encircle_escape');
        }
      }

      // ── 2. Emergency / safety / giant flee ───────────────
      // v3b: At small sizes, skip ALL safety boost. Steer only.
      if (goal && goal.tag === 'safety') {
        if (isSmallSnake) {
          return this._setBoost(false, 'small_no_safety_boost');
        }

        // Emergency escape — only boost if heading toward escape
        if (avoidance && avoidance.emergency) {
          var headAngle = playerSnake.angle || 0;
          var safeAngle = Math.atan2(goal.dirY || 0, goal.dirX || 0);
          var headVsSafe = Math.abs(this._angleDiff(headAngle, safeAngle));
          if (headVsSafe < Math.PI * 0.6) {
            return this._setBoost(true, 'emergency_escape');
          }
          return this._setBoost(false, 'emergency_turning');
        }

        // Giant flee
        if (goal.meta && goal.meta.giantFlee) {
          return this._setBoost(true, 'flee_giant');
        }

        // Safety escape (high magnitude)
        if (goal.boost && avoidance && avoidance.magnitude > 15.0) {
          var sHeadAngle = playerSnake.angle || 0;
          var sSafeAngle = Math.atan2(goal.dirY || 0, goal.dirX || 0);
          var sHeadVsSafe = Math.abs(this._angleDiff(sHeadAngle, sSafeAngle));
          if (sHeadVsSafe < Math.PI * 0.6) {
            return this._setBoost(true, 'safety_escape');
          }
          return this._setBoost(false, 'safety_turning');
        }

        // Safety stuck
        if (goal.meta && goal.meta.stuckEscape) {
          return this._setBoost(true, 'safety_stuck');
        }
      }

      // ── 4. Too short ─────────────────────────────────────
      if (playerSnake.length < MIN_LENGTH_TO_BOOST) {
        return this._setBoost(false, 'too_short');
      }

      // ── 5. Edge heading ──────────────────────────────────
      if (mapRadius > 0) {
        var distFromCenter = MathUtil.distance(mapRadius, mapRadius, playerSnake.x, playerSnake.y);
        var distToEdge = mapRadius - distFromCenter;

        if (distToEdge < EDGE_NO_BOOST_DIST) {
          var angleToCenter = MathUtil.angle(playerSnake.x, playerSnake.y, mapRadius, mapRadius);
          var headingDiff = Math.abs(this._angleDiff(playerSnake.angle || 0, angleToCenter));
          if (headingDiff > Math.PI * 0.5) {
            return this._setBoost(false, 'heading_toward_edge');
          }
        }
      }

      // ── Cooldown enforcement ─────────────────────────────
      if (_framesSinceToggle < COOLDOWN_FRAMES) {
        if (_lastBoostState && avoidance && avoidance.magnitude > 0.8) {
          return this._setBoost(false, 'safety_cutoff');
        }
        if (_lastBoostState && _boostFrames < BOOST_DURATION_MIN) {
          _boostFrames++;
          return { boost: true, reason: 'min_duration' };
        }
        return { boost: _lastBoostState, reason: 'cooldown' };
      }

      // ── 5b. Budget gate (v2) — deny non-emergency boost when over budget ──
      if (_boostBudget >= 0 && _boostSpent >= _boostBudget) {
        return this._setBoost(false, 'over_budget');
      }

      // ── 6. Kill pursuit ──────────────────────────────────
      if (goal && goal.tag === 'kill' && goal.boost) {
        // Verify path is still clear
        if (snakes && SP.CollisionAvoidance && SP.CollisionAvoidance.scanForward && goal.meta) {
          var px = playerSnake.x;
          var py = playerSnake.y;
          var ix = goal.meta.interceptX || px;
          var iy = goal.meta.interceptY || py;
          var killAngle = MathUtil.angle(px, py, ix, iy);
          var pathHits = SP.CollisionAvoidance.scanForward(
            px, py, killAngle, snakes, KILL_PATH_CLEAR_DIST, KILL_PATH_CLEAR_WIDTH
          );
          if (pathHits > 0) {
            return this._setBoost(false, 'kill_path_blocked');
          }
        }
        return this._setBoost(true, 'kill_pursuit');
      }

      // ── 7. Death food race ───────────────────────────────
      // v3: Never boost for death food during emergencies — survival first.
      // Also require reasonable path safety (mag < 10) or exceptional value (> 15).
      if (goal && goal.tag === 'deathFood' && goal.boost) {
        if (avoidance && avoidance.emergency) {
          return this._setBoost(false, 'df_emergency');
        }
        var dfMagOk = !avoidance || avoidance.magnitude < 14.0;  // v5b: was 10.0 — boost toward death food in mild threat zones
        var dfHighValue = goal.score && goal.score > 12.0;    // v5b: was 15.0 — lower threshold for high-value override
        if (dfMagOk || dfHighValue) {
          return this._setBoost(true, 'death_food_race');
        }
      }

      // ── 8. Offensive coil ────────────────────────────────
      if (goal && goal.tag === 'coil' && goal.boost) {
        return this._setBoost(true, 'coil_boost');
      }

      // ── 9. Food chase ────────────────────────────────────
      if (goal && goal.tag === 'food' && goal.meta && goal.meta.foodTarget) {
        var boostConservation = (params && params.boostConservation != null)
          ? params.boostConservation : 0.5;
        var aggressionLevel = (params && params.aggressionLevel != null)
          ? params.aggressionLevel : 0;

        if (boostConservation >= 0.3) {
          var foodTarget = goal.meta.foodTarget;
          var isSafeFood = this.isAreaSafe(playerSnake, snakes, SAFE_DISTANCE);

          var threshold = FOOD_SCORE_THRESHOLD;
          if (foodTarget.hasLargeFood) {
            threshold = FOOD_SCORE_THRESHOLD / LARGE_FOOD_SCORE_MULT;
          }
          threshold *= (1.0 - aggressionLevel * 0.3);

          // v11: Length-aware conservation — larger snakes lose more food per boost frame
          // Length 100 → 1.0x, 300 → 1.6x, 600 → 2.5x, 1000 → 3.7x
          var lengthPenalty = 1.0 + Math.max(0, (playerSnake.length || 10) - 100) * 0.003;
          threshold *= lengthPenalty;

          var minFoodSafety = 0.6 - (aggressionLevel * 0.2);

          // v11: Don't boost for nearby food — we can reach it without boosting.
          // Boosting drops food behind us, creating a net loss for close targets.
          var minBoostDist = 150;
          if (isSafeFood && foodTarget.score > threshold && foodTarget.safety > minFoodSafety && foodTarget.dist > minBoostDist) {
            return this._setBoost(true, 'food_chase');
          }
        }
      }

      // ── Default: no boost ────────────────────────────────
      return this._setBoost(false, 'default');
    },

    /* ══════════════════════════════════════════════════════════
     *  Kill / Trap Detection (public utilities)
     * ══════════════════════════════════════════════════════════ */

    /**
     * Find the best cut-off kill opportunity.
     * Pure function — no side effects, no boost state changes.
     *
     * @param {object} playerSnake
     * @param {Array}  snakes
     * @param {number} killSizeRatio   - from StrategyManager
     * @param {number} aggressionLevel - from StrategyManager
     * @returns {{interceptX, interceptY, targetSnake, approachAngle, crossAngle, score}|null}
     */
    findCutOffOpportunity: function (playerSnake, snakes, killSizeRatio, aggressionLevel) {
      if (!snakes || snakes.length === 0) return null;

      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;
      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;
      var pSpeed = (playerSnake.speed || 8) * BOOST_SPEED_MULT;

      var bestTarget = null;
      var bestScore = -Infinity;

      for (var i = 0; i < snakes.length; i++) {
        var enemy = snakes[i];
        if (!enemy) continue;

        var enemySizeRatio = (enemy.length || 10) / (playerSnake.length || 10);
        if (killSizeRatio > 0 && enemySizeRatio > killSizeRatio * 2.5) continue;

        var dist = MathUtil.distance(px, py, enemy.x, enemy.y);
        if (dist > KILL_DISTANCE || dist < KILL_MIN_DISTANCE) continue;

        var angleToEnemy = MathUtil.angle(px, py, enemy.x, enemy.y);
        var headingToEnemyDiff = Math.abs(this._angleDiff(pAng, angleToEnemy));
        if (headingToEnemyDiff > KILL_ANGLE_THRESHOLD) continue;

        var eAng = enemy.angle || 0;
        var eSpeed = enemy.speed || 8;

        if (Tracker) {
          var tracked = Tracker.getTracked(enemy.id);
          if (tracked && tracked.avgSpeed > 0) {
            eSpeed = tracked.avgSpeed;
            var latestPos = tracked.positions.get(0);
            if (latestPos) {
              eAng = latestPos.angle;
            }
          }
        }

        // Don't cut off someone heading straight at us
        var enemyAngleToUs = MathUtil.angle(enemy.x, enemy.y, px, py);
        var enemyApproachDiff = Math.abs(this._angleDiff(eAng, enemyAngleToUs));
        if (enemyApproachDiff < Math.PI * 0.2) continue;

        // Adaptive intercept distance
        var timeToEngage = dist / (pSpeed + eSpeed);
        var interceptDist = eSpeed * timeToEngage * INTERCEPT_DIST_FACTOR;
        interceptDist = MathUtil.clamp(interceptDist, INTERCEPT_DIST_MIN, INTERCEPT_DIST_MAX);

        // Curved prediction if available
        var interceptX, interceptY;
        if (Tracker) {
          // v4c: timeToEngage is already in frames (dist / speed-per-frame).
          // Was incorrectly multiplied by 60 (treating as seconds), predicting
          // 1000+ frames ahead → intercept points 8000+ units away → kills never land.
          var predicted = Tracker.predictPosition(enemy.id, Math.ceil(timeToEngage));
          if (predicted) {
            var predAng = predicted.angle || eAng;
            interceptX = predicted.x + Math.cos(predAng) * interceptDist * 0.5;
            interceptY = predicted.y + Math.sin(predAng) * interceptDist * 0.5;
          } else {
            interceptX = enemy.x + Math.cos(eAng) * interceptDist;
            interceptY = enemy.y + Math.sin(eAng) * interceptDist;
          }
        } else {
          interceptX = enemy.x + Math.cos(eAng) * interceptDist;
          interceptY = enemy.y + Math.sin(eAng) * interceptDist;
        }

        // Timing check
        var enemyDistToIntercept = MathUtil.distance(enemy.x, enemy.y, interceptX, interceptY);
        var enemyTimeToIntercept = enemyDistToIntercept / eSpeed;
        var ourDistToIntercept = MathUtil.distance(px, py, interceptX, interceptY);
        var ourTimeToIntercept = ourDistToIntercept / pSpeed;

        if (ourTimeToIntercept >= enemyTimeToIntercept * INTERCEPT_TIME_RATIO) continue;

        // Soft cross-angle scoring
        var ourAngleToIntercept = MathUtil.angle(px, py, interceptX, interceptY);

        // v9: Turn feasibility — skip if snake can't physically complete the turn arc
        if (MathUtil.framesToTurn) {
          var turnNeeded = Math.abs(this._angleDiff(pAng, ourAngleToIntercept));
          var turnFrames = MathUtil.framesToTurn(turnNeeded, playerSnake.length || 10);
          if (turnFrames > ourTimeToIntercept * 0.8) continue;
        }

        var crossAngle = Math.abs(this._angleDiff(ourAngleToIntercept, eAng));

        var crossQuality = Math.sin(crossAngle);
        var anglePenalty = 1.0;

        var isChaseOpportunity = false;
        if (aggressionLevel >= 0.4 && crossAngle < Math.PI * 0.25) {
          isChaseOpportunity = true;
          crossQuality = 0.75;
          anglePenalty = 1.0;
        } else if (crossAngle < Math.PI * 0.12) {
          anglePenalty = CROSS_ANGLE_PENALTY_NARROW;
        } else if (crossAngle < Math.PI * 0.2) {
          anglePenalty = 0.4 + (crossAngle - Math.PI * 0.12) / (Math.PI * 0.08) * 0.6;
        } else if (crossAngle > Math.PI * 0.88) {
          anglePenalty = CROSS_ANGLE_PENALTY_WIDE;
        } else if (crossAngle > Math.PI * 0.75) {
          anglePenalty = 0.4 + (Math.PI * 0.88 - crossAngle) / (Math.PI * 0.13) * 0.6;
        }

        // Third-party danger check
        var thirdPartyDanger = false;
        for (var j = 0; j < snakes.length; j++) {
          if (j === i) continue;
          var other = snakes[j];
          if (!other) continue;
          var otherDist = MathUtil.distance(other.x, other.y, interceptX, interceptY);
          if (otherDist < INTERCEPT_DANGER_RADIUS) {
            thirdPartyDanger = true;
            break;
          }
        }
        if (thirdPartyDanger) continue;

        // Path clear check
        if (SP.CollisionAvoidance && SP.CollisionAvoidance.scanForward) {
          var pathHits = SP.CollisionAvoidance.scanForward(
            px, py, ourAngleToIntercept,
            snakes, KILL_PATH_CLEAR_DIST, KILL_PATH_CLEAR_WIDTH
          );
          if (pathHits > 0) continue;
        }

        // Behavior-aware scoring
        var behaviorBonus = 1.0;
        if (Tracker) {
          var trackedEnemy = Tracker.getTracked(enemy.id);
          if (trackedEnemy) {
            if (trackedEnemy.behavior === 'PASSIVE') behaviorBonus = 1.3;
            else if (trackedEnemy.behavior === 'ERRATIC') behaviorBonus = 0.6;
            else if (trackedEnemy.behavior === 'AGGRESSIVE') behaviorBonus = 0.4;
          }
        }

        // Composite score
        var distFactor = 1 - (dist / KILL_DISTANCE);
        var sizeFactor = Math.max(0.1, 1 - enemySizeRatio * 0.5);
        var chaseBonus = isChaseOpportunity ? 1.3 : 1.0;
        var score = (crossQuality * 2.0 + distFactor * 1.5 + sizeFactor * 1.0)
                    * anglePenalty
                    * behaviorBonus
                    * chaseBonus
                    * (0.4 + aggressionLevel * 0.6);

        if (score > bestScore) {
          bestScore = score;
          bestTarget = {
            interceptX: interceptX,
            interceptY: interceptY,
            targetSnake: enemy,
            approachAngle: ourAngleToIntercept,
            crossAngle: crossAngle,
            score: score
          };
        }
      }

      return bestTarget;
    },

    /**
     * Find head trap opportunity.
     * Pure function — no side effects.
     *
     * @param {object} playerSnake
     * @param {Array}  snakes
     * @returns {{boostAngle, targetSnake, bodyX, bodyY, score}|null}
     */
    findHeadTrapOpportunity: function (playerSnake, snakes) {
      if (!snakes || snakes.length === 0) return null;
      if (!playerSnake.bodyParts || playerSnake.bodyParts.length < 10) return null;

      var MathUtil = SP.MathUtil;
      var Tracker = SP.SnakeTracker;
      var px = playerSnake.x;
      var py = playerSnake.y;
      var pAng = playerSnake.angle || 0;

      var bestTrap = null;
      var bestScore = HEAD_TRAP_SCORE_THRESH;

      var bodyStep = Math.max(1, Math.floor(playerSnake.bodyParts.length / HEAD_TRAP_BODY_SAMPLES));

      for (var i = 0; i < snakes.length; i++) {
        var enemy = snakes[i];
        if (!enemy) continue;

        if (enemy.length >= playerSnake.length * 0.6) continue;

        var eAng = enemy.angle || 0;
        var eSpeed = enemy.speed || 8;

        if (Tracker) {
          var tracked = Tracker.getTracked(enemy.id);
          if (tracked && tracked.avgSpeed > 0) {
            eSpeed = tracked.avgSpeed;
            var latestPos = tracked.positions.get(0);
            if (latestPos) eAng = latestPos.angle;
          }
        }

        for (var b = 5; b < playerSnake.bodyParts.length; b += bodyStep) {
          var bodyPart = playerSnake.bodyParts[b];
          if (!bodyPart) continue;

          var distToBody = MathUtil.distance(enemy.x, enemy.y, bodyPart.x, bodyPart.y);
          if (distToBody > HEAD_TRAP_ENEMY_DIST || distToBody < 20) continue;

          var angleToBody = MathUtil.angle(enemy.x, enemy.y, bodyPart.x, bodyPart.y);
          var headingDiff = Math.abs(this._angleDiff(eAng, angleToBody));
          if (headingDiff > HEAD_TRAP_ANGLE_THRESH) continue;

          var timeToBody = distToBody / eSpeed;
          if (timeToBody > 30) continue;

          var closenessScore = 1 - (distToBody / HEAD_TRAP_ENEMY_DIST);
          var directnessScore = 1 - (headingDiff / HEAD_TRAP_ANGLE_THRESH);
          var sizeAdvantage = 1 - (enemy.length / playerSnake.length);
          var score = closenessScore * 0.4 + directnessScore * 0.4 + sizeAdvantage * 0.2;

          var dangerNearby = false;
          for (var j = 0; j < snakes.length; j++) {
            if (j === i) continue;
            var otherS = snakes[j];
            if (!otherS) continue;
            var otherDist = MathUtil.distance(otherS.x, otherS.y, px, py);
            if (otherDist < 150) {
              dangerNearby = true;
              break;
            }
          }
          if (dangerNearby) continue;

          if (score > bestScore) {
            bestScore = score;
            bestTrap = {
              boostAngle: pAng,
              targetSnake: enemy,
              bodyX: bodyPart.x,
              bodyY: bodyPart.y,
              score: score
            };
          }
        }
      }

      return bestTrap;
    },

    /**
     * Check if the area around the player is free of nearby enemies.
     */
    isAreaSafe: function (playerSnake, snakes, safeDistance) {
      var MathUtil = SP.MathUtil;
      var safeSq = safeDistance * safeDistance;

      for (var i = 0; i < snakes.length; i++) {
        var s = snakes[i];
        if (!s) continue;

        var headDSq = MathUtil.distanceSq(playerSnake.x, playerSnake.y, s.x, s.y);
        if (headDSq < safeSq) return false;

        if (s.bodyParts) {
          for (var j = 0; j < s.bodyParts.length; j += 3) {  // v7: Finer sampling
            var part = s.bodyParts[j];
            if (!part) continue;
            var pDSq = MathUtil.distanceSq(playerSnake.x, playerSnake.y, part.x, part.y);
            if (pDSq < safeSq) return false;
          }
        }
      }

      return true;
    },

    /* ══════════════════════════════════════════════════════════
     *  Internal
     * ══════════════════════════════════════════════════════════ */

    _setBoost: function (active, reason) {
      if (active !== _lastBoostState) {
        _framesSinceToggle = 0;
        _boostFrames = 0;
      }
      if (active) {
        _boostFrames++;
        // v2: Track boost spending against budget
        if (_boostBudget !== BUDGET_UNLIMITED) {
          _boostSpent += BOOST_COST_PER_FRAME;
        }
      }
      _lastBoostState = active;
      return { boost: active, reason: reason };
    },

    _angleDiff: function (a, b) {
      var d = b - a;
      while (d > Math.PI)  d -= 2 * Math.PI;
      while (d < -Math.PI) d += 2 * Math.PI;
      return d;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.AutoBoost = AutoBoost;
})();
