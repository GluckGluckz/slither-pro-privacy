/**
 * Slither Pro — Strategy Manager (Bot AI v3 — Mode Profiles)
 * Size-dependent behavior profiles + game-phase awareness + player modes.
 * Dynamically scales parameters for all bot modules based on snake length,
 * enemy density, and map position. Player-selectable mode (Aggressive /
 * Balanced / Defensive) overlays multipliers on phase params.
 * Provides wander patterns when no food/threat targets exist.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP || !SP.MathUtil) {
    console.error('[SlitherPro] StrategyManager: missing dependencies');
    return;
  }

  var MathUtil = SP.MathUtil;

  // ─── Phase Definitions ────────────────────────────────────────
  var PHASE = {
    HATCHLING:  'HATCHLING',
    GROWING:    'GROWING',
    CONTENDER:  'CONTENDER',
    PREDATOR:   'PREDATOR',
    APEX:       'APEX'
  };

  var PHASE_THRESHOLDS = [20, 60, 150, 400]; // length boundaries

  // Phase profiles: each key maps to parameter overrides
  //   avoidanceRadiusScale  — multiplier on base avoidance radius
  //   foodSearchRadiusScale — multiplier on base food search radius
  //   killSizeRatio         — max enemy/our-length ratio we'll attempt to kill
  //   boostConservation     — 0..1, how freely we spend length on boost
  //   edgeTolerance         — 0..1, how close to edge we dare go
  //   aggressionLevel       — 0..1, general aggression
  //   targetCenterBias      — 0..1, how strongly to drift toward center
  //   wanderPattern         — string: patrol strategy when idle
  //   minSafetyForFood      — minimum safety score to pursue food
  //   minLengthToKill       — absolute minimum length to attempt kills
  var PHASE_PROFILES = {};

  PHASE_PROFILES[PHASE.HATCHLING] = {
    avoidanceRadiusScale:  1.4,
    foodSearchRadiusScale: 0.8,     // v13: was 0.6 — find more food to grow faster
    killSizeRatio:         1.0,     // v13: was 0.6 — allow kills on same-size snakes
    boostConservation:     0.15,    // v13: was 0.3 — below 0.3 gate, hatchlings never boost for food
    edgeTolerance:         0.5,
    aggressionLevel:       0.35,    // v13: was 0.2 — enable early opportunistic kills
    targetCenterBias:      0.1,
    wanderPattern:         'edge-hug',
    minSafetyForFood:      0.50,    // v13: was 0.65 — eat more aggressively
    minLengthToKill:       8        // v13: was 12 — try kills earlier
  };

  PHASE_PROFILES[PHASE.GROWING] = {
    avoidanceRadiusScale:  1.2,
    foodSearchRadiusScale: 1.0,     // v13: was 0.8 — wider food search for better growth
    killSizeRatio:         1.5,     // v13: was 1.2 — target enemies up to 1.5x our size
    boostConservation:     0.55,
    edgeTolerance:         0.65,
    aggressionLevel:       0.55,    // v13: was 0.4 — more aggression for kill attempts
    targetCenterBias:      0.2,
    wanderPattern:         'spiral',
    minSafetyForFood:      0.40,    // v13: was 0.50 — eat more freely
    minLengthToKill:       10       // v13: was 15 — try kills earlier
  };

  PHASE_PROFILES[PHASE.CONTENDER] = {
    avoidanceRadiusScale:  1.0,
    foodSearchRadiusScale: 1.0,
    killSizeRatio:         2.0,    // v8: Kill enemies up to 2x our size
    boostConservation:     0.75,
    edgeTolerance:         0.8,
    aggressionLevel:       0.8,    // v8: More aggressive mid-game
    targetCenterBias:      0.3,
    wanderPattern:         'spiral',
    minSafetyForFood:      0.45,   // v8: Raise safety floor
    minLengthToKill:       20
  };

  PHASE_PROFILES[PHASE.PREDATOR] = {
    avoidanceRadiusScale:  0.9,    // v8: Don't shrink avoidance so much
    foodSearchRadiusScale: 1.3,
    killSizeRatio:         2.5,    // v8: More aggressive targeting
    boostConservation:     0.9,
    edgeTolerance:         0.9,
    aggressionLevel:       0.9,
    targetCenterBias:      0.4,
    wanderPattern:         'patrol',
    minSafetyForFood:      0.45,   // v8: Match contender safety floor
    minLengthToKill:       15
  };

  PHASE_PROFILES[PHASE.APEX] = {
    avoidanceRadiusScale:  0.80,   // v8: Big snakes still need awareness
    foodSearchRadiusScale: 1.5,
    killSizeRatio:         3.5,    // v8: Very aggressive target selection
    boostConservation:     1.0,
    edgeTolerance:         1.0,
    aggressionLevel:       1.0,
    targetCenterBias:      0.5,
    wanderPattern:         'patrol',
    minSafetyForFood:      0.40,   // v8: Safety floor stays meaningful
    minLengthToKill:       10
  };

  // ─── Mode Profiles (v2 — player-selectable playstyle) ─────────
  // Each mode is a set of multipliers consumed by all subsystems.
  // Phase profiles control WHAT the bot does at each size.
  // Mode profiles control HOW aggressively/cautiously it does it.
  var MODE_PROFILES = {
    aggressive: {
      killCommitMult:       1.5,   // v5: was 2.0 — 30 frames (500ms), less tunnel vision
      safetyCommitMult:     0.5,   // v3c: was 0.7 — break out of safety faster
      killBoostBudgetMult:  2.0,   // v3c: was 1.5 — 10% of length for kills
      foodBoostBudgetMult:  0.0,   // v3: no food boosting
      safetyNudgeCap:       0.10,  // v5: was 0.05 — minimum 10% dodge ability during kills
      killThreatGate:       0.8,   // v3c: was 0.7 — accept even more risk on kills
      killSizeRatioMult:    1.5,   // v3c: was 1.3 — target even bigger enemies
      deathFoodCommitMult:  1.5,   // v5b: was 1.3 — race harder for death food, longer commitment
      avoidanceRadiusMult:  0.65,  // v3c: was 0.85 — scan MUCH closer, stay near snakes
      foodSearchRadiusMult: 1.0,
      giantFleeRatioMult:   0.4,   // v3c: was 0.8 — only flee snakes 6.25x bigger
      edgeToleranceMult:    1.2,   // venture closer to edges
      coilCommitMult:       2.0,   // v3c: was 1.5 — hold coil attacks much longer
      boostCostAwareness:   0.5,   // v3c: was 0.7 — even less concerned
      safetyScoreMult:      0.35,  // v5: was 0.20 — safety can compete with kills
      safetyMagThreshold:   15.0   // v5: was 20.0 — react to threats earlier (avg mag ~14)
    },
    balanced: {
      killCommitMult:       1.0,
      safetyCommitMult:     1.0,
      killBoostBudgetMult:  1.0,
      foodBoostBudgetMult:  0.0,   // no food boosting
      safetyNudgeCap:       0.20,
      killThreatGate:       0.5,
      killSizeRatioMult:    1.0,
      deathFoodCommitMult:  1.0,
      avoidanceRadiusMult:  1.0,
      foodSearchRadiusMult: 1.0,
      giantFleeRatioMult:   1.0,
      edgeToleranceMult:    1.0,
      coilCommitMult:       1.0,
      boostCostAwareness:   1.0,
      safetyScoreMult:      1.0,   // v3: default safety scoring
      safetyMagThreshold:   4.0    // v5: was 5.0 — slightly more responsive
    },
    defensive: {
      killCommitMult:       0.5,   // short kill commitment (10 frames)
      safetyCommitMult:     1.5,   // longer safety holds (12 frames)
      killBoostBudgetMult:  0.3,   // tiny kill budgets (1.5%)
      foodBoostBudgetMult:  0.0,   // never boost for food
      safetyNudgeCap:       0.30,  // strong safety interference (30%)
      killThreatGate:       0.3,   // reject kills at lower threat
      killSizeRatioMult:    0.6,   // only target much smaller enemies
      deathFoodCommitMult:  0.7,   // cautious death food racing
      avoidanceRadiusMult:  1.3,   // scan further out (more cautious)
      foodSearchRadiusMult: 1.2,   // wider food search for steady growth
      giantFleeRatioMult:   1.3,   // flee earlier from giants
      edgeToleranceMult:    0.7,   // stay further from edges
      coilCommitMult:       0.5,   // short coil commitment
      boostCostAwareness:   1.5,   // very concerned about boost cost
      safetyScoreMult:      1.5,   // v3: safety scores 50% more — extra cautious
      safetyMagThreshold:   3.0    // v3: react to weaker threats
    }
  };

  // ─── Density Constants ────────────────────────────────────────
  var DENSITY_RADIUS          = 800;  // radius for enemy density check
  var HIGH_DENSITY_THRESHOLD  = 5;    // snakes in radius = crowded
  var LOW_DENSITY_THRESHOLD   = 2;    // snakes in radius = sparse

  // ─── Wander Constants ─────────────────────────────────────────
  var EDGE_HUG_RADIUS_RATIO  = 0.70; // orbit at 70% of map radius
  var SPIRAL_INWARD_RATE     = 0.002; // radians tightening per frame
  var SPIRAL_MIN_RADIUS      = 0.35; // fraction of map radius before reversing
  var SPIRAL_MAX_RADIUS      = 0.75;
  var PATROL_HOTZONE_RADIUS  = 600;  // radius around hotzone targets

  // ─── State ────────────────────────────────────────────────────
  var _phase         = PHASE.HATCHLING;
  var _params        = null;
  var _enemyDensity  = 0;
  var _mode          = 'balanced';  // v2: player-selected mode
  var _serverScale   = 1.0;         // v5c: rank-based threshold multiplier
  var _serverRank    = 0;           // v5c: cached server rank

  // Wander state
  var _wanderAngle     = 0;
  var _wanderRadius    = 0.6; // fraction of map radius
  var _wanderDirection = 1;   // 1 = outward/CW, -1 = inward/CCW
  var _wanderTargetX   = 0;
  var _wanderTargetY   = 0;
  var _patrolIndex     = 0;

  var _settings = {};

  // ─── Server-Relative Scaling (v5c) ─────────────────────────────
  // The game's `rank` variable is the player's live leaderboard position
  // (1 = #1 on server). Higher rank # = more snakes ahead of us.
  // We use rank to scale phase thresholds so the bot's self-assessment
  // matches reality. A length-200 bot on a 14K server is GROWING,
  // not PREDATOR.
  function getServerScale() {
    var r = 0;
    try { r = (typeof window.rank === 'number') ? window.rank : 0; } catch (e) {}
    _serverRank = r;

    if (r <= 0) return 1.0;      // no rank data yet — use base thresholds

    // Top 10: we're dominant, advance phases slightly faster
    if (r <= 10) return 0.85;
    // Top 25: normal thresholds — we're competitive
    if (r <= 25) return 1.0;
    // 26–50: moderate upscale — still mid-pack
    if (r <= 50) return 1.5;
    // 51–100: significant upscale — bottom of leaderboard
    if (r <= 100) return 2.5;
    // 101–200: heavy upscale — off leaderboard
    if (r <= 200) return 4.0;
    // 200+: maximum upscale — server is far ahead
    return 5.0;
  }

  // ─── Phase Determination ──────────────────────────────────────
  function determinePhase(length) {
    var scale = getServerScale();
    _serverScale = scale;

    var t0 = PHASE_THRESHOLDS[0] * scale;
    var t1 = PHASE_THRESHOLDS[1] * scale;
    var t2 = PHASE_THRESHOLDS[2] * scale;
    var t3 = PHASE_THRESHOLDS[3] * scale;

    if (length < t0) return PHASE.HATCHLING;
    if (length < t1) return PHASE.GROWING;
    if (length < t2) return PHASE.CONTENDER;
    if (length < t3) return PHASE.PREDATOR;
    return PHASE.APEX;
  }

  // ─── Enemy Density ────────────────────────────────────────────
  function computeDensity(trackedSnakes, playerX, playerY) {
    var count = 0;
    for (var i = 0; i < trackedSnakes.length; i++) {
      var t = trackedSnakes[i];
      var pos = t.positions.get(0);
      if (!pos) continue;
      var dSq = MathUtil.distanceSq(pos.x, pos.y, playerX, playerY);
      if (dSq < DENSITY_RADIUS * DENSITY_RADIUS) {
        count++;
      }
    }
    return count;
  }

  // ─── Parameter Blending ───────────────────────────────────────
  function computeParams(phase, density, mode) {
    var base = PHASE_PROFILES[phase];
    if (!base) base = PHASE_PROFILES[PHASE.HATCHLING];

    // Clone base params
    var p = {};
    var keys = Object.keys(base);
    for (var i = 0; i < keys.length; i++) {
      p[keys[i]] = base[keys[i]];
    }
    p.phase = phase;
    p.enemyDensity = density;
    p.serverScale = _serverScale;   // v5c: rank-based threshold multiplier
    p.serverRank = _serverRank;     // v5c: player's leaderboard rank

    // Density adjustments
    if (density >= HIGH_DENSITY_THRESHOLD) {
      // Crowded: be more cautious (v8: cap to prevent fleeing everything)
      p.avoidanceRadiusScale = Math.min(p.avoidanceRadiusScale * 1.15, 1.5);
      p.aggressionLevel *= 0.7;
      p.boostConservation *= 0.8;
    } else if (density <= LOW_DENSITY_THRESHOLD && phase !== PHASE.HATCHLING) {
      // Sparse: can afford to be bolder
      p.aggressionLevel = Math.min(1.0, p.aggressionLevel * 1.2);
      p.boostConservation = Math.min(1.0, p.boostConservation * 1.1);
    }

    // v2: Apply mode profile multipliers (replaces aggressiveness slider)
    var mp = MODE_PROFILES[mode] || MODE_PROFILES['balanced'];
    p.avoidanceRadiusScale  *= mp.avoidanceRadiusMult;
    p.foodSearchRadiusScale *= mp.foodSearchRadiusMult;
    p.killSizeRatio = MathUtil.clamp(p.killSizeRatio * mp.killSizeRatioMult, 0, 5.0);
    p.edgeTolerance = MathUtil.clamp((p.edgeTolerance || 1.0) * mp.edgeToleranceMult, 0, 1.5);

    // Pass through mode-specific params for subsystem consumption
    p.killCommitMult       = mp.killCommitMult;
    p.safetyCommitMult     = mp.safetyCommitMult;
    p.killBoostBudgetMult  = mp.killBoostBudgetMult;
    p.foodBoostBudgetMult  = mp.foodBoostBudgetMult;
    p.safetyNudgeCap       = mp.safetyNudgeCap;
    p.killThreatGate       = mp.killThreatGate;
    p.deathFoodCommitMult  = mp.deathFoodCommitMult;
    p.giantFleeRatioMult   = mp.giantFleeRatioMult;
    p.coilCommitMult       = mp.coilCommitMult;
    p.boostCostAwareness   = mp.boostCostAwareness;
    p.safetyScoreMult      = mp.safetyScoreMult;
    p.safetyMagThreshold   = mp.safetyMagThreshold;
    p.mode = mode;

    return p;
  }

  // ─── Wander Pattern Generators ────────────────────────────────
  function computeWanderTarget(pattern, playerX, playerY, mapRadius, foodBursts) {
    if (pattern === 'edge-hug') {
      return _wanderEdgeHug(playerX, playerY, mapRadius);
    } else if (pattern === 'spiral') {
      return _wanderSpiral(playerX, playerY, mapRadius);
    } else if (pattern === 'patrol') {
      return _wanderPatrol(playerX, playerY, mapRadius, foodBursts);
    }
    // Fallback: drift toward center
    return { x: mapRadius, y: mapRadius };
  }

  function _wanderEdgeHug(playerX, playerY, mapRadius) {
    var targetRadius = mapRadius * EDGE_HUG_RADIUS_RATIO;
    _wanderAngle += 0.015 * _wanderDirection; // slow orbit

    // Offset by mapRadius — map center is at (mapRadius, mapRadius), not (0,0)
    _wanderTargetX = mapRadius + Math.cos(_wanderAngle) * targetRadius;
    _wanderTargetY = mapRadius + Math.sin(_wanderAngle) * targetRadius;

    return { x: _wanderTargetX, y: _wanderTargetY };
  }

  function _wanderSpiral(playerX, playerY, mapRadius) {
    // Spiral between 35% and 75% of map radius
    _wanderRadius += SPIRAL_INWARD_RATE * _wanderDirection;

    if (_wanderRadius > SPIRAL_MAX_RADIUS) {
      _wanderDirection = -1; // start spiraling inward
    } else if (_wanderRadius < SPIRAL_MIN_RADIUS) {
      _wanderDirection = 1;  // start spiraling outward
    }

    _wanderAngle += 0.02; // rotation speed
    var r = mapRadius * _wanderRadius;
    // Offset by mapRadius — map center is at (mapRadius, mapRadius), not (0,0)
    _wanderTargetX = mapRadius + Math.cos(_wanderAngle) * r;
    _wanderTargetY = mapRadius + Math.sin(_wanderAngle) * r;

    return { x: _wanderTargetX, y: _wanderTargetY };
  }

  function _wanderPatrol(playerX, playerY, mapRadius, foodBursts) {
    // Build patrol hotzone list: center + food burst locations
    var hotzones = [{ x: mapRadius, y: mapRadius }]; // center is always a hotzone

    if (foodBursts && foodBursts.length > 0) {
      for (var i = 0; i < foodBursts.length && i < 3; i++) {
        hotzones.push({ x: foodBursts[i].x, y: foodBursts[i].y });
      }
    }

    // Check if we're near current target
    var target = hotzones[_patrolIndex % hotzones.length];
    var distSq = MathUtil.distanceSq(playerX, playerY, target.x, target.y);

    if (distSq < PATROL_HOTZONE_RADIUS * PATROL_HOTZONE_RADIUS) {
      // Arrived — move to next hotzone
      _patrolIndex = (_patrolIndex + 1) % hotzones.length;
      target = hotzones[_patrolIndex];
    }

    return { x: target.x, y: target.y };
  }

  // ─── Main Update ──────────────────────────────────────────────
  function update(playerSnake, trackedSnakes, foodBursts) {
    if (!playerSnake) return;

    var newPhase = determinePhase(playerSnake.length || 0);
    _phase = newPhase;

    _enemyDensity = computeDensity(
      trackedSnakes || [],
      playerSnake.x,
      playerSnake.y
    );

    _params = computeParams(_phase, _enemyDensity, _mode);
  }

  // ─── Public API ───────────────────────────────────────────────
  function init(settings) {
    _settings = (settings && settings.bot) ? settings.bot : {};
    _mode = _settings.mode || 'balanced';
    _phase = PHASE.HATCHLING;
    _params = computeParams(_phase, 0, _mode);
    _wanderAngle = Math.random() * Math.PI * 2;
    _wanderRadius = 0.6;
    _wanderDirection = 1;
    _patrolIndex = 0;
  }

  function updateSettings(settings) {
    _settings = (settings && settings.bot) ? settings.bot : {};
    _mode = _settings.mode || 'balanced';
  }

  function getMode() {
    return _mode;
  }

  function getParams() {
    return _params || computeParams(PHASE.HATCHLING, 0, _mode);
  }

  function getPhase() {
    return _phase;
  }

  function getWanderTarget(playerX, playerY, mapRadius, foodBursts) {
    if (!_params) return { x: mapRadius, y: mapRadius };
    return computeWanderTarget(_params.wanderPattern, playerX, playerY, mapRadius, foodBursts);
  }

  function reset() {
    _phase = PHASE.HATCHLING;
    _params = computeParams(PHASE.HATCHLING, 0, _mode);
    _wanderAngle = Math.random() * Math.PI * 2;
    _wanderRadius = 0.6;
    _wanderDirection = 1;
    _patrolIndex = 0;
  }

  // ─── Export ───────────────────────────────────────────────────
  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.StrategyManager = {
    init:            init,
    reset:           reset,
    update:          update,
    updateSettings:  updateSettings,
    getParams:       getParams,
    getPhase:        getPhase,
    getMode:         getMode,
    getWanderTarget: getWanderTarget,
    getServerScale:  function () { return _serverScale; },  // v5c
    getServerRank:   function () { return _serverRank; },   // v5c
    PHASE:           PHASE
  };

})();
