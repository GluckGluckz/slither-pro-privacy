/**
 * Slither Pro — Snake Tracker (Bot AI v2)
 * Persistent identity tracking + behavior classification of opponent snakes.
 * Tracks snakes across frames using their id, computes real velocity/turn-rate
 * from position deltas, classifies behavior (PASSIVE, AGGRESSIVE, CIRCLING, ERRATIC),
 * and detects dead-snake food bursts.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP || !SP.MathUtil) {
    console.error('[SlitherPro] SnakeTracker: missing dependencies');
    return;
  }

  var MathUtil = SP.MathUtil;

  // ─── Constants ────────────────────────────────────────────────
  var HISTORY_SIZE          = 30;    // position ring buffer capacity
  var STALE_THRESHOLD       = 90;    // frames before dropping a tracked snake
  var FOOD_BURST_DECAY      = 480;   // v4d: was 300 (~5s). Now ~8s — food persists on screen, give bot time to reach it
  var FOOD_BURST_MIN_LENGTH = 15;    // min snake length to generate a food burst
  var FOOD_BURST_MAX_DIST   = 1000;  // v4d: was 600. View range is ~700-1200, catch deaths within visible area
  var BEHAVIOR_WINDOW       = 15;    // frames for behavior classification
  var AGGRESSIVE_ANGLE      = Math.PI / 3;   // ~60° — heading toward us
  var CIRCLING_TURN_RATE    = 0.03;  // rad/frame sustained = circling
  var ERRATIC_SIGN_CHANGES  = 6;     // turn direction flips in window = erratic
  var PREDICT_FALLBACK_FRAMES = 3;   // min history before using curved prediction

  // Behavior enum
  var BEHAVIOR = {
    PASSIVE:    'PASSIVE',
    AGGRESSIVE: 'AGGRESSIVE',
    CIRCLING:   'CIRCLING',
    ERRATIC:    'ERRATIC'
  };

  // ─── State ────────────────────────────────────────────────────
  var _tracked      = {};   // keyed by snake.id
  var _foodBursts   = [];   // [{x, y, frame, estimatedValue}]
  var _frameCounter = 0;
  var _playerX      = 0;
  var _playerY      = 0;

  // ─── Ring Buffer Helper ───────────────────────────────────────
  function RingBuffer(capacity) {
    this.capacity = capacity;
    this.data = [];
    this.head = 0;
    this.length = 0;
  }

  RingBuffer.prototype.push = function (item) {
    if (this.length < this.capacity) {
      this.data.push(item);
      this.length++;
    } else {
      this.data[this.head] = item;
    }
    this.head = (this.head + 1) % this.capacity;
  };

  RingBuffer.prototype.get = function (indexFromEnd) {
    // 0 = most recent, 1 = one before that, etc.
    if (indexFromEnd >= this.length) return null;
    var idx = (this.head - 1 - indexFromEnd + this.capacity * 2) % this.capacity;
    return this.data[idx];
  };

  RingBuffer.prototype.clear = function () {
    this.data = [];
    this.head = 0;
    this.length = 0;
  };

  // ─── Tracked Entry Factory ────────────────────────────────────
  function createEntry(snake) {
    var entry = {
      id:                 snake.id,
      positions:          new RingBuffer(HISTORY_SIZE),
      avgSpeed:           snake.speed || 0,
      avgTurnRate:        0,
      velocityX:          0,
      velocityY:          0,
      behavior:           BEHAVIOR.PASSIVE,
      behaviorConfidence: 0,
      lastSeen:           _frameCounter,
      lastLength:         snake.length || 0,
      approachAngle:      0,
      isApproaching:      false,
      isOrbiting:         false,  // v5: stable distance, circling nearby
      threatLevel:        0
    };
    entry.positions.push({
      x:           snake.x,
      y:           snake.y,
      angle:       snake.angle,
      wantedAngle: snake.wantedAngle,
      speed:       snake.speed,
      frame:       _frameCounter
    });
    return entry;
  }

  // ─── Velocity & Turn Rate Computation ─────────────────────────
  function computeVelocity(entry) {
    var buf = entry.positions;
    if (buf.length < 2) return;

    var cur  = buf.get(0);
    var prev = buf.get(1);
    if (!cur || !prev) return;

    var dt = cur.frame - prev.frame;
    if (dt <= 0) dt = 1;

    entry.velocityX = (cur.x - prev.x) / dt;
    entry.velocityY = (cur.y - prev.y) / dt;

    // Average speed over last 5 frames for stability
    var totalSpeed = 0;
    var count = 0;
    var samples = Math.min(5, buf.length);
    for (var i = 0; i < samples; i++) {
      var p = buf.get(i);
      if (p) {
        totalSpeed += p.speed;
        count++;
      }
    }
    entry.avgSpeed = count > 0 ? totalSpeed / count : (cur.speed || 0);
  }

  function computeTurnRate(entry) {
    var buf = entry.positions;
    var samples = Math.min(5, buf.length - 1);
    if (samples < 1) {
      entry.avgTurnRate = 0;
      return;
    }

    var totalTurn = 0;
    var actualSamples = 0;
    for (var i = 0; i < samples; i++) {
      var cur  = buf.get(i);
      var prev = buf.get(i + 1);
      if (!cur || !prev) break;
      var diff = cur.angle - prev.angle;
      // Normalize to [-PI, PI]
      while (diff > Math.PI)  diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      var dt = cur.frame - prev.frame;
      if (dt <= 0) dt = 1;
      totalTurn += diff / dt;
      actualSamples++;
    }
    entry.avgTurnRate = actualSamples > 0 ? totalTurn / actualSamples : 0;
  }

  // ─── Behavior Classification ──────────────────────────────────
  function classifyBehavior(entry) {
    var buf = entry.positions;
    if (buf.length < BEHAVIOR_WINDOW) {
      entry.behavior = BEHAVIOR.PASSIVE;
      entry.behaviorConfidence = 0.2;
      return;
    }

    // Gather window data
    var windowSize = Math.min(BEHAVIOR_WINDOW, buf.length - 1);
    var approachCount   = 0;
    var turnSignChanges = 0;
    var totalAbsTurn    = 0;
    var prevTurnSign    = 0;

    for (var i = 0; i < windowSize; i++) {
      var cur  = buf.get(i);
      var prev = buf.get(i + 1);
      if (!cur || !prev) break;

      // Check if heading toward player
      var angleToPlayer = MathUtil.angle(cur.x, cur.y, _playerX, _playerY);
      var headingDiff = Math.abs(cur.angle - angleToPlayer);
      while (headingDiff > Math.PI) headingDiff = Math.PI * 2 - headingDiff;
      if (headingDiff < AGGRESSIVE_ANGLE) {
        approachCount++;
      }

      // Track turn rate sign changes
      var turnDiff = cur.angle - prev.angle;
      while (turnDiff > Math.PI)  turnDiff -= Math.PI * 2;
      while (turnDiff < -Math.PI) turnDiff += Math.PI * 2;
      totalAbsTurn += Math.abs(turnDiff);

      var turnSign = turnDiff > 0.005 ? 1 : (turnDiff < -0.005 ? -1 : 0);
      if (turnSign !== 0 && prevTurnSign !== 0 && turnSign !== prevTurnSign) {
        turnSignChanges++;
      }
      if (turnSign !== 0) prevTurnSign = turnSign;
    }

    // Classify
    var avgAbsTurn = totalAbsTurn / windowSize;

    // AGGRESSIVE: consistently heading toward us
    if (approachCount >= windowSize * 0.53 && entry.isApproaching) {
      entry.behavior = BEHAVIOR.AGGRESSIVE;
      entry.behaviorConfidence = Math.min(1.0, approachCount / windowSize);
      return;
    }

    // CIRCLING: sustained turn rate in one direction
    if (Math.abs(entry.avgTurnRate) > CIRCLING_TURN_RATE && turnSignChanges <= 2) {
      entry.behavior = BEHAVIOR.CIRCLING;
      entry.behaviorConfidence = Math.min(1.0, Math.abs(entry.avgTurnRate) / (CIRCLING_TURN_RATE * 2));
      return;
    }

    // ERRATIC: frequent direction changes
    if (turnSignChanges >= ERRATIC_SIGN_CHANGES) {
      entry.behavior = BEHAVIOR.ERRATIC;
      entry.behaviorConfidence = Math.min(1.0, turnSignChanges / (ERRATIC_SIGN_CHANGES * 2));
      return;
    }

    // Default: PASSIVE
    entry.behavior = BEHAVIOR.PASSIVE;
    entry.behaviorConfidence = 0.8 - (avgAbsTurn * 5); // less confident if turning a lot
    if (entry.behaviorConfidence < 0.2) entry.behaviorConfidence = 0.2;
  }

  // ─── Approach & Threat Analysis ───────────────────────────────
  function computeApproach(entry) {
    var buf = entry.positions;
    var cur = buf.get(0);
    if (!cur) return;

    // Angle from enemy to player
    entry.approachAngle = MathUtil.angle(cur.x, cur.y, _playerX, _playerY);

    // Is getting closer?
    if (buf.length >= 3) {
      var prev = buf.get(2);
      if (prev) {
        var distNow  = MathUtil.distanceSq(cur.x, cur.y, _playerX, _playerY);
        var distPrev = MathUtil.distanceSq(prev.x, prev.y, _playerX, _playerY);
        entry.isApproaching = distNow < distPrev * 0.98; // 2% closer = approaching
      }
    }

    // v5: Orbital detection — snake nearby at stable distance (circling, not approaching/retreating).
    // A giant orbiting at ~400 units will have distNow/distOlder ratio between 0.92 and 1.08
    entry.isOrbiting = false;
    if (buf.length >= 5) {
      var older = buf.get(4);
      if (older) {
        var distNowSq  = MathUtil.distanceSq(cur.x, cur.y, _playerX, _playerY);
        var distOlderSq = MathUtil.distanceSq(older.x, older.y, _playerX, _playerY);
        if (distOlderSq > 0) {
          var ratio = distNowSq / distOlderSq;
          // Stable distance (ratio ~1.0) AND within 600 units (sq = 360000)
          entry.isOrbiting = (ratio > 0.92 && ratio < 1.08 && distNowSq < 360000);
        }
      }
    }
  }

  function computeThreatLevel(entry) {
    var buf = entry.positions;
    var cur = buf.get(0);
    if (!cur) { entry.threatLevel = 0; return; }

    // Approach factor: how directly heading toward us (0..1)
    var headingDiff = Math.abs(cur.angle - entry.approachAngle);
    while (headingDiff > Math.PI) headingDiff = Math.PI * 2 - headingDiff;
    var approachFactor = 1.0 - (headingDiff / Math.PI);
    if (!entry.isApproaching) approachFactor *= 0.3;

    // Speed factor: faster = more dangerous (0..1)
    var speedFactor = MathUtil.clamp(entry.avgSpeed / 16, 0, 1);

    // Size factor: larger = more dangerous (0..1)
    var sizeFactor = MathUtil.clamp(entry.lastLength / 200, 0, 1);

    // Behavior factor
    var behaviorFactor = 0.1;
    if (entry.behavior === BEHAVIOR.AGGRESSIVE) behaviorFactor = 1.0;
    else if (entry.behavior === BEHAVIOR.CIRCLING) behaviorFactor = 0.7;
    else if (entry.behavior === BEHAVIOR.ERRATIC) behaviorFactor = 0.3;

    entry.threatLevel = approachFactor * 0.4 +
                        speedFactor   * 0.2 +
                        sizeFactor    * 0.2 +
                        behaviorFactor * 0.2;
  }

  // ─── Food Burst Detection ─────────────────────────────────────
  function checkFoodBursts(currentSnakeIds) {
    var trackedIds = Object.keys(_tracked);
    for (var i = 0; i < trackedIds.length; i++) {
      var id    = trackedIds[i];
      var entry = _tracked[id];

      // If snake was seen recently but is now gone
      if (!currentSnakeIds[id] && (_frameCounter - entry.lastSeen) > 2 &&
          (_frameCounter - entry.lastSeen) < 10) {
        // v5b: One-shot guard — only create one burst per disappearance.
        // Without this, the same death creates 7 duplicate burst entries
        // (one per frame in the 3-9 frame window after lastSeen).
        if (entry._burstCreated) continue;

        // Snake disappeared suddenly — likely died
        var lastPos = entry.positions.get(0);
        if (lastPos && entry.lastLength >= FOOD_BURST_MIN_LENGTH) {
          // v4: Only create burst if snake was close to player.
          // Snakes far away that disappear probably just left view range, not died.
          var burstDist = MathUtil.distance(_playerX, _playerY, lastPos.x, lastPos.y);
          if (burstDist <= FOOD_BURST_MAX_DIST) {
            _foodBursts.push({
              x:              lastPos.x,
              y:              lastPos.y,
              frame:          _frameCounter,
              estimatedValue: entry.lastLength * 2 // rough food value
            });
            entry._burstCreated = true;  // v5b: prevent duplicates
          }
        }
      }
    }

    // Decay old bursts
    var fresh = [];
    for (var j = 0; j < _foodBursts.length; j++) {
      if (_frameCounter - _foodBursts[j].frame < FOOD_BURST_DECAY) {
        fresh.push(_foodBursts[j]);
      }
    }
    _foodBursts = fresh;
  }

  // ─── Curved Path Prediction ───────────────────────────────────
  function predictPosition(id, framesAhead) {
    var entry = _tracked[id];
    if (!entry) return null;

    var buf = entry.positions;
    var cur = buf.get(0);
    if (!cur) return null;

    // v8: Curve-aware fallback using wantedAngle instead of dead-linear
    if (buf.length < PREDICT_FALLBACK_FRAMES) {
      var fx = cur.x, fy = cur.y, fAng = cur.angle;
      var fSpd = entry.avgSpeed;
      var wAng = cur.wantedAngle !== undefined ? cur.wantedAngle : fAng;
      var wDiff = wAng - fAng;
      while (wDiff > Math.PI) wDiff -= Math.PI * 2;
      while (wDiff < -Math.PI) wDiff += Math.PI * 2;
      var turnEst = wDiff * 0.08;
      for (var ff = 0; ff < framesAhead; ff++) {
        fAng += turnEst;
        fx += Math.cos(fAng) * fSpd;
        fy += Math.sin(fAng) * fSpd;
        turnEst *= 0.92;
      }
      return { x: fx, y: fy, angle: fAng };
    }

    // Curved prediction using measured velocity + turn rate
    var x     = cur.x;
    var y     = cur.y;
    var angle = cur.angle;
    var speed = entry.avgSpeed;
    var turn  = entry.avgTurnRate;

    // Dampen turn rate slightly over time (snakes don't turn forever)
    var turnDamping = 0.97;

    for (var f = 0; f < framesAhead; f++) {
      angle += turn;
      x += Math.cos(angle) * speed;
      y += Math.sin(angle) * speed;
      turn *= turnDamping;
    }

    return { x: x, y: y, angle: angle };
  }

  // ─── Main Update ──────────────────────────────────────────────
  function update(nearbySnakes, playerX, playerY, frameCounter) {
    _frameCounter = frameCounter;
    _playerX = playerX;
    _playerY = playerY;

    // Build lookup of current snake IDs
    var currentIds = {};
    for (var i = 0; i < nearbySnakes.length; i++) {
      var snake = nearbySnakes[i];
      if (!snake) continue;
      currentIds[snake.id] = true;

      var entry = _tracked[snake.id];
      if (!entry) {
        // New snake — create entry
        entry = createEntry(snake);
        _tracked[snake.id] = entry;
      } else {
        // Existing snake — push new position
        entry.positions.push({
          x:           snake.x,
          y:           snake.y,
          angle:       snake.angle,
          wantedAngle: snake.wantedAngle,
          speed:       snake.speed,
          frame:       _frameCounter
        });
        entry.lastSeen = _frameCounter;
        entry.lastLength = snake.length || entry.lastLength;
      }

      // Compute derived data
      computeVelocity(entry);
      computeTurnRate(entry);
      computeApproach(entry);
      computeThreatLevel(entry);
    }

    // Classify behavior every BEHAVIOR_WINDOW frames (not every frame)
    if (_frameCounter % BEHAVIOR_WINDOW === 0) {
      var allIds = Object.keys(_tracked);
      for (var b = 0; b < allIds.length; b++) {
        if (currentIds[allIds[b]]) {
          classifyBehavior(_tracked[allIds[b]]);
        }
      }
    }

    // Detect food bursts from disappeared snakes
    checkFoodBursts(currentIds);

    // Prune stale entries
    var staleIds = Object.keys(_tracked);
    for (var s = 0; s < staleIds.length; s++) {
      if (_frameCounter - _tracked[staleIds[s]].lastSeen > STALE_THRESHOLD) {
        delete _tracked[staleIds[s]];
      }
    }
  }

  // ─── Public API ───────────────────────────────────────────────
  function init() {
    _tracked = {};
    _foodBursts = [];
    _frameCounter = 0;
  }

  function reset() {
    _tracked = {};
    _foodBursts = [];
    _frameCounter = 0;
  }

  function getTracked(id) {
    return _tracked[id] || null;
  }

  function getAllTracked() {
    var result = [];
    var ids = Object.keys(_tracked);
    for (var i = 0; i < ids.length; i++) {
      result.push(_tracked[ids[i]]);
    }
    return result;
  }

  function getAggressors() {
    var result = [];
    var ids = Object.keys(_tracked);
    for (var i = 0; i < ids.length; i++) {
      if (_tracked[ids[i]].behavior === BEHAVIOR.AGGRESSIVE) {
        result.push(_tracked[ids[i]]);
      }
    }
    return result;
  }

  function getFoodBursts() {
    return _foodBursts;
  }

  function getFrameCounter() {
    return _frameCounter;
  }

  // ─── Export ───────────────────────────────────────────────────
  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.SnakeTracker = {
    init:             init,
    reset:            reset,
    update:           update,
    getTracked:       getTracked,
    getAllTracked:     getAllTracked,
    getAggressors:    getAggressors,
    getFoodBursts:    getFoodBursts,
    getFrameCounter:  getFrameCounter,
    predictPosition:  predictPosition,
    BEHAVIOR:         BEHAVIOR
  };

})();
