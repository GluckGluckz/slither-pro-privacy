/**
 * Slither Pro — Visual Effects.
 * Background theme filter + your-snake boost trail particles.
 *
 * Kept deliberately small: we no longer fire any death/kill/shake
 * effects. Those were pure CPU cost with no gameplay value and were
 * removed in the v1.3.x audit pass. The boost trail stays and paints
 * on the player's own snake — disabled under Graphics Quality = Low
 * since it's the single hottest particle source.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI;
  var settings = null;
  var _initialized = false;
  var _lastBgTheme = null;
  var _lastBgColor = null;
  var _bgOverlay = null;

  /* ── Game background canvas hook state ──────────────────── */
  var _origFillRect = null;
  var _gameBgColor = null;
  var _gameBgCanvas = null;
  var _lastGameBgEnabled = null;
  var _lastGameBgColor = null;

  /* ── Particle pool ──────────────────────────────────────── */
  var MAX_PARTICLES = 200;
  var _particles = [];
  var _particleCount = 0;

  /* ── Boost trail state ──────────────────────────────────── */
  var _lastPlayerX = 0;
  var _lastPlayerY = 0;

  // Pre-allocate particle pool
  for (var p = 0; p < MAX_PARTICLES; p++) {
    _particles.push({
      active: false,
      x: 0, y: 0,
      vx: 0, vy: 0,
      life: 0, maxLife: 0,
      size: 0,
      r: 0, g: 0, b: 0,
      type: '' // 'burst', 'trail', 'spark'
    });
  }

  function _spawnParticle(x, y, vx, vy, life, size, r, g, b, type) {
    if (_particleCount >= MAX_PARTICLES) return;
    for (var i = 0; i < MAX_PARTICLES; i++) {
      if (!_particles[i].active) {
        var pt = _particles[i];
        pt.active = true;
        pt.x = x; pt.y = y;
        pt.vx = vx; pt.vy = vy;
        pt.life = life; pt.maxLife = life;
        pt.size = size;
        pt.r = r; pt.g = g; pt.b = b;
        pt.type = type;
        _particleCount++;
        return;
      }
    }
  }

  var VisualEffects = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;
      GameAPI = SP.GameAPI;
      settings = s;
      this._applyBackground(s);
      this._applyGameBackground(s);
    },

    updateSettings: function (s) {
      settings = s;
      this._applyBackground(s);
      this._applyGameBackground(s);
    },

    /* ── Public triggers ─────────────────────────────────── */

    /**
     * Whether the player's own boost trail particles should spawn.
     * 'low' graphics quality disables the trail entirely since it's
     * the single hottest particle source (~3 spawns per frame while
     * boosting).
     */
    _boostFxAllowed: function () {
      if (!settings || !settings.gameplay) return true;
      return settings.gameplay.graphicsQuality !== 'low';
    },

    /**
     * Spawn boost trail particles behind the snake head.
     * @param {object} [skinColor] - optional {r,g,b} to match active skin
     */
    spawnBoostTrail: function (worldX, worldY, angle, skinColor) {
      if (!this._boostFxAllowed()) return;
      var pr = skinColor ? skinColor.r : 255;
      var pg = skinColor ? skinColor.g : (165 + Math.floor(Math.random() * 60));
      var pb = skinColor ? skinColor.b : 0;
      for (var i = 0; i < 3; i++) {
        var spread = (Math.random() - 0.5) * 0.6;
        var backAngle = angle + Math.PI + spread;
        var speed = 0.8 + Math.random() * 1.5;
        // Add slight color variation for natural look
        var cr = Math.min(255, Math.max(0, pr + Math.floor((Math.random() - 0.5) * 40)));
        var cg = Math.min(255, Math.max(0, pg + Math.floor((Math.random() - 0.5) * 40)));
        var cb = Math.min(255, Math.max(0, pb + Math.floor((Math.random() - 0.5) * 40)));
        _spawnParticle(
          worldX + (Math.random() - 0.5) * 6,
          worldY + (Math.random() - 0.5) * 6,
          Math.cos(backAngle) * speed, Math.sin(backAngle) * speed,
          15 + Math.floor(Math.random() * 10),
          2 + Math.random() * 3,
          cr, cg, cb,
          'trail'
        );
      }
    },

    /**
     * Overlay render — boost trail particles.
     */
    render: function (ctx, canvas, s) {
      if (!s) return;

      // ── Render particles ──────────────────────────────
      var viewPos = GameAPI ? GameAPI.getViewPosition() : null;
      var scale = GameAPI ? GameAPI.getScale() : 1;
      if (viewPos && _particleCount > 0) {
        var cx = canvas.width / 2;
        var cy = canvas.height / 2;

        for (var i = 0; i < MAX_PARTICLES; i++) {
          var pt = _particles[i];
          if (!pt.active) continue;

          // Update
          pt.x += pt.vx;
          pt.y += pt.vy;
          pt.vx *= 0.96;  // friction
          pt.vy *= 0.96;
          pt.life--;

          if (pt.life <= 0) {
            pt.active = false;
            _particleCount = Math.max(0, _particleCount - 1);
            continue;
          }

          // World to screen
          var screenX = cx + (pt.x - viewPos.x) * scale;
          var screenY = cy + (pt.y - viewPos.y) * scale;

          // Cull off-screen
          if (screenX < -20 || screenX > canvas.width + 20 ||
              screenY < -20 || screenY > canvas.height + 20) continue;

          var alpha = pt.life / pt.maxLife;
          var drawSize = pt.size * scale * alpha;
          if (drawSize < 0.5) continue;

          ctx.globalAlpha = alpha * 0.8;
          ctx.fillStyle = 'rgb(' + pt.r + ',' + pt.g + ',' + pt.b + ')';

          if (pt.type === 'burst') {
            // Glow effect for burst particles
            ctx.shadowColor = 'rgb(' + pt.r + ',' + pt.g + ',' + pt.b + ')';
            ctx.shadowBlur = drawSize * 2;
          }

          ctx.beginPath();
          ctx.arc(screenX, screenY, drawSize, 0, Math.PI * 2);
          ctx.fill();

          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
        }
      }

      ctx.globalAlpha = 1;
    },

    // ─── Background Theme ─────────────────────────────────────
    // Uses a dedicated overlay div with mix-blend-mode instead of CSS
    // filter, so snakes and food stay vivid while the arena is tinted.

    _applyBackground: function (s) {
      if (!s || !s.visual) return;
      var theme = s.visual.background;
      var bgColor = s.visual.backgroundColor || '#111111';

      // Skip redundant updates
      if (theme === _lastBgTheme && bgColor === _lastBgColor) return;
      _lastBgTheme = theme;
      _lastBgColor = bgColor;

      // Remove any legacy CSS filter on the game canvas
      var gameCanvas = GameAPI ? GameAPI.getGameCanvas() : null;
      if (gameCanvas) {
        gameCanvas.style.removeProperty('filter');
      }

      // Default — remove overlay entirely
      if (theme === 'default') {
        if (_bgOverlay) _bgOverlay.style.display = 'none';
        return;
      }

      // Create overlay div on first use
      if (!_bgOverlay) {
        _bgOverlay = document.createElement('div');
        _bgOverlay.id = 'sp-bg-overlay';
        _bgOverlay.style.cssText = [
          'position:fixed',
          'top:0',
          'left:0',
          'width:100vw',
          'height:100vh',
          'pointer-events:none',
          'z-index:1',
          'transition:background .4s,opacity .4s',
          'mix-blend-mode:multiply'
        ].join(';');
        // MUST stay in <body> so mix-blend-mode:multiply blends against the
        // game canvas. Placing it inside sp-hud-root (z-index: max) creates
        // a new stacking context that isolates it from the canvas, which
        // makes the overlay paint its raw color (gray) instead of tinting.
        document.body.appendChild(_bgOverlay);
      }

      _bgOverlay.style.display = '';
      _bgOverlay.style.opacity = '1';
      _bgOverlay.style.mixBlendMode = 'multiply';

      switch (theme) {
        case 'dark':
          // Subtle darkening — dark areas get darker, bright snakes stay bright
          _bgOverlay.style.background = 'rgba(180,180,190,1)';
          _bgOverlay.style.mixBlendMode = 'multiply';
          break;
        case 'midnight':
          // Deep blue-purple tint on the arena
          _bgOverlay.style.background = 'rgba(120,110,200,1)';
          _bgOverlay.style.mixBlendMode = 'multiply';
          break;
        case 'custom':
          var rgb = this._hexToRgb(bgColor);
          if (rgb) {
            // Lighten the color so multiply blending tints without crushing blacks
            var cr = Math.min(255, rgb.r + 100);
            var cg = Math.min(255, rgb.g + 100);
            var cb = Math.min(255, rgb.b + 100);
            _bgOverlay.style.background = 'rgb(' + cr + ',' + cg + ',' + cb + ')';
            _bgOverlay.style.mixBlendMode = 'multiply';
          }
          break;
        default:
          if (_bgOverlay) _bgOverlay.style.display = 'none';
          break;
      }
    },

    // ─── Game Background (Canvas Hook) ───────────────────────────
    // Hooks CanvasRenderingContext2D.fillRect to intercept full-canvas
    // background fills and replace the color — actually changes what
    // the game renders instead of overlaying a filter.

    _applyGameBackground: function (s) {
      if (!s || !s.visual) return;
      var enabled = !!s.visual.gameBackgroundEnabled;
      var color = s.visual.gameBackgroundColor || '#0a0a2e';

      // Skip if nothing changed
      if (enabled === _lastGameBgEnabled && color === _lastGameBgColor) return;
      _lastGameBgEnabled = enabled;
      _lastGameBgColor = color;

      if (!enabled) {
        _gameBgColor = null;
        return;
      }

      var gameCanvas = GameAPI ? GameAPI.getGameCanvas() : null;
      if (!gameCanvas) return;

      _gameBgCanvas = gameCanvas;
      _gameBgColor = color;

      // Hook fillRect once — stays installed, becomes pass-through when disabled
      if (!_origFillRect) {
        _origFillRect = CanvasRenderingContext2D.prototype.fillRect;
        var savedFR = _origFillRect;
        CanvasRenderingContext2D.prototype.fillRect = function (x, y, w, h) {
          if (_gameBgColor && this.canvas === _gameBgCanvas) {
            var area = Math.abs(w * h);
            var canvasArea = this.canvas.width * this.canvas.height;
            if (area >= canvasArea * 0.85) {
              var origStyle = this.fillStyle;
              this.fillStyle = _gameBgColor;
              savedFR.call(this, x, y, w, h);
              this.fillStyle = origStyle;
              return;
            }
          }
          savedFR.call(this, x, y, w, h);
        };
      }
    },

    _hexToRgb: function (hex) {
      var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : null;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.VisualEffects = VisualEffects;
})();
