/**
 * Slither Pro — Zoom Mod.
 * Overrides mouse wheel to control game zoom with smooth interpolation.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI, MathUtil, CONSTANTS;
  var settings = null;

  var targetZoom = 0.9;
  var currentZoom = 0.9;
  var _initialized = false;

  var ZoomMod = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;

      GameAPI = SP.GameAPI;
      MathUtil = SP.MathUtil;
      CONSTANTS = SP.CONSTANTS;
      settings = s;

      targetZoom = s.zoom.level || CONSTANTS.DEFAULT_SCALE;
      currentZoom = targetZoom;

      this._attachListeners();
    },

    updateSettings: function (s) {
      if (!s || !s.zoom) return;
      // Only update targetZoom if zoom.level was explicitly changed
      // (not from unrelated setting updates like food style, grid, etc.)
      var oldLevel = settings && settings.zoom ? settings.zoom.level : undefined;
      settings = s;
      if (s.zoom.level !== undefined && s.zoom.level !== oldLevel) {
        targetZoom = s.zoom.level;
      }
    },

    /**
     * Called each frame. Smoothly interpolates toward target zoom.
     */
    update: function () {
      if (!settings || !settings.zoom || !settings.zoom.enabled) return;

      if (settings.zoom.smoothing) {
        currentZoom = MathUtil.lerp(currentZoom, targetZoom, 0.15);
        // Snap if very close
        if (Math.abs(currentZoom - targetZoom) < 0.001) {
          currentZoom = targetZoom;
        }
      } else {
        currentZoom = targetZoom;
      }

      GameAPI.setScale(currentZoom);
    },

    resetZoom: function () {
      targetZoom = CONSTANTS.DEFAULT_SCALE;
      currentZoom = CONSTANTS.DEFAULT_SCALE;
      GameAPI.setScale(CONSTANTS.DEFAULT_SCALE);
    },

    _attachListeners: function () {
      var self = this;

      // Mouse wheel zoom
      document.addEventListener('wheel', function (e) {
        if (!settings || !settings.zoom || !settings.zoom.enabled) return;
        if (!GameAPI.isPlaying()) return;

        e.preventDefault();

        var sensitivity = settings.zoom.sensitivity || 0.05;
        if (e.deltaY < 0) {
          // Scroll up = zoom in (decrease scale value for closer view)
          targetZoom = MathUtil.clamp(targetZoom - sensitivity, CONSTANTS.MIN_SCALE, CONSTANTS.MAX_SCALE);
        } else {
          // Scroll down = zoom out
          targetZoom = MathUtil.clamp(targetZoom + sensitivity, CONSTANTS.MIN_SCALE, CONSTANTS.MAX_SCALE);
        }
      }, { passive: false });

      // Keyboard zoom
      document.addEventListener('keydown', function (e) {
        if (!settings || !settings.zoom || !settings.zoom.enabled) return;
        if (!GameAPI.isPlaying()) return;
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

        var sensitivity = settings.zoom.sensitivity || 0.05;
        if (e.key === '=' || e.key === '+') {
          targetZoom = MathUtil.clamp(targetZoom - sensitivity * 2, CONSTANTS.MIN_SCALE, CONSTANTS.MAX_SCALE);
        } else if (e.key === '-') {
          targetZoom = MathUtil.clamp(targetZoom + sensitivity * 2, CONSTANTS.MIN_SCALE, CONSTANTS.MAX_SCALE);
        }
        // '0' reset is handled in inject.js keyboard shortcuts
      });
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.ZoomMod = ZoomMod;
})();
