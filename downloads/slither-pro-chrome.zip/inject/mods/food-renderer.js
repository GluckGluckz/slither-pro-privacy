/**
 * Slither Pro — Food Renderer (v5).
 *
 * Modifies food appearance by directly manipulating the game's food objects
 * and hooking drawImage() for style/scale changes.
 *
 * slither.io food objects have pre-rendered sprite canvases:
 *   fi   (small)   — core dot (5-11px, has actual color)
 *   ofi  (medium)  — outer halo (~32px)
 *   gfi  (large)   — glow effect (~100px, performance hog)
 *   g2fi (larger)  — secondary glow (~160px, even worse)
 *
 * The game draws food layers via drawImage with `lighter` (additive) blending,
 * which washes colors to white on the yellow background. Styles that replace
 * food sprites must override compositing to `source-over`.
 *
 * Styles:
 *   default — no changes, original game look
 *   flat    — removes glow layers + source-over compositing for clean look
 *   simple  — replaces food with colored gradient gems
 *   custom  — replaces core food draw with user-uploaded image
 *
 * Glow toggle is INDEPENDENT of style — controls shadowBlur + glow canvases.
 *
 * All ES5 — var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  /* ── State ─────────────────────────────────────────────── */
  var _settings      = null;
  var _initialized   = false;
  var _gameCanvas     = null;
  var _defaultGsc     = 0.9;

  /* Hook originals */
  var _origDrawImage  = null;
  var _origSBDesc     = null;

  /* Blank canvas used to suppress glow layers */
  var _blankCanvas    = null;

  /* Custom image */
  var _customImg      = null;
  var _customImgSrc   = '';

  /* Food canvas tag key — marks a canvas as belonging to a food item */
  var TAG = '_spF';
  /* Tag values */
  var T_CORE = 1;   // fi
  var T_OUTER = 2;  // ofi
  var T_GLOW = 3;   // gfi
  var T_GLOW2 = 4;  // g2fi

  /* Track which foods we've already tagged (by id) */
  var _taggedIds = {};
  var _taggedCleanupCounter = 0;
  var _updateTick = 0;
  // Batch-processing state — walk the food array in slices so a single
  // pass never spikes. Tagging of brand-new food still happens every call
  // (fast O(1) hashmap lookup) so drawImage detection stays real-time.
  var _processCursor = 0;
  var _lastStyle = null;
  var _lastGlowOff = null;
  var FOOD_BATCH_SIZE = 120;
  var TAGGED_CLEANUP_INTERVAL = 300; // ~5s at 60fps

  /* Simple-style replacement canvases keyed by food id + glow state */
  var _simpleCanvases = {};
  var _simpleGlowState = false;

  /* Color map for food cv values (fallback if pixel read fails) */
  var CV_COLORS = {
    1: '#8f99ff',  // blue
    2: '#7fcfcf',  // cyan
    3: '#7ffe7f',  // green
    4: '#eeee70',  // yellow
    5: '#ff8040',  // orange
    6: '#ff6040',  // red-orange
    7: '#ff4040'   // red
  };

  /* ── Helpers ────────────────────────────────────────────── */

  function createBlankCanvas() {
    var c = document.createElement('canvas');
    c.width = 1;
    c.height = 1;
    return c;
  }

  function loadCustomImage(dataUrl) {
    if (!dataUrl) { _customImg = null; _customImgSrc = ''; return; }
    if (dataUrl === _customImgSrc && _customImg) return;
    _customImgSrc = dataUrl;
    var img = new Image();
    img.onload = function () { _customImg = img; };
    img.onerror = function () { _customImg = null; };
    img.src = dataUrl;
  }

  /**
   * Read the dominant color from a food item's fi (core) canvas.
   * Samples the center pixel. Returns an {r,g,b} object.
   */
  function readFoodColor(fi) {
    if (!fi || fi.width < 1 || fi.height < 1) return null;
    try {
      var ctx = fi.getContext('2d');
      var cx = Math.floor(fi.width / 2);
      var cy = Math.floor(fi.height / 2);
      var data = ctx.getImageData(cx, cy, 1, 1).data;
      if (data[3] < 50) return null;
      return { r: data[0], g: data[1], b: data[2] };
    } catch (e) {
      return null;
    }
  }

  /**
   * Create a gradient gem canvas for "simple" style.
   * @param {number} size — base size from fi canvas
   * @param {object} color — {r,g,b}
   * @param {boolean} withGlow — include outer glow ring (controlled by glow toggle)
   */
  function createSimpleGem(size, color, withGlow) {
    var sz = Math.max(Math.round(size * 2.0), 14);
    var c = document.createElement('canvas');
    c.width = sz;
    c.height = sz;
    var ctx = c.getContext('2d');
    var half = sz / 2;

    // Saturate color for more vivid look
    var maxC = Math.max(color.r, color.g, color.b, 1);
    var sat = 255 / maxC;
    var sr = Math.min(255, Math.round(color.r * sat * 0.9));
    var sg = Math.min(255, Math.round(color.g * sat * 0.9));
    var sb = Math.min(255, Math.round(color.b * sat * 0.9));

    // Outer glow ring — only when glow toggle is ON
    if (withGlow) {
      var glowGrad = ctx.createRadialGradient(half, half, half * 0.5, half, half, half);
      glowGrad.addColorStop(0, 'rgba(' + sr + ',' + sg + ',' + sb + ',0.35)');
      glowGrad.addColorStop(1, 'rgba(' + sr + ',' + sg + ',' + sb + ',0)');
      ctx.fillStyle = glowGrad;
      ctx.fillRect(0, 0, sz, sz);
    }

    // Main gem body
    var bodyRadius = half * 0.55;
    var bodyGrad = ctx.createRadialGradient(
      half - bodyRadius * 0.3, half - bodyRadius * 0.3, 0,
      half, half, bodyRadius
    );
    var br = Math.min(255, sr + 60);
    var bg2 = Math.min(255, sg + 60);
    var bb = Math.min(255, sb + 60);
    bodyGrad.addColorStop(0, 'rgb(' + br + ',' + bg2 + ',' + bb + ')');
    bodyGrad.addColorStop(0.6, 'rgb(' + sr + ',' + sg + ',' + sb + ')');
    var dr = Math.max(0, Math.round(sr * 0.4));
    var dg = Math.max(0, Math.round(sg * 0.4));
    var db = Math.max(0, Math.round(sb * 0.4));
    bodyGrad.addColorStop(1, 'rgb(' + dr + ',' + dg + ',' + db + ')');

    ctx.beginPath();
    ctx.arc(half, half, bodyRadius, 0, Math.PI * 2);
    ctx.fillStyle = bodyGrad;
    ctx.fill();

    // Specular highlight
    var shineGrad = ctx.createRadialGradient(
      half - bodyRadius * 0.3, half - bodyRadius * 0.3, 0,
      half - bodyRadius * 0.2, half - bodyRadius * 0.2, bodyRadius * 0.55
    );
    shineGrad.addColorStop(0, 'rgba(255,255,255,0.85)');
    shineGrad.addColorStop(0.3, 'rgba(255,255,255,0.25)');
    shineGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.beginPath();
    ctx.arc(half, half, bodyRadius, 0, Math.PI * 2);
    ctx.fillStyle = shineGrad;
    ctx.fill();

    c[TAG] = T_CORE;
    c._spSimple = true;

    return c;
  }

  /**
   * Get or create a simple gem canvas for a food item.
   * Gems are cached per food id but invalidated when glow state changes.
   */
  function getSimpleCanvas(food, withGlow) {
    if (_simpleCanvases[food.id]) return _simpleCanvases[food.id];

    var color = null;
    // Read color from original fi (not our replacement)
    var origFi = food._origFi || food.fi;
    if (origFi && !origFi._spSimple) {
      color = readFoodColor(origFi);
    }
    if (!color) {
      var hex = CV_COLORS[food.cv] || CV_COLORS[7];
      var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      if (result) {
        color = {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16)
        };
      } else {
        color = { r: 255, g: 64, b: 64 };
      }
    }

    var size = food.fw || (origFi ? origFi.width : 8);
    var gem = createSimpleGem(size, color, withGlow);
    _simpleCanvases[food.id] = gem;
    return gem;
  }

  /**
   * Compute dampened scale correction factor.
   * Uses sqrt curve so zoomed-out food shrinks but doesn't vanish.
   * gsc=0.9 → 1.0, gsc=0.5 → 0.75, gsc=0.2 → 0.47
   * Returns 0 when no correction needed (at default zoom).
   */
  function getScaleFactor() {
    var gsc = window.gsc || _defaultGsc;
    if (Math.abs(gsc - _defaultGsc) < 0.01) return 0;
    return Math.sqrt(gsc / _defaultGsc);
  }

  /**
   * Apply scale correction to drawImage arguments.
   * Handles both 3-arg (no explicit size) and 5/9-arg forms.
   * Returns null if no correction needed, otherwise the adjusted args array.
   */
  function scaleArgs(args, factor) {
    var n = args.length;
    var a;
    if (n === 3) {
      // drawImage(src, dx, dy) — no explicit size, uses canvas dimensions
      var src = args[0];
      var w = src.width;
      var h = src.height;
      var nw = w * factor;
      var nh = h * factor;
      // Center the scaled image on the original position
      return [src, args[1] + (w - nw) / 2, args[2] + (h - nh) / 2, nw, nh];
    } else if (n === 5) {
      a = [args[0], args[1], args[2], args[3], args[4]];
      var cx = a[1] + a[3] / 2;
      var cy = a[2] + a[4] / 2;
      a[3] = a[3] * factor; a[4] = a[4] * factor;
      a[1] = cx - a[3] / 2; a[2] = cy - a[4] / 2;
      return a;
    } else if (n === 9) {
      a = [args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]];
      var cx2 = a[5] + a[7] / 2;
      var cy2 = a[6] + a[8] / 2;
      a[7] = a[7] * factor; a[8] = a[8] * factor;
      a[5] = cx2 - a[7] / 2; a[6] = cy2 - a[8] / 2;
      return a;
    }
    return null;
  }

  /**
   * Tag all food canvases so drawImage hook can identify them.
   * Also handles glow removal and style-based canvas swaps.
   *
   * Performance strategy:
   *   - New food tagging runs for EVERY food every call (cheap O(1) check)
   *     so drawImage detection is always real-time.
   *   - Expensive canvas-layer enforcement is BATCHED across frames — at
   *     peak density (~600+ foods) this used to spike to 25ms in a single
   *     frame. We now process FOOD_BATCH_SIZE items per call in a rolling
   *     cursor, capping per-frame work. A style/glow change forces a full
   *     immediate resweep so the UI responds instantly to setting toggles.
   */
  function processFood() {
    var foods = window.foods;
    if (!foods) return;

    var fs = _settings.food;
    // Graphics Quality = Low forces glow off regardless of the per-
    // feature toggle so the "Performance" slider has a single knob
    // that actually drops CPU cost.
    var gpu = _settings.gameplay && _settings.gameplay.graphicsQuality;
    var glowEnabledEffective = glowEnabledEffective && gpu !== 'low';
    var glowOff = !glowEnabledEffective;
    var style = fs.style;

    // Invalidate simple gem cache when glow state changes
    if (style === 'simple' && _simpleGlowState !== glowEnabledEffective) {
      _simpleGlowState = glowEnabledEffective;
      _simpleCanvases = {};
    }

    // Periodic cleanup: purge stale entries from _taggedIds and _simpleCanvases
    _taggedCleanupCounter++;
    if (_taggedCleanupCounter >= TAGGED_CLEANUP_INTERVAL) {
      _taggedCleanupCounter = 0;
      var activeFoodIds = {};
      for (var ci = 0; ci < foods.length; ci++) {
        if (foods[ci]) activeFoodIds[foods[ci].id] = true;
      }
      var tagKey;
      for (tagKey in _taggedIds) {
        if (!activeFoodIds[tagKey]) delete _taggedIds[tagKey];
      }
      for (tagKey in _simpleCanvases) {
        if (!activeFoodIds[tagKey]) delete _simpleCanvases[tagKey];
      }
    }

    var n = foods.length;
    if (n === 0) return;

    // Force a full resweep if the user changed style or glow — otherwise
    // the batch would take up to n/BATCH frames to catch up visually.
    var settingsChanged = _lastStyle !== style || _lastGlowOff !== glowOff;
    _lastStyle = style;
    _lastGlowOff = glowOff;

    var batchStart, batchEnd;
    if (settingsChanged) {
      batchStart = 0; batchEnd = n;
      _processCursor = 0;
    } else {
      if (_processCursor >= n) _processCursor = 0;
      batchStart = _processCursor;
      batchEnd = Math.min(_processCursor + FOOD_BATCH_SIZE, n);
      _processCursor = batchEnd >= n ? 0 : batchEnd;
    }

    for (var i = 0; i < n; i++) {
      var f = foods[i];
      if (!f) continue;

      // Tag canvases for drawImage detection (once per food item)
      // This is cheap and always runs so newly-spawned food is recognized
      // on the very next draw call, not batch frames later.
      if (!_taggedIds[f.id]) {
        _taggedIds[f.id] = true;
        if (f.fi)   f.fi[TAG]   = T_CORE;
        if (f.ofi)  f.ofi[TAG]  = T_OUTER;
        if (f.gfi)  f.gfi[TAG]  = T_GLOW;
        if (f.g2fi) f.g2fi[TAG] = T_GLOW2;
        f._origGfi  = f.gfi;
        f._origG2fi = f.g2fi;
        f._origOfi  = f.ofi;
        f._origFi   = f.fi;
      }

      // Skip heavy canvas-swap enforcement if this food isn't in the current batch.
      // Newly-tagged foods get a one-time enforcement pass regardless.
      if (i < batchStart || i >= batchEnd) continue;

      // ── Style: simple — replace all layers with gem ──
      if (style === 'simple') {
        if (f.gfi !== _blankCanvas)  f.gfi  = _blankCanvas;
        if (f.g2fi !== _blankCanvas) f.g2fi = _blankCanvas;
        if (f.ofi !== _blankCanvas)  f.ofi  = _blankCanvas;
        var gem = getSimpleCanvas(f, glowEnabledEffective);
        if (f.fi !== gem) f.fi = gem;
        continue;
      }

      // ── Style: flat — always remove glow canvases for clean look ──
      // Glow toggle independently controls shadowBlur (in the hook)
      if (style === 'flat') {
        if (f.gfi !== _blankCanvas)  f.gfi  = _blankCanvas;
        if (f.g2fi !== _blankCanvas) f.g2fi = _blankCanvas;
        // Restore ofi and fi if they were replaced by simple
        if (f.ofi === _blankCanvas && f._origOfi) f.ofi = f._origOfi;
        if (f.fi && f.fi._spSimple && f._origFi) f.fi = f._origFi;
        continue;
      }

      // ── Default / custom: glow toggle controls glow canvases ──
      if (glowOff) {
        if (f.gfi !== _blankCanvas)  f.gfi  = _blankCanvas;
        if (f.g2fi !== _blankCanvas) f.g2fi = _blankCanvas;
      } else {
        if (f.gfi === _blankCanvas && f._origGfi)   f.gfi  = f._origGfi;
        if (f.g2fi === _blankCanvas && f._origG2fi) f.g2fi = f._origG2fi;
      }
      // Always restore ofi and fi for default/custom
      if (f.ofi === _blankCanvas && f._origOfi) f.ofi = f._origOfi;
      if (f.fi && f.fi._spSimple && f._origFi)  f.fi  = f._origFi;
    }
  }

  /* ── Install canvas hooks ──────────────────────────────── */
  function installHooks() {
    var proto = CanvasRenderingContext2D.prototype;

    // ── drawImage hook ──────────────────────────────────────
    _origDrawImage = proto.drawImage;
    proto.drawImage = function () {
      var src = arguments[0];
      if (src && src[TAG] && this.canvas === _gameCanvas && _settings && _settings.food) {
        var fs = _settings.food;
        var tag = src[TAG];
        var style = fs.style;

        // ── Scale factor (shared across all style paths) ──
        var factor = fs.scaleCorrection ? getScaleFactor() : 0;

        // ── Simple style: source-over compositing for correct colors ──
        if (style === 'simple' && src._spSimple && tag === T_CORE) {
          var prevComp = this.globalCompositeOperation;
          var prevAlpha = this.globalAlpha;
          this.globalCompositeOperation = 'source-over';
          this.globalAlpha = 1;
          if (factor > 0) {
            var sa = scaleArgs(arguments, factor);
            if (sa) { _origDrawImage.apply(this, sa); }
            else { _origDrawImage.apply(this, arguments); }
          } else {
            _origDrawImage.apply(this, arguments);
          }
          this.globalCompositeOperation = prevComp;
          this.globalAlpha = prevAlpha;
          return;
        }

        // ── Flat style: source-over compositing for clean look ──
        if (style === 'flat' && (tag === T_CORE || tag === T_OUTER)) {
          var prevComp3 = this.globalCompositeOperation;
          this.globalCompositeOperation = 'source-over';
          if (factor > 0) {
            var sa3 = scaleArgs(arguments, factor);
            if (sa3) { _origDrawImage.apply(this, sa3); }
            else { _origDrawImage.apply(this, arguments); }
          } else {
            _origDrawImage.apply(this, arguments);
          }
          this.globalCompositeOperation = prevComp3;
          return;
        }

        // ── Custom style: replace core food draw with custom image ──
        if (style === 'custom' && _customImg && tag === T_CORE) {
          var dx, dy, dw, dh;
          if (arguments.length >= 5) {
            dx = arguments[1]; dy = arguments[2];
            dw = arguments[3]; dh = arguments[4];
          } else {
            dx = arguments[1] || 0; dy = arguments[2] || 0;
            dw = src.width; dh = src.height;
          }
          if (factor > 0) {
            var cxC = dx + dw / 2;
            var cyC = dy + dh / 2;
            dw = dw * factor; dh = dh * factor;
            dx = cxC - dw / 2; dy = cyC - dh / 2;
          }
          var prevComp4 = this.globalCompositeOperation;
          this.globalCompositeOperation = 'source-over';
          var imgSz = Math.max(dw, dh) * 1.3;
          _origDrawImage.call(this, _customImg,
            dx + dw / 2 - imgSz / 2,
            dy + dh / 2 - imgSz / 2,
            imgSz, imgSz);
          this.globalCompositeOperation = prevComp4;
          return;
        }

        // ── Scale correction for default style (all food layers) ──
        if (factor > 0) {
          var sa2 = scaleArgs(arguments, factor);
          if (sa2) {
            _origDrawImage.apply(this, sa2);
            return;
          }
        }
      }

      _origDrawImage.apply(this, arguments);
    };

    // ── shadowBlur — suppress glow ──────────────────────────
    _origSBDesc = Object.getOwnPropertyDescriptor(proto, 'shadowBlur');
    if (_origSBDesc && _origSBDesc.set) {
      Object.defineProperty(proto, 'shadowBlur', {
        get: _origSBDesc.get,
        set: function (val) {
          if (_settings && _settings.food && this.canvas === _gameCanvas && val > 0) {
            // Glow toggle controls shadowBlur for ALL styles
            if (!_settings.food.glowEnabled) {
              val = 0;
            }
          }
          _origSBDesc.set.call(this, val);
        },
        configurable: true,
        enumerable: true
      });
    }
  }

  /* ── Public API ─────────────────────────────────────────── */
  var FoodRenderer = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;
      _settings = s;
      _gameCanvas = SP.GameAPI ? SP.GameAPI.getGameCanvas() : null;
      _defaultGsc = (SP.CONSTANTS && SP.CONSTANTS.DEFAULT_SCALE) || 0.9;
      _blankCanvas = createBlankCanvas();
      _simpleGlowState = s.food ? s.food.glowEnabled : true;

      installHooks();

      if (s.food && s.food.customImage) {
        loadCustomImage(s.food.customImage);
      }
    },

    updateSettings: function (s) {
      var oldStyle = _settings && _settings.food ? _settings.food.style : '';
      _settings = s;

      // Clear simple caches when switching away from simple
      if (oldStyle === 'simple' && s.food && s.food.style !== 'simple') {
        _simpleCanvases = {};
      }

      if (s.food && s.food.customImage) {
        loadCustomImage(s.food.customImage);
      } else {
        _customImg = null;
        _customImgSrc = '';
      }
    },

    update: function () {
      if (!_settings || !_settings.food) return;
      // Throttle to every 2 frames (30Hz). processFood walks the entire
      // food array (~600+ items at peak density) and swaps canvas layers.
      // Food spawn/despawn doesn't need 60Hz response; 30Hz is imperceptible.
      _updateTick = (_updateTick + 1) | 0;
      if (_updateTick & 1) return;
      processFood();
    },

    setCustomImage: function (dataUrl) {
      loadCustomImage(dataUrl);
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.FoodRenderer = FoodRenderer;
})();
