/**
 * Slither Pro — Skins Mod (v2 — Animated & Polished).
 * Applies custom color schemes with animation support.
 *
 * How slither.io rendering works (render_mode 2, default high-quality):
 *   - Each body segment is drawn using pre-rendered sprite canvases.
 *   - window.per_color_imgs[i] contains sprites for color index i (0–41).
 *   - snake.rbcs = [i, j, i, j, ...] defines the repeating color pattern.
 *   - snake.cv = base color index (used for head/fallback).
 *   - Colors are baked into the sprites; we pick from the 42 available.
 *
 * For render_mode 1 (low quality stroke path):
 *   - Uses snake.cs (hex string) for strokeStyle.
 *   - We also set snake.cs for compatibility.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var settings = null;
  var _initialized = false;
  var _colorCycleFrame = 0;
  var _availableColors = null;  // Cached array of {r, g, b, index}
  var _lastAppliedSkin = null;
  var _lastSnakeId = null;

  /* ── Animated skin identifiers ──────────────────────────── */
  var ANIMATED_SKINS = {
    'rainbow': true,
    'aurora': true,
    'plasma': true,
    'pulse-fire': true,
    'pulse-ice': true,
    'candy': true,
    'lightning': true,
    'vaporwave': true,
    'neon-pulse': true,
    'inferno': true,
    'frozen': true
  };

  var SkinsMod = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;
      settings = s;
    },

    updateSettings: function (s) {
      if (!s || !s.visual) return;
      settings = s;
      _lastAppliedSkin = null;
    },

    /**
     * Called each frame. Overrides snake color pattern if a custom skin is active.
     */
    update: function () {
      if (!settings || !settings.visual) return;
      var skinId = settings.visual.skin;
      if (skinId === 'default') {
        _lastAppliedSkin = null;
        return;
      }

      var snake = window.slither;
      if (!snake) return;

      // Detect respawn
      var currentSnakeId = snake.id;
      if (currentSnakeId !== _lastSnakeId) {
        _lastSnakeId = currentSnakeId;
        _lastAppliedSkin = null;
      }

      // Build color palette once
      if (!_availableColors) {
        _availableColors = this._buildColorPalette();
        if (!_availableColors || _availableColors.length === 0) return;
      }

      _colorCycleFrame++;

      // ── Animated skins (update every frame) ───────────
      if (ANIMATED_SKINS[skinId]) {
        this._applyAnimatedSkin(snake, skinId);
        return;
      }

      // ── Static skins ──────────────────────────────────
      var colors;
      if (skinId === 'custom') {
        colors = settings.visual.customColors || ['#39ff14', '#006600'];
      } else {
        colors = SP.SKIN_PRESETS ? SP.SKIN_PRESETS[skinId] : null;
      }

      if (!colors || colors.length === 0) return;

      var skinKey = skinId + ':' + colors.join(',');
      if (_lastAppliedSkin !== skinKey) {
        _lastAppliedSkin = skinKey;
        this._applySkin(snake, colors);
      }

      // Subtle shimmer for static skins
      if (settings.visual.skinAnimation !== false && snake.rbcs && snake.rbcs.length > 2) {
        if (_colorCycleFrame % 45 === 0) {
          var first = snake.rbcs[0];
          for (var si = 0; si < snake.rbcs.length - 1; si++) {
            snake.rbcs[si] = snake.rbcs[si + 1];
          }
          snake.rbcs[snake.rbcs.length - 1] = first;
        }
      }

      // Mode-1 fallback
      var primary = this._hexToRgb(colors[0]);
      if (primary) {
        snake.cs = colors[0];
        snake.rr = primary.r;
        snake.gg = primary.g;
        snake.bb = primary.b;
      }
    },

    /* ══════════════════════════════════════════════════════════
     *  Animated Skin Engine
     * ══════════════════════════════════════════════════════════ */

    _applyAnimatedSkin: function (snake, skinId) {
      switch (skinId) {
        case 'rainbow':    this._applyRainbow(snake); break;
        case 'aurora':     this._applyAurora(snake); break;
        case 'plasma':     this._applyPlasma(snake); break;
        case 'pulse-fire': this._applyPulse(snake, 'fire'); break;
        case 'pulse-ice':  this._applyPulse(snake, 'ice'); break;
        case 'candy':      this._applyCandy(snake); break;
        case 'lightning':  this._applyLightning(snake); break;
        case 'vaporwave':  this._applyVaporwave(snake); break;
        case 'neon-pulse': this._applyNeonPulse(snake); break;
        case 'inferno':    this._applyInferno(snake); break;
        case 'frozen':     this._applyFrozen(snake); break;
      }
    },

    /**
     * Rainbow — 12-color smooth spectrum with fluid cycling.
     */
    _applyRainbow: function (snake) {
      if (!_availableColors || _availableColors.length === 0) return;

      // Full 12-color spectrum for smooth gradients
      var spectrum = [
        '#ff0000', '#ff4500', '#ff8c00', '#ffd700',
        '#ffff00', '#7fff00', '#00ff00', '#00fa9a',
        '#00bfff', '#4169e1', '#8a2be2', '#ff00ff'
      ];
      var indices = [];
      for (var i = 0; i < spectrum.length; i++) {
        var rgb = this._hexToRgb(spectrum[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      // Smooth continuous shift — every 8 frames for fluid flow
      var shift = Math.floor(_colorCycleFrame / 8) % indices.length;
      var patternLen = 20;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        rbcs.push(indices[(j + shift) % indices.length]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = spectrum[shift % spectrum.length];
    },

    /**
     * Aurora — Northern lights shimmer (blue/green/purple with slow wave).
     */
    _applyAurora: function (snake) {
      var auroraColors = [
        '#00ff88', '#00ffcc', '#00e5ff', '#00bfff',
        '#4488ff', '#6644ff', '#aa44ff', '#cc44ff',
        '#6644ff', '#4488ff', '#00bfff', '#00e5ff'
      ];
      var indices = [];
      for (var i = 0; i < auroraColors.length; i++) {
        var rgb = this._hexToRgb(auroraColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      // Slow wave — shift every 12 frames
      var shift = Math.floor(_colorCycleFrame / 12) % indices.length;
      var patternLen = 18;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        // Interleave two offset waves for depth
        var idx1 = (j + shift) % indices.length;
        var idx2 = (j + shift + 4) % indices.length;
        rbcs.push(j % 3 === 0 ? indices[idx2] : indices[idx1]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = auroraColors[shift % auroraColors.length];
    },

    /**
     * Plasma — Hot morphing energy (red/orange/yellow/white cycle).
     */
    _applyPlasma: function (snake) {
      var plasmaColors = [
        '#ff0040', '#ff2200', '#ff4400', '#ff6600',
        '#ff8800', '#ffaa00', '#ffcc00', '#ffee00',
        '#ffffff', '#ffee00', '#ffcc00', '#ffaa00',
        '#ff8800', '#ff6600', '#ff4400', '#ff2200'
      ];
      var indices = [];
      for (var i = 0; i < plasmaColors.length; i++) {
        var rgb = this._hexToRgb(plasmaColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      // Fast pulse — shift every 6 frames
      var shift = Math.floor(_colorCycleFrame / 6) % indices.length;
      var patternLen = 16;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        rbcs.push(indices[(j * 2 + shift) % indices.length]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = plasmaColors[shift % plasmaColors.length];
    },

    /**
     * Pulse Fire/Ice — Base colors with brightness wave ripple.
     */
    _applyPulse: function (snake, theme) {
      var colors;
      if (theme === 'fire') {
        colors = [
          '#ff0000', '#ff2200', '#ff4400', '#ff6600',
          '#ff8800', '#ffaa00', '#ffcc00', '#ffaa00',
          '#ff8800', '#ff6600', '#ff4400', '#ff2200'
        ];
      } else {
        colors = [
          '#0044ff', '#0066ff', '#0088ff', '#00aaff',
          '#00ccff', '#00eeff', '#88ffff', '#00eeff',
          '#00ccff', '#00aaff', '#0088ff', '#0066ff'
        ];
      }

      var indices = [];
      for (var i = 0; i < colors.length; i++) {
        var rgb = this._hexToRgb(colors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      // Wave ripple — phase shifts along body
      var time = _colorCycleFrame;
      var patternLen = 16;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        // Sine-based offset creates wave effect along body
        var wave = Math.floor(Math.sin((j * 0.5) + (time * 0.08)) * 4 + 6);
        rbcs.push(indices[Math.abs(wave) % indices.length]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = colors[0];
    },

    /**
     * Candy — Pastel swirl (pink/blue/yellow/green).
     */
    _applyCandy: function (snake) {
      var candyColors = [
        '#ff69b4', '#ff88cc', '#ffaadd', '#ffccee',
        '#ccddff', '#aaccff', '#88bbff', '#77ddff',
        '#88ffcc', '#aaffaa', '#ccff88', '#ffff77',
        '#ffdd88', '#ffbb99', '#ff99aa'
      ];
      var indices = [];
      for (var i = 0; i < candyColors.length; i++) {
        var rgb = this._hexToRgb(candyColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      var shift = Math.floor(_colorCycleFrame / 10) % indices.length;
      var patternLen = 20;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        rbcs.push(indices[(j + shift) % indices.length]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = candyColors[shift % candyColors.length];
    },

    /**
     * Lightning — Electric blue/white with random flicker segments.
     */
    _applyLightning: function (snake) {
      var baseColors = ['#0044ff', '#0066ff', '#0088ff', '#00aaff'];
      var flashColors = ['#ffffff', '#ccddff', '#aaccff'];
      var allColors = baseColors.concat(flashColors);

      var indices = [];
      for (var i = 0; i < allColors.length; i++) {
        var rgb = this._hexToRgb(allColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      var baseCount = baseColors.length;
      var patternLen = 18;
      var rbcs = [];
      var shift = Math.floor(_colorCycleFrame / 10) % baseCount;

      for (var j = 0; j < patternLen; j++) {
        // Random flash segments every ~20 frames
        var isFlash = (_colorCycleFrame + j * 7) % 20 < 3;
        if (isFlash) {
          rbcs.push(indices[baseCount + (j % flashColors.length)]);
        } else {
          rbcs.push(indices[(j + shift) % baseCount]);
        }
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];

      // Flash the mode-1 color periodically
      if (_colorCycleFrame % 20 < 3) {
        snake.cs = '#ffffff';
      } else {
        snake.cs = baseColors[shift];
      }
    },

    /**
     * Vaporwave — Retro pink/cyan/purple with smooth gradient cycling.
     */
    _applyVaporwave: function (snake) {
      var vwColors = [
        '#ff71ce', '#ff9de2', '#ffccf9', '#ffd1dc',
        '#e0aaff', '#c77dff', '#9d4edd', '#7b2cbf',
        '#5a189a', '#3c096c', '#240046', '#3c096c',
        '#5a189a', '#7b2cbf', '#9d4edd', '#c77dff',
        '#01cdfe', '#05ffa1', '#b967ff', '#fffb96'
      ];
      var indices = [];
      for (var i = 0; i < vwColors.length; i++) {
        var rgb = this._hexToRgb(vwColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      var shift = Math.floor(_colorCycleFrame / 10) % indices.length;
      var patternLen = 20;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        rbcs.push(indices[(j + shift) % indices.length]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = vwColors[shift % vwColors.length];
    },

    /**
     * Neon Pulse — All segments cycle through 3 neon colors with breathing effect.
     * Shifts all segments together (not wave) every 20 frames.
     */
    _applyNeonPulse: function (snake) {
      var neonColors = ['#39ff14', '#00ffff', '#ff00ff'];
      var indices = [];
      for (var i = 0; i < neonColors.length; i++) {
        var rgb = this._hexToRgb(neonColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      // All segments use the same color, shifting every 20 frames
      var phase = Math.floor(_colorCycleFrame / 20) % indices.length;
      var patternLen = 18;
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        rbcs.push(indices[phase]);
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = neonColors[phase];
    },

    /**
     * Inferno — Fire-like animation with rapid upward color shifting.
     * Colors shift every 4 frames. Random segments flash white.
     */
    _applyInferno: function (snake) {
      var fireColors = [
        '#ff0000', '#ff2200', '#ff4400', '#ff6600',
        '#ff8800', '#ffaa00', '#ffcc00', '#ffee00',
        '#ffffff', '#ffee00', '#ffcc00', '#ffaa00',
        '#ff8800', '#ff6600', '#ff4400', '#ff2200'
      ];
      var indices = [];
      for (var i = 0; i < fireColors.length; i++) {
        var rgb = this._hexToRgb(fireColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      var whiteRgb = this._hexToRgb('#ffffff');
      var whiteIdx = whiteRgb ? this._findClosestColor(whiteRgb.r, whiteRgb.g, whiteRgb.b) : indices[0];

      // Rapid shift every 4 frames for flickering fire
      var shift = Math.floor(_colorCycleFrame / 4) % indices.length;
      var patternLen = 18;
      var rbcs = [];
      // Use a seeded pseudo-random based on frame for consistent flicker per cycle
      var flickerSeed = Math.floor(_colorCycleFrame / 4);
      for (var j = 0; j < patternLen; j++) {
        // Random segments flash white (~10% chance, using deterministic hash)
        var hash = ((flickerSeed * 31 + j * 17) % 100);
        if (hash < 10) {
          rbcs.push(whiteIdx);
        } else {
          rbcs.push(indices[(j + shift) % indices.length]);
        }
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = fireColors[shift % fireColors.length];
    },

    /**
     * Frozen — Slow crystalline shimmer with ice sparkle effect.
     * Colors shift every 60 frames. ~5% of segments sparkle white per cycle.
     */
    _applyFrozen: function (snake) {
      var iceColors = [
        '#0044ff', '#0066ff', '#0088ff', '#00aaff',
        '#00ccff', '#44ddff', '#88ffff', '#aaffff',
        '#ffffff', '#aaffff', '#88ffff', '#44ddff',
        '#00ccff', '#00aaff', '#0088ff', '#0066ff'
      ];
      var indices = [];
      for (var i = 0; i < iceColors.length; i++) {
        var rgb = this._hexToRgb(iceColors[i]);
        if (rgb) indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
      }
      if (indices.length === 0) return;

      var whiteRgb = this._hexToRgb('#ffffff');
      var whiteIdx = whiteRgb ? this._findClosestColor(whiteRgb.r, whiteRgb.g, whiteRgb.b) : indices[0];

      // Very slow shift — every 60 frames for crystalline feel
      var shift = Math.floor(_colorCycleFrame / 60) % indices.length;
      var patternLen = 18;
      var rbcs = [];
      var sparkleSeed = Math.floor(_colorCycleFrame / 60);
      for (var j = 0; j < patternLen; j++) {
        // Ice sparkle: ~5% chance per segment per cycle
        var sparkleHash = ((sparkleSeed * 37 + j * 13) % 100);
        if (sparkleHash < 5) {
          rbcs.push(whiteIdx);
        } else {
          rbcs.push(indices[(j + shift) % indices.length]);
        }
      }

      snake.rbcs = rbcs;
      snake.cv = rbcs[0];
      snake.cs = iceColors[shift % iceColors.length];
    },

    /* ══════════════════════════════════════════════════════════
     *  Current Colors (for Name Tag, Trail, etc.)
     * ══════════════════════════════════════════════════════════ */

    /**
     * Returns the hex color array currently applied to the snake.
     * Used by name tag, trail effects, etc.
     */
    getCurrentColors: function () {
      if (!settings || !settings.visual) return null;
      var skinId = settings.visual.skin;
      if (skinId === 'default') return null;

      if (skinId === 'custom') {
        return settings.visual.customColors || ['#39ff14', '#006600'];
      }

      var preset = SP.SKIN_PRESETS ? SP.SKIN_PRESETS[skinId] : null;
      return preset || null;
    },

    /* ══════════════════════════════════════════════════════════
     *  Trail Color Helpers (for VisualEffects)
     * ══════════════════════════════════════════════════════════ */

    /**
     * Get trail particle color matching the current skin.
     * Returns {r, g, b} or null for default.
     */
    getTrailColor: function () {
      if (!settings || !settings.visual) return null;
      var skinId = settings.visual.skin;
      switch (skinId) {
        case 'fire':
        case 'lava':
        case 'pulse-fire':
        case 'plasma':      return { r: 255, g: 100, b: 0 };
        case 'ice':
        case 'pulse-ice':
        case 'lightning':   return { r: 0, g: 180, b: 255 };
        case 'neon-green':
        case 'toxic':       return { r: 57, g: 255, b: 20 };
        case 'neon-pink':
        case 'candy':       return { r: 255, g: 105, b: 180 };
        case 'neon-blue':
        case 'ocean':       return { r: 0, g: 191, b: 255 };
        case 'neon-purple':
        case 'galaxy':
        case 'vaporwave':   return { r: 180, g: 0, b: 255 };
        case 'aurora':      return { r: 0, g: 255, b: 200 };
        case 'sunset':      return { r: 255, g: 69, b: 0 };
        case 'stealth':     return { r: 80, g: 80, b: 100 };
        case 'rainbow':     return null; // use default
        default:            return null;
      }
    },

    /* ══════════════════════════════════════════════════════════
     *  Core Utilities
     * ══════════════════════════════════════════════════════════ */

    _buildColorPalette: function () {
      var pci = window.per_color_imgs;
      if (!pci || !pci.length) return null;

      var palette = [];
      for (var i = 0; i < pci.length; i++) {
        if (!pci[i]) continue;
        var rgb = null;

        if (pci[i].cs) {
          rgb = this._hexToRgb(pci[i].cs);
        }

        if (!rgb && window.rrs && window.ggs && window.bbs) {
          rgb = {
            r: window.rrs[i] || 0,
            g: window.ggs[i] || 0,
            b: window.bbs[i] || 0
          };
        }

        if (rgb) {
          palette.push({ r: rgb.r, g: rgb.g, b: rgb.b, index: i });
        }
      }

      return palette;
    },

    _findClosestColor: function (r, g, b) {
      if (!_availableColors || _availableColors.length === 0) return 0;

      var bestDist = Infinity;
      var bestIndex = 0;

      for (var i = 0; i < _availableColors.length; i++) {
        var c = _availableColors[i];
        var dr = c.r - r;
        var dg = c.g - g;
        var db = c.b - b;
        var dist = dr * dr * 0.299 + dg * dg * 0.587 + db * db * 0.114;
        if (dist < bestDist) {
          bestDist = dist;
          bestIndex = c.index;
        }
      }

      return bestIndex;
    },

    _applySkin: function (snake, hexColors) {
      var indices = [];
      for (var i = 0; i < hexColors.length; i++) {
        var rgb = this._hexToRgb(hexColors[i]);
        if (rgb) {
          indices.push(this._findClosestColor(rgb.r, rgb.g, rgb.b));
        }
      }

      if (indices.length === 0) return;

      var patternLen = Math.max(indices.length * 2, 10);
      var rbcs = [];
      for (var j = 0; j < patternLen; j++) {
        rbcs.push(indices[j % indices.length]);
      }

      snake.rbcs = rbcs;
      snake.cv = indices[0];
    },

    _hexToRgb: function (hex) {
      var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : null;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.SkinsMod = SkinsMod;
})();
