/**
 * Slither Pro -- Aura Effect Renderer (v2).
 * Draws stunning geometric aura effects around the player snake
 * on the overlay canvas using bezier curves, jagged polylines,
 * and complex animated shapes.
 *
 * Registered with OverlayManager; called with render(ctx, canvas, settings).
 * Uses GameAPI for snake data and view transform.
 *
 * Aura types: none, electric, fire, shadow.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI;
  var settings = null;
  var _initialized = false;
  var _frame = 0;

  /* ================================================================== */
  /*  Constants                                                          */
  /* ================================================================== */

  var TWO_PI = Math.PI * 2;
  var PI = Math.PI;
  var sin = Math.sin;
  var cos = Math.cos;
  var abs = Math.abs;
  var floor = Math.floor;
  var max = Math.max;
  var min = Math.min;
  var rand = Math.random;
  var sqrt = Math.sqrt;
  var atan2 = Math.atan2;

  /* ================================================================== */
  /*  ELECTRIC -- Lightning bolt pool                                    */
  /* ================================================================== */

  var MAX_BOLTS = 15;
  var _bolts = [];
  var _sparkParticles = [];
  var MAX_SPARKS = 45;

  // Pre-allocate bolt pool
  (function () {
    var i, j;
    for (i = 0; i < MAX_BOLTS; i++) {
      var segs = [];
      for (j = 0; j < 8; j++) {
        segs.push({ x: 0, y: 0 });
      }
      _bolts.push({
        active: false,
        startX: 0,
        startY: 0,
        segCount: 0,
        segments: segs,
        life: 0,
        maxLife: 0,
        // Branch data (sub-bolt)
        hasBranch: false,
        branchStartSeg: 0,
        branchSegs: [
          { x: 0, y: 0 },
          { x: 0, y: 0 },
          { x: 0, y: 0 }
        ]
      });
    }

    // Pre-allocate spark pool
    for (i = 0; i < MAX_SPARKS; i++) {
      _sparkParticles.push({
        active: false,
        x: 0, y: 0,
        vx: 0, vy: 0,
        life: 0,
        maxLife: 0,
        size: 0
      });
    }
  })();

  var _boltSpawnTimer = 0;
  var _boltSpawnInterval = 10; // frames between new bolt batches

  function _spawnBolt(sx, sy, bodyR) {
    var i, b;
    for (i = 0; i < MAX_BOLTS; i++) {
      b = _bolts[i];
      if (!b.active) break;
    }
    if (i >= MAX_BOLTS) return;

    b.active = true;
    b.startX = sx;
    b.startY = sy;
    b.life = 8 + floor(rand() * 3);
    b.maxLife = b.life;

    var segCount = 4 + floor(rand() * 3); // 4-6 segments
    b.segCount = min(segCount, b.segments.length);

    // Generate jagged bolt path
    var angle = rand() * TWO_PI;
    var px = sx;
    var py = sy;
    b.segments[0].x = px;
    b.segments[0].y = py;

    for (var s = 1; s < b.segCount; s++) {
      angle += (rand() - 0.5) * 1.2;
      var segLen = 8 + rand() * 15;
      px = px + cos(angle) * segLen;
      py = py + sin(angle) * segLen;
      b.segments[s].x = px;
      b.segments[s].y = py;
    }

    // 20% chance to fork a sub-bolt from a middle segment
    b.hasBranch = rand() < 0.2 && b.segCount > 2;
    if (b.hasBranch) {
      var branchIdx = 1 + floor(rand() * (b.segCount - 2));
      b.branchStartSeg = branchIdx;
      var bpx = b.segments[branchIdx].x;
      var bpy = b.segments[branchIdx].y;
      var brAngle = angle + (rand() - 0.5) * 1.5;
      for (var br = 0; br < 3; br++) {
        brAngle += (rand() - 0.5) * 1.0;
        var brLen = 5 + rand() * 10;
        bpx = bpx + cos(brAngle) * brLen;
        bpy = bpy + sin(brAngle) * brLen;
        b.branchSegs[br].x = bpx;
        b.branchSegs[br].y = bpy;
      }
    }

    // Spawn sparks at the bolt endpoint
    var endSeg = b.segments[b.segCount - 1];
    _spawnSparks(endSeg.x, endSeg.y, 2 + floor(rand() * 2));
  }

  function _spawnSparks(x, y, count) {
    var spawned = 0;
    for (var i = 0; i < MAX_SPARKS && spawned < count; i++) {
      var sp = _sparkParticles[i];
      if (!sp.active) {
        sp.active = true;
        sp.x = x;
        sp.y = y;
        var a = rand() * TWO_PI;
        var spd = 1.5 + rand() * 3.0;
        sp.vx = cos(a) * spd;
        sp.vy = sin(a) * spd;
        sp.life = 6 + floor(rand() * 6);
        sp.maxLife = sp.life;
        sp.size = 1.0 + rand() * 1.5;
        spawned++;
      }
    }
  }

  function _drawBoltPath(ctx, segments, segCount, lineWidth, color, alpha) {
    if (segCount < 2) return;
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.moveTo(segments[0].x, segments[0].y);
    for (var i = 1; i < segCount; i++) {
      ctx.lineTo(segments[i].x, segments[i].y);
    }
    ctx.stroke();
  }

  function _renderElectric(ctx, canvas, head, parts, bodyR, player) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    var i, j, b, sp;

    /* --- Electric hum: thin glowing line connecting body parts --- */
    if (parts.length >= 2) {
      var humAlpha = 0.12 + sin(_frame * 0.08) * 0.05;
      ctx.shadowColor = 'rgba(0, 220, 255, 0.6)';
      ctx.shadowBlur = 6;
      ctx.globalAlpha = humAlpha;
      ctx.strokeStyle = 'rgba(100, 220, 255, 0.5)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(parts[0].x, parts[0].y);
      for (i = 1; i < parts.length; i++) {
        // Add subtle jitter to the hum line
        var jx = (rand() - 0.5) * 2.0;
        var jy = (rand() - 0.5) * 2.0;
        ctx.lineTo(parts[i].x + jx, parts[i].y + jy);
      }
      ctx.stroke();

      // Second pass: brighter thinner core hum
      ctx.shadowBlur = 0;
      ctx.globalAlpha = humAlpha * 0.7;
      ctx.strokeStyle = 'rgba(200, 240, 255, 0.6)';
      ctx.lineWidth = 0.6;
      ctx.beginPath();
      ctx.moveTo(parts[0].x, parts[0].y);
      for (i = 1; i < parts.length; i++) {
        ctx.lineTo(parts[i].x, parts[i].y);
      }
      ctx.stroke();
    }

    /* --- Spawn new bolt batch --- */
    _boltSpawnTimer++;
    if (_boltSpawnTimer >= _boltSpawnInterval) {
      _boltSpawnTimer = 0;
      _boltSpawnInterval = 8 + floor(rand() * 5); // 8-12 frames
      var boltCount = 3 + floor(rand() * 3); // 3-5 new bolts
      for (i = 0; i < boltCount; i++) {
        if (parts.length === 0) break;
        var srcIdx = floor(rand() * parts.length);
        var src = parts[srcIdx];
        // Offset from body surface
        var offAngle = rand() * TWO_PI;
        var offDist = bodyR * 0.5;
        _spawnBolt(
          src.x + cos(offAngle) * offDist,
          src.y + sin(offAngle) * offDist,
          bodyR
        );
      }
    }

    /* --- Render active bolts --- */
    for (i = 0; i < MAX_BOLTS; i++) {
      b = _bolts[i];
      if (!b.active) continue;

      b.life--;
      if (b.life <= 0) {
        b.active = false;
        continue;
      }

      var progress = b.life / b.maxLife;

      // Outer glow layer (cyan, thick with shadowBlur)
      ctx.shadowColor = 'rgba(0, 180, 255, 0.9)';
      ctx.shadowBlur = min(14, 6 + bodyR * 0.3);
      _drawBoltPath(ctx, b.segments, b.segCount,
        max(3, bodyR * 0.18),
        'rgba(0, 200, 255,' + (progress * 0.6).toFixed(3) + ')',
        progress * 0.6
      );

      // White core (thin, bright)
      ctx.shadowBlur = 0;
      _drawBoltPath(ctx, b.segments, b.segCount,
        max(1.2, bodyR * 0.06),
        'rgba(220, 240, 255,' + (progress * 0.95).toFixed(3) + ')',
        progress * 0.95
      );

      // Draw branch if present
      if (b.hasBranch) {
        var brStart = b.segments[b.branchStartSeg];
        ctx.shadowColor = 'rgba(0, 180, 255, 0.7)';
        ctx.shadowBlur = 4;
        ctx.globalAlpha = progress * 0.5;
        ctx.strokeStyle = 'rgba(0, 200, 255,' + (progress * 0.5).toFixed(3) + ')';
        ctx.lineWidth = max(2, bodyR * 0.1);
        ctx.beginPath();
        ctx.moveTo(brStart.x, brStart.y);
        for (j = 0; j < 3; j++) {
          ctx.lineTo(b.branchSegs[j].x, b.branchSegs[j].y);
        }
        ctx.stroke();

        // Branch core
        ctx.shadowBlur = 0;
        ctx.globalAlpha = progress * 0.7;
        ctx.strokeStyle = 'rgba(220, 240, 255,' + (progress * 0.7).toFixed(3) + ')';
        ctx.lineWidth = max(0.8, bodyR * 0.04);
        ctx.beginPath();
        ctx.moveTo(brStart.x, brStart.y);
        for (j = 0; j < 3; j++) {
          ctx.lineTo(b.branchSegs[j].x, b.branchSegs[j].y);
        }
        ctx.stroke();
      }
    }

    /* --- Update and render spark particles --- */
    for (i = 0; i < MAX_SPARKS; i++) {
      sp = _sparkParticles[i];
      if (!sp.active) continue;

      sp.x += sp.vx;
      sp.y += sp.vy;
      sp.vx *= 0.88;
      sp.vy *= 0.88;
      sp.life--;

      if (sp.life <= 0) {
        sp.active = false;
        continue;
      }

      // Cull off-screen
      if (sp.x < -50 || sp.x > canvas.width + 50 ||
          sp.y < -50 || sp.y > canvas.height + 50) {
        sp.active = false;
        continue;
      }

      var sparkProg = sp.life / sp.maxLife;
      var sparkSize = sp.size * (0.3 + sparkProg * 0.7);

      // Spark glow
      ctx.shadowColor = 'rgba(0, 200, 255, 0.8)';
      ctx.shadowBlur = 4;
      ctx.globalAlpha = sparkProg * 0.8;
      ctx.fillStyle = 'rgba(200, 240, 255,' + (sparkProg * 0.9).toFixed(3) + ')';
      ctx.beginPath();
      // Draw as a tiny diamond shape (not a boring circle)
      ctx.moveTo(sp.x, sp.y - sparkSize);
      ctx.lineTo(sp.x + sparkSize * 0.6, sp.y);
      ctx.lineTo(sp.x, sp.y + sparkSize);
      ctx.lineTo(sp.x - sparkSize * 0.6, sp.y);
      ctx.closePath();
      ctx.fill();
    }

    /* --- Head corona: crackling arc around the head --- */
    ctx.shadowColor = 'rgba(0, 200, 255, 0.6)';
    ctx.shadowBlur = 8;
    ctx.globalAlpha = 0.2 + sin(_frame * 0.12) * 0.08;
    ctx.strokeStyle = 'rgba(100, 220, 255, 0.4)';
    ctx.lineWidth = 1.5;

    // Draw jagged corona arc around head
    var coronaSegs = 12;
    var coronaR = bodyR * 1.8;
    ctx.beginPath();
    for (i = 0; i <= coronaSegs; i++) {
      var ca = (i / coronaSegs) * TWO_PI;
      var cjitter = (rand() - 0.5) * bodyR * 0.5;
      var crx = head.x + cos(ca) * (coronaR + cjitter);
      var cry = head.y + sin(ca) * (coronaR + cjitter);
      if (i === 0) {
        ctx.moveTo(crx, cry);
      } else {
        ctx.lineTo(crx, cry);
      }
    }
    ctx.closePath();
    ctx.stroke();

    ctx.shadowBlur = 0;
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }

  /* ================================================================== */
  /*  FIRE -- Flame tongue and ember pools                               */
  /* ================================================================== */

  var MAX_EMBERS = 30;
  var _embers = [];

  // Pre-allocate ember pool
  (function () {
    for (var i = 0; i < MAX_EMBERS; i++) {
      _embers.push({
        active: false,
        x: 0, y: 0,
        vx: 0, vy: 0,
        life: 0,
        maxLife: 0,
        size: 0,
        r: 255, g: 160, b: 0
      });
    }
  })();

  function _spawnEmber(x, y) {
    var i, em;
    for (i = 0; i < MAX_EMBERS; i++) {
      em = _embers[i];
      if (!em.active) break;
    }
    if (i >= MAX_EMBERS) return;

    em.active = true;
    em.x = x;
    em.y = y;
    em.vx = (rand() - 0.5) * 0.8;
    em.vy = -(1.2 + rand() * 2.0);
    em.life = 20 + floor(rand() * 15);
    em.maxLife = em.life;
    em.size = 1.2 + rand() * 2.0;
    // Random fire color
    var colorRoll = rand();
    if (colorRoll < 0.3) {
      em.r = 255; em.g = 80; em.b = 0;     // deep orange
    } else if (colorRoll < 0.6) {
      em.r = 255; em.g = 200; em.b = 0;    // amber
    } else {
      em.r = 255; em.g = 255; em.b = 100;  // yellow
    }
  }

  // Flame layers: color, size-multiplier, alpha
  var FLAME_LAYERS = [
    { color: '#aa0000', sizeMul: 1.0,  alpha: 0.3  },
    { color: '#ff6600', sizeMul: 0.78, alpha: 0.5  },
    { color: '#ffcc00', sizeMul: 0.55, alpha: 0.7  },
    { color: '#ffffaa', sizeMul: 0.3,  alpha: 0.9  }
  ];

  /**
   * Draw a single flame tongue shape using quadratic bezier curves.
   * baseX, baseY = base of flame (on body surface)
   * tipX, tipY   = tip of flame
   * width        = flame width at base
   * swayPhase    = animation phase for sway
   * layer        = FLAME_LAYERS entry
   */
  function _drawFlameTongue(ctx, baseX, baseY, tipX, tipY, width, swayPhase, layer) {
    var flameH = sqrt((tipX - baseX) * (tipX - baseX) + (tipY - baseY) * (tipY - baseY));
    if (flameH < 2) return;

    // Direction from base to tip
    var dx = tipX - baseX;
    var dy = tipY - baseY;
    var len = sqrt(dx * dx + dy * dy);
    if (len < 0.01) return;
    var nx = dx / len;
    var ny = dy / len;

    // Perpendicular
    var px = -ny;
    var py = nx;

    var w = width * layer.sizeMul;
    var sway = sin(swayPhase) * w * 0.4;

    // Scale tip position for inner layers
    var scTipX = baseX + nx * flameH * layer.sizeMul;
    var scTipY = baseY + ny * flameH * layer.sizeMul;

    // Left and right base points
    var lbx = baseX + px * w * 0.5;
    var lby = baseY + py * w * 0.5;
    var rbx = baseX - px * w * 0.5;
    var rby = baseY - py * w * 0.5;

    // Control points (60% up the flame, swayed)
    var cp1x = baseX + px * (w * 0.3 + sway) + nx * flameH * 0.6 * layer.sizeMul;
    var cp1y = baseY + py * (w * 0.3 + sway) + ny * flameH * 0.6 * layer.sizeMul;
    var cp2x = baseX - px * (w * 0.3 - sway) + nx * flameH * 0.6 * layer.sizeMul;
    var cp2y = baseY - py * (w * 0.3 - sway) + ny * flameH * 0.6 * layer.sizeMul;

    ctx.globalAlpha = layer.alpha;
    ctx.fillStyle = layer.color;
    ctx.beginPath();
    ctx.moveTo(lbx, lby);
    ctx.quadraticCurveTo(cp1x, cp1y, scTipX, scTipY);
    ctx.quadraticCurveTo(cp2x, cp2y, rbx, rby);
    ctx.closePath();
    ctx.fill();
  }

  function _renderFire(ctx, canvas, head, parts, bodyR, player) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';

    var i, j, layerIdx;

    // Calculate direction vectors between adjacent body parts for flame orientation
    // Flames rise perpendicular to the body direction
    var directions = [];
    for (i = 0; i < parts.length; i++) {
      var nextIdx = (i + 1 < parts.length) ? i + 1 : i;
      var prevIdx = (i > 0) ? i - 1 : i;
      var ddx = parts[nextIdx].x - parts[prevIdx].x;
      var ddy = parts[nextIdx].y - parts[prevIdx].y;
      var dlen = sqrt(ddx * ddx + ddy * ddy);
      if (dlen < 0.01) dlen = 1;
      // Perpendicular direction (flame rises perpendicular to body)
      directions.push({ x: -ddy / dlen, y: ddx / dlen });
    }

    /* --- Draw flame tongues on every 3rd body part --- */
    ctx.shadowColor = 'rgba(255, 100, 0, 0.8)';
    ctx.shadowBlur = 10;

    for (i = 0; i < parts.length; i += 3) {
      var p = parts[i];
      var dir = directions[i];
      var flameCount = 1 + floor(rand() * 0.7); // 1, sometimes 2

      for (j = 0; j < flameCount; j++) {
        // Flame parameters with animation
        var seed = i * 7.3 + j * 3.7;
        var heightAnim = sin(_frame * 0.08 + seed) * 0.3 + 0.7;
        var flameH = (15 + rand() * 25) * heightAnim;
        var flameW = bodyR * (0.6 + rand() * 0.4);

        // Sway phase unique to each flame
        var swayFreq = 0.1 + (seed % 1) * 0.08;
        var swayPhase = _frame * swayFreq + seed;

        // Slight random angular offset for variety
        var angOff = (rand() - 0.5) * 0.4;
        var fdx = dir.x * cos(angOff) - dir.y * sin(angOff);
        var fdy = dir.x * sin(angOff) + dir.y * cos(angOff);

        // Flip direction randomly to get flames on both sides
        if (j === 1 || (j === 0 && rand() < 0.35)) {
          fdx = -fdx;
          fdy = -fdy;
        }

        var baseX = p.x;
        var baseY = p.y;
        var tipX = baseX + fdx * flameH;
        var tipY = baseY + fdy * flameH;

        // Render all four layers (dark to bright)
        for (layerIdx = 0; layerIdx < FLAME_LAYERS.length; layerIdx++) {
          ctx.shadowBlur = (layerIdx === 0) ? 10 : 0;
          _drawFlameTongue(ctx, baseX, baseY, tipX, tipY, flameW, swayPhase, FLAME_LAYERS[layerIdx]);
        }
      }
    }

    /* --- Head flame crown: larger, more intense --- */
    ctx.shadowColor = 'rgba(255, 120, 0, 0.9)';
    ctx.shadowBlur = 12;

    var crownCount = 5;
    for (i = 0; i < crownCount; i++) {
      var crAngle = (i / crownCount) * PI + PI * 0.5; // fan upward (semicircle above head)
      // Adjust relative to head-to-first-body direction
      var headDir = { x: 0, y: -1 };
      if (parts.length > 0) {
        var hdx = head.x - parts[0].x;
        var hdy = head.y - parts[0].y;
        var hdlen = sqrt(hdx * hdx + hdy * hdy);
        if (hdlen > 0.01) {
          headDir.x = hdx / hdlen;
          headDir.y = hdy / hdlen;
        }
      }

      var crRad = crAngle + atan2(headDir.y, headDir.x) - PI * 0.5;
      var crDirX = cos(crRad);
      var crDirY = sin(crRad);

      var crSeed = i * 5.1;
      var crHeight = (25 + rand() * 15) * (0.7 + sin(_frame * 0.1 + crSeed) * 0.3);
      var crWidth = bodyR * (0.5 + rand() * 0.3);
      var crSway = _frame * (0.12 + (crSeed % 1) * 0.06) + crSeed;

      var crBaseX = head.x + crDirX * bodyR * 0.3;
      var crBaseY = head.y + crDirY * bodyR * 0.3;
      var crTipX = crBaseX + crDirX * crHeight;
      var crTipY = crBaseY + crDirY * crHeight;

      for (layerIdx = 0; layerIdx < FLAME_LAYERS.length; layerIdx++) {
        ctx.shadowBlur = (layerIdx === 0) ? 12 : 0;
        _drawFlameTongue(ctx, crBaseX, crBaseY, crTipX, crTipY, crWidth, crSway, FLAME_LAYERS[layerIdx]);
      }
    }

    /* --- Heat distortion glow along body --- */
    ctx.shadowColor = 'rgba(255, 80, 0, 0.5)';
    ctx.shadowBlur = 8;
    ctx.globalAlpha = 0.08 + sin(_frame * 0.06) * 0.03;
    ctx.fillStyle = 'rgba(255, 100, 0, 0.15)';
    for (i = 0; i < parts.length; i++) {
      ctx.beginPath();
      ctx.arc(parts[i].x, parts[i].y, bodyR * 1.8, 0, TWO_PI);
      ctx.fill();
    }

    /* --- Spawn ember particles --- */
    if (_frame % 3 === 0 && parts.length > 0) {
      var emberSrc = parts[floor(rand() * parts.length)];
      _spawnEmber(
        emberSrc.x + (rand() - 0.5) * bodyR,
        emberSrc.y + (rand() - 0.5) * bodyR
      );
    }
    // Also from head
    if (_frame % 5 === 0) {
      _spawnEmber(
        head.x + (rand() - 0.5) * bodyR * 0.8,
        head.y + (rand() - 0.5) * bodyR * 0.8
      );
    }

    /* --- Update and render ember particles --- */
    for (i = 0; i < MAX_EMBERS; i++) {
      var em = _embers[i];
      if (!em.active) continue;

      em.x += em.vx;
      em.y += em.vy;
      // Horizontal sway
      em.vx += sin(_frame * 0.15 + i * 2.3) * 0.05;
      em.vx *= 0.98;
      em.vy *= 0.99;
      em.life--;

      if (em.life <= 0) {
        em.active = false;
        continue;
      }

      // Cull off-screen
      if (em.x < -50 || em.x > canvas.width + 50 ||
          em.y < -50 || em.y > canvas.height + 50) {
        em.active = false;
        continue;
      }

      var emProg = em.life / em.maxLife;
      var emSize = em.size * (0.3 + emProg * 0.7);

      // Draw ember as a tiny teardrop
      ctx.shadowColor = 'rgba(' + em.r + ',' + em.g + ',' + em.b + ', 0.6)';
      ctx.shadowBlur = 3;
      ctx.globalAlpha = emProg * 0.85;
      ctx.fillStyle = 'rgba(' + em.r + ',' + em.g + ',' + em.b + ',' + (emProg * 0.9).toFixed(3) + ')';
      ctx.beginPath();
      // Teardrop: wider at bottom, pointed at top (direction of travel)
      var emAngle = atan2(em.vy, em.vx);
      var emNx = cos(emAngle);
      var emNy = sin(emAngle);
      var emPx = -emNy;
      var emPy = emNx;
      ctx.moveTo(em.x + emNx * emSize * 1.5, em.y + emNy * emSize * 1.5); // point
      ctx.quadraticCurveTo(
        em.x + emPx * emSize * 0.8,
        em.y + emPy * emSize * 0.8,
        em.x - emNx * emSize * 0.5,
        em.y - emNy * emSize * 0.5
      );
      ctx.quadraticCurveTo(
        em.x - emPx * emSize * 0.8,
        em.y - emPy * emSize * 0.8,
        em.x + emNx * emSize * 1.5,
        em.y + emNy * emSize * 1.5
      );
      ctx.closePath();
      ctx.fill();
    }

    ctx.shadowBlur = 0;
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }

  /* ================================================================== */
  /*  SHADOW -- Tendril, void ring, and shadow particle pools            */
  /* ================================================================== */

  var MAX_TENDRILS = 8;
  var _tendrils = [];
  var MAX_RINGS = 3;
  var _rings = [];
  var MAX_SHADOW_PARTICLES = 20;
  var _shadowParticles = [];

  // Pre-allocate tendril pool
  (function () {
    var i;
    for (i = 0; i < MAX_TENDRILS; i++) {
      _tendrils.push({
        active: false,
        anchorX: 0,
        anchorY: 0,
        // Bezier control points (base positions, writhe offsets applied at render)
        cp1x: 0, cp1y: 0,
        cp2x: 0, cp2y: 0,
        endX: 0, endY: 0,
        life: 0,
        maxLife: 0,
        // Unique phase offsets for writhing animation
        phase1: 0, phase2: 0, phase3: 0,
        bodyPartIdx: 0,  // which body part this is anchored to
        lineWidth: 2
      });
    }

    // Pre-allocate void ring pool
    for (i = 0; i < MAX_RINGS; i++) {
      _rings.push({
        active: false,
        x: 0, y: 0,
        radius: 0,
        maxRadius: 0,
        startRadius: 0,
        life: 0,
        maxLife: 0
      });
    }

    // Pre-allocate shadow particle pool
    for (i = 0; i < MAX_SHADOW_PARTICLES; i++) {
      _shadowParticles.push({
        active: false,
        x: 0, y: 0,
        vx: 0, vy: 0,
        life: 0,
        maxLife: 0,
        size: 0,
        phase: 0  // for wavering motion
      });
    }
  })();

  var _tendrilSpawnTimer = 0;
  var _ringSpawnTimer = 0;

  function _spawnTendril(ax, ay, bodyPartIdx, bodyR) {
    var i, t;
    for (i = 0; i < MAX_TENDRILS; i++) {
      t = _tendrils[i];
      if (!t.active) break;
    }
    if (i >= MAX_TENDRILS) return;

    t.active = true;
    t.anchorX = ax;
    t.anchorY = ay;
    t.bodyPartIdx = bodyPartIdx;
    t.life = 30 + floor(rand() * 21); // 30-50 frames
    t.maxLife = t.life;

    // Generate an S-curve or spiral extending outward
    var outAngle = rand() * TWO_PI;
    var tendrilLen = 40 + rand() * 40; // 40-80px

    // Control point 1: ~30% along, offset perpendicular
    var perpOff1 = (rand() - 0.5) * tendrilLen * 0.6;
    t.cp1x = ax + cos(outAngle) * tendrilLen * 0.3 + cos(outAngle + PI * 0.5) * perpOff1;
    t.cp1y = ay + sin(outAngle) * tendrilLen * 0.3 + sin(outAngle + PI * 0.5) * perpOff1;

    // Control point 2: ~70% along, offset perpendicular (opposite direction for S-curve)
    var perpOff2 = (rand() - 0.5) * tendrilLen * 0.6;
    t.cp2x = ax + cos(outAngle) * tendrilLen * 0.7 + cos(outAngle + PI * 0.5) * perpOff2;
    t.cp2y = ay + sin(outAngle) * tendrilLen * 0.7 + sin(outAngle + PI * 0.5) * perpOff2;

    // End point
    t.endX = ax + cos(outAngle) * tendrilLen;
    t.endY = ay + sin(outAngle) * tendrilLen;

    // Unique phase offsets for organic writhing
    t.phase1 = rand() * TWO_PI;
    t.phase2 = rand() * TWO_PI;
    t.phase3 = rand() * TWO_PI;

    t.lineWidth = 2 + rand() * 1.5;
  }

  function _spawnVoidRing(x, y, startRadius, maxRadius) {
    var i, r;
    for (i = 0; i < MAX_RINGS; i++) {
      r = _rings[i];
      if (!r.active) break;
    }
    if (i >= MAX_RINGS) return;

    r.active = true;
    r.x = x;
    r.y = y;
    r.startRadius = startRadius;
    r.maxRadius = maxRadius;
    r.radius = startRadius;
    r.life = 25;
    r.maxLife = 25;
  }

  function _spawnShadowParticle(x, y) {
    var i, sp;
    for (i = 0; i < MAX_SHADOW_PARTICLES; i++) {
      sp = _shadowParticles[i];
      if (!sp.active) break;
    }
    if (i >= MAX_SHADOW_PARTICLES) return;

    sp.active = true;
    sp.x = x;
    sp.y = y;
    var a = rand() * TWO_PI;
    var spd = 0.3 + rand() * 0.6;
    sp.vx = cos(a) * spd;
    sp.vy = sin(a) * spd;
    sp.life = 25 + floor(rand() * 20);
    sp.maxLife = sp.life;
    sp.size = 1.5 + rand() * 2.5;
    sp.phase = rand() * TWO_PI;
  }

  function _renderShadow(ctx, canvas, head, parts, bodyR, player) {
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    var i, j;

    /* --- Dark aura base: faint darkness surrounding the body --- */
    ctx.globalAlpha = 0.15;
    ctx.fillStyle = 'rgba(10, 0, 20, 0.15)';
    for (i = 0; i < parts.length; i++) {
      ctx.beginPath();
      ctx.arc(parts[i].x, parts[i].y, bodyR * 2.5, 0, TWO_PI);
      ctx.fill();
    }
    // Head gets larger dark base
    ctx.globalAlpha = 0.18;
    ctx.beginPath();
    ctx.arc(head.x, head.y, bodyR * 3.0, 0, TWO_PI);
    ctx.fill();

    /* --- Spawn new tendrils --- */
    _tendrilSpawnTimer++;
    if (_tendrilSpawnTimer >= 30 + floor(rand() * 21)) {
      _tendrilSpawnTimer = 0;
      // Spawn 1-2 new tendrils
      var tCount = 1 + floor(rand() * 2);
      for (i = 0; i < tCount; i++) {
        if (parts.length === 0) break;
        var tIdx = floor(rand() * parts.length);
        _spawnTendril(parts[tIdx].x, parts[tIdx].y, tIdx, bodyR);
      }
    }

    /* --- Render active tendrils --- */
    ctx.lineCap = 'round';
    for (i = 0; i < MAX_TENDRILS; i++) {
      var t = _tendrils[i];
      if (!t.active) continue;

      t.life--;
      if (t.life <= 0) {
        t.active = false;
        continue;
      }

      var tProg = t.life / t.maxLife;

      // Update anchor position to track body part if still valid
      if (t.bodyPartIdx < parts.length) {
        var anchorDx = parts[t.bodyPartIdx].x - t.anchorX;
        var anchorDy = parts[t.bodyPartIdx].y - t.anchorY;
        t.anchorX += anchorDx;
        t.anchorY += anchorDy;
        t.cp1x += anchorDx;
        t.cp1y += anchorDy;
        t.cp2x += anchorDx;
        t.cp2y += anchorDy;
        t.endX += anchorDx;
        t.endY += anchorDy;
      }

      // Writhing offsets using sin/cos with unique phases
      var w1x = sin(_frame * 0.05 + t.phase1) * 15;
      var w1y = cos(_frame * 0.07 + t.phase1) * 15;
      var w2x = sin(_frame * 0.03 + t.phase2 + 1) * 20;
      var w2y = cos(_frame * 0.04 + t.phase2 + 2) * 20;
      var wex = sin(_frame * 0.06 + t.phase3) * 10;
      var wey = cos(_frame * 0.08 + t.phase3) * 10;

      // Outer dark glow layer
      ctx.shadowColor = 'rgba(80, 0, 160, 0.7)';
      ctx.shadowBlur = 6;
      ctx.globalAlpha = tProg * 0.45;
      ctx.strokeStyle = 'rgba(26, 0, 51,' + (tProg * 0.5).toFixed(3) + ')';
      ctx.lineWidth = t.lineWidth + 2;
      ctx.beginPath();
      ctx.moveTo(t.anchorX, t.anchorY);
      ctx.bezierCurveTo(
        t.cp1x + w1x, t.cp1y + w1y,
        t.cp2x + w2x, t.cp2y + w2y,
        t.endX + wex, t.endY + wey
      );
      ctx.stroke();

      // Inner bright purple core
      ctx.shadowBlur = 0;
      ctx.globalAlpha = tProg * 0.6;
      ctx.strokeStyle = 'rgba(102, 0, 204,' + (tProg * 0.65).toFixed(3) + ')';
      ctx.lineWidth = t.lineWidth;
      ctx.beginPath();
      ctx.moveTo(t.anchorX, t.anchorY);
      ctx.bezierCurveTo(
        t.cp1x + w1x, t.cp1y + w1y,
        t.cp2x + w2x, t.cp2y + w2y,
        t.endX + wex, t.endY + wey
      );
      ctx.stroke();

      // Brightest thin core for depth
      ctx.globalAlpha = tProg * 0.35;
      ctx.strokeStyle = 'rgba(160, 60, 255,' + (tProg * 0.4).toFixed(3) + ')';
      ctx.lineWidth = max(0.8, t.lineWidth * 0.4);
      ctx.beginPath();
      ctx.moveTo(t.anchorX, t.anchorY);
      ctx.bezierCurveTo(
        t.cp1x + w1x, t.cp1y + w1y,
        t.cp2x + w2x, t.cp2y + w2y,
        t.endX + wex, t.endY + wey
      );
      ctx.stroke();
    }

    /* --- Void pulse rings from head --- */
    _ringSpawnTimer++;
    if (_ringSpawnTimer >= 20) {
      _ringSpawnTimer = 0;
      _spawnVoidRing(head.x, head.y, bodyR, bodyR * 4);
    }

    for (i = 0; i < MAX_RINGS; i++) {
      var ring = _rings[i];
      if (!ring.active) continue;

      ring.life--;
      if (ring.life <= 0) {
        ring.active = false;
        continue;
      }

      var rProg = ring.life / ring.maxLife;
      ring.radius = ring.startRadius + (ring.maxRadius - ring.startRadius) * (1 - rProg);

      // Track head position
      ring.x = head.x;
      ring.y = head.y;

      // Outer ring glow
      ctx.shadowColor = 'rgba(80, 0, 160, 0.4)';
      ctx.shadowBlur = 5;
      ctx.globalAlpha = rProg * 0.25;
      ctx.strokeStyle = 'rgba(60, 0, 120,' + (rProg * 0.3).toFixed(3) + ')';
      ctx.lineWidth = max(1.5, 3 * rProg);
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, ring.radius, 0, TWO_PI);
      ctx.stroke();

      // Inner subtle ring
      ctx.shadowBlur = 0;
      ctx.globalAlpha = rProg * 0.15;
      ctx.strokeStyle = 'rgba(120, 0, 220,' + (rProg * 0.2).toFixed(3) + ')';
      ctx.lineWidth = max(0.8, 1.5 * rProg);
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, ring.radius * 0.85, 0, TWO_PI);
      ctx.stroke();
    }

    /* --- Spawn shadow particles --- */
    if (_frame % 5 === 0 && parts.length > 0) {
      var spSrc = parts[floor(rand() * parts.length)];
      _spawnShadowParticle(
        spSrc.x + (rand() - 0.5) * bodyR,
        spSrc.y + (rand() - 0.5) * bodyR
      );
    }

    /* --- Update and render shadow particles --- */
    for (i = 0; i < MAX_SHADOW_PARTICLES; i++) {
      var sp = _shadowParticles[i];
      if (!sp.active) continue;

      // Wavering drift
      sp.x += sp.vx + sin(_frame * 0.1 + sp.phase) * 0.15;
      sp.y += sp.vy + cos(_frame * 0.08 + sp.phase) * 0.15;
      sp.life--;

      if (sp.life <= 0) {
        sp.active = false;
        continue;
      }

      // Cull off-screen
      if (sp.x < -50 || sp.x > canvas.width + 50 ||
          sp.y < -50 || sp.y > canvas.height + 50) {
        sp.active = false;
        continue;
      }

      var spProg = sp.life / sp.maxLife;
      var spAlpha = 0.2 + spProg * 0.2; // 0.2-0.4
      var spSize = sp.size * (0.4 + spProg * 0.6);

      // Draw as dark amorphous shape (irregular polygon)
      ctx.shadowColor = 'rgba(40, 0, 80, 0.4)';
      ctx.shadowBlur = 3;
      ctx.globalAlpha = spAlpha;
      ctx.fillStyle = 'rgba(15, 0, 30,' + spAlpha.toFixed(3) + ')';
      ctx.beginPath();

      // Irregular 5-sided shape
      var spBaseAngle = _frame * 0.03 + sp.phase;
      for (j = 0; j < 5; j++) {
        var spA = spBaseAngle + (j / 5) * TWO_PI;
        var spR = spSize * (0.7 + sin(spA * 3 + sp.phase) * 0.3);
        var spPtX = sp.x + cos(spA) * spR;
        var spPtY = sp.y + sin(spA) * spR;
        if (j === 0) {
          ctx.moveTo(spPtX, spPtY);
        } else {
          ctx.lineTo(spPtX, spPtY);
        }
      }
      ctx.closePath();
      ctx.fill();
    }

    /* --- Dark energy vein along body path (bezier curve connecting parts) --- */
    if (parts.length >= 3) {
      ctx.shadowColor = 'rgba(60, 0, 120, 0.5)';
      ctx.shadowBlur = 4;
      ctx.globalAlpha = 0.12 + sin(_frame * 0.04) * 0.04;
      ctx.strokeStyle = 'rgba(40, 0, 80, 0.2)';
      ctx.lineWidth = max(1.5, bodyR * 0.12);
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.moveTo(parts[0].x, parts[0].y);
      for (i = 1; i < parts.length - 1; i += 2) {
        var cpX = parts[i].x + sin(_frame * 0.05 + i * 0.5) * 8;
        var cpY = parts[i].y + cos(_frame * 0.06 + i * 0.7) * 8;
        var nextI = min(i + 1, parts.length - 1);
        ctx.quadraticCurveTo(cpX, cpY, parts[nextI].x, parts[nextI].y);
      }
      ctx.stroke();
    }

    ctx.shadowBlur = 0;
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }

  /* ================================================================== */
  /*  Aura renderer lookup table                                         */
  /* ================================================================== */

  var AURA_RENDERERS = {
    'electric': _renderElectric,
    'fire':     _renderFire,
    'shadow':   _renderShadow
  };

  /* ================================================================== */
  /*  Pool reset (called when aura type changes)                         */
  /* ================================================================== */

  function _resetPools() {
    var i;
    for (i = 0; i < MAX_BOLTS; i++) {
      _bolts[i].active = false;
    }
    for (i = 0; i < MAX_SPARKS; i++) {
      _sparkParticles[i].active = false;
    }
    for (i = 0; i < MAX_EMBERS; i++) {
      _embers[i].active = false;
    }
    for (i = 0; i < MAX_TENDRILS; i++) {
      _tendrils[i].active = false;
    }
    for (i = 0; i < MAX_RINGS; i++) {
      _rings[i].active = false;
    }
    for (i = 0; i < MAX_SHADOW_PARTICLES; i++) {
      _shadowParticles[i].active = false;
    }
    _boltSpawnTimer = 0;
    _tendrilSpawnTimer = 0;
    _ringSpawnTimer = 0;
  }

  /* ================================================================== */
  /*  Module interface                                                   */
  /* ================================================================== */

  var _lastAura = 'none';

  var AurasMod = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;
      GameAPI = SP.GameAPI;
      settings = s;
    },

    updateSettings: function (s) {
      settings = s;
    },

    /**
     * Called by OverlayManager each frame.
     * Draws the selected aura effect around the player snake.
     */
    render: function (ctx, canvas, s) {
      if (!s || !s.visual || !s.visual.aura || s.visual.aura === 'none') return;

      _frame++;

      // Reset pools when aura type changes
      var currentAura = s.visual.aura;
      if (currentAura !== _lastAura) {
        _resetPools();
        _lastAura = currentAura;
      }

      var player = GameAPI.getPlayerSnake();
      if (!player || !player.bodyParts || player.bodyParts.length < 2) return;

      var viewPos = GameAPI.getViewPosition();
      if (!viewPos) return;

      var scale = GameAPI.getScale();
      if (!scale || scale <= 0) return;

      var cx = canvas.width / 2;
      var cy = canvas.height / 2;

      // Convert body parts to screen coordinates (sampled for performance)
      var screenParts = [];
      var step = max(2, floor(player.bodyParts.length / 30));
      for (var i = 0; i < player.bodyParts.length; i += step) {
        var bp = player.bodyParts[i];
        var sx = cx + (bp.x - viewPos.x) * scale;
        var sy = cy + (bp.y - viewPos.y) * scale;

        // Cull body parts well off-screen
        if (sx > -100 && sx < canvas.width + 100 &&
            sy > -100 && sy < canvas.height + 100) {
          screenParts.push({ x: sx, y: sy });
        }
      }

      if (screenParts.length === 0) return;

      // Always include head
      var headScreen = {
        x: cx + (player.x - viewPos.x) * scale,
        y: cy + (player.y - viewPos.y) * scale
      };

      // Cull if head is far off-screen
      if (headScreen.x < -200 || headScreen.x > canvas.width + 200 ||
          headScreen.y < -200 || headScreen.y > canvas.height + 200) {
        return;
      }

      // Body radius in screen pixels
      var bodyRadius = max(4, (player.thickness || 1) * scale * 14);

      // Dispatch to the appropriate aura renderer
      var renderer = AURA_RENDERERS[currentAura];
      if (renderer) {
        renderer(ctx, canvas, headScreen, screenParts, bodyRadius, player);
      }
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.AurasMod = AurasMod;
})();
