/**
 * Slither Pro — Game API abstraction layer.
 * This is the ONLY file that directly accesses Slither.io's global variables.
 * If the game updates its internals, only this file needs to change.
 *
 * Verified variable names (as of 2026-04):
 *   window.slither   — player snake object
 *   window.slithers  — array of nearby snakes
 *   window.foods     — array of food objects  (each has .xx .yy .sz)
 *   window.mc        — the main game <canvas> element
 *   window.gsc       — current scale/zoom
 *   window.view_xx / view_yy — camera center in game coords
 *   window.xm / ym   — mouse offset from canvas center
 *   window.playing    — boolean, true when in-game
 *   window.grd        — map radius in game units
 *   window.setAcceleration(n) — function: 1 = boost, 0 = stop
 */
(function () {
  'use strict';

  var _deathCallbacks = [];
  var _gameStartCallbacks = [];
  var _wasPlaying = false;

  var GameAPI = {
    // ─── State Queries ────────────────────────────────────────

    /**
     * Returns true if the player is currently in-game.
     */
    isPlaying: function () {
      return !!(window.playing && window.slither);
    },

    /**
     * Get the player's snake, normalized.
     * Returns null if not playing.
     */
    getPlayerSnake: function () {
      var s = window.slither;
      if (!s) return null;
      var computedScore = this.computeScore(s);
      return {
        id: s.id,
        x: s.xx,
        y: s.yy,
        angle: s.ang,
        wantedAngle: s.wang,
        speed: s.sp,
        length: computedScore,   // v9: Use displayed score as length (was sct)
        sct: s.sct,              // v9: Raw section count preserved separately
        thickness: s.sc,
        score: computedScore,
        bodyParts: this._extractBodyParts(s),
        name: s.nk || '',
        isPlayer: true
      };
    },

    /**
     * Get nearby snakes (excludes the player).
     */
    getNearbySnakes: function () {
      var snakes = window.slithers;
      if (!snakes) return [];
      var playerSnake = window.slither;
      var playerId = playerSnake ? playerSnake.id : -1;
      var result = [];
      for (var i = 0; i < snakes.length; i++) {
        var s = snakes[i];
        if (!s || s.id === playerId) continue;
        var enemyScore = this.computeScore(s);
        result.push({
          id: s.id,
          x: s.xx,
          y: s.yy,
          angle: s.ang,
          wantedAngle: s.wang,
          speed: s.sp,
          length: enemyScore,    // v9: Use displayed score as length (was sct)
          sct: s.sct,            // v9: Raw section count preserved separately
          thickness: s.sc,
          score: enemyScore,
          bodyParts: this._extractBodyParts(s),
          name: s.nk || '',
          isPlayer: false
        });
      }
      return result;
    },

    /**
     * Get the food array. Each item has {x, y, sz}.
     */
    getFoods: function () {
      var foods = window.foods;
      if (!foods) return [];
      var result = [];
      for (var i = 0; i < foods.length; i++) {
        var f = foods[i];
        if (!f) continue;
        result.push({
          x: f.xx,
          y: f.yy,
          sz: f.sz || 1
        });
      }
      return result;
    },

    /**
     * Get the main game canvas element.
     * slither.io stores it as window.mc
     */
    getGameCanvas: function () {
      // Primary: the game's own canvas reference
      if (window.mc && window.mc instanceof HTMLCanvasElement) {
        return window.mc;
      }
      // Fallback: largest position:fixed canvas on body
      var canvases = document.querySelectorAll('body > canvas');
      var best = null;
      var bestArea = 0;
      for (var i = 0; i < canvases.length; i++) {
        var c = canvases[i];
        var area = c.width * c.height;
        if (area > bestArea) {
          bestArea = area;
          best = c;
        }
      }
      return best || document.querySelector('canvas');
    },

    /**
     * Get current game scale (zoom level).
     */
    getScale: function () {
      return window.gsc || 0.9;
    },

    /**
     * Get the camera/view center position (game coordinates).
     */
    getViewPosition: function () {
      return {
        x: window.view_xx || (window.slither ? window.slither.xx : 0),
        y: window.view_yy || (window.slither ? window.slither.yy : 0)
      };
    },

    /**
     * Get the player's position.
     */
    getPlayerPosition: function () {
      var s = window.slither;
      if (!s) return null;
      return { x: s.xx, y: s.yy };
    },

    /**
     * Get the map radius.
     */
    getMapRadius: function () {
      return window.grd || 16384;
    },

    // ─── Server Queries ──────────────────────────────────────

    /**
     * Get list of available servers (IPv4 only, deduplicated).
     * Each entry is a unique game room identified by sid.
     */
    getServers: function () {
      var servers = window.sos;
      if (!servers || !servers.length) return [];
      var result = [];
      var seen = {};
      for (var i = 0; i < servers.length; i++) {
        var s = servers[i];
        if (!s || !s.ip) continue;
        // Skip IPv6 duplicates
        if (s.ip.indexOf('[') !== -1) continue;
        // Deduplicate by sid
        var sid = s.sid || 0;
        if (seen[sid]) continue;
        seen[sid] = true;
        result.push({
          ip: s.ip,
          port: s.po || 0,
          active: s.ac || 0,
          sid: sid,
          _raw: s  // keep reference for connectToServer
        });
      }
      // Sort by sid ascending for consistent ordering
      result.sort(function (a, b) { return a.sid - b.sid; });
      return result;
    },

    /**
     * Get the currently connected server.
     */
    getCurrentServer: function () {
      var s = window.bso;
      if (!s) return null;
      return { ip: s.ip || '', port: s.po || 0, sid: s.sid || 0 };
    },

    /**
     * Force-connect to a specific server by sid or raw server object.
     * Sets bso to the target entry so the game connects to the exact room.
     */
    connectToServer: function (sid) {
      var servers = window.sos;
      if (!servers) return;
      // Find the exact server entry by sid
      var target = null;
      for (var i = 0; i < servers.length; i++) {
        var s = servers[i];
        if (s && s.sid === sid && s.ip.indexOf('[') === -1) {
          target = s;
          break;
        }
      }
      if (!target) return;
      window.bso = target;
      window.forcing = target.ip;
      if (typeof window.connect === 'function') {
        window.connect();
      }
    },

    // ─── Control Mutations ────────────────────────────────────

    /**
     * Set the zoom/scale value.
     */
    setScale: function (value) {
      window.gsc = value;
    },

    /**
     * Set mouse position (controls snake direction).
     * Coordinates are in screen pixels relative to canvas center.
     * When input is locked, also stores values for the overwrite loop.
     */
    setMousePosition: function (x, y) {
      window.xm = x;
      window.ym = y;
      if (this._inputBlocked) {
        this._lockedXm = x;
        this._lockedYm = y;
      }
    },

    /**
     * Engage or disengage boost.
     */
    setBoost: function (active) {
      if (typeof window.setAcceleration === 'function') {
        window.setAcceleration(active ? 1 : 0);
      }
    },

    // ─── Input Lock (v8.1) ────────────────────────────────────
    //
    // slither.io defines window.xm/ym as non-configurable properties,
    // so Object.defineProperty cannot intercept them.
    //
    // Strategy: run a tight rAF loop that overwrites xm/ym with the
    // bot's values AFTER the game's mousemove handler sets them.
    // Combined with capture-phase event blockers on window+document
    // to suppress as many mouse events as possible before they reach
    // the game's handler.

    _inputBlocked: false,
    _lockedXm: 0,
    _lockedYm: 0,
    _blockRafId: null,
    _blockHandlers: null,

    /**
     * Block user mouse input so the bot has exclusive control.
     * Uses two layers:
     *   1. Capture-phase event blockers on window + document
     *   2. rAF overwrite loop as a safety net
     */
    blockUserInput: function () {
      if (this._inputBlocked) return;
      this._inputBlocked = true;

      this._lockedXm = window.xm || 0;
      this._lockedYm = window.ym || 0;

      // Layer 1: Capture-phase event blockers on both window and document
      var handler = function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();
      };
      this._blockHandlers = handler;

      try {
        window.addEventListener('mousemove', handler, true);
        document.addEventListener('mousemove', handler, true);
        window.addEventListener('touchmove', handler, true);
        document.addEventListener('touchmove', handler, true);
      } catch (e) { /* non-fatal */ }

      // Layer 2: rAF overwrite loop — ensures xm/ym always hold bot values
      var self = this;
      var overwrite = function () {
        if (!self._inputBlocked) return;
        window.xm = self._lockedXm;
        window.ym = self._lockedYm;
        self._blockRafId = requestAnimationFrame(overwrite);
      };
      this._blockRafId = requestAnimationFrame(overwrite);
    },

    /**
     * Restore normal mouse input.
     */
    unblockUserInput: function () {
      if (!this._inputBlocked) return;
      this._inputBlocked = false;

      // Remove event blockers
      if (this._blockHandlers) {
        try {
          window.removeEventListener('mousemove', this._blockHandlers, true);
          document.removeEventListener('mousemove', this._blockHandlers, true);
          window.removeEventListener('touchmove', this._blockHandlers, true);
          document.removeEventListener('touchmove', this._blockHandlers, true);
        } catch (e) { /* non-fatal */ }
        this._blockHandlers = null;
      }

      // Stop overwrite loop
      if (this._blockRafId) {
        cancelAnimationFrame(this._blockRafId);
        this._blockRafId = null;
      }
    },

    // ─── Event Hooks ──────────────────────────────────────────

    onDeath: function (callback) {
      _deathCallbacks.push(callback);
    },

    onGameStart: function (callback) {
      _gameStartCallbacks.push(callback);
    },

    /**
     * Called each frame by the main loop to check state transitions.
     */
    pollStateTransitions: function () {
      var isPlaying = this.isPlaying();

      if (_wasPlaying && !isPlaying) {
        for (var i = 0; i < _deathCallbacks.length; i++) {
          try { _deathCallbacks[i](); } catch (e) { console.error('[SlitherPro] Death callback error:', e); }
        }
      }

      if (!_wasPlaying && isPlaying) {
        for (var i = 0; i < _gameStartCallbacks.length; i++) {
          try { _gameStartCallbacks[i](); } catch (e) { console.error('[SlitherPro] GameStart callback error:', e); }
        }
      }

      _wasPlaying = isPlaying;
    },

    // ─── Internal Helpers ─────────────────────────────────────

    /**
     * Compute score from snake section count and food amount.
     * Uses the game's own fpsls/fmlts lookup tables if available.
     */
    computeScore: function (snake) {
      if (!snake) return 0;
      var sct = snake.sct || 0;
      var fam = snake.fam || 0;
      // Try the game's own score formula
      if (window.fpsls && window.fmlts && window.fpsls[sct] !== undefined
          && sct < window.fmlts.length) {
        var fmltVal = window.fmlts[sct];
        if (!fmltVal || fmltVal <= 0) return 0;
        return Math.max(0, Math.floor(15 * (window.fpsls[sct] + fam / fmltVal - 1) - 5));
      }
      // Fallback approximation
      return Math.max(0, Math.floor(sct * 15 + fam * 15 - 5));
    },

    /**
     * Extract body parts from a snake's pts array.
     */
    _extractBodyParts: function (snake) {
      if (!snake || !snake.pts) return [];
      var parts = [];
      for (var i = 0; i < snake.pts.length; i++) {
        var p = snake.pts[i];
        if (p && p.xx !== undefined) {
          parts.push({ x: p.xx, y: p.yy });
        }
      }
      return parts;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.GameAPI = GameAPI;
})();
