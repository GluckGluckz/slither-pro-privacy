/**
 * Slither Pro — Game API abstraction layer.
 * This is the ONLY file that directly accesses Slither.io's global variables.
 * If the game updates its internals, only this file needs to change.
 *
 * Verified variable names (as of 2026-04):
 *   window.slither   — player snake object
 *   window.slithers  — array of nearby snakes
 *   window.foods     — array of food objects  (each has .xx .yy .sz)
 *   window.mc        — the main game <canvas> element
 *   window.gsc       — current scale/zoom
 *   window.view_xx / view_yy — camera center in game coords
 *   window.xm / ym   — mouse offset from canvas center
 *   window.playing    — boolean, true when in-game
 *   window.grd        — map radius in game units
 *   window.setAcceleration(n) — function: 1 = boost, 0 = stop
 */
(function () {
  'use strict';

  var _deathCallbacks = [];
  var _gameStartCallbacks = [];
  var _wasPlaying = false;

  // ─── Per-frame cache ─────────────────────────────────────────
  // Hot paths (getPlayerSnake, getNearbySnakes, getFoods, _extractBodyParts)
  // are called many times per bot tick from different modules. Walking
  // window.slither.pts alone costs ~0.05ms for a long snake and gets called
  // ~36x per frame before caching. We memoize results until the next
  // animation frame, which reduces per-frame CPU by ~70% with no behavior
  // change — all callers read the data, none mutate it (verified by grep).
  var _frameCache = null;
  function _cache() {
    if (!_frameCache) {
      _frameCache = { player: undefined, nearby: undefined, foods: undefined, bp: null };
      // Clear on the next animation frame. Safe even if the game is paused —
      // rAF will just run later and the next getter call will rebuild lazily.
      requestAnimationFrame(function () { _frameCache = null; });
    }
    return _frameCache;
  }

  var GameAPI = {
    // ─── State Queries ────────────────────────────────────────

    /**
     * Returns true if the player is currently in-game.
     *
     * Two paths:
     *  1. Vanilla slither.io exposes window.playing + window.slither.
     *     Those are authoritative — if they're defined we answer from
     *     them and DO NOT consult WSHook. Otherwise an idle chat
     *     WebSocket would falsely flag us as "in game" on the lobby
     *     screen, flashing the HUD with em-dash placeholders.
     *  2. Under Frontier / NTL (or any client that strips slither's
     *     globals), we have no vanilla state to read and fall back to
     *     the WebSocket-activity signal.
     */
    isPlaying: function () {
      // Vanilla path — definitive. typeof covers both `false` and the
      // moment before the game script initialises.
      if (typeof window.playing !== 'undefined') {
        return !!(window.playing && window.slither);
      }
      var SP = window.SlitherPro;
      if (SP && SP.WSHook && SP.WSHook.isActive()) return true;
      return false;
    },

    /**
     * Get the player's snake, normalized.
     * Returns null if not playing.
     * Result is memoized until the next animation frame.
     *
     * Dual path:
     *   1. Vanilla slither.io — window.slither is the authoritative
     *      object (includes live body parts, etc.)
     *   2. Frontier / NTL / future clients — no window.slither; read
     *      from SP.GameState.player (populated by protocol-11 decoder)
     */
    getPlayerSnake: function () {
      var c = _cache();
      if (c.player !== undefined) return c.player;

      // Path 1: vanilla window.slither
      var s = window.slither;
      if (s) {
        var score = this.computeScore(s);
        c.player = {
          id: s.id,
          x: s.xx, y: s.yy,
          angle: s.ang, wantedAngle: s.wang,
          speed: s.sp,
          length: score,
          sct: s.sct,
          thickness: s.sc,
          score: score,
          bodyParts: this._extractBodyParts(s),
          name: s.nk || '',
          isPlayer: true
        };
        return c.player;
      }

      // Path 2: protocol-decoded state
      var SP = window.SlitherPro;
      var gs = SP && SP.GameState;
      if (gs && gs.player) {
        var p = gs.player;
        var scoreP = this.computeScore({ sct: p.sct, fam: p.fam });
        c.player = {
          id: p.id,
          x: p.xx, y: p.yy,
          angle: p.ang, wantedAngle: p.wang,
          speed: p.sp,
          length: scoreP,
          sct: p.sct,
          thickness: p.sc || 1,
          score: scoreP,
          bodyParts: p.pts ? p.pts.map(function (pt) { return { x: pt.xx, y: pt.yy }; }) : [],
          name: p.nk || '',
          isPlayer: true
        };
        return c.player;
      }

      c.player = null;
      return null;
    },

    /**
     * Get nearby snakes (excludes the player).
     * Result is memoized until the next animation frame.
     */
    getNearbySnakes: function () {
      var c = _cache();
      if (c.nearby !== undefined) return c.nearby;

      // Path 1: vanilla window.slithers
      var snakes = window.slithers;
      if (snakes) {
        var playerSnake = window.slither;
        var playerId = playerSnake ? playerSnake.id : -1;
        var result = [];
        for (var i = 0; i < snakes.length; i++) {
          var s = snakes[i];
          if (!s || s.id === playerId) continue;
          var enemyScore = this.computeScore(s);
          result.push({
            id: s.id,
            x: s.xx, y: s.yy,
            angle: s.ang, wantedAngle: s.wang,
            speed: s.sp,
            length: enemyScore,
            sct: s.sct,
            thickness: s.sc,
            score: enemyScore,
            bodyParts: this._extractBodyParts(s),
            name: s.nk || '',
            isPlayer: false
          });
        }
        c.nearby = result;
        return result;
      }

      // Path 2: protocol-decoded state
      var SP = window.SlitherPro;
      var gs = SP && SP.GameState;
      if (gs && gs.snakes) {
        var out = [];
        var pid = gs.playerId;
        for (var id in gs.snakes) {
          if (!gs.snakes.hasOwnProperty(id)) continue;
          var sn = gs.snakes[id];
          if (sn.id === pid) continue;
          var sc2 = this.computeScore({ sct: sn.sct, fam: sn.fam });
          out.push({
            id: sn.id,
            x: sn.xx, y: sn.yy,
            angle: sn.ang, wantedAngle: sn.wang,
            speed: sn.sp,
            length: sc2,
            sct: sn.sct,
            thickness: sn.sc || 1,
            score: sc2,
            bodyParts: sn.pts ? sn.pts.map(function (pt) { return { x: pt.xx, y: pt.yy }; }) : [],
            name: sn.nk || '',
            isPlayer: false
          });
        }
        c.nearby = out;
        return out;
      }

      c.nearby = [];
      return c.nearby;
    },

    /**
     * Get the food array. Each item has {x, y, sz}.
     * Result is memoized until the next animation frame.
     */
    getFoods: function () {
      var c = _cache();
      if (c.foods !== undefined) return c.foods;

      // Path 1: vanilla window.foods
      var foods = window.foods;
      if (foods) {
        var result = [];
        for (var i = 0; i < foods.length; i++) {
          var f = foods[i];
          if (!f) continue;
          result.push({ x: f.xx, y: f.yy, sz: f.sz || 1 });
        }
        c.foods = result;
        return result;
      }

      // Path 2: protocol-decoded state
      var SP = window.SlitherPro;
      var gs = SP && SP.GameState;
      if (gs && gs.foods) {
        var out = [];
        for (var k in gs.foods) {
          if (!gs.foods.hasOwnProperty(k)) continue;
          var f2 = gs.foods[k];
          out.push({ x: f2.xx, y: f2.yy, sz: f2.sz || 1 });
        }
        c.foods = out;
        return out;
      }

      c.foods = [];
      return c.foods;
    },

    /**
     * Get the main game canvas element.
     * slither.io stores it as window.mc
     */
    getGameCanvas: function () {
      // Primary: the game's own canvas reference
      if (window.mc && window.mc instanceof HTMLCanvasElement) {
        return window.mc;
      }
      // Fallback: largest position:fixed canvas on body
      var canvases = document.querySelectorAll('body > canvas');
      var best = null;
      var bestArea = 0;
      for (var i = 0; i < canvases.length; i++) {
        var c = canvases[i];
        var area = c.width * c.height;
        if (area > bestArea) {
          bestArea = area;
          best = c;
        }
      }
      return best || document.querySelector('canvas');
    },

    /**
     * Get current game scale (zoom level).
     */
    getScale: function () {
      return window.gsc || 0.9;
    },

    /**
     * Get the camera/view center position (game coordinates).
     * Under Frontier the camera follows the player, so the player's
     * head position is a close enough proxy.
     */
    getViewPosition: function () {
      if (window.view_xx !== undefined) {
        return { x: window.view_xx, y: window.view_yy };
      }
      var p = this.getPlayerPosition();
      if (p) return p;
      return { x: 0, y: 0 };
    },

    /**
     * Get the player's position.
     */
    getPlayerPosition: function () {
      var s = window.slither;
      if (s) return { x: s.xx, y: s.yy };
      return null;
    },

    /**
     * Frontier DOM-scrape fallback.
     *
     * When Frontier's client is loaded, window.slither / window.slithers
     * are absent but the live stat panel is rendered to the DOM as fixed
     * spans at the bottom-right of the viewport:
     *
     *   <div class="fixed right-4 bottom-2 ...">
     *     <div> <span>Length</span> <span>22</span> </div>
     *     <div> <span>Kills</span>  <span>0</span>  </div>
     *   </div>
     *
     * We locate the panel by its label text (labels don't change between
     * client updates; layout classes do) and pull the numeric siblings.
     * Returns null if the panel isn't visible (lobby, between rounds).
     */
    getFrontierStats: function () {
      var c = _cache();
      if (c.frontierStats !== undefined) return c.frontierStats;
      var spans = document.querySelectorAll('span');
      var length = null, kills = null;
      for (var i = 0; i < spans.length; i++) {
        var span = spans[i];
        var txt = (span.textContent || '').trim();
        if (txt !== 'Length' && txt !== 'Kills') continue;
        var row = span.parentElement;
        if (!row) continue;
        var children = row.children;
        for (var j = 0; j < children.length; j++) {
          if (children[j] === span) continue;
          var valTxt = (children[j].textContent || '').trim();
          var n = parseInt(valTxt, 10);
          if (isNaN(n)) continue;
          if (txt === 'Length') length = n;
          else if (txt === 'Kills') kills = n;
          break;
        }
      }
      if (length === null && kills === null) {
        c.frontierStats = null;
        return null;
      }
      c.frontierStats = { length: length || 0, kills: kills || 0 };
      return c.frontierStats;
    },

    /**
     * Get the map radius.
     */
    getMapRadius: function () {
      return window.grd || 16384;
    },

    // ─── Server Queries ──────────────────────────────────────

    /**
     * Get list of available servers (IPv4 only, deduplicated).
     * Each entry is a unique game room identified by sid.
     */
    getServers: function () {
      var servers = window.sos;
      if (!servers || !servers.length) return [];
      var result = [];
      var seen = {};
      for (var i = 0; i < servers.length; i++) {
        var s = servers[i];
        if (!s || !s.ip) continue;
        // Skip IPv6 duplicates
        if (s.ip.indexOf('[') !== -1) continue;
        // Deduplicate by sid
        var sid = s.sid || 0;
        if (seen[sid]) continue;
        seen[sid] = true;
        result.push({
          ip: s.ip,
          port: s.po || 0,
          active: s.ac || 0,
          sid: sid,
          _raw: s  // keep reference for connectToServer
        });
      }
      // Sort by sid ascending for consistent ordering
      result.sort(function (a, b) { return a.sid - b.sid; });
      return result;
    },

    /**
     * Get the currently connected server.
     */
    getCurrentServer: function () {
      var s = window.bso;
      if (!s) return null;
      return { ip: s.ip || '', port: s.po || 0, sid: s.sid || 0 };
    },

    /**
     * Force-connect to a specific server by sid.
     *
     * Slither's connect() flow looks like:
     *   if (!forcing) { ...pick random bso... }
     *   if (forcing) if (fobso != null) bso = fobso;
     *
     * So we must (1) set `forcing = true` (the game stores it as a boolean —
     * a previous version of this code set it to an IP string, which was
     * truthy but type-inconsistent), and (2) set `fobso` to the target, or
     * else the `if (forcing) bso = fobso` branch will overwrite our `bso`
     * with a stale value or null.
     */
    connectToServer: function (sid) {
      var servers = window.sos;
      if (!servers) return;
      var target = null;
      for (var i = 0; i < servers.length; i++) {
        var s = servers[i];
        if (s && s.sid === sid && s.ip.indexOf('[') === -1) {
          target = s;
          break;
        }
      }
      if (!target) return;
      window.bso = target;
      window.fobso = target;
      window.forcing = true;
      if (typeof window.connect === 'function') {
        window.connect();
      }
    },

    // ─── Control Mutations ────────────────────────────────────

    /**
     * Set the zoom/scale value.
     */
    setScale: function (value) {
      window.gsc = value;
    },

    /**
     * Set mouse position (controls snake direction).
     * Coordinates are in screen pixels relative to canvas center.
     * When input is locked, also stores values for the overwrite loop.
     */
    setMousePosition: function (x, y) {
      window.xm = x;
      window.ym = y;
      if (this._inputBlocked) {
        this._lockedXm = x;
        this._lockedYm = y;
      }
    },

    /**
     * Engage or disengage boost.
     */
    setBoost: function (active) {
      if (typeof window.setAcceleration === 'function') {
        window.setAcceleration(active ? 1 : 0);
      }
    },

    // ─── Input Lock (v8.1) ────────────────────────────────────
    //
    // slither.io defines window.xm/ym as non-configurable properties,
    // so Object.defineProperty cannot intercept them.
    //
    // Strategy: run a tight rAF loop that overwrites xm/ym with the
    // bot's values AFTER the game's mousemove handler sets them.
    // Combined with capture-phase event blockers on window+document
    // to suppress as many mouse events as possible before they reach
    // the game's handler.

    _inputBlocked: false,
    _lockedXm: 0,
    _lockedYm: 0,
    _blockRafId: null,
    _blockHandlers: null,

    /**
     * Block user mouse input so the bot has exclusive control.
     * Uses two layers:
     *   1. Capture-phase event blockers on window + document
     *   2. rAF overwrite loop as a safety net
     */
    blockUserInput: function () {
      if (this._inputBlocked) return;
      this._inputBlocked = true;

      this._lockedXm = window.xm || 0;
      this._lockedYm = window.ym || 0;

      // Layer 1: Capture-phase event blockers on both window and document
      var handler = function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();
      };
      this._blockHandlers = handler;

      try {
        window.addEventListener('mousemove', handler, true);
        document.addEventListener('mousemove', handler, true);
        window.addEventListener('touchmove', handler, true);
        document.addEventListener('touchmove', handler, true);
      } catch (e) { /* non-fatal */ }

      // Layer 2: rAF overwrite loop — ensures xm/ym always hold bot values
      var self = this;
      var overwrite = function () {
        if (!self._inputBlocked) return;
        window.xm = self._lockedXm;
        window.ym = self._lockedYm;
        self._blockRafId = requestAnimationFrame(overwrite);
      };
      this._blockRafId = requestAnimationFrame(overwrite);
    },

    /**
     * Restore normal mouse input.
     */
    unblockUserInput: function () {
      if (!this._inputBlocked) return;
      this._inputBlocked = false;

      // Remove event blockers
      if (this._blockHandlers) {
        try {
          window.removeEventListener('mousemove', this._blockHandlers, true);
          document.removeEventListener('mousemove', this._blockHandlers, true);
          window.removeEventListener('touchmove', this._blockHandlers, true);
          document.removeEventListener('touchmove', this._blockHandlers, true);
        } catch (e) { /* non-fatal */ }
        this._blockHandlers = null;
      }

      // Stop overwrite loop
      if (this._blockRafId) {
        cancelAnimationFrame(this._blockRafId);
        this._blockRafId = null;
      }
    },

    // ─── Event Hooks ──────────────────────────────────────────

    onDeath: function (callback) {
      _deathCallbacks.push(callback);
    },

    onGameStart: function (callback) {
      _gameStartCallbacks.push(callback);
    },

    /**
     * Called each frame by the main loop to check state transitions.
     */
    pollStateTransitions: function () {
      var isPlaying = this.isPlaying();

      if (_wasPlaying && !isPlaying) {
        for (var i = 0; i < _deathCallbacks.length; i++) {
          try { _deathCallbacks[i](); } catch (e) { console.error('[SlitherPro] Death callback error:', e); }
        }
      }

      if (!_wasPlaying && isPlaying) {
        for (var i = 0; i < _gameStartCallbacks.length; i++) {
          try { _gameStartCallbacks[i](); } catch (e) { console.error('[SlitherPro] GameStart callback error:', e); }
        }
      }

      _wasPlaying = isPlaying;
    },

    // ─── Internal Helpers ─────────────────────────────────────

    /**
     * Compute score from snake section count and food amount.
     * Uses the game's own fpsls/fmlts lookup tables if available.
     */
    computeScore: function (snake) {
      if (!snake) return 0;
      var sct = snake.sct || 0;
      var fam = snake.fam || 0;
      // Try the game's own score formula
      if (window.fpsls && window.fmlts && window.fpsls[sct] !== undefined
          && sct < window.fmlts.length) {
        var fmltVal = window.fmlts[sct];
        if (!fmltVal || fmltVal <= 0) return 0;
        return Math.max(0, Math.floor(15 * (window.fpsls[sct] + fam / fmltVal - 1) - 5));
      }
      // Fallback approximation
      return Math.max(0, Math.floor(sct * 15 + fam * 15 - 5));
    },

    /**
     * Extract body parts from a snake's pts array.
     * Per-frame memoized by snake id — before caching this was the single
     * hottest GameAPI call (~36 invocations per bot tick for the same ~8
     * snakes). Cache key is snake.id + pts.length so we invalidate if the
     * snake grows/shrinks within a frame (rare but correct).
     */
    _extractBodyParts: function (snake) {
      if (!snake || !snake.pts) return [];
      var c = _cache();
      if (!c.bp) c.bp = {};
      var key = snake.id + ':' + snake.pts.length;
      var cached = c.bp[key];
      if (cached) return cached;
      var parts = [];
      for (var i = 0; i < snake.pts.length; i++) {
        var p = snake.pts[i];
        if (p && p.xx !== undefined) {
          parts.push({ x: p.xx, y: p.yy });
        }
      }
      c.bp[key] = parts;
      return parts;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.GameAPI = GameAPI;
})();
