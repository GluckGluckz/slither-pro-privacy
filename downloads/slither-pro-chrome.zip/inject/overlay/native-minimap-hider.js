/**
 * Slither Pro — Native Minimap Hider.
 * The game renders its native minimap into a DOM div the game code refers to
 * as `window.loch` (a class="nsi" container holding two canvases + the
 * "server ####" label). Pressing M or clicking the in-game map button flips
 * its inline `style.display`. We attach a MutationObserver to the style
 * attribute: any time the display flips back on while the user has our
 * "Hide Game's Minimap" toggle active, we force it back to none. This beats
 * setting the display once (which M-key would undo) and avoids the ugly
 * opaque overlay the first version used.
 *
 * Verified 2026-04-19 against live slither.io via Chrome devtools:
 *   window.loch.tagName === 'DIV'
 *   window.loch.className === 'nsi'
 *   children = [IMG, CANVAS, CANVAS, DIV, IMG]  (2 minimap canvases + label)
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP) return;

  var settings = null;
  var _loch = null;
  var _observer = null;
  var _prevDisplay = '';
  var _waitTimer = null;
  var _suppressObserver = false;

  function hide() {
    if (!_loch) return;
    _suppressObserver = true;
    if (_loch.style.display !== 'none') {
      _prevDisplay = _loch.style.display || '';
    }
    _loch.style.display = 'none';
    _suppressObserver = false;
  }

  function show() {
    if (!_loch) return;
    _suppressObserver = true;
    // Restore whatever value the game had last — if we never saw one, clear
    // our override entirely so the game's own styling wins.
    if (_prevDisplay) _loch.style.display = _prevDisplay;
    else _loch.style.removeProperty('display');
    _suppressObserver = false;
  }

  function apply() {
    if (!_loch || !settings || !settings.hud) return;
    if (settings.hud.hideNativeMinimap) hide();
    else show();
  }

  function attach(el) {
    _loch = el;
    _observer = new MutationObserver(function () {
      if (_suppressObserver) return;
      if (!settings || !settings.hud || !settings.hud.hideNativeMinimap) return;
      // Game re-enabled display — stash the value it tried to set, then hide.
      if (_loch.style.display !== 'none') {
        _prevDisplay = _loch.style.display || '';
        hide();
      }
    });
    _observer.observe(_loch, { attributes: true, attributeFilter: ['style'] });
    apply();
  }

  function waitForLoch() {
    if (_loch) return;
    if (window.loch && window.loch.nodeType === 1) {
      attach(window.loch);
      return;
    }
    _waitTimer = setInterval(function () {
      if (window.loch && window.loch.nodeType === 1) {
        clearInterval(_waitTimer);
        _waitTimer = null;
        attach(window.loch);
      }
    }, 200);
  }

  var NativeMinimapHider = {
    init: function (s) {
      settings = s;
      waitForLoch();
    },
    updateSettings: function (s) {
      settings = s;
      apply();
    }
  };

  window.SlitherPro.NativeMinimapHider = NativeMinimapHider;
})();
