/**
 * Slither Pro — Grid Overlay Renderer.
 * Draws a world-space grid over the game canvas for spatial awareness.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI;
  var settings = null;

  var GRID_SPACING = 200; // Game units between grid lines

  var GridRenderer = {
    init: function (s) {
      GameAPI = SP.GameAPI;
      settings = s;
    },

    updateSettings: function (s) {
      settings = s;
    },

    render: function (ctx, canvas, s) {
      if (!s || !s.visual || !s.visual.gridEnabled) return;
      if (!GameAPI || !GameAPI.isPlaying()) return;

      settings = s;

      var scale = GameAPI.getScale();
      var view = GameAPI.getViewPosition();
      var w = canvas.width;
      var h = canvas.height;

      // Calculate the visible area in game coordinates
      var halfW = (w / 2) / scale;
      var halfH = (h / 2) / scale;
      var left = view.x - halfW;
      var right = view.x + halfW;
      var top = view.y - halfH;
      var bottom = view.y + halfH;

      // Snap to grid
      var startX = Math.floor(left / GRID_SPACING) * GRID_SPACING;
      var startY = Math.floor(top / GRID_SPACING) * GRID_SPACING;

      ctx.save();

      ctx.strokeStyle = s.visual.gridColor || '#333333';
      ctx.globalAlpha = s.visual.gridOpacity || 0.3;
      ctx.lineWidth = 1;

      ctx.beginPath();

      // Vertical lines
      for (var gx = startX; gx <= right; gx += GRID_SPACING) {
        var screenX = (gx - view.x) * scale + w / 2;
        ctx.moveTo(screenX, 0);
        ctx.lineTo(screenX, h);
      }

      // Horizontal lines
      for (var gy = startY; gy <= bottom; gy += GRID_SPACING) {
        var screenY = (gy - view.y) * scale + h / 2;
        ctx.moveTo(0, screenY);
        ctx.lineTo(w, screenY);
      }

      ctx.stroke();

      // Draw coordinate labels at intersections (every 5th line)
      ctx.globalAlpha = (s.visual.gridOpacity || 0.3) * 0.6;
      ctx.fillStyle = s.visual.gridColor || '#333333';
      ctx.font = '10px monospace';
      ctx.textBaseline = 'top';
      for (var lx = startX; lx <= right; lx += GRID_SPACING * 5) {
        for (var ly = startY; ly <= bottom; ly += GRID_SPACING * 5) {
          var sx = (lx - view.x) * scale + w / 2;
          var sy = (ly - view.y) * scale + h / 2;
          ctx.fillText(Math.round(lx) + ',' + Math.round(ly), sx + 3, sy + 3);
        }
      }

      ctx.restore();
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.GridRenderer = GridRenderer;
})();
