/**
 * Slither Pro — Overlay Manager.
 * Creates and manages a transparent canvas layered on top of the game canvas.
 * The game canvas (window.mc) is position:fixed on <body>, so the overlay
 * must mirror its exact position, size, and stacking.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  var overlayCanvas = null;
  var overlayCtx = null;
  var gameCanvas = null;
  var renderers = [];
  var _initialized = false;
  var _resizeObserver = null;

  var OverlayManager = {
    init: function (canvas) {
      if (_initialized) return;
      _initialized = true;
      gameCanvas = canvas;

      var CONSTANTS = (window.SlitherPro && window.SlitherPro.CONSTANTS) || {};
      var zIndex = CONSTANTS.OVERLAY_Z_INDEX || 999999;

      // Remove any previous overlay (e.g. from a stale init on the wrong canvas)
      var old = document.getElementById('slither-pro-overlay');
      if (old) old.remove();

      // Create overlay canvas
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.id = 'slither-pro-overlay';
      overlayCanvas.style.pointerEvents = 'none';
      overlayCanvas.style.zIndex = String(zIndex);

      // Mirror the game canvas positioning exactly
      this._syncSize();
      this._syncPosition();

      // Persistent HUD root so other mods (Frontier, NTL) replacing <body>
      // don't orphan us.
      SP.HudRoot.append(overlayCanvas);

      overlayCtx = overlayCanvas.getContext('2d');

      // Keep overlay sized and positioned correctly
      var self = this;
      if (_resizeObserver) {
        try { _resizeObserver.disconnect(); } catch (e) {}
        _resizeObserver = null;
      }
      if (typeof ResizeObserver !== 'undefined') {
        _resizeObserver = new ResizeObserver(function () {
          self._syncSize();
          self._syncPosition();
        });
        _resizeObserver.observe(gameCanvas);
      }
      window.addEventListener('resize', function () {
        self._syncSize();
        self._syncPosition();
      });

      /* overlay initialized */
    },

    /**
     * Register a renderer module.
     */
    register: function (name, renderer, priority) {
      renderers.push({ name: name, renderer: renderer, priority: priority || 0 });
      renderers.sort(function (a, b) { return a.priority - b.priority; });
    },

    /**
     * Called each frame from the main loop.
     */
    render: function (settings) {
      if (!overlayCtx || !overlayCanvas) return;

      // Re-sync if game canvas size or position changed
      if (gameCanvas) {
        if (overlayCanvas.width !== gameCanvas.width || overlayCanvas.height !== gameCanvas.height) {
          this._syncSize();
        }
        this._syncPosition();
      }

      // Clear the overlay
      overlayCtx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);

      // Call each renderer in priority order
      for (var i = 0; i < renderers.length; i++) {
        var r = renderers[i];
        try {
          if (r.renderer && typeof r.renderer.render === 'function') {
            r.renderer.render(overlayCtx, overlayCanvas, settings);
          }
        } catch (err) {
          console.error('[SlitherPro] Renderer "' + r.name + '" error:', err);
        }
      }
    },

    getCanvas: function () { return overlayCanvas; },
    getContext: function () { return overlayCtx; },
    getGameCanvas: function () { return gameCanvas; },

    /**
     * Match the overlay's pixel dimensions to the game canvas.
     */
    _syncSize: function () {
      if (!gameCanvas || !overlayCanvas) return;
      var w = gameCanvas.width || gameCanvas.offsetWidth || 800;
      var h = gameCanvas.height || gameCanvas.offsetHeight || 600;
      overlayCanvas.width = w;
      overlayCanvas.height = h;
      overlayCanvas.style.width = w + 'px';
      overlayCanvas.style.height = h + 'px';
    },

    /**
     * Copy the game canvas's CSS position so the overlay sits exactly on top.
     * The game canvas is typically position:fixed with left/top offsets.
     */
    _syncPosition: function () {
      if (!gameCanvas || !overlayCanvas) return;
      var cs = gameCanvas.style;
      overlayCanvas.style.position = cs.position || 'fixed';
      overlayCanvas.style.left = cs.left || '0px';
      overlayCanvas.style.top = cs.top || '0px';
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.OverlayManager = OverlayManager;
})();
