/**
 * Slither Pro — Minimap Renderer (compatibility shim).
 * Minimap rendering is now handled by HudManager via its own widget canvas.
 * This file is kept to avoid breaking overlay-manager registration.
 */
(function () {
  'use strict';

  var MinimapRenderer = {
    init: function () {},
    updateSettings: function () {},
    render: function () { /* no-op — HudManager renders minimap */ }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.MinimapRenderer = MinimapRenderer;
})();
