/**
 * Slither Pro — HUD Renderer (compatibility shim).
 * Delegates to HudManager for data. No canvas rendering.
 * Kept so death-recap.js can call getPeakScore/getKills/getSessionTime.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  var HudRenderer = {
    init: function () {},
    updateSettings: function () {},
    resetSession: function () {
      if (SP.HudManager) SP.HudManager.resetSession();
    },
    getKills: function () { return SP.HudManager ? SP.HudManager.getKills() : 0; },
    getPeakScore: function () { return SP.HudManager ? SP.HudManager.getPeakScore() : 0; },
    getSessionTime: function () { return SP.HudManager ? SP.HudManager.getSessionTime() : 0; },
    render: function () { /* no-op — HudManager renders via HTML widgets */ }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.HudRenderer = HudRenderer;
})();
