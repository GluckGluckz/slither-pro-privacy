/**
 * Slither Pro — Visual Skin Picker.
 *
 * An in-game modal skin selector injected onto slither.io's main
 * screen (directly beneath the Play button). Complements the dropdown
 * inside the extension popup — both write to settings.visual.skin and
 * both react to SETTINGS_UPDATE messages, so changing one updates the
 * other in real time.
 *
 * Design philosophy: look like it was *baked into* vanilla slither.io.
 * Rounded pill button matching the Play button's visual grammar
 * (soft greens, casual typography), modal uses slither's cream/white
 * card aesthetic rather than the neon-green tech look reserved for
 * our HUD widgets.
 *
 * Preview fidelity:
 *   Every card renders a small canvas with a curved snake drawn as
 *   overlapping circle segments. The per-segment colour cycle for
 *   animated skins is re-implemented here using the same phase
 *   constants as src/inject/mods/skins.js so what you see in the
 *   card matches what lands on your snake in-game.
 *
 * All ES5 — var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP) return;
  if (SP.SkinPicker) return;

  var settings = null;
  var _initialized = false;

  // DOM refs
  var _triggerBtn = null;    // pill button below Play
  var _backdropEl = null;    // full-screen dim
  var _modalEl = null;       // centered dialog
  var _gridEl = null;
  var _cardByKey = {};       // skin key → card DOM + canvas ctx + frame counter
  var _open = false;
  var _rafId = 0;
  var _keydownHooked = false;

  // Ordered skin list — grouped so related skins cluster together in
  // the grid, and "default" + "custom" sit at the start for quick access.
  var SKIN_ORDER = [
    'default', 'custom',
    // Static
    'neon-green', 'neon-pink', 'neon-blue', 'neon-purple',
    'fire', 'ice', 'galaxy', 'toxic', 'lava', 'ocean',
    'sunset', 'stealth',
    // Animated
    'rainbow', 'aurora', 'plasma', 'pulse-fire', 'pulse-ice',
    'candy', 'lightning', 'vaporwave', 'neon-pulse',
    'inferno', 'frozen',
    // Glowing
    'neon-emerald', 'neon-crimson', 'neon-cyan', 'neon-gold',
    'solar-flare', 'deep-space', 'radioactive', 'holographic',
    'ember', 'crystal', 'void', 'electric-storm',
    'blood-moon', 'arctic', 'cherry-blossom', 'matrix'
  ];

  // Skin keys whose preview animates (same set as ANIMATED_SKINS in
  // src/inject/mods/skins.js — kept in sync manually).
  var ANIMATED = {
    'rainbow': true, 'aurora': true, 'plasma': true,
    'pulse-fire': true, 'pulse-ice': true, 'candy': true,
    'lightning': true, 'vaporwave': true, 'neon-pulse': true,
    'inferno': true, 'frozen': true
  };

  // Tag each skin with a category badge ("NEW", "ANIM", "GLOW") so the
  // card art carries a bit of extra flavour like slither.io's own shop.
  var CATEGORY = {};
  [
    'rainbow', 'aurora', 'plasma', 'pulse-fire', 'pulse-ice',
    'candy', 'lightning', 'vaporwave', 'neon-pulse',
    'inferno', 'frozen'
  ].forEach(function (k) { CATEGORY[k] = 'ANIM'; });
  [
    'neon-emerald', 'neon-crimson', 'neon-cyan', 'neon-gold',
    'solar-flare', 'deep-space', 'radioactive', 'holographic',
    'ember', 'crystal', 'void', 'electric-storm',
    'blood-moon', 'arctic', 'cherry-blossom', 'matrix'
  ].forEach(function (k) { CATEGORY[k] = 'GLOW'; });

  // ─────────────────────────────────────────────────────────
  // Labels
  // ─────────────────────────────────────────────────────────
  function prettyName(key) {
    if (key === 'default') return 'Default';
    if (key === 'custom') return 'Custom';
    return key.replace(/-/g, ' ').replace(/\b\w/g, function (c) {
      return c.toUpperCase();
    });
  }

  // ─────────────────────────────────────────────────────────
  // Color helpers
  // ─────────────────────────────────────────────────────────
  function hexToRgb(hex) {
    var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!m) return null;
    return {
      r: parseInt(m[1], 16),
      g: parseInt(m[2], 16),
      b: parseInt(m[3], 16)
    };
  }

  /**
   * Resolve a skin key → the hex-colour array that's currently active
   * for that skin's PREVIEW. For custom, reads the latest settings.
   * For default, returns a slither-green pair so the "Default" card
   * doesn't look empty.
   */
  function colorsFor(key) {
    if (key === 'default') return ['#2a9d5a', '#3fd37c'];
    if (key === 'custom') {
      if (settings && settings.visual && settings.visual.customColors) {
        return settings.visual.customColors.slice();
      }
      return ['#39ff14', '#006600'];
    }
    var preset = SP.SKIN_PRESETS ? SP.SKIN_PRESETS[key] : null;
    return preset || ['#2a9d5a', '#3fd37c'];
  }

  // ─────────────────────────────────────────────────────────
  // Per-skin preview pattern generators (mirrors skins.js logic)
  //
  // Each returns a function(frame, patternLen) → array of hex colours.
  // skins.js feeds the ACTUAL snake segments via the game's closest-
  // colour palette (42 discrete hues). For previews we just paint the
  // source hex directly — visually equivalent on a small card.
  // ─────────────────────────────────────────────────────────
  function staticPattern(colors) {
    return function (_frame, patternLen) {
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        out.push(colors[i % colors.length]);
      }
      return out;
    };
  }

  function rainbowPattern() {
    var spec = [
      '#ff0000', '#ff4500', '#ff8c00', '#ffd700',
      '#ffff00', '#7fff00', '#00ff00', '#00fa9a',
      '#00bfff', '#4169e1', '#8a2be2', '#ff00ff'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 8) % spec.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        out.push(spec[(i + shift) % spec.length]);
      }
      return out;
    };
  }

  function auroraPattern() {
    var cols = [
      '#00ff88', '#00ffcc', '#00e5ff', '#00bfff',
      '#4488ff', '#6644ff', '#aa44ff', '#cc44ff',
      '#6644ff', '#4488ff', '#00bfff', '#00e5ff'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 12) % cols.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        var i1 = (i + shift) % cols.length;
        var i2 = (i + shift + 4) % cols.length;
        out.push(i % 3 === 0 ? cols[i2] : cols[i1]);
      }
      return out;
    };
  }

  function plasmaPattern() {
    var cols = [
      '#ff0040', '#ff2200', '#ff4400', '#ff6600',
      '#ff8800', '#ffaa00', '#ffcc00', '#ffee00',
      '#ffffff', '#ffee00', '#ffcc00', '#ffaa00',
      '#ff8800', '#ff6600', '#ff4400', '#ff2200'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 6) % cols.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        out.push(cols[(i * 2 + shift) % cols.length]);
      }
      return out;
    };
  }

  function pulsePattern(theme) {
    var cols = theme === 'fire' ? [
      '#ff0000', '#ff2200', '#ff4400', '#ff6600',
      '#ff8800', '#ffaa00', '#ffcc00', '#ffaa00',
      '#ff8800', '#ff6600', '#ff4400', '#ff2200'
    ] : [
      '#0044ff', '#0066ff', '#0088ff', '#00aaff',
      '#00ccff', '#00eeff', '#88ffff', '#00eeff',
      '#00ccff', '#00aaff', '#0088ff', '#0066ff'
    ];
    return function (frame, patternLen) {
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        var wave = Math.floor(Math.sin((i * 0.5) + (frame * 0.08)) * 4 + 6);
        out.push(cols[Math.abs(wave) % cols.length]);
      }
      return out;
    };
  }

  function candyPattern() {
    var cols = [
      '#ff69b4', '#ff88cc', '#ffaadd', '#ffccee',
      '#ccddff', '#aaccff', '#88bbff', '#77ddff',
      '#88ffcc', '#aaffaa', '#ccff88', '#ffff77',
      '#ffdd88', '#ffbb99', '#ff99aa'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 10) % cols.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        out.push(cols[(i + shift) % cols.length]);
      }
      return out;
    };
  }

  function lightningPattern() {
    var base = ['#0044ff', '#0066ff', '#0088ff', '#00aaff'];
    var flash = ['#ffffff', '#ccddff', '#aaccff'];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 10) % base.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        var isFlash = (frame + i * 7) % 20 < 3;
        if (isFlash) {
          out.push(flash[i % flash.length]);
        } else {
          out.push(base[(i + shift) % base.length]);
        }
      }
      return out;
    };
  }

  function vaporwavePattern() {
    var cols = [
      '#ff71ce', '#ff9de2', '#ffccf9', '#ffd1dc',
      '#e0aaff', '#c77dff', '#9d4edd', '#7b2cbf',
      '#5a189a', '#3c096c', '#240046', '#3c096c',
      '#5a189a', '#7b2cbf', '#9d4edd', '#c77dff',
      '#01cdfe', '#05ffa1', '#b967ff', '#fffb96'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 10) % cols.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        out.push(cols[(i + shift) % cols.length]);
      }
      return out;
    };
  }

  function neonPulsePattern() {
    var cols = ['#39ff14', '#00ffff', '#ff00ff'];
    return function (frame, patternLen) {
      var phase = Math.floor(frame / 20) % cols.length;
      var out = [];
      for (var i = 0; i < patternLen; i++) out.push(cols[phase]);
      return out;
    };
  }

  function infernoPattern() {
    var cols = [
      '#ff0000', '#ff2200', '#ff4400', '#ff6600',
      '#ff8800', '#ffaa00', '#ffcc00', '#ffee00',
      '#ffffff', '#ffee00', '#ffcc00', '#ffaa00',
      '#ff8800', '#ff6600', '#ff4400', '#ff2200'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 4) % cols.length;
      var seed = Math.floor(frame / 4);
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        var hash = (seed * 31 + i * 17) % 100;
        if (hash < 10) out.push('#ffffff');
        else out.push(cols[(i + shift) % cols.length]);
      }
      return out;
    };
  }

  function frozenPattern() {
    var cols = [
      '#0044ff', '#0066ff', '#0088ff', '#00aaff',
      '#00ccff', '#44ddff', '#88ffff', '#aaffff',
      '#ffffff', '#aaffff', '#88ffff', '#44ddff',
      '#00ccff', '#00aaff', '#0088ff', '#0066ff'
    ];
    return function (frame, patternLen) {
      var shift = Math.floor(frame / 60) % cols.length;
      var seed = Math.floor(frame / 60);
      var out = [];
      for (var i = 0; i < patternLen; i++) {
        var hash = (seed * 37 + i * 13) % 100;
        if (hash < 5) out.push('#ffffff');
        else out.push(cols[(i + shift) % cols.length]);
      }
      return out;
    };
  }

  /** Return the pattern-generator function for a given skin key. */
  function patternFor(key) {
    switch (key) {
      case 'rainbow':    return rainbowPattern();
      case 'aurora':     return auroraPattern();
      case 'plasma':     return plasmaPattern();
      case 'pulse-fire': return pulsePattern('fire');
      case 'pulse-ice':  return pulsePattern('ice');
      case 'candy':      return candyPattern();
      case 'lightning':  return lightningPattern();
      case 'vaporwave':  return vaporwavePattern();
      case 'neon-pulse': return neonPulsePattern();
      case 'inferno':    return infernoPattern();
      case 'frozen':     return frozenPattern();
      default:           return staticPattern(colorsFor(key));
    }
  }

  // ─────────────────────────────────────────────────────────
  // Canvas drawing — a curved snake shape that shows off
  // the skin's segment colours at a readable scale.
  // ─────────────────────────────────────────────────────────
  var SEG_COUNT = 14;         // body segments visible in the preview
  var CANVAS_SIZE = 80;       // square canvas size in CSS px
  var SEG_RADIUS = 7;

  /** Return the (x, y) of the i-th segment along a gentle S-curve. */
  function segmentXY(i) {
    var t = i / (SEG_COUNT - 1);
    // Curve from upper-left quadrant to lower-right, sine in the middle.
    var x = 14 + t * (CANVAS_SIZE - 28);
    var y = CANVAS_SIZE / 2 + Math.sin(t * Math.PI * 1.6) * 14;
    return { x: x, y: y };
  }

  function drawPreview(ctx, colours, isDefault) {
    var w = CANVAS_SIZE, h = CANVAS_SIZE;
    ctx.clearRect(0, 0, w, h);

    // Subtle arena-style backdrop so pale skins remain visible.
    var grd = ctx.createRadialGradient(w / 2, h / 2, 4, w / 2, h / 2, w / 1.3);
    grd.addColorStop(0, 'rgba(255,255,255,0.05)');
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, w, h);

    // Tail → head so the head overlaps and looks in-front.
    for (var i = SEG_COUNT - 1; i >= 0; i--) {
      var p = segmentXY(i);
      var col = colours[i % colours.length];
      // Subtle segment darken near tail for depth.
      var depth = i / (SEG_COUNT - 1);
      var r = SEG_RADIUS - depth * 1.5;

      ctx.beginPath();
      ctx.fillStyle = col;
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();

      // Soft highlight
      ctx.beginPath();
      ctx.fillStyle = 'rgba(255,255,255,0.14)';
      ctx.arc(p.x - r * 0.3, p.y - r * 0.3, r * 0.4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Eye on the head for character.
    var head = segmentXY(0);
    ctx.beginPath();
    ctx.fillStyle = '#ffffff';
    ctx.arc(head.x - 2, head.y - 2, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.fillStyle = '#000000';
    ctx.arc(head.x - 2, head.y - 2, 0.9, 0, Math.PI * 2);
    ctx.fill();

    // A tiny "default" label so the default card doesn't feel empty.
    if (isDefault) {
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.font = '9px "Segoe UI", Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('(vanilla)', w / 2, h - 6);
    }
  }

  // ─────────────────────────────────────────────────────────
  // Animation loop — pumps every card in the grid.
  // Runs only while the modal is open; cancelled on close.
  // ─────────────────────────────────────────────────────────
  function tick() {
    if (!_open) return;
    for (var key in _cardByKey) {
      if (!_cardByKey.hasOwnProperty(key)) continue;
      var card = _cardByKey[key];
      if (!card.ctx) continue;
      card.frame++;
      var colours = card.gen(card.frame, SEG_COUNT);
      drawPreview(card.ctx, colours, key === 'default');
    }
    _rafId = requestAnimationFrame(tick);
  }

  // ─────────────────────────────────────────────────────────
  // CSS — slither.io-style rounded, cream/white card modal.
  // ─────────────────────────────────────────────────────────
  function injectCSS() {
    if (document.getElementById('sp-skin-picker-css')) return;
    var s = document.createElement('style');
    s.id = 'sp-skin-picker-css';
    s.textContent = [
      // Pill trigger button under Play — echoes the Play button's
      // rounded silhouette and hover lift without copying its colour.
      '.sp-skin-btn{display:inline-block;margin:12px auto 0;padding:9px 28px;border-radius:999px;',
        'background:linear-gradient(180deg,#6d5bbf 0%,#4e3f98 100%);color:#fff;',
        'font:700 18px "Segoe UI",Arial,sans-serif;letter-spacing:.5px;',
        'border:none;outline:none;cursor:pointer;user-select:none;',
        'box-shadow:0 3px 0 rgba(0,0,0,0.25),0 4px 10px rgba(0,0,0,0.22);',
        'transition:transform .08s,box-shadow .08s,filter .15s}',
      '.sp-skin-btn:hover{filter:brightness(1.08)}',
      '.sp-skin-btn:active{transform:translateY(2px);box-shadow:0 1px 0 rgba(0,0,0,0.25),0 2px 6px rgba(0,0,0,0.22)}',
      '.sp-skin-btn .ico{display:inline-block;margin-right:8px;font-size:18px;vertical-align:-2px}',

      // Wrapper lets the button sit under the Play button even though
      // Play itself is position:absolute. We inject this wrapper as a
      // sibling so it flows into the next visual row naturally.
      '.sp-skin-btn-wrap{text-align:center;width:100%;pointer-events:auto;position:relative;z-index:5}',

      // Backdrop + modal — pointer-events:auto required because
      // SP.HudRoot has pointer-events:none (inherited).
      '.sp-skin-backdrop{position:fixed;inset:0;background:rgba(10,14,22,.62);',
        'z-index:2147483646;display:none;pointer-events:auto;',
        'backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}',
      '.sp-skin-backdrop.open{display:block}',

      '.sp-skin-modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);',
        'width:640px;max-width:92vw;max-height:82vh;',
        'background:#f4f1e4;color:#2b2a26;',
        'border-radius:18px;box-shadow:0 24px 60px rgba(0,0,0,.55),0 0 0 2px rgba(0,0,0,.06);',
        'z-index:2147483647;display:none;flex-direction:column;',
        'font-family:"Segoe UI",-apple-system,Arial,sans-serif;',
        'pointer-events:auto;overflow:hidden}',
      '.sp-skin-modal.open{display:flex}',

      '.sp-skin-head{display:flex;align-items:center;justify-content:space-between;',
        'padding:14px 20px;background:linear-gradient(180deg,#fffdf6 0%,#efe9d6 100%);',
        'border-bottom:1px solid rgba(0,0,0,.08)}',
      '.sp-skin-head-title{font-size:18px;font-weight:700;color:#2b2a26;letter-spacing:.2px}',
      '.sp-skin-head-sub{font-size:11px;color:rgba(0,0,0,.45);margin-top:2px;font-weight:500}',
      '.sp-skin-close{cursor:pointer;width:30px;height:30px;border-radius:50%;',
        'display:flex;align-items:center;justify-content:center;',
        'background:rgba(0,0,0,.05);color:#444;font-size:18px;line-height:1;',
        'transition:background .15s;border:none;user-select:none}',
      '.sp-skin-close:hover{background:rgba(0,0,0,.12);color:#000}',

      '.sp-skin-grid-wrap{padding:14px 16px;overflow-y:auto;',
        'background:#f4f1e4;scrollbar-width:thin}',
      '.sp-skin-grid-wrap::-webkit-scrollbar{width:8px}',
      '.sp-skin-grid-wrap::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px}',

      '.sp-skin-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}',
      '@media (max-width:560px){.sp-skin-grid{grid-template-columns:repeat(3,1fr)}}',
      '@media (max-width:400px){.sp-skin-grid{grid-template-columns:repeat(2,1fr)}}',

      '.sp-skin-card{position:relative;background:#fffdf6;border:2px solid transparent;',
        'border-radius:12px;padding:10px 6px 8px;cursor:pointer;user-select:none;',
        'text-align:center;transition:transform .1s,border-color .1s,box-shadow .1s;',
        'box-shadow:0 1px 2px rgba(0,0,0,.05)}',
      '.sp-skin-card:hover{transform:translateY(-2px);box-shadow:0 6px 14px rgba(0,0,0,.12);',
        'border-color:rgba(109,91,191,.35)}',
      '.sp-skin-card.selected{border-color:#6d5bbf;background:#fffdf6;',
        'box-shadow:0 0 0 3px rgba(109,91,191,.18),0 4px 12px rgba(109,91,191,.2)}',

      '.sp-skin-card canvas{display:block;width:80px;height:80px;margin:0 auto;',
        'background:#2b2a26;border-radius:10px;',
        'box-shadow:inset 0 0 0 1px rgba(255,255,255,.05)}',

      '.sp-skin-card-label{margin-top:6px;font-size:12px;font-weight:600;',
        'color:#2b2a26;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;',
        'padding:0 4px}',

      '.sp-skin-card-badge{position:absolute;top:6px;right:6px;',
        'font-size:8px;font-weight:800;letter-spacing:.5px;',
        'padding:1px 5px;border-radius:6px;color:#fff;',
        'background:rgba(0,0,0,.4);text-transform:uppercase}',
      '.sp-skin-card-badge.anim{background:#6d5bbf}',
      '.sp-skin-card-badge.glow{background:#d67a2e}',

      '.sp-skin-card-check{position:absolute;top:6px;left:6px;',
        'width:20px;height:20px;border-radius:50%;',
        'background:#6d5bbf;color:#fff;font-size:13px;line-height:20px;',
        'text-align:center;font-weight:900;display:none}',
      '.sp-skin-card.selected .sp-skin-card-check{display:block}'
    ].join('\n');
    document.head.appendChild(s);
  }

  // ─────────────────────────────────────────────────────────
  // Trigger button — pill under Play
  // ─────────────────────────────────────────────────────────
  function ensureTriggerButton() {
    if (_triggerBtn && _triggerBtn.isConnected) return true;
    var playh = document.getElementById('playh');
    if (!playh || !playh.parentNode) return false;

    var wrap = document.createElement('div');
    wrap.className = 'sp-skin-btn-wrap';
    wrap.id = 'sp-skin-btn-wrap';

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'sp-skin-btn';
    btn.innerHTML = '<span class="ico">&#127912;</span>Choose Skin';
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openPicker();
    });

    wrap.appendChild(btn);

    // Insert directly after the Play button (playh). playh is often
    // wrapped in centered container markup so inserting as its next
    // sibling reliably places our button on the next visual row.
    if (playh.nextSibling) {
      playh.parentNode.insertBefore(wrap, playh.nextSibling);
    } else {
      playh.parentNode.appendChild(wrap);
    }

    _triggerBtn = btn;
    return true;
  }

  // Observe for late #playh mounts (slither recreates this element
  // during lobby↔game transitions on some versions).
  //
  // We prefer the MutationObserver when it's available and fall back
  // to a short polling window otherwise. Observer + polling together
  // were double-work; this version stops polling the moment either
  // source succeeds.
  function watchPlayHolder() {
    var installed = false;
    function tryInstall() {
      if (installed) return true;
      if (document.getElementById('playh') && !document.getElementById('sp-skin-btn-wrap')) {
        if (ensureTriggerButton()) {
          installed = true;
        }
      } else if (document.getElementById('sp-skin-btn-wrap')) {
        installed = true;
      }
      return installed;
    }

    if (tryInstall()) return;

    if (typeof MutationObserver === 'function') {
      var obs = new MutationObserver(function () {
        if (tryInstall()) obs.disconnect();
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      return;
    }

    // MutationObserver unavailable — 30 s polling fallback
    var tries = 0;
    var timer = setInterval(function () {
      if (tryInstall() || ++tries >= 60) clearInterval(timer);
    }, 500);
  }

  // ─────────────────────────────────────────────────────────
  // Modal construction
  // ─────────────────────────────────────────────────────────
  function buildModal() {
    if (_modalEl) return;

    _backdropEl = document.createElement('div');
    _backdropEl.className = 'sp-skin-backdrop';
    _backdropEl.addEventListener('click', closePicker);

    _modalEl = document.createElement('div');
    _modalEl.className = 'sp-skin-modal';
    _modalEl.setAttribute('role', 'dialog');
    _modalEl.setAttribute('aria-label', 'Choose Your Skin');

    var head = document.createElement('div');
    head.className = 'sp-skin-head';

    var title = document.createElement('div');
    var h1 = document.createElement('div');
    h1.className = 'sp-skin-head-title';
    h1.textContent = 'Choose Your Skin';
    var sub = document.createElement('div');
    sub.className = 'sp-skin-head-sub';
    sub.textContent = 'Click a skin to apply — changes save instantly';
    title.appendChild(h1);
    title.appendChild(sub);

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'sp-skin-close';
    close.innerHTML = '&times;';
    close.setAttribute('aria-label', 'Close');
    close.addEventListener('click', closePicker);

    head.appendChild(title);
    head.appendChild(close);
    _modalEl.appendChild(head);

    var gridWrap = document.createElement('div');
    gridWrap.className = 'sp-skin-grid-wrap';
    _gridEl = document.createElement('div');
    _gridEl.className = 'sp-skin-grid';
    gridWrap.appendChild(_gridEl);
    _modalEl.appendChild(gridWrap);

    buildCards();

    if (SP.HudRoot) {
      SP.HudRoot.append(_backdropEl);
      SP.HudRoot.append(_modalEl);
    } else {
      document.documentElement.appendChild(_backdropEl);
      document.documentElement.appendChild(_modalEl);
    }

    if (!_keydownHooked) {
      _keydownHooked = true;
      document.addEventListener('keydown', function (e) {
        if (!_open) return;
        if (e.key === 'Escape' || e.keyCode === 27) {
          closePicker();
        }
      }, false);
    }
  }

  function buildCards() {
    _cardByKey = {};
    _gridEl.innerHTML = '';

    for (var i = 0; i < SKIN_ORDER.length; i++) {
      var key = SKIN_ORDER[i];

      var card = document.createElement('div');
      card.className = 'sp-skin-card';
      card.setAttribute('data-skin', key);

      var canvas = document.createElement('canvas');
      canvas.width = CANVAS_SIZE;
      canvas.height = CANVAS_SIZE;
      card.appendChild(canvas);

      var label = document.createElement('div');
      label.className = 'sp-skin-card-label';
      label.textContent = prettyName(key);
      card.appendChild(label);

      if (CATEGORY[key]) {
        var badge = document.createElement('div');
        badge.className = 'sp-skin-card-badge ' + CATEGORY[key].toLowerCase();
        badge.textContent = CATEGORY[key];
        card.appendChild(badge);
      }

      var check = document.createElement('div');
      check.className = 'sp-skin-card-check';
      check.innerHTML = '&#10003;';
      card.appendChild(check);

      (function (k, cardEl) {
        cardEl.addEventListener('click', function () {
          selectSkin(k);
        });
      })(key, card);

      _gridEl.appendChild(card);

      _cardByKey[key] = {
        el: card,
        ctx: canvas.getContext('2d'),
        frame: 0,
        gen: patternFor(key)
      };

      // Paint an initial static frame so the grid isn't blank before
      // the animation loop starts.
      var first = _cardByKey[key].gen(0, SEG_COUNT);
      drawPreview(_cardByKey[key].ctx, first, key === 'default');
    }

    refreshSelection();
  }

  function refreshSelection() {
    if (!_gridEl) return;
    var current = settings && settings.visual ? settings.visual.skin : 'default';
    var cards = _gridEl.querySelectorAll('.sp-skin-card');
    for (var i = 0; i < cards.length; i++) {
      if (cards[i].getAttribute('data-skin') === current) {
        cards[i].classList.add('selected');
      } else {
        cards[i].classList.remove('selected');
      }
    }
    // Custom preview depends on customColors which may have changed;
    // rebuild its generator.
    if (_cardByKey['custom']) {
      _cardByKey['custom'].gen = patternFor('custom');
    }
  }

  // ─────────────────────────────────────────────────────────
  // Open / close
  // ─────────────────────────────────────────────────────────
  function openPicker() {
    buildModal();
    _open = true;
    _backdropEl.classList.add('open');
    _modalEl.classList.add('open');
    refreshSelection();
    cancelAnimationFrame(_rafId);
    _rafId = requestAnimationFrame(tick);
  }

  function closePicker() {
    if (!_open) return;
    _open = false;
    if (_backdropEl) _backdropEl.classList.remove('open');
    if (_modalEl) _modalEl.classList.remove('open');
    cancelAnimationFrame(_rafId);
  }

  // ─────────────────────────────────────────────────────────
  // Selection → persist → notify popup
  // ─────────────────────────────────────────────────────────
  function selectSkin(key) {
    if (!settings) settings = {};
    if (!settings.visual) settings.visual = {};
    settings.visual.skin = key;

    // Tell SkinsMod immediately so in-game change is live.
    if (SP.SkinsMod && SP.SkinsMod.updateSettings) {
      SP.SkinsMod.updateSettings(settings);
    }

    // Broadcast so content script writes to chrome.storage.sync and
    // the popup dropdown updates via storage.onChanged.
    if (SP.MessageBus && SP.EVENTS) {
      SP.MessageBus.send(SP.EVENTS.SETTINGS_UPDATE, { visual: settings.visual });
    }

    refreshSelection();
  }

  // ─────────────────────────────────────────────────────────
  // Public API
  // ─────────────────────────────────────────────────────────
  var SkinPicker = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;
      settings = s || {};
      injectCSS();
      watchPlayHolder();
    },

    updateSettings: function (s) {
      if (!s) return;
      settings = s;
      refreshSelection();
    },

    open:  openPicker,
    close: closePicker
  };

  SP.SkinPicker = SkinPicker;
})();
