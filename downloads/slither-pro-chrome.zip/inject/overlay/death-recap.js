/**
 * Slither Pro — Death Recap Panel (v3 — Premium DOM).
 * Shows a glass-morphism death summary panel in the bottom-right corner
 * when the player dies, with stat cards, growth rate, killer info,
 * animated progress bar, and auto-dismiss.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI, MathUtil;
  var settings = null;

  var _visible = false;
  var _deathData = null;
  var _panelEl = null;
  var _dismissTimer = null;
  var _cssInjected = false;

  var DISMISS_MS = 10000;
  var DISMISS_SEC = DISMISS_MS / 1000;

  // ── Cause-detection thresholds ─────────────────────────────
  // HEAD_KILL_RANGE — radius around player at which an enemy HEAD is
  //   plausibly the kill. 80 matches HudManager._trackKills which uses
  //   the same value to count OUR kills in the other direction.
  // BODY_HIT_RANGE — radius around player that counts as "touched"
  //   an enemy body segment. Tighter than head because body parts are
  //   densely packed and we want high precision for coil/tail kills.
  // WALL_EDGE_DIST — distance-from-edge under which we call it a
  //   wall hit. Well inside the lethal band.
  // HISTORY_LEN — rolling window the attribution scan looks over.
  //   60 frames ≈ 1s of pre-death context at 60fps — enough to see
  //   the enemy's approach, not so long that old threats pollute the
  //   evidence.
  var HEAD_KILL_RANGE = 80;
  var BODY_HIT_RANGE  = 30;
  var WALL_EDGE_DIST  = 80;
  var HISTORY_LEN     = 60;

  // ── Pre-death history ring ──────────────────────────────────
  // Captured every frame while playing. When window.slither goes
  // null on death, this is the only surviving evidence of what
  // happened. _history[_history.length-1] is the latest snapshot.
  var _history = [];

  /* ── Skull SVG path (24×24 viewBox) ── */
  var SKULL_PATH = 'M12 2C6.48 2 2 6.48 2 12c0 2.69 1.07 5.13 2.81 6.93L4 22h3l.5-2h1L9 22h6l.5-2h1l.5 2h3l-.81-3.07C20.93 17.13 22 14.69 22 12c0-5.52-4.48-10-10-10zm-3 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm6 0c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm-3 1.5c-.55 0-1-.22-1-.5s.45-.5 1-.5 1 .22 1 .5-.45.5-1 .5z';

  /* ── Mini skull for kills stat (12×12) ── */
  var MINI_SKULL_PATH = 'M6 1C3.24 1 1 3.24 1 6c0 1.34.54 2.56 1.41 3.46L2 11h1.5l.25-1h.5L4.5 11h3l.25-1h.5l.25 1H10l-.41-1.54C10.46 8.56 11 7.34 11 6c0-2.76-2.24-5-5-5zM4.5 8c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm3 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z';

  function _injectCSS() {
    if (_cssInjected) return;
    _cssInjected = true;
    var s = document.createElement('style');
    s.id = 'sp-death-recap-css';
    s.textContent = [
      /* keyframes */
      '@keyframes sp-dr-shrink{from{width:100%}to{width:0%}}',
      '@keyframes sp-dr-fadein{from{opacity:0;transform:scale(.95);filter:blur(6px)}to{opacity:1;transform:scale(1);filter:blur(0)}}',

      /* panel */
      '#sp-dr{position:fixed;bottom:20px;right:20px;z-index:1000010;width:340px;',
      'background:rgba(10,10,30,.94);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);',
      'border:1px solid rgba(57,255,20,.12);border-left:3px solid rgba(255,71,87,.5);',
      'border-radius:12px;padding:16px 18px 0;font-family:"Segoe UI",-apple-system,sans-serif;',
      'color:#fff;pointer-events:auto;opacity:0;transform:scale(.95);filter:blur(6px);',
      'box-shadow:0 4px 24px rgba(0,0,0,.55),0 0 40px rgba(255,71,87,.06);',
      'contain:layout style paint;will-change:transform,opacity}',

      '#sp-dr.sp-dr-show{animation:sp-dr-fadein .45s cubic-bezier(.22,1,.36,1) forwards}',

      '#sp-dr.sp-dr-hiding{opacity:0;transform:scale(.95);filter:blur(6px);',
      'transition:opacity .3s ease,transform .3s ease,filter .3s ease}',

      /* header */
      '#sp-dr .sp-dr-header{display:flex;align-items:center;gap:8px;margin:0 0 12px}',
      '#sp-dr .sp-dr-skull{flex-shrink:0}',
      '#sp-dr .sp-dr-title{color:#ff4757;font-size:20px;font-weight:700;letter-spacing:1.5px;',
      'text-shadow:0 0 8px rgba(255,71,87,.45),0 0 20px rgba(255,71,87,.15);margin:0}',

      /* close button */
      '#sp-dr .sp-dr-close{position:absolute;top:8px;right:10px;color:rgba(255,255,255,.35);',
      'cursor:pointer;font-size:20px;line-height:1;padding:4px 6px;border:none;background:none;',
      'transition:color .2s}',
      '#sp-dr .sp-dr-close:hover{color:#ff4757}',

      /* grid */
      '#sp-dr .sp-dr-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}',
      '#sp-dr .sp-dr-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);',
      'border-radius:8px;padding:10px 12px;text-align:center}',
      '#sp-dr .sp-dr-card-label{display:block;font-size:10px;text-transform:uppercase;',
      'letter-spacing:.8px;color:rgba(255,255,255,.4);margin-bottom:4px}',
      '#sp-dr .sp-dr-card-value{display:flex;align-items:center;justify-content:center;gap:4px;',
      'font-weight:700;font-size:20px;line-height:1.2}',

      /* card color accents */
      '#sp-dr .sp-dr-card--score .sp-dr-card-value{color:#ffa502;font-size:22px}',
      '#sp-dr .sp-dr-card--peak .sp-dr-card-value{color:#ffd700}',
      '#sp-dr .sp-dr-card--kills .sp-dr-card-value{color:#ff6b6b}',
      '#sp-dr .sp-dr-card--time .sp-dr-card-value{color:#74b9ff}',

      /* growth rate */
      '#sp-dr .sp-dr-growth{text-align:center;font-size:12px;color:rgba(255,255,255,.45);margin-bottom:8px}',
      '#sp-dr .sp-dr-growth span{color:#39ff14;font-weight:600}',

      /* divider */
      '#sp-dr .sp-dr-divider{border:none;border-top:1px solid rgba(255,255,255,.07);margin:0 0 8px}',

      /* killer */
      '#sp-dr .sp-dr-killer{font-size:13px;color:rgba(255,255,255,.45);text-align:center;margin-bottom:14px}',
      '#sp-dr .sp-dr-killer span{color:#ff4757;font-weight:600}',

      /* progress bar */
      '#sp-dr .sp-dr-progress-bar{position:absolute;bottom:0;left:0;height:3px;',
      'background:#39ff14;border-radius:0 0 0 12px;',
      'animation:sp-dr-shrink ' + DISMISS_SEC + 's linear forwards}'
    ].join('\n');
    document.head.appendChild(s);
  }

  /* ── DOM helpers ── */

  function _svgEl(tag, attrs) {
    var el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (var k in attrs) {
      if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]);
    }
    return el;
  }

  function _createSkullIcon() {
    var svg = _svgEl('svg', {
      width: '24', height: '24', viewBox: '0 0 24 24',
      fill: '#ff4757', 'class': 'sp-dr-skull'
    });
    var p = _svgEl('path', { d: SKULL_PATH });
    svg.appendChild(p);
    return svg;
  }

  function _createMiniSkull() {
    var svg = _svgEl('svg', {
      width: '12', height: '12', viewBox: '0 0 12 12',
      fill: '#ff6b6b', style: 'flex-shrink:0'
    });
    var p = _svgEl('path', { d: MINI_SKULL_PATH });
    svg.appendChild(p);
    return svg;
  }

  function _createCard(labelText, extraClass) {
    var card = document.createElement('div');
    card.className = 'sp-dr-card ' + extraClass;

    var label = document.createElement('span');
    label.className = 'sp-dr-card-label';
    label.textContent = labelText;

    var value = document.createElement('div');
    value.className = 'sp-dr-card-value';

    card.appendChild(label);
    card.appendChild(value);
    return card;
  }

  function _createPanel() {
    if (_panelEl) {
      /* Remove old panel entirely so progress bar restarts */
      if (_panelEl.parentNode) _panelEl.parentNode.removeChild(_panelEl);
      _panelEl = null;
    }
    _injectCSS();

    var panel = document.createElement('div');
    panel.id = 'sp-dr';

    /* header */
    var header = document.createElement('div');
    header.className = 'sp-dr-header';
    header.appendChild(_createSkullIcon());
    var title = document.createElement('div');
    title.className = 'sp-dr-title';
    title.textContent = 'GAME OVER';
    header.appendChild(title);
    panel.appendChild(header);

    /* close button */
    var closeBtn = document.createElement('button');
    closeBtn.className = 'sp-dr-close';
    closeBtn.textContent = '\u00D7';
    closeBtn.addEventListener('click', function () {
      DeathRecap.hide();
    });
    panel.appendChild(closeBtn);

    /* stat grid */
    var grid = document.createElement('div');
    grid.className = 'sp-dr-grid';

    var scoreCard = _createCard('Final Score', 'sp-dr-card--score');
    scoreCard.id = 'sp-dr-c-score';
    grid.appendChild(scoreCard);

    var peakCard = _createCard('Peak Score', 'sp-dr-card--peak');
    peakCard.id = 'sp-dr-c-peak';
    grid.appendChild(peakCard);

    var killsCard = _createCard('Kills', 'sp-dr-card--kills');
    killsCard.id = 'sp-dr-c-kills';
    grid.appendChild(killsCard);

    var timeCard = _createCard('Time Survived', 'sp-dr-card--time');
    timeCard.id = 'sp-dr-c-time';
    grid.appendChild(timeCard);

    panel.appendChild(grid);

    /* growth rate */
    var growth = document.createElement('div');
    growth.className = 'sp-dr-growth';
    growth.id = 'sp-dr-growth';
    panel.appendChild(growth);

    /* divider */
    var hr = document.createElement('hr');
    hr.className = 'sp-dr-divider';
    panel.appendChild(hr);

    /* killer info */
    var killer = document.createElement('div');
    killer.className = 'sp-dr-killer';
    killer.id = 'sp-dr-killer';
    panel.appendChild(killer);

    /* progress bar */
    var bar = document.createElement('div');
    bar.className = 'sp-dr-progress-bar';
    panel.appendChild(bar);

    SP.HudRoot.append(panel);
    _panelEl = panel;
  }

  /* ── Formatters ── */

  function _formatNumber(n) {
    if (n === undefined || n === null || isNaN(n)) return '0';
    return Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  function _formatTime(ms) {
    var totalSeconds = Math.floor(ms / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    return (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
  }

  function _formatGrowth(score, sessionMs) {
    if (!sessionMs || sessionMs <= 0) return '0.0';
    var perMin = score / (sessionMs / 60000);
    return perMin.toFixed(1);
  }

  /* ── Populate helpers ── */

  function _setCardValue(cardId, content) {
    var card = document.getElementById(cardId);
    if (!card) return null;
    var valEl = card.querySelector('.sp-dr-card-value');
    if (!valEl) return null;
    while (valEl.firstChild) valEl.removeChild(valEl.firstChild);
    return valEl;
  }

  function _populatePanel() {
    var d = _deathData;
    if (!d) return;

    /* Final Score */
    var scoreVal = _setCardValue('sp-dr-c-score');
    if (scoreVal) {
      scoreVal.textContent = _formatNumber(d.finalScore);
    }

    /* Peak Score */
    var peakVal = _setCardValue('sp-dr-c-peak');
    if (peakVal) {
      peakVal.textContent = _formatNumber(d.peakScore);
    }

    /* Kills — prepend mini skull */
    var killsVal = _setCardValue('sp-dr-c-kills');
    if (killsVal) {
      killsVal.appendChild(_createMiniSkull());
      var killText = document.createTextNode(_formatNumber(d.kills));
      killsVal.appendChild(killText);
    }

    /* Time Survived */
    var timeVal = _setCardValue('sp-dr-c-time');
    if (timeVal) {
      timeVal.textContent = _formatTime(d.sessionTime);
    }

    /* Growth rate */
    var growthEl = document.getElementById('sp-dr-growth');
    if (growthEl) {
      while (growthEl.firstChild) growthEl.removeChild(growthEl.firstChild);
      growthEl.appendChild(document.createTextNode('Growth: '));
      var growthSpan = document.createElement('span');
      growthSpan.textContent = _formatGrowth(d.finalScore, d.sessionTime) + '/min';
      growthEl.appendChild(growthSpan);
    }

    /* Cause line — uses the cause classifier output. Mode gives the
     * user a clearer story than a bare name: "Killed by X (head-on)"
     * vs "Ran into X's body" vs "Boosted into X". Wall-hits carry a
     * secondary tag when we were boosting ("Hit the wall boosting"). */
    var killerEl = document.getElementById('sp-dr-killer');
    if (killerEl) {
      while (killerEl.firstChild) killerEl.removeChild(killerEl.firstChild);
      if (d.killer) {
        var k = d.killer;
        var prefix, suffix = '';
        if (k.mode === 'body') prefix = 'Ran into ';
        else if (k.mode === 'boost') prefix = 'Boosted into ';
        else prefix = 'Killed by ';
        // Suffix details — only surface the mode tag when it's
        // genuinely informative (e.g., enemy was boosting toward us).
        if (k.mode === 'head' && k.enemyBoosting) suffix = ' (boosted at us)';
        else if (k.mode === 'body') suffix = "'s body";

        killerEl.appendChild(document.createTextNode(prefix));
        var nameSpan = document.createElement('span');
        nameSpan.textContent = k.name;
        killerEl.appendChild(nameSpan);
        if (suffix) killerEl.appendChild(document.createTextNode(suffix));

        // Low-confidence attributions get a "?" so the user knows we're
        // guessing — surface uncertainty rather than hide it.
        if (k.confidence === 'low') {
          var q = document.createElement('span');
          q.textContent = ' ?';
          q.style.color = 'rgba(255,255,255,.35)';
          q.title = 'Low-confidence attribution (score ' + k.rawScore + ')';
          killerEl.appendChild(q);
        }
      } else if (d.hitWall) {
        killerEl.textContent = d.wallBoosted ? 'Boosted into the wall' : 'Hit the wall';
      } else {
        killerEl.textContent = 'Unknown cause';
      }
    }
  }

  /* ── Cause classification ─────────────────────────────────
   *
   * Scans HISTORY_LEN frames, scores each nearby snake on how much
   * evidence points at them as the killer, and picks the winner.
   *
   * The death event happens AT the client/server collision moment.
   * Our last snapshot is up to 1 frame (~16ms) before that, during
   * which both snakes can have moved 8-16 units. Combined with
   * slither's snake-thickness (~25u), a "contact" collision can
   * show up as heads-25-to-60-units-apart in the snapshot — so the
   * sharp 80u cutoff rejected too many real kills.
   *
   * New approach: every nearby snake gets a score proportional to
   * how close they came, on a smooth curve that reaches beyond
   * nominal contact distance. Proximity-only scores (even no
   * approach, no boost) can still identify a clear winner when
   * someone is notably closer than anyone else. We also fall back
   * to "closest-body-contact" if nothing scores high, rather than
   * giving up — the wrong name with low confidence is more useful
   * than Unknown when the user can see snakes around them.
   *
   * We also snapshot the analysis onto the public debug API so a
   * repro can be inspected after the fact (SlitherPro.DeathRecap.
   * getLastAnalysis()).
   */

  // Softer scoring ranges — reached beyond nominal contact so a
  // snapshot taken one frame pre-collision still credits the killer.
  var HEAD_SCORE_RANGE = 180;
  var BODY_SCORE_RANGE = 100;
  var MIN_ATTRIBUTION_SCORE = 25;   // below = fall back to closest
  var _lastAnalysis = null;          // exposed via debug API

  function _classifyDeath(data) {
    if (!MathUtil || _history.length === 0) return;
    var latest = _history[_history.length - 1];
    if (!latest) return;

    // 1. WALL — last frame was inside the lethal edge band. Take a
    //    peek two frames back too so a single rogue snapshot doesn't
    //    mislabel a close-pass as a wall hit.
    var inWallBand = latest.edgeDist !== null && latest.edgeDist < WALL_EDGE_DIST;
    var prev = _history.length > 3 ? _history[_history.length - 3] : null;
    var prevInWallBand = prev && prev.edgeDist !== null && prev.edgeDist < WALL_EDGE_DIST * 1.5;
    if (inWallBand || prevInWallBand) {
      data.hitWall = true;
      data.wallBoosted = !!latest.boosting;
      _lastAnalysis = { reason: 'wall', edgeDist: latest.edgeDist, boosting: latest.boosting };
      return;
    }

    // Build a self-identity set: every (id, name) pairing the player
    // went through across the history. IDs can get reassigned on
    // reconnect/respawn so a single-ID filter isn't enough — we also
    // reject any snake whose nick matches any nick we ever had in the
    // window. Handles the "killed by yourself" false positive.
    var selfIds = {};
    var selfNames = {};
    for (var si = 0; si < _history.length; si++) {
      var sn = _history[si];
      if (sn.playerId !== undefined) selfIds[sn.playerId] = true;
      if (sn.playerName) selfNames[sn.playerName] = true;
    }

    // 2. Per-snake scoring scan across the full history.
    var candidates = {};
    for (var h = 0; h < _history.length; h++) {
      var snap = _history[h];
      var snakes = snap.nearby;
      if (!snakes) continue;
      for (var i = 0; i < snakes.length; i++) {
        var s = snakes[i];
        var id = s.id;
        if (id === undefined || id === null) continue;
        // Self-filter: skip any snake whose id or name matches ours
        // at any point in the captured window.
        if (selfIds[id]) continue;
        if (s.name && selfNames[s.name]) continue;
        var c = candidates[id];
        if (!c) {
          c = candidates[id] = {
            id: id, name: s.name || 'Unknown', score: s.score,
            minHead: Infinity, minBody: Infinity,
            firstDist: null, lastDist: null,
            frames: 0, boostedFrames: 0
          };
        }
        c.score = s.score;
        c.frames++;
        if (s.boosting) c.boostedFrames++;

        var hd = MathUtil.distance(snap.x, snap.y, s.x, s.y);
        if (hd < c.minHead) c.minHead = hd;
        if (c.firstDist === null) c.firstDist = hd;
        c.lastDist = hd;

        var parts = s.bodyParts;
        if (parts) {
          for (var j = 0; j < parts.length; j++) {
            var bd = MathUtil.distance(snap.x, snap.y, parts[j].x, parts[j].y);
            if (bd < c.minBody) c.minBody = bd;
          }
        }
      }
    }

    // 3. Score each candidate. Smooth curves so even "close but not
    //    touching" shows up — the frame-lag between last snapshot and
    //    actual collision makes a hard threshold unreliable.
    var scoredList = [];
    for (var id2 in candidates) {
      if (!candidates.hasOwnProperty(id2)) continue;
      var e = candidates[id2];
      var score = 0;

      // Head proximity: 150 at contact, decays to 0 by HEAD_SCORE_RANGE.
      if (e.minHead < HEAD_SCORE_RANGE) {
        score += 150 * (1 - e.minHead / HEAD_SCORE_RANGE);
      }
      // Body proximity: 120 at contact, decays to 0 by BODY_SCORE_RANGE.
      if (e.minBody < BODY_SCORE_RANGE) {
        score += 120 * (1 - e.minBody / BODY_SCORE_RANGE);
      }
      if (e.firstDist !== null && e.lastDist !== null && e.firstDist > e.lastDist) {
        var closed = (e.firstDist - e.lastDist) / (e.firstDist || 1);
        score += 30 * Math.min(1, closed);
      }
      if (e.boostedFrames > 0) score += 20;
      score += Math.min(10, e.frames);

      e.finalScore = Math.round(score);
      scoredList.push(e);
    }
    scoredList.sort(function (a, b) { return b.finalScore - a.finalScore; });

    // 4. Pick the winner. First try the strong signal; fall back to
    //    "closest plausible" if everything scored weakly but someone
    //    was genuinely in collision range. FALLBACK_RANGE is the
    //    ceiling past which we refuse to blame anyone — at >150u
    //    from the player in any snapshot, they physically could not
    //    have collided with us. Better to say "Unknown" honestly
    //    than to name someone who was on the other side of the map.
    var FALLBACK_RANGE = 150;
    var best = scoredList[0] || null;
    var fallback = false;
    if (!best || best.finalScore < MIN_ATTRIBUTION_SCORE) {
      var closest = null;
      var closestD = Infinity;
      for (var s2 = 0; s2 < scoredList.length; s2++) {
        var ee = scoredList[s2];
        var d = Math.min(ee.minHead, ee.minBody);
        if (d < closestD) { closestD = d; closest = ee; }
      }
      if (closest && closestD <= FALLBACK_RANGE) {
        best = closest;
        fallback = true;
      } else {
        best = null;   // nobody plausibly close enough — honestly Unknown
      }
    }

    _lastAnalysis = {
      reason: best ? (fallback ? 'fallback-closest' : 'score') : 'no-nearby',
      candidates: scoredList.slice(0, 5),    // top 5 for inspection
      picked: best ? { id: best.id, name: best.name, score: best.finalScore, minHead: Math.round(best.minHead), minBody: Math.round(best.minBody) } : null,
      historyFrames: _history.length
    };

    if (!best) return;

    // 5. Mode classification.
    var mode = 'head';
    if (latest.boosting) mode = 'boost';
    else if (best.minHead > BODY_SCORE_RANGE && best.minBody <= BODY_SCORE_RANGE) mode = 'body';

    // Confidence buckets — fallback picks are always "low".
    var confidence;
    if (fallback) confidence = 'low';
    else if (best.finalScore >= 100) confidence = 'high';
    else if (best.finalScore >= 60) confidence = 'med';
    else confidence = 'low';

    data.killer = {
      name: best.name,
      score: best.score,
      distance: Math.round(Math.min(best.minHead, best.minBody)),
      mode: mode,
      confidence: confidence,
      boosted: !!latest.boosting,
      enemyBoosting: best.boostedFrames > 0,
      rawScore: best.finalScore
    };
  }

  /* ── Public API ── */

  var DeathRecap = {
    init: function (s) {
      GameAPI = SP.GameAPI;
      MathUtil = SP.MathUtil;
      settings = s;
    },

    updateSettings: function (s) {
      settings = s;
    },

    /**
     * Called each frame from the main loop. Pushes a snapshot of
     * everything near the player to the history ring. The ring is
     * consulted on death — by then window.slither is null and we
     * can't query live state.
     *
     * Hot path: bounded work per frame (ring truncation + one
     * getNearbySnakes call which is already cached by GameAPI).
     */
    update: function () {
      if (!GameAPI || !GameAPI.isPlaying()) return;
      var pos = GameAPI.getPlayerPosition();
      var snake = GameAPI.getPlayerSnake();
      if (!pos || !snake) return;

      var mapR = GameAPI.getMapRadius ? GameAPI.getMapRadius() : 0;
      var edgeDist = null;
      if (mapR > 0) {
        var dx = pos.x - mapR, dy = pos.y - mapR;
        edgeDist = Math.round(mapR - Math.sqrt(dx * dx + dy * dy));
      }

      _history.push({
        t: performance.now(),
        x: pos.x, y: pos.y,
        angle: snake.angle || 0,
        speed: snake.speed || 0,
        boosting: !!snake.boosting,
        edgeDist: edgeDist,
        // Track player identity per frame — IDs can reassign across
        // reconnects or respawns, so we stamp both id AND name and
        // use whichever matches to filter self-hits from the enemy
        // list during attribution.
        playerId: snake.id,
        playerName: snake.name || '',
        // Snake-reference arrays from GameAPI are stable per-frame and
        // we only read from them — safe to keep a reference rather
        // than deep-copy every one of up to ~50 snakes each frame.
        nearby: GameAPI.getNearbySnakes() || []
      });
      if (_history.length > HISTORY_LEN) _history.shift();
    },

    show: function () {
      if (!settings || !settings.hud || !settings.hud.deathRecap) return;

      _createPanel();

      /* Capture final state data */
      var hud = SP.HudManager;
      var peakScore = hud ? hud.getPeakScore() : 0;

      /* Use cached _sp_lastScore for final score if available, else fallback */
      var finalScore = (typeof window._sp_lastScore === 'number') ? window._sp_lastScore : peakScore;

      var sessionTime = hud ? hud.getSessionTime() : 0;

      _deathData = {
        finalScore: finalScore,
        kills: hud ? hud.getKills() : 0,
        sessionTime: sessionTime,
        peakScore: peakScore,
        timestamp: Date.now()
      };

      /* Identify the cause of death using the pre-death snapshot.
       * By the time show() fires, window.slither is already null —
       * we can only consult what we cached on the frame before death. */
      _classifyDeath(_deathData);

      _populatePanel();

      _visible = true;

      /* Trigger entrance animation after DOM settles */
      setTimeout(function () {
        if (_panelEl) _panelEl.classList.add('sp-dr-show');
      }, 30);

      /* Auto-dismiss */
      if (_dismissTimer) clearTimeout(_dismissTimer);
      _dismissTimer = setTimeout(function () {
        DeathRecap.hide();
      }, DISMISS_MS);

      /* Send death event to content script for storage */
      if (SP && SP.MessageBus && SP.EVENTS && SP.EVENTS.DEATH_EVENT) {
        SP.MessageBus.send(SP.EVENTS.DEATH_EVENT, _deathData);
      }
    },

    hide: function () {
      _visible = false;
      _deathData = null;
      // Flush history so a fast respawn doesn't inherit the prior
      // life's pre-death context. The ring would age out naturally
      // after HISTORY_LEN frames anyway, but clearing here prevents
      // any death-within-1s of respawn from being mis-attributed.
      _history.length = 0;
      if (_dismissTimer) { clearTimeout(_dismissTimer); _dismissTimer = null; }
      if (_panelEl) {
        _panelEl.classList.remove('sp-dr-show');
        _panelEl.classList.add('sp-dr-hiding');
        /* Remove from DOM after transition so progress bar resets on next show */
        setTimeout(function () {
          if (_panelEl && _panelEl.parentNode) {
            _panelEl.parentNode.removeChild(_panelEl);
          }
          _panelEl = null;
        }, 350);
      }
    },

    /**
     * Overlay render — no-op (DOM-based panel).
     */
    render: function (ctx, canvas, s) {
      /* Death recap is DOM-based; no canvas rendering needed */
    },

    /**
     * Last kill-attribution analysis for debugging why a specific
     * death was labeled Unknown (or why the wrong snake was named).
     * Usage in console: SlitherPro.DeathRecap.getLastAnalysis()
     */
    getLastAnalysis: function () {
      return _lastAnalysis;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.DeathRecap = DeathRecap;
})();
