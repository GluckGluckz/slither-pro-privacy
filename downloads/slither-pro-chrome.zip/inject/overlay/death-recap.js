/**
 * Slither Pro — Death Recap Panel (v3 — Premium DOM).
 * Shows a glass-morphism death summary panel in the bottom-right corner
 * when the player dies, with stat cards, growth rate, killer info,
 * animated progress bar, and auto-dismiss.
 *
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var GameAPI, MathUtil;
  var settings = null;

  var _visible = false;
  var _deathData = null;
  var _panelEl = null;
  var _dismissTimer = null;
  var _cssInjected = false;

  var DISMISS_MS = 10000;
  var DISMISS_SEC = DISMISS_MS / 1000;
  var KILLER_RANGE = 150;

  /* ── Skull SVG path (24×24 viewBox) ── */
  var SKULL_PATH = 'M12 2C6.48 2 2 6.48 2 12c0 2.69 1.07 5.13 2.81 6.93L4 22h3l.5-2h1L9 22h6l.5-2h1l.5 2h3l-.81-3.07C20.93 17.13 22 14.69 22 12c0-5.52-4.48-10-10-10zm-3 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm6 0c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm-3 1.5c-.55 0-1-.22-1-.5s.45-.5 1-.5 1 .22 1 .5-.45.5-1 .5z';

  /* ── Mini skull for kills stat (12×12) ── */
  var MINI_SKULL_PATH = 'M6 1C3.24 1 1 3.24 1 6c0 1.34.54 2.56 1.41 3.46L2 11h1.5l.25-1h.5L4.5 11h3l.25-1h.5l.25 1H10l-.41-1.54C10.46 8.56 11 7.34 11 6c0-2.76-2.24-5-5-5zM4.5 8c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm3 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z';

  function _injectCSS() {
    if (_cssInjected) return;
    _cssInjected = true;
    var s = document.createElement('style');
    s.id = 'sp-death-recap-css';
    s.textContent = [
      /* keyframes */
      '@keyframes sp-dr-shrink{from{width:100%}to{width:0%}}',
      '@keyframes sp-dr-fadein{from{opacity:0;transform:scale(.95);filter:blur(6px)}to{opacity:1;transform:scale(1);filter:blur(0)}}',

      /* panel */
      '#sp-dr{position:fixed;bottom:20px;right:20px;z-index:1000010;width:340px;',
      'background:rgba(10,10,30,.94);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);',
      'border:1px solid rgba(57,255,20,.12);border-left:3px solid rgba(255,71,87,.5);',
      'border-radius:12px;padding:16px 18px 0;font-family:"Segoe UI",-apple-system,sans-serif;',
      'color:#fff;pointer-events:auto;opacity:0;transform:scale(.95);filter:blur(6px);',
      'box-shadow:0 4px 24px rgba(0,0,0,.55),0 0 40px rgba(255,71,87,.06)}',

      '#sp-dr.sp-dr-show{animation:sp-dr-fadein .45s cubic-bezier(.22,1,.36,1) forwards}',

      '#sp-dr.sp-dr-hiding{opacity:0;transform:scale(.95);filter:blur(6px);',
      'transition:opacity .3s ease,transform .3s ease,filter .3s ease}',

      /* header */
      '#sp-dr .sp-dr-header{display:flex;align-items:center;gap:8px;margin:0 0 12px}',
      '#sp-dr .sp-dr-skull{flex-shrink:0}',
      '#sp-dr .sp-dr-title{color:#ff4757;font-size:20px;font-weight:700;letter-spacing:1.5px;',
      'text-shadow:0 0 8px rgba(255,71,87,.45),0 0 20px rgba(255,71,87,.15);margin:0}',

      /* close button */
      '#sp-dr .sp-dr-close{position:absolute;top:8px;right:10px;color:rgba(255,255,255,.35);',
      'cursor:pointer;font-size:20px;line-height:1;padding:4px 6px;border:none;background:none;',
      'transition:color .2s}',
      '#sp-dr .sp-dr-close:hover{color:#ff4757}',

      /* grid */
      '#sp-dr .sp-dr-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}',
      '#sp-dr .sp-dr-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);',
      'border-radius:8px;padding:10px 12px;text-align:center}',
      '#sp-dr .sp-dr-card-label{display:block;font-size:10px;text-transform:uppercase;',
      'letter-spacing:.8px;color:rgba(255,255,255,.4);margin-bottom:4px}',
      '#sp-dr .sp-dr-card-value{display:flex;align-items:center;justify-content:center;gap:4px;',
      'font-weight:700;font-size:20px;line-height:1.2}',

      /* card color accents */
      '#sp-dr .sp-dr-card--score .sp-dr-card-value{color:#ffa502;font-size:22px}',
      '#sp-dr .sp-dr-card--peak .sp-dr-card-value{color:#ffd700}',
      '#sp-dr .sp-dr-card--kills .sp-dr-card-value{color:#ff6b6b}',
      '#sp-dr .sp-dr-card--time .sp-dr-card-value{color:#74b9ff}',

      /* growth rate */
      '#sp-dr .sp-dr-growth{text-align:center;font-size:12px;color:rgba(255,255,255,.45);margin-bottom:8px}',
      '#sp-dr .sp-dr-growth span{color:#39ff14;font-weight:600}',

      /* divider */
      '#sp-dr .sp-dr-divider{border:none;border-top:1px solid rgba(255,255,255,.07);margin:0 0 8px}',

      /* killer */
      '#sp-dr .sp-dr-killer{font-size:13px;color:rgba(255,255,255,.45);text-align:center;margin-bottom:14px}',
      '#sp-dr .sp-dr-killer span{color:#ff4757;font-weight:600}',

      /* progress bar */
      '#sp-dr .sp-dr-progress-bar{position:absolute;bottom:0;left:0;height:3px;',
      'background:#39ff14;border-radius:0 0 0 12px;',
      'animation:sp-dr-shrink ' + DISMISS_SEC + 's linear forwards}'
    ].join('\n');
    document.head.appendChild(s);
  }

  /* ── DOM helpers ── */

  function _svgEl(tag, attrs) {
    var el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (var k in attrs) {
      if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]);
    }
    return el;
  }

  function _createSkullIcon() {
    var svg = _svgEl('svg', {
      width: '24', height: '24', viewBox: '0 0 24 24',
      fill: '#ff4757', 'class': 'sp-dr-skull'
    });
    var p = _svgEl('path', { d: SKULL_PATH });
    svg.appendChild(p);
    return svg;
  }

  function _createMiniSkull() {
    var svg = _svgEl('svg', {
      width: '12', height: '12', viewBox: '0 0 12 12',
      fill: '#ff6b6b', style: 'flex-shrink:0'
    });
    var p = _svgEl('path', { d: MINI_SKULL_PATH });
    svg.appendChild(p);
    return svg;
  }

  function _createCard(labelText, extraClass) {
    var card = document.createElement('div');
    card.className = 'sp-dr-card ' + extraClass;

    var label = document.createElement('span');
    label.className = 'sp-dr-card-label';
    label.textContent = labelText;

    var value = document.createElement('div');
    value.className = 'sp-dr-card-value';

    card.appendChild(label);
    card.appendChild(value);
    return card;
  }

  function _createPanel() {
    if (_panelEl) {
      /* Remove old panel entirely so progress bar restarts */
      if (_panelEl.parentNode) _panelEl.parentNode.removeChild(_panelEl);
      _panelEl = null;
    }
    _injectCSS();

    var panel = document.createElement('div');
    panel.id = 'sp-dr';

    /* header */
    var header = document.createElement('div');
    header.className = 'sp-dr-header';
    header.appendChild(_createSkullIcon());
    var title = document.createElement('div');
    title.className = 'sp-dr-title';
    title.textContent = 'GAME OVER';
    header.appendChild(title);
    panel.appendChild(header);

    /* close button */
    var closeBtn = document.createElement('button');
    closeBtn.className = 'sp-dr-close';
    closeBtn.textContent = '\u00D7';
    closeBtn.addEventListener('click', function () {
      DeathRecap.hide();
    });
    panel.appendChild(closeBtn);

    /* stat grid */
    var grid = document.createElement('div');
    grid.className = 'sp-dr-grid';

    var scoreCard = _createCard('Final Score', 'sp-dr-card--score');
    scoreCard.id = 'sp-dr-c-score';
    grid.appendChild(scoreCard);

    var peakCard = _createCard('Peak Score', 'sp-dr-card--peak');
    peakCard.id = 'sp-dr-c-peak';
    grid.appendChild(peakCard);

    var killsCard = _createCard('Kills', 'sp-dr-card--kills');
    killsCard.id = 'sp-dr-c-kills';
    grid.appendChild(killsCard);

    var timeCard = _createCard('Time Survived', 'sp-dr-card--time');
    timeCard.id = 'sp-dr-c-time';
    grid.appendChild(timeCard);

    panel.appendChild(grid);

    /* growth rate */
    var growth = document.createElement('div');
    growth.className = 'sp-dr-growth';
    growth.id = 'sp-dr-growth';
    panel.appendChild(growth);

    /* divider */
    var hr = document.createElement('hr');
    hr.className = 'sp-dr-divider';
    panel.appendChild(hr);

    /* killer info */
    var killer = document.createElement('div');
    killer.className = 'sp-dr-killer';
    killer.id = 'sp-dr-killer';
    panel.appendChild(killer);

    /* progress bar */
    var bar = document.createElement('div');
    bar.className = 'sp-dr-progress-bar';
    panel.appendChild(bar);

    document.body.appendChild(panel);
    _panelEl = panel;
  }

  /* ── Formatters ── */

  function _formatNumber(n) {
    if (n === undefined || n === null || isNaN(n)) return '0';
    return Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  function _formatTime(ms) {
    var totalSeconds = Math.floor(ms / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    return (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
  }

  function _formatGrowth(score, sessionMs) {
    if (!sessionMs || sessionMs <= 0) return '0.0';
    var perMin = score / (sessionMs / 60000);
    return perMin.toFixed(1);
  }

  /* ── Populate helpers ── */

  function _setCardValue(cardId, content) {
    var card = document.getElementById(cardId);
    if (!card) return null;
    var valEl = card.querySelector('.sp-dr-card-value');
    if (!valEl) return null;
    while (valEl.firstChild) valEl.removeChild(valEl.firstChild);
    return valEl;
  }

  function _populatePanel() {
    var d = _deathData;
    if (!d) return;

    /* Final Score */
    var scoreVal = _setCardValue('sp-dr-c-score');
    if (scoreVal) {
      scoreVal.textContent = _formatNumber(d.finalScore);
    }

    /* Peak Score */
    var peakVal = _setCardValue('sp-dr-c-peak');
    if (peakVal) {
      peakVal.textContent = _formatNumber(d.peakScore);
    }

    /* Kills — prepend mini skull */
    var killsVal = _setCardValue('sp-dr-c-kills');
    if (killsVal) {
      killsVal.appendChild(_createMiniSkull());
      var killText = document.createTextNode(_formatNumber(d.kills));
      killsVal.appendChild(killText);
    }

    /* Time Survived */
    var timeVal = _setCardValue('sp-dr-c-time');
    if (timeVal) {
      timeVal.textContent = _formatTime(d.sessionTime);
    }

    /* Growth rate */
    var growthEl = document.getElementById('sp-dr-growth');
    if (growthEl) {
      while (growthEl.firstChild) growthEl.removeChild(growthEl.firstChild);
      growthEl.appendChild(document.createTextNode('Growth: '));
      var growthSpan = document.createElement('span');
      growthSpan.textContent = _formatGrowth(d.finalScore, d.sessionTime) + '/min';
      growthEl.appendChild(growthSpan);
    }

    /* Killer info */
    var killerEl = document.getElementById('sp-dr-killer');
    if (killerEl) {
      while (killerEl.firstChild) killerEl.removeChild(killerEl.firstChild);
      if (d.killer) {
        killerEl.appendChild(document.createTextNode('Killed by '));
        var nameSpan = document.createElement('span');
        nameSpan.textContent = d.killer.name;
        killerEl.appendChild(nameSpan);
      } else if (d.hitWall) {
        killerEl.textContent = 'Hit the wall';
      } else {
        killerEl.textContent = 'Unknown cause';
      }
    }
  }

  /* ── Public API ── */

  var DeathRecap = {
    init: function (s) {
      GameAPI = SP.GameAPI;
      MathUtil = SP.MathUtil;
      settings = s;
    },

    updateSettings: function (s) {
      settings = s;
    },

    show: function () {
      if (!settings || !settings.hud || !settings.hud.deathRecap) return;

      _createPanel();

      /* Capture final state data */
      var hud = SP.HudManager;
      var peakScore = hud ? hud.getPeakScore() : 0;

      /* Use cached _sp_lastScore for final score if available, else fallback */
      var finalScore = (typeof window._sp_lastScore === 'number') ? window._sp_lastScore : peakScore;

      var sessionTime = hud ? hud.getSessionTime() : 0;

      _deathData = {
        finalScore: finalScore,
        kills: hud ? hud.getKills() : 0,
        sessionTime: sessionTime,
        peakScore: peakScore,
        timestamp: Date.now()
      };

      /* Identify the killer — closest snake head within KILLER_RANGE units */
      if (GameAPI && MathUtil) {
        var nearby = GameAPI.getNearbySnakes();
        var playerPos = GameAPI.getPlayerPosition();
        if (nearby && nearby.length > 0 && playerPos) {
          var closest = null;
          var closestDist = Infinity;
          for (var i = 0; i < nearby.length; i++) {
            var d = MathUtil.distance(playerPos.x, playerPos.y, nearby[i].x, nearby[i].y);
            if (d < closestDist) {
              closestDist = d;
              closest = nearby[i];
            }
          }
          if (closest && closestDist <= KILLER_RANGE) {
            _deathData.killer = {
              name: closest.name || 'Unknown',
              score: closest.score,
              distance: Math.round(closestDist)
            };
          }
          /* No killer within range — could be wall or unknown */
        }
      }

      _populatePanel();

      _visible = true;

      /* Trigger entrance animation after DOM settles */
      setTimeout(function () {
        if (_panelEl) _panelEl.classList.add('sp-dr-show');
      }, 30);

      /* Auto-dismiss */
      if (_dismissTimer) clearTimeout(_dismissTimer);
      _dismissTimer = setTimeout(function () {
        DeathRecap.hide();
      }, DISMISS_MS);

      /* Send death event to content script for storage */
      if (SP && SP.MessageBus && SP.EVENTS && SP.EVENTS.DEATH_EVENT) {
        SP.MessageBus.send(SP.EVENTS.DEATH_EVENT, _deathData);
      }
    },

    hide: function () {
      _visible = false;
      _deathData = null;
      if (_dismissTimer) { clearTimeout(_dismissTimer); _dismissTimer = null; }
      if (_panelEl) {
        _panelEl.classList.remove('sp-dr-show');
        _panelEl.classList.add('sp-dr-hiding');
        /* Remove from DOM after transition so progress bar resets on next show */
        setTimeout(function () {
          if (_panelEl && _panelEl.parentNode) {
            _panelEl.parentNode.removeChild(_panelEl);
          }
          _panelEl = null;
        }, 350);
      }
    },

    /**
     * Overlay render — no-op (DOM-based panel).
     */
    render: function (ctx, canvas, s) {
      /* Death recap is DOM-based; no canvas rendering needed */
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.DeathRecap = DeathRecap;
})();
