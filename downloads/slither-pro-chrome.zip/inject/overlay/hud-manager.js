/**
 * Slither Pro — HUD Widget Manager.
 * Creates draggable HTML widgets overlaying the game.
 * Widgets: Stats, FPS, Minimap, Bot Status, Keybinds Legend.
 * Each can be dragged to any screen position; positions persist in localStorage.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var STORAGE_KEY = 'sp_hud_positions';
  var POSITIONS_VERSION = 5; // Bump to discard stale layouts (v5: logo + locked stats)
  var Z_INDEX = 1000000;

  var _initialized = false;
  var _settings = null;
  var _widgets = {};
  var _savedPositions = {};
  var _dragState = null;
  var _keybindsVisible = true;
  var _userDraggedWidgets = {};

  // ── Data Tracking ─────────────────────────────────────
  var _sessionStart = 0;
  var _kills = 0;
  var _peakScore = 0;
  var _lastNearbyIds = {};
  var _frameCount = 0;
  var _lastFpsTime = 0;
  var _currentFps = 0;
  var _fpsHistory = [];
  var FPS_HISTORY_LEN = 60;
  var _minimapFrame = 0;
  var _cachedFoodDots = [];
  var _playerTrail = [];

  // ── Update throttles (frames between recomputes) ──────────
  // HUD widgets don't need 60Hz. Throttling saves ~0.6ms per frame without
  // any visible degradation — numbers still update 20–30×/sec which is well
  // past what the human eye resolves.
  var UPDATE_EVERY_FRAME = 0;      // every frame
  var UPDATE_EVERY_2_FRAMES = 1;   // 30Hz — stats, FPS, bot status
  var UPDATE_EVERY_3_FRAMES = 2;   // 20Hz — minimap, kill-feed
  var UPDATE_EVERY_4_FRAMES = 3;   // 15Hz — boost meter, threat radar
  var _hudTick = 0;

  var HudManager = {
    init: function (s) {
      if (_initialized) return;
      _initialized = true;
      _settings = s;
      this.resetSession();
      this._injectCSS();
      this._createWidgets();
      this._initPositions();
      this._loadPositions();
      this._setupDrag();
    },

    updateSettings: function (s) {
      var prevMmPos = _settings && _settings.hud && _settings.hud.minimapPosition;
      _settings = s;
      // Resize minimap if changed
      if (_widgets.minimap) {
        var newSize = (s && s.hud && s.hud.minimapSize) || 200;
        if (_widgets.minimap.size !== newSize) {
          _widgets.minimap.size = newSize;
          _widgets.minimap.canvas.width = newSize;
          _widgets.minimap.canvas.height = newSize;
          _widgets.minimap.canvas.style.width = newSize + 'px';
          _widgets.minimap.canvas.style.height = newSize + 'px';
        }
      }
      // Reposition if the user changed minimap corner. Clear the
      // user-dragged flag for the minimap so the new default sticks.
      var newMmPos = s && s.hud && s.hud.minimapPosition;
      if (newMmPos && newMmPos !== prevMmPos) {
        delete _userDraggedWidgets['minimap'];
        delete _savedPositions['minimap'];
        this._savePositions();
        this._initPositions();
      }
    },

    resetSession: function () {
      _sessionStart = Date.now();
      _kills = 0;
      _peakScore = 0;
      _lastNearbyIds = {};
      _frameCount = 0;
      _lastFpsTime = performance.now();
      _currentFps = 0;
      _fpsHistory = [];
    },

    getKills: function () { return _kills; },
    getPeakScore: function () { return _peakScore; },
    getSessionTime: function () { return Date.now() - _sessionStart; },

    toggleKeybinds: function () {
      _keybindsVisible = !_keybindsVisible;
    },

    /**
     * Called every frame from the main loop.
     * Cheap per-frame work (FPS sampling, kill tracking) runs every tick.
     * Expensive DOM/canvas redraws are throttled by frame count:
     *   - Stats / FPS / bot status: 30Hz (every 2 frames)
     *   - Minimap / kill feed:      20Hz (every 3 frames)
     *   - Boost meter / threat:     15Hz (every 4 frames)
     * Human perception threshold for HUD numerics is ~20Hz; throttling
     * saves ~0.6ms per frame with no visible degradation.
     */
    update: function () {
      if (!_settings) return;
      var GameAPI = SP.GameAPI;
      if (!GameAPI) return;

      var playing = GameAPI.isPlaying();
      var hud = _settings.hud;
      var hudEnabled = hud && hud.enabled;

      if (!playing || !hudEnabled) {
        this._hideAll();
        return;
      }

      // Cheap: runs every frame
      this._updateFps();
      this._trackKills();

      _hudTick = (_hudTick + 1) | 0;
      var m2 = _hudTick % 2;
      var m3 = _hudTick % 3;
      var m4 = _hudTick % 4;

      if (m2 === 0) {
        this._updateStatsContent();
        this._updateFpsContent();
        this._updateBotContent();
      }
      if (m3 === 0) {
        this._updateMinimapContent();
        this._updateKillFeedContent();
      }
      if (m4 === 0) {
        this._updateBoostMeterContent();
        this._updateThreatRadarContent();
      }
      // Visibility tracks pause state — keep per-frame so toggles respond fast
      this._updateVisibility();
    },

    // ══════════════════════════════════════════════════════════
    //  CSS Injection
    // ══════════════════════════════════════════════════════════

    _injectCSS: function () {
      if (document.getElementById('sp-hud-css')) return;
      var s = document.createElement('style');
      s.id = 'sp-hud-css';
      s.textContent = [
        // contain + will-change promote each widget to its own GPU composition
        // layer so the browser doesn't re-rasterize the whole HUD stack every
        // frame when the game canvas underneath repaints. Before this, showing
        // HUD widgets added +24% jank at 60Hz; after, widgets are composited
        // cheaply on the GPU and only re-raster when their OWN content changes.
        '.sp-widget{position:fixed;z-index:' + Z_INDEX + ';pointer-events:auto;cursor:grab;user-select:none;font-family:"Segoe UI",-apple-system,sans-serif;display:none;transition:box-shadow .15s;contain:layout style paint;will-change:transform;transform:translateZ(0);backface-visibility:hidden}',
        '.sp-widget.sp-vis{display:block}',
        '.sp-widget:hover{box-shadow:0 0 14px rgba(57,255,20,.15)}',
        '.sp-widget.sp-drag{cursor:grabbing;opacity:.88;box-shadow:0 0 22px rgba(57,255,20,.3)}',
        '.sp-widget::after{content:"\\2807";position:absolute;top:3px;right:5px;font-size:11px;color:rgba(255,255,255,.12);pointer-events:none}',
        '.sp-widget:hover::after{color:rgba(57,255,20,.35)}',
        // Stats
        '#sp-w-stats{background:rgba(8,8,24,.78);border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:10px 14px 8px;min-width:195px;border-left:3px solid rgba(57,255,20,.5);cursor:default}',
        '#sp-w-stats::after{display:none}',
        '#sp-w-stats:hover{box-shadow:none}',
        '.sp-sr{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:1px}',
        '.sp-sl{font-size:11px;color:rgba(255,255,255,.42);text-transform:uppercase;letter-spacing:.5px}',
        '.sp-sv{font:bold 16px "Consolas","SF Mono",monospace}',
        '.sp-ss{display:flex;justify-content:space-between;margin-bottom:5px}',
        '.sp-ss span{font:10px "Consolas","SF Mono",monospace;color:rgba(255,255,255,.28)}',
        '.sp-ss .sp-pk{color:rgba(255,215,0,.35)}',
        '.sp-sep{height:1px;background:rgba(255,255,255,.05);margin:5px 0}',
        '.sp-cs{color:#39ff14}.sp-ck{color:#ff6b6b}.sp-ct{color:#74b9ff}',
        // FPS
        '#sp-w-fps{background:rgba(8,8,24,.78);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:5px 10px 3px;text-align:center;min-width:50px}',
        '.sp-fv{font:bold 14px "Consolas","SF Mono",monospace}',
        '.sp-fl{font-size:9px;color:rgba(255,255,255,.32);margin-top:-1px}',
        '.sp-fk{display:block;margin-top:2px}',
        '.sp-pr{display:none;margin-top:3px;padding-top:3px;border-top:1px solid rgba(255,255,255,.06);font:bold 11px "Consolas","SF Mono",monospace;color:#aee1ff;text-align:center}',
        '.sp-pr.sp-show{display:block}',
        '.sp-pv{margin-right:2px}',
        '.sp-pl{font-size:8px;color:rgba(255,255,255,.35)}',
        // Bot
        '#sp-w-bot{background:rgba(8,8,24,.78);border:1px solid rgba(255,255,255,.06);border-radius:6px;padding:4px 12px;display:none;align-items:center;gap:8px;cursor:default;white-space:nowrap}',
        '#sp-w-bot.sp-vis{display:flex}',
        '#sp-w-bot::after{display:none}',
        '#sp-w-bot:hover{box-shadow:none}',
        '.sp-bd{width:7px;height:7px;border-radius:50%;animation:sp-p 1.5s infinite}',
        '@keyframes sp-p{0%,100%{opacity:.4}50%{opacity:1}}',
        '.sp-bt{font:600 11px "Segoe UI",sans-serif}',
        '.sp-bm{font:600 9px "Segoe UI",sans-serif;padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:.5px;margin-left:6px;opacity:.75}',
        '.sp-bm.aggressive{color:#ff6b6b;background:rgba(255,107,107,.1);border:1px solid rgba(255,107,107,.2)}',
        '.sp-bm.balanced{color:#ffa502;background:rgba(255,165,2,.1);border:1px solid rgba(255,165,2,.2)}',
        '.sp-bm.defensive{color:#39ff14;background:rgba(57,255,20,.1);border:1px solid rgba(57,255,20,.2)}',
        // Minimap
        '#sp-w-minimap{background:transparent;border:none}',
        '#sp-w-minimap::after{display:none}',
        '.sp-mc{display:block}',
        '.sp-mco{text-align:center;font:10px "Consolas","SF Mono",monospace;color:rgba(255,255,255,.35);margin-top:4px}',
        // Keybinds
        '#sp-w-keys{background:rgba(8,8,24,.68);border:1px solid rgba(255,255,255,.05);border-radius:6px;padding:5px 14px;white-space:nowrap}',
        '#sp-w-keys::after{display:none}',
        '.sp-kb{display:flex;gap:14px;align-items:center;flex-wrap:wrap}',
        '.sp-ki{display:flex;align-items:center;gap:4px;font-size:10px;color:rgba(255,255,255,.35)}',
        '.sp-kk{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:3px;padding:1px 5px;font:bold 10px "Consolas","SF Mono",monospace;color:rgba(57,255,20,.6)}',
        // v7: Kill Feed
        '#sp-w-killfeed{background:rgba(8,8,24,.72);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:6px 10px;pointer-events:none;cursor:default}',
        '#sp-w-killfeed::after{display:none}',
        // Hide the kill-feed pill entirely when there are no kill entries.
        // Without this, the widget renders as a small empty dark pill on the
        // canvas (visible against the bright game background).
        '#sp-w-killfeed:empty{display:none!important;background:transparent!important;border:none!important;padding:0!important}',
        '.sp-kf-entry{font-size:11px;color:rgba(255,255,255,.55);padding:2px 0;transition:opacity .5s}',
        '.sp-kf-entry .sp-kf-name{color:#39ff14;font-weight:600}',
        '.sp-kf-entry .sp-kf-score{color:#ffa502;font-size:10px}',
        '.sp-kf-fade{opacity:0}',
        // v7: Boost Meter
        '#sp-w-boost{background:rgba(8,8,24,.72);border:1px solid rgba(255,255,255,.06);border-radius:6px;padding:4px 10px;min-width:120px}',
        '#sp-w-boost::after{display:none}',
        '.sp-bm-label{font-size:9px;color:rgba(255,255,255,.32);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px}',
        '.sp-bm-bar{height:6px;border-radius:3px;background:rgba(255,255,255,.08);overflow:hidden}',
        '.sp-bm-fill{height:100%;border-radius:3px;transition:width .15s;background:linear-gradient(90deg,#39ff14,#00cc44)}',
        '.sp-bm-fill.sp-bm-boost{background:linear-gradient(90deg,#ff6b6b,#ff4757)}',
        // v7: Threat Radar
        '#sp-w-radar{background:transparent;border:none}',
        '#sp-w-radar::after{display:none}',
        '.sp-radar-canvas{display:block}',
        // Logo watermark
        '#sp-w-logo{background:transparent;border:none;cursor:default;display:none;align-items:center;gap:8px;pointer-events:none}',
        '#sp-w-logo.sp-vis{display:flex}',
        '#sp-w-logo::after{display:none}',
        '#sp-w-logo:hover{box-shadow:none}',
        '.sp-logo-svg{flex-shrink:0;animation:sp-hud-logo-glow 4s ease-in-out infinite}',
        '@keyframes sp-hud-logo-glow{0%{filter:drop-shadow(0 0 2px rgba(57,255,20,.15))}40%{filter:drop-shadow(0 0 8px rgba(57,255,20,.6)) drop-shadow(0 0 16px rgba(57,255,20,.25))}70%{filter:drop-shadow(0 0 3px rgba(57,255,20,.2))}100%{filter:drop-shadow(0 0 2px rgba(57,255,20,.15))}}',
        '.sp-logo-text{font-size:18px;font-weight:800;letter-spacing:.8px;background:linear-gradient(90deg,#fff 0%,#fff 20%,#39ff14 38%,#20ff60 50%,#39ff14 62%,#fff 80%,#fff 100%);background-size:300% 100%;background-clip:text;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:sp-hud-text-flow 4s ease-in-out infinite}',
        '@keyframes sp-hud-text-flow{0%{background-position:100% 0}100%{background-position:0% 0}}'
      ].join('\n');
      document.head.appendChild(s);
    },

    // ══════════════════════════════════════════════════════════
    //  Widget Creation
    // ══════════════════════════════════════════════════════════

    _createWidgets: function () {
      this._createLogo();
      this._createStats();
      this._createFps();
      this._createMinimap();
      this._createBot();
      this._createKeybinds();
      this._createKillFeed();
      this._createBoostMeter();
      this._createThreatRadar();
    },

    /** DOM helper: create element with optional class, text, and attributes. */
    _h: function (tag, cls, text, attrs) {
      var el = document.createElement(tag);
      if (cls) el.className = cls;
      if (text) el.textContent = text;
      if (attrs) { for (var k in attrs) { if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]); } }
      return el;
    },

    _createLogo: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-logo' });

      // SVG snake icon (same as popup)
      var svgNS = 'http://www.w3.org/2000/svg';
      var svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('width', '28');
      svg.setAttribute('height', '28');
      svg.setAttribute('viewBox', '0 0 32 32');
      svg.setAttribute('class', 'sp-logo-svg');

      var defs = document.createElementNS(svgNS, 'defs');
      var grad = document.createElementNS(svgNS, 'linearGradient');
      grad.setAttribute('id', 'sp-hud-snake-grad');
      grad.setAttribute('x1', '0%');
      grad.setAttribute('y1', '0%');
      grad.setAttribute('x2', '100%');
      grad.setAttribute('y2', '100%');
      var stop1 = document.createElementNS(svgNS, 'stop');
      stop1.setAttribute('offset', '0%');
      stop1.setAttribute('style', 'stop-color:#39ff14;stop-opacity:1');
      var stop2 = document.createElementNS(svgNS, 'stop');
      stop2.setAttribute('offset', '100%');
      stop2.setAttribute('style', 'stop-color:#20cc0a;stop-opacity:1');
      grad.appendChild(stop1);
      grad.appendChild(stop2);
      defs.appendChild(grad);
      svg.appendChild(defs);

      var circle = document.createElementNS(svgNS, 'circle');
      circle.setAttribute('cx', '16');
      circle.setAttribute('cy', '16');
      circle.setAttribute('r', '14');
      circle.setAttribute('fill', 'none');
      circle.setAttribute('stroke', 'url(#sp-hud-snake-grad)');
      circle.setAttribute('stroke-width', '2');
      circle.setAttribute('opacity', '0.5');
      svg.appendChild(circle);

      var path = document.createElementNS(svgNS, 'path');
      path.setAttribute('d', 'M7 17 Q10 8 16 12 Q22 16 25 10');
      path.setAttribute('fill', 'none');
      path.setAttribute('stroke', 'url(#sp-hud-snake-grad)');
      path.setAttribute('stroke-width', '2.5');
      path.setAttribute('stroke-linecap', 'round');
      svg.appendChild(path);

      var eye = document.createElementNS(svgNS, 'circle');
      eye.setAttribute('cx', '24');
      eye.setAttribute('cy', '10');
      eye.setAttribute('r', '2.5');
      eye.setAttribute('fill', '#39ff14');
      svg.appendChild(eye);

      var pupil = document.createElementNS(svgNS, 'circle');
      pupil.setAttribute('cx', '24.2');
      pupil.setAttribute('cy', '9.6');
      pupil.setAttribute('r', '1');
      pupil.setAttribute('fill', '#0a0a1e');
      svg.appendChild(pupil);

      el.appendChild(svg);

      var textEl = h('span', 'sp-logo-text', 'Slither Pro');
      el.appendChild(textEl);

      SP.HudRoot.append(el);
      _widgets.logo = { el: el };
    },

    _createStats: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-stats' });

      // SCORE row
      var scoreRow = h('div', 'sp-sr');
      scoreRow.appendChild(h('span', 'sp-sl', 'SCORE'));
      var scoreVal = h('span', 'sp-sv sp-cs', '0', { 'data-f': 'score' });
      scoreRow.appendChild(scoreVal);
      el.appendChild(scoreRow);

      // LEN / PEAK row
      var subRow = h('div', 'sp-ss');
      var lenEl = h('span', null, 'LEN 0', { 'data-f': 'len' });
      var peakEl = h('span', 'sp-pk', 'PEAK 0', { 'data-f': 'peak' });
      subRow.appendChild(lenEl);
      subRow.appendChild(peakEl);
      el.appendChild(subRow);

      el.appendChild(h('div', 'sp-sep'));

      // KILLS row
      var killRow = h('div', 'sp-sr', null, { 'data-sec': 'k' });
      killRow.appendChild(h('span', 'sp-sl', 'KILLS'));
      var killsVal = h('span', 'sp-sv sp-ck', '0', { 'data-f': 'kills' });
      killRow.appendChild(killsVal);
      el.appendChild(killRow);

      el.appendChild(h('div', 'sp-sep', null, { 'data-sec': 'ks' }));

      // TIME row
      var timeRow = h('div', 'sp-sr', null, { 'data-sec': 't' });
      timeRow.appendChild(h('span', 'sp-sl', 'TIME'));
      var timeVal = h('span', 'sp-sv sp-ct', '00:00', { 'data-f': 'time' });
      timeRow.appendChild(timeVal);
      el.appendChild(timeRow);

      // COORDS row (gated by hud.coordinates)
      var coordsSep = h('div', 'sp-sep', null, { 'data-sec': 'cos' });
      el.appendChild(coordsSep);
      var coordsRow = h('div', 'sp-sr', null, { 'data-sec': 'co' });
      coordsRow.appendChild(h('span', 'sp-sl', 'COORDS'));
      var coordsVal = h('span', 'sp-sv', '--, --', { 'data-f': 'coords' });
      coordsRow.appendChild(coordsVal);
      el.appendChild(coordsRow);

      // SERVER row (gated by hud.serverInfo)
      var serverSep = h('div', 'sp-sep', null, { 'data-sec': 'svs' });
      el.appendChild(serverSep);
      var serverRow = h('div', 'sp-sr', null, { 'data-sec': 'sv' });
      serverRow.appendChild(h('span', 'sp-sl', 'SERVER'));
      var serverVal = h('span', 'sp-sv', '--', { 'data-f': 'server' });
      serverRow.appendChild(serverVal);
      el.appendChild(serverRow);

      SP.HudRoot.append(el);

      _widgets.stats = {
        el: el,
        fields: {
          score: scoreVal, len: lenEl, peak: peakEl, kills: killsVal,
          time: timeVal, coords: coordsVal, server: serverVal
        },
        secKills: killRow,
        secKillsSep: el.querySelector('[data-sec="ks"]'),
        secTimer: timeRow,
        secCoords: coordsRow, secCoordsSep: coordsSep,
        secServer: serverRow, secServerSep: serverSep
      };
    },

    _createFps: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-fps' });

      var fpsVal = h('div', 'sp-fv', '0', { 'data-f': 'fv' });
      el.appendChild(fpsVal);
      el.appendChild(h('div', 'sp-fl', 'FPS'));

      var sparkCanvas = h('canvas', 'sp-fk', null, { width: '55', height: '12' });
      el.appendChild(sparkCanvas);

      // Ping row — gated by hud.pingDisplay
      var pingRow = h('div', 'sp-pr', null, { 'data-sec': 'ping' });
      var pingVal = h('span', 'sp-pv', '--', { 'data-f': 'ping' });
      var pingLabel = h('span', 'sp-pl', 'ms');
      pingRow.appendChild(pingVal);
      pingRow.appendChild(pingLabel);
      el.appendChild(pingRow);

      SP.HudRoot.append(el);

      _widgets.fps = {
        el: el,
        valEl: fpsVal,
        sparkCanvas: sparkCanvas,
        sparkCtx: sparkCanvas.getContext('2d'),
        pingEl: pingVal,
        pingRow: pingRow
      };
    },

    _createMinimap: function () {
      var h = this._h;
      var size = (_settings && _settings.hud && _settings.hud.minimapSize) || 200;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-minimap' });

      var canvas = h('canvas', 'sp-mc', null, {
        width: String(size), height: String(size)
      });
      canvas.style.width = size + 'px';
      canvas.style.height = size + 'px';
      el.appendChild(canvas);

      var coordsEl = h('div', 'sp-mco', '', { 'data-f': 'mc' });
      el.appendChild(coordsEl);

      SP.HudRoot.append(el);

      _widgets.minimap = {
        el: el, canvas: canvas, ctx: canvas.getContext('2d'),
        coordsEl: coordsEl, size: size
      };
    },

    _createBot: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-bot' });

      var dotEl = h('span', 'sp-bd');
      var textEl = h('span', 'sp-bt', 'BOT IDLE', { 'data-f': 'bt' });
      var modeEl = h('span', 'sp-bm balanced', 'balanced');
      el.appendChild(dotEl);
      el.appendChild(textEl);
      el.appendChild(modeEl);

      SP.HudRoot.append(el);

      _widgets.bot = { el: el, dotEl: dotEl, textEl: textEl, modeEl: modeEl };
    },

    _createKeybinds: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-keys' });

      var kb = h('div', 'sp-kb');
      var binds = [['B','Bot'],['G','Grid'],['M','Map'],['+/-','Zoom'],['0','Reset'],['H','Hide']];
      for (var i = 0; i < binds.length; i++) {
        var ki = h('span', 'sp-ki');
        ki.appendChild(h('span', 'sp-kk', binds[i][0]));
        ki.appendChild(document.createTextNode(binds[i][1]));
        kb.appendChild(ki);
      }
      el.appendChild(kb);

      SP.HudRoot.append(el);
      _widgets.keybinds = { el: el };
    },

    // v7: Kill Feed
    _createKillFeed: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-killfeed' });
      SP.HudRoot.append(el);
      _widgets.killFeed = { el: el, entries: [], lastKills: 0 };
    },

    // v7: Boost Meter
    _createBoostMeter: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-boost' });

      el.appendChild(h('div', 'sp-bm-label', 'BOOST'));
      var barOuter = h('div', 'sp-bm-bar');
      var barFill = h('div', 'sp-bm-fill');
      barFill.style.width = '100%';
      barOuter.appendChild(barFill);
      el.appendChild(barOuter);

      SP.HudRoot.append(el);
      _widgets.boostMeter = { el: el, fillEl: barFill, lastPct: 100 };
    },

    // v7: Threat Radar
    _createThreatRadar: function () {
      var h = this._h;
      var el = h('div', 'sp-widget', null, { id: 'sp-w-radar' });

      var canvas = h('canvas', 'sp-radar-canvas', null, { width: '80', height: '80' });
      canvas.style.width = '80px';
      canvas.style.height = '80px';
      el.appendChild(canvas);

      SP.HudRoot.append(el);
      _widgets.radar = { el: el, canvas: canvas, ctx: canvas.getContext('2d') };
    },

    // ══════════════════════════════════════════════════════════
    //  Default Positions (viewport-aware)
    // ══════════════════════════════════════════════════════════

    /**
     * Calculate and apply default positions based on current viewport size.
     * Uses left/top exclusively — no right/bottom/transform ambiguity.
     * Skips widgets the user has manually dragged.
     *
     * Layout:
     *   Top-left:     Stats
     *   Top-right:    FPS, Kill Feed (stacked)
     *   Bottom-left:  Bot, Boost Meter, Radar (stacked upward)
     *   Bottom-right: Minimap
     *   Bottom-center: Keybinds
     */
    _initPositions: function () {
      var vw = window.innerWidth;
      var vh = window.innerHeight;
      var pad = 14;
      var mmSize = (_widgets.minimap && _widgets.minimap.size) || 200;

      // Estimated widget heights for stacking
      var botH = 28;
      var boostH = 30;
      var radarH = 80;
      var gap = 6;

      // Chat widget sits at bottom-left (fixed: left 14px, width 400px,
      // bottom 60px).  Bot / boost / radar go to the RIGHT of the chat
      // so they can never overlap regardless of chat height.
      var chatEl = document.getElementById('sp-chat');
      var chatRight = pad + 400 + 8;        // fallback: 14 + 400 + gap
      var chatBottomY = vh - 60;             // fallback: bottom:60px
      if (chatEl && chatEl.offsetParent !== null) {
        var chatRect = chatEl.getBoundingClientRect();
        chatRight = Math.round(chatRect.right) + 8;
        chatBottomY = Math.round(chatRect.bottom);
      }
      // Logo + Stats are locked top-left (logo above stats)
      var logoH = 34;

      // Minimap lives in one of the four viewport corners — user-chosen
      // via settings.hud.minimapPosition. Top-left bumps down below the
      // stats panel so it doesn't overlap the score readout.
      var mmPos = (_settings && _settings.hud && _settings.hud.minimapPosition) || 'bottom-right';
      var mmCoord = { left: vw - mmSize - pad, top: vh - mmSize - 30 };
      if (mmPos === 'bottom-left') {
        mmCoord = { left: pad, top: vh - mmSize - 30 };
      } else if (mmPos === 'top-right') {
        mmCoord = { left: vw - mmSize - pad, top: pad + 56 };
      } else if (mmPos === 'top-left') {
        mmCoord = { left: pad, top: pad + logoH + 140 + gap };
      }

      var defaults = {
        // Top-left: Logo watermark (locked)
        logo:       { left: pad, top: pad },
        // Below logo: Stats panel (locked)
        stats:      { left: pad, top: pad + logoH + gap },
        // Top-right: FPS counter
        fps:        { left: vw - 84, top: pad },
        // Right side below FPS: Kill feed
        killFeed:   { left: vw - 164, top: pad + 56 },
        // Minimap — position chosen above
        minimap:    mmCoord,
        // Right of chat: Bot status, Boost meter, Radar (stacked upward)
        bot:        { left: chatRight, top: chatBottomY - botH },
        boostMeter: { left: chatRight, top: chatBottomY - botH - gap - boostH },
        radar:      { left: chatRight, top: chatBottomY - botH - gap - boostH - gap - radarH },
        // Bottom-center: Keybinds legend
        keybinds:   { left: Math.max(pad, Math.round((vw - 300) / 2)), top: vh - 42 }
      };

      for (var key in defaults) {
        // Skip widgets the user has manually repositioned
        if (_userDraggedWidgets[key]) continue;
        if (!_widgets[key] || !_widgets[key].el) continue;

        var el = _widgets[key].el;
        var p = defaults[key];
        el.style.left = p.left + 'px';
        el.style.top = p.top + 'px';
        el.style.right = 'auto';
        el.style.bottom = 'auto';
        el.style.transform = 'none';
      }
    },

    // ══════════════════════════════════════════════════════════
    //  Position Persistence
    // ══════════════════════════════════════════════════════════

    _loadPositions: function () {
      try {
        var stored = localStorage.getItem(STORAGE_KEY);
        if (!stored) return;

        var data = JSON.parse(stored);

        // Version gate: discard stale layouts from older code
        if (!data || data._v !== POSITIONS_VERSION) {
          localStorage.removeItem(STORAGE_KEY);
          return;
        }

        _savedPositions = data.positions || {};
        // Mark all previously saved positions as user-dragged
        // (locked widgets always use computed defaults)
        delete _savedPositions['bot'];
        delete _savedPositions['logo'];
        delete _savedPositions['stats'];
        for (var key in _savedPositions) {
          if (_savedPositions.hasOwnProperty(key)) {
            _userDraggedWidgets[key] = true;
          }
        }
        this._applyPositions();
      } catch (e) {
        // Corrupt data — wipe and use defaults
        localStorage.removeItem(STORAGE_KEY);
      }
    },

    _savePositions: function () {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          _v: POSITIONS_VERSION,
          positions: _savedPositions
        }));
      } catch (e) { /* ignore */ }
    },

    /** Estimated widget heights for height-aware clamping. */
    _widgetHeight: function (key) {
      var mmSize = (_widgets.minimap && _widgets.minimap.size) || 200;
      var h = { logo: 34, stats: 120, fps: 55, minimap: mmSize + 20, bot: 30, keybinds: 35, killFeed: 30, boostMeter: 35, radar: 85 };
      return h[key] || 40;
    },

    _applyPositions: function () {
      var vw = window.innerWidth;
      var vh = window.innerHeight;
      for (var key in _savedPositions) {
        if (_widgets[key] && _savedPositions[key]) {
          var pos = _savedPositions[key];
          var el = _widgets[key].el;
          var wH = this._widgetHeight(key);
          // Clamp: keep widget fully on-screen (or as much as possible)
          var clampedLeft = Math.max(0, Math.min(pos.left, vw - 40));
          var clampedTop = Math.max(0, Math.min(pos.top, vh - wH));
          el.style.top = clampedTop + 'px';
          el.style.left = clampedLeft + 'px';
          el.style.right = 'auto';
          el.style.bottom = 'auto';
          el.style.transform = 'none';
        }
      }
    },

    // ══════════════════════════════════════════════════════════
    //  Drag & Drop
    // ══════════════════════════════════════════════════════════

    _setupDrag: function () {
      var self = this;

      document.addEventListener('mousedown', function (e) {
        // .closest() handles both <body>- and <html>-rooted widgets;
        // the previous hand-written walker bailed at document.body,
        // which broke once widgets moved under SP.HudRoot on <html>.
        var widgetEl = e.target && e.target.closest
          ? e.target.closest('.sp-widget')
          : null;
        if (!widgetEl) return;

        e.preventDefault();
        e.stopPropagation();

        var widgetKey = null;
        for (var k in _widgets) {
          if (_widgets[k].el === widgetEl) { widgetKey = k; break; }
        }
        if (!widgetKey) return;

        // Locked widgets — not draggable
        if (widgetKey === 'bot' || widgetKey === 'logo' || widgetKey === 'stats') return;

        var rect = widgetEl.getBoundingClientRect();
        _dragState = {
          key: widgetKey,
          el: widgetEl,
          offsetX: e.clientX - rect.left,
          offsetY: e.clientY - rect.top
        };
        widgetEl.classList.add('sp-drag');
      }, true);

      document.addEventListener('mousemove', function (e) {
        if (!_dragState) return;
        e.preventDefault();

        var el = _dragState.el;
        var rect = el.getBoundingClientRect();
        var x = Math.max(0, Math.min(e.clientX - _dragState.offsetX, window.innerWidth - rect.width));
        var y = Math.max(0, Math.min(e.clientY - _dragState.offsetY, window.innerHeight - rect.height));

        el.style.left = x + 'px';
        el.style.top = y + 'px';
        el.style.right = 'auto';
        el.style.bottom = 'auto';
        el.style.transform = 'none';
      }, true);

      document.addEventListener('mouseup', function () {
        if (!_dragState) return;
        _dragState.el.classList.remove('sp-drag');
        var rect = _dragState.el.getBoundingClientRect();
        _savedPositions[_dragState.key] = {
          top: Math.round(rect.top),
          left: Math.round(rect.left)
        };
        _userDraggedWidgets[_dragState.key] = true;
        self._savePositions();
        _dragState = null;
      }, true);

      // Clamp widget positions on window resize so they stay visible
      var _resizeTimer = null;
      window.addEventListener('resize', function () {
        if (_resizeTimer) clearTimeout(_resizeTimer);
        _resizeTimer = setTimeout(function () {
          self._clampAllPositions();
        }, 150);
      });

      // Watch the chat element for size changes (messages arriving, minimize
      // toggle, etc.) and reposition HUD widgets that stack above it.
      var _chatObserverTimer = null;
      function _watchChat() {
        var chatEl = document.getElementById('sp-chat');
        if (!chatEl) {
          // Chat widget not created yet — retry shortly
          setTimeout(_watchChat, 500);
          return;
        }
        if (typeof ResizeObserver !== 'undefined') {
          var ro = new ResizeObserver(function () {
            if (_chatObserverTimer) clearTimeout(_chatObserverTimer);
            _chatObserverTimer = setTimeout(function () {
              self._initPositions();
            }, 60);
          });
          ro.observe(chatEl);
        }
      }
      _watchChat();
    },

    /**
     * Reposition all widgets after viewport resize.
     * Non-dragged widgets get fresh viewport-aware defaults.
     * User-dragged widgets are clamped to stay visible.
     */
    _clampAllPositions: function () {
      var vw = window.innerWidth;
      var vh = window.innerHeight;

      // Recalculate default positions for non-dragged widgets
      this._initPositions();

      // Clamp user-dragged widgets — height-aware, visual only (don't
      // persist clamped values so original positions restore on larger viewport)
      for (var key in _userDraggedWidgets) {
        if (!_savedPositions[key]) continue;
        if (!_widgets[key] || !_widgets[key].el) continue;

        var el = _widgets[key].el;
        var pos = _savedPositions[key];
        var wH = this._widgetHeight(key);
        var clampedLeft = Math.max(0, Math.min(pos.left, vw - 40));
        var clampedTop = Math.max(0, Math.min(pos.top, vh - wH));

        el.style.left = clampedLeft + 'px';
        el.style.top = clampedTop + 'px';
        el.style.right = 'auto';
        el.style.bottom = 'auto';
        el.style.transform = 'none';
      }
    },

    // ══════════════════════════════════════════════════════════
    //  Visibility
    // ══════════════════════════════════════════════════════════

    _updateVisibility: function () {
      if (!_settings || !_settings.hud) return;
      var h = _settings.hud;
      this._toggle('logo', h.enabled);
      this._toggle('stats', h.enabled && (h.scoreDisplay || h.killCounter || h.sessionTimer));
      this._toggle('fps', h.enabled && h.fpsCounter);
      this._toggle('minimap', h.enabled && h.minimapEnabled);
      this._toggle('bot', h.enabled && _settings.bot && _settings.bot.enabled && SP.BotController && SP.BotController.isActive());
      this._toggle('keybinds', h.enabled && _keybindsVisible);
      // v7: New widgets always visible when HUD enabled
      this._toggle('killFeed', h.enabled && h.killCounter);
      // Boost meter + radar are bot-telemetry widgets — only show when the
      // user has an active bot session (debug mode alone is not enough, or
      // we'd expose these to non-Pro users who just pressed F3).
      var debugOn = SP.Debug && SP.Debug.isEnabled();
      var botActive = _settings.bot && _settings.bot.enabled
        && SP.BotController && SP.BotController.isActive();
      this._toggle('boostMeter', h.enabled && debugOn && botActive);
      this._toggle('radar', h.enabled && debugOn && botActive);

      // Toggle sub-sections within stats
      if (_widgets.stats) {
        var w = _widgets.stats;
        if (w.secKills) w.secKills.style.display = h.killCounter ? '' : 'none';
        if (w.secKillsSep) w.secKillsSep.style.display = (h.killCounter && h.sessionTimer) ? '' : 'none';
        if (w.secTimer) w.secTimer.style.display = h.sessionTimer ? '' : 'none';
        if (w.secCoords) w.secCoords.style.display = h.coordinates ? '' : 'none';
        if (w.secCoordsSep) w.secCoordsSep.style.display = h.coordinates ? '' : 'none';
        if (w.secServer) w.secServer.style.display = h.serverInfo ? '' : 'none';
        if (w.secServerSep) w.secServerSep.style.display = h.serverInfo ? '' : 'none';
      }

      // Ping row inside the FPS widget
      if (_widgets.fps && _widgets.fps.pingRow) {
        _widgets.fps.pingRow.classList.toggle('sp-show', !!h.pingDisplay);
      }
    },

    _toggle: function (key, show) {
      if (_widgets[key]) _widgets[key].el.classList.toggle('sp-vis', !!show);
    },

    _hideAll: function () {
      for (var k in _widgets) {
        if (_widgets[k]) _widgets[k].el.classList.remove('sp-vis');
      }
    },

    // ══════════════════════════════════════════════════════════
    //  Content Updates
    // ══════════════════════════════════════════════════════════

    _updateStatsContent: function () {
      if (!_widgets.stats) return;
      var f = _widgets.stats.fields;

      // Session-local fields — always update.
      this._txt(f.time, this._fmtTime(Date.now() - _sessionStart));

      var GameAPI = SP.GameAPI;

      // Coords — pull from player position (vanilla) or GameState.player
      // (Frontier). Em-dashes when not in a game.
      if (f.coords) {
        var pos = GameAPI.getPlayerPosition && GameAPI.getPlayerPosition();
        if (pos && isFinite(pos.x) && isFinite(pos.y)) {
          this._txt(f.coords, Math.round(pos.x) + ', ' + Math.round(pos.y));
        } else {
          this._txt(f.coords, '\u2014, \u2014');
        }
      }

      // Server info — slither.io exposes window.bso (currently-connected
      // server) once the connection is up.
      if (f.server) {
        var srv = GameAPI.getCurrentServer && GameAPI.getCurrentServer();
        if (srv && srv.sid) {
          this._txt(f.server, '#' + srv.sid);
        } else if (window.bso && window.bso.ip) {
          this._txt(f.server, window.bso.ip);
        } else {
          this._txt(f.server, '\u2014');
        }
      }

      var player = GameAPI.getPlayerSnake();
      if (player) {
        // Vanilla slither — authoritative player object available.
        if (player.score > _peakScore) _peakScore = player.score;
        this._txt(f.score, this._fmtNum(player.score));
        this._txt(f.len, 'LEN ' + this._fmtNum(player.length));
        this._txt(f.peak, 'PEAK ' + this._fmtNum(_peakScore));
        this._txt(f.kills, String(_kills));
        return;
      }

      // Frontier / NTL path — scrape the stat panel that the modded
      // client renders to the DOM. Frontier displays only a single
      // stat (Length) which serves as both length and score; showing
      // them as different numbers would confuse users comparing
      // against the game's own readout.
      var fs = GameAPI.getFrontierStats && GameAPI.getFrontierStats();
      if (fs) {
        if (fs.length > _peakScore) _peakScore = fs.length;
        this._txt(f.score, this._fmtNum(fs.length));
        this._txt(f.len, 'LEN ' + this._fmtNum(fs.length));
        this._txt(f.peak, 'PEAK ' + this._fmtNum(_peakScore));
        this._txt(f.kills, String(fs.kills));
        return;
      }

      // Neither source available — stay honest with em-dashes.
      this._txt(f.score, '\u2014');
      this._txt(f.len, 'LEN \u2014');
      this._txt(f.peak, 'PEAK ' + this._fmtNum(_peakScore));
      this._txt(f.kills, String(_kills));
    },

    _updateFpsContent: function () {
      var w = _widgets.fps;
      if (!w) return;
      var str = String(_currentFps);
      if (w.valEl.textContent !== str) {
        w.valEl.textContent = str;
        w.valEl.style.color = _currentFps >= 55 ? '#39ff14' : _currentFps >= 30 ? '#ffa502' : '#ff4757';
      }
      this._drawSparkline();

      // Ping: SP.WSHook.getPing() returns the smoothed round-trip time
      // in ms based on 1-byte outbound / 'p' pong inbound pairs.
      if (w.pingEl && _settings && _settings.hud && _settings.hud.pingDisplay) {
        var pingMs = (SP.WSHook && SP.WSHook.getPing) ? SP.WSHook.getPing() : null;
        if (pingMs !== null) {
          w.pingEl.textContent = String(pingMs);
          w.pingEl.style.color = pingMs < 80 ? '#39ff14' : pingMs < 180 ? '#ffa502' : '#ff4757';
        } else {
          w.pingEl.textContent = '\u2014';
          w.pingEl.style.color = 'rgba(255,255,255,.4)';
        }
      }
    },

    _drawSparkline: function () {
      var w = _widgets.fps;
      if (!w || !w.sparkCtx || _fpsHistory.length < 2) return;
      var ctx = w.sparkCtx;
      var cw = 55, ch = 12;
      ctx.clearRect(0, 0, cw, ch);
      var color = _currentFps >= 55 ? '#39ff14' : _currentFps >= 30 ? '#ffa502' : '#ff4757';
      ctx.strokeStyle = color;
      ctx.globalAlpha = 0.4;
      ctx.lineWidth = 1;
      ctx.beginPath();
      var step = cw / (FPS_HISTORY_LEN - 1);
      for (var i = 0; i < _fpsHistory.length; i++) {
        var v = Math.min(_fpsHistory[i] / 80, 1);
        var x = i * step;
        var y = ch - v * ch;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.globalAlpha = 1;
    },

    _updateBotContent: function () {
      var w = _widgets.bot;
      if (!w || !SP.BotController || !SP.BotController.isActive()) return;
      var state = SP.BotController.getState();
      var labels = { IDLE:'IDLE', FOOD:'SEEKING', KILL:'KILL', SAFETY:'AVOIDING', BORDER:'BORDER', DEATH_FOOD:'DEATH FOOD', COIL:'COIL', WANDER:'WANDER' };
      var colors = { IDLE:'#666680', FOOD:'#ffa502', KILL:'#ff6b6b', SAFETY:'#ff4757', BORDER:'#ff0040', DEATH_FOOD:'#f9ca24', COIL:'#e056fd', WANDER:'#74b9ff' };
      var c = colors[state] || '#fff';
      w.textEl.textContent = 'BOT  ' + (labels[state] || state);
      w.textEl.style.color = c;
      w.dotEl.style.background = c;

      // Update mode badge
      if (w.modeEl && SP.StrategyManager) {
        var mode = SP.StrategyManager.getMode() || 'balanced';
        var modeLabels = { aggressive:'AGG', balanced:'BAL', defensive:'DEF' };
        w.modeEl.textContent = modeLabels[mode] || mode;
        w.modeEl.className = 'sp-bm ' + mode;
      }
    },

    // ══════════════════════════════════════════════════════════
    //  Minimap
    // ══════════════════════════════════════════════════════════

    _updateMinimapContent: function () {
      var w = _widgets.minimap;
      if (!w) return;
      var GameAPI = SP.GameAPI;
      var MathUtil = SP.MathUtil;
      if (!GameAPI || !MathUtil) return;

      _minimapFrame++;
      var size = w.size;
      var canvas = w.canvas;
      var ctx = w.ctx;
      var mapR = GameAPI.getMapRadius();
      var pp = GameAPI.getPlayerPosition();
      if (!pp) return;

      var player = GameAPI.getPlayerSnake();
      var pa = (player && player.angle !== undefined) ? player.angle : 0;

      // Player-centered radar: show 4000 game-unit radius around player
      var radarRadius = 4000;
      var cx = size / 2, cy = size / 2, hs = size / 2;
      var sc = hs / radarRadius;

      // Track player trail (last 20 positions)
      if (_minimapFrame % 2 === 0) {
        _playerTrail.push({ x: pp.x, y: pp.y });
        if (_playerTrail.length > 20) _playerTrail.shift();
      }

      ctx.clearRect(0, 0, size, size);
      ctx.save();
      try {

      // Outer glow
      var g = ctx.createRadialGradient(cx, cy, hs - 6, cx, cy, hs + 4);
      g.addColorStop(0, 'rgba(57,255,20,.08)');
      g.addColorStop(1, 'rgba(57,255,20,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, size, size);

      // Background circle — dark navy
      ctx.fillStyle = 'rgba(6,6,18,0.85)';
      ctx.beginPath(); ctx.arc(cx, cy, hs, 0, Math.PI * 2); ctx.fill();

      // Subtle green border
      ctx.strokeStyle = 'rgba(57,255,20,.3)';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(cx, cy, hs, 0, Math.PI * 2); ctx.stroke();

      // Clip to circle
      ctx.beginPath(); ctx.arc(cx, cy, hs - 2, 0, Math.PI * 2); ctx.clip();

      // ── Concentric range rings at 25%, 50%, 75% ──
      ctx.strokeStyle = 'rgba(255,255,255,.06)';
      ctx.lineWidth = 0.5;
      var ri;
      for (ri = 1; ri <= 3; ri++) {
        ctx.beginPath();
        ctx.arc(cx, cy, hs * ri * 0.25, 0, Math.PI * 2);
        ctx.stroke();
      }

      // ── Tick marks at N/S/E/W instead of compass text ──
      ctx.strokeStyle = 'rgba(255,255,255,.15)';
      ctx.lineWidth = 1;
      var tickLen = 5;
      // N
      ctx.beginPath(); ctx.moveTo(cx, 2); ctx.lineTo(cx, 2 + tickLen); ctx.stroke();
      // S
      ctx.beginPath(); ctx.moveTo(cx, size - 2); ctx.lineTo(cx, size - 2 - tickLen); ctx.stroke();
      // W
      ctx.beginPath(); ctx.moveTo(2, cy); ctx.lineTo(2 + tickLen, cy); ctx.stroke();
      // E
      ctx.beginPath(); ctx.moveTo(size - 2, cy); ctx.lineTo(size - 2 - tickLen, cy); ctx.stroke();

      // ── Map boundary — red arc only when near edge ──
      var playerDistFromCenter = Math.sqrt(
        (pp.x - mapR) * (pp.x - mapR) + (pp.y - mapR) * (pp.y - mapR)
      );
      var distToBoundary = mapR - playerDistFromCenter;
      if (distToBoundary < radarRadius) {
        // Boundary is within radar range — draw the visible arc
        // The map boundary is a circle of radius mapR centered at (mapR, mapR)
        // In radar coords, the map center is at:
        var worldCenterDx = (mapR - pp.x) * sc;
        var worldCenterDy = (mapR - pp.y) * sc;
        var bCx = cx + worldCenterDx;
        var bCy = cy + worldCenterDy;
        var bR = mapR * sc;
        ctx.strokeStyle = 'rgba(255,50,50,.5)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        ctx.arc(bCx, bCy, bR, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // ── Food dots (cached every 5 frames) ──
      if (_minimapFrame % 5 === 0) {
        var foods = GameAPI.getFoods() || [];
        _cachedFoodDots = [];
        var fi, fd, fdx, fdy, fdist2, fScreenX, fScreenY;
        var hsSquared = hs * hs;
        for (fi = 0; fi < foods.length; fi += 3) {
          fd = foods[fi];
          if (!fd) continue;
          fdx = fd.x - pp.x;
          fdy = fd.y - pp.y;
          fdist2 = fdx * fdx + fdy * fdy;
          if (fdist2 > radarRadius * radarRadius) continue;
          fScreenX = cx + fdx * sc;
          fScreenY = cy + fdy * sc;
          var fChkX = fScreenX - cx, fChkY = fScreenY - cy;
          if (fChkX * fChkX + fChkY * fChkY < hsSquared) {
            _cachedFoodDots.push({ x: fScreenX, y: fScreenY, sz: fd.sz || 1 });
          }
        }
      }
      var di, dd, dotColor, dotSize;
      for (di = 0; di < _cachedFoodDots.length; di++) {
        dd = _cachedFoodDots[di];
        // Color by size: small=dim gray, medium=orange, large=bright gold
        if (dd.sz >= 8) {
          dotColor = 'rgba(255,215,0,0.8)';
          dotSize = 3;
        } else if (dd.sz >= 3) {
          dotColor = 'rgba(255,165,0,0.6)';
          dotSize = 2;
        } else {
          dotColor = 'rgba(160,160,160,0.35)';
          dotSize = 1;
        }
        ctx.fillStyle = dotColor;
        ctx.beginPath();
        ctx.arc(dd.x, dd.y, dotSize * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // ── Enemy snakes — draw body trails + heads + labels ──
      var snakes = GameAPI.getNearbySnakes();
      var labelCandidates = [];
      var si, sn, sl, snColor, sdx, sdy, sdist2;
      var radarR2 = radarRadius * radarRadius;
      var hsSquared2 = hs * hs;

      for (si = 0; si < snakes.length; si++) {
        sn = snakes[si];
        sl = sn.length || 10;

        // Threat color: large=red, mid=orange, small=yellow
        if (sl > 100) { snColor = '#ff2040'; }
        else if (sl > 40) { snColor = '#ff8c00'; }
        else { snColor = '#ffdd44'; }

        // Draw body trail from bodyParts
        var parts = sn.bodyParts;
        if (parts && parts.length > 1) {
          ctx.strokeStyle = snColor;
          ctx.globalAlpha = 0.5;
          ctx.lineWidth = sl > 100 ? 2.5 : (sl > 40 ? 1.8 : 1.2);
          ctx.beginPath();
          var started = false;
          var pi, bp, bpDx, bpDy, bpSx, bpSy, bpChkX, bpChkY;
          // Sample body parts for performance (every 2nd-3rd segment)
          var step = parts.length > 40 ? 3 : (parts.length > 20 ? 2 : 1);
          for (pi = 0; pi < parts.length; pi += step) {
            bp = parts[pi];
            bpDx = bp.x - pp.x;
            bpDy = bp.y - pp.y;
            if (bpDx * bpDx + bpDy * bpDy > radarR2) continue;
            bpSx = cx + bpDx * sc;
            bpSy = cy + bpDy * sc;
            bpChkX = bpSx - cx; bpChkY = bpSy - cy;
            if (bpChkX * bpChkX + bpChkY * bpChkY > hsSquared2) continue;
            if (!started) {
              ctx.moveTo(bpSx, bpSy);
              started = true;
            } else {
              ctx.lineTo(bpSx, bpSy);
            }
          }
          ctx.stroke();
          ctx.globalAlpha = 1;
        }

        // Head position
        sdx = sn.x - pp.x;
        sdy = sn.y - pp.y;
        sdist2 = sdx * sdx + sdy * sdy;
        if (sdist2 > radarR2) continue;
        var headSx = cx + sdx * sc;
        var headSy = cy + sdy * sc;
        var headChkX = headSx - cx, headChkY = headSy - cy;
        if (headChkX * headChkX + headChkY * headChkY > hsSquared2) continue;

        // Head dot (slightly larger)
        var headR = sl > 100 ? 4 : (sl > 40 ? 3 : 2.5);
        ctx.fillStyle = snColor;
        ctx.globalAlpha = 0.9;
        ctx.beginPath(); ctx.arc(headSx, headSy, headR, 0, Math.PI * 2); ctx.fill();

        // Direction indicator line from head
        if (sn.angle !== undefined) {
          ctx.strokeStyle = snColor;
          ctx.globalAlpha = 0.6;
          ctx.lineWidth = 1.5;
          var dirLen = sl > 100 ? 10 : 7;
          ctx.beginPath();
          ctx.moveTo(headSx, headSy);
          ctx.lineTo(headSx + Math.cos(sn.angle) * dirLen, headSy + Math.sin(sn.angle) * dirLen);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;

        // Collect label candidates (for top 3 largest)
        labelCandidates.push({ x: headSx, y: headSy, len: sl, color: snColor });
      }

      // Label the largest 3 snakes with their length
      labelCandidates.sort(function (a, b) { return b.len - a.len; });
      var labelCount = Math.min(labelCandidates.length, 3);
      ctx.font = '600 8px "Segoe UI",sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'bottom';
      var li, lc;
      for (li = 0; li < labelCount; li++) {
        lc = labelCandidates[li];
        ctx.fillStyle = lc.color;
        ctx.globalAlpha = 0.85;
        ctx.fillText(String(lc.len), lc.x + 5, lc.y - 2);
      }
      ctx.globalAlpha = 1;

      // ── Player trail (faint recent positions) ──
      if (_playerTrail.length > 1) {
        ctx.strokeStyle = 'rgba(57,255,20,.15)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        var ti, tr, trDx, trDy, trSx, trSy;
        for (ti = 0; ti < _playerTrail.length; ti++) {
          tr = _playerTrail[ti];
          trDx = tr.x - pp.x;
          trDy = tr.y - pp.y;
          trSx = cx + trDx * sc;
          trSy = cy + trDy * sc;
          if (ti === 0) {
            ctx.moveTo(trSx, trSy);
          } else {
            ctx.lineTo(trSx, trSy);
          }
        }
        // Connect trail to center (current position)
        ctx.lineTo(cx, cy);
        ctx.stroke();
      }

      // ── Player indicator — green arrow at center with glow ──
      ctx.shadowColor = '#39ff14';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#39ff14';
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(pa) * 7, cy + Math.sin(pa) * 7);
      ctx.lineTo(cx + Math.cos(pa + 2.5) * 4, cy + Math.sin(pa + 2.5) * 4);
      ctx.lineTo(cx + Math.cos(pa - 2.5) * 4, cy + Math.sin(pa - 2.5) * 4);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;

      } finally { ctx.restore(); }

      // Coordinates below minimap
      this._txt(w.coordsEl, Math.round(pp.x) + ' , ' + Math.round(pp.y));
    },

    // ══════════════════════════════════════════════════════════
    //  v7: New Widget Updates
    // ══════════════════════════════════════════════════════════

    _updateKillFeedContent: function () {
      var w = _widgets.killFeed;
      if (!w) return;

      // Detect new kills
      if (_kills > w.lastKills) {
        var diff = _kills - w.lastKills;
        for (var k = 0; k < diff; k++) {
          var entry = document.createElement('div');
          entry.className = 'sp-kf-entry';
          entry.innerHTML = '<span class="sp-kf-name">Kill!</span> <span class="sp-kf-score">+1</span>';
          // Prepend
          if (w.el.firstChild) {
            w.el.insertBefore(entry, w.el.firstChild);
          } else {
            w.el.appendChild(entry);
          }
          w.entries.unshift({ el: entry, time: Date.now() });
        }
        w.lastKills = _kills;
      }

      // Fade and remove old entries
      var now = Date.now();
      for (var i = w.entries.length - 1; i >= 0; i--) {
        var age = now - w.entries[i].time;
        if (age > 5000) {
          w.entries[i].el.classList.add('sp-kf-fade');
          if (age > 5500 && w.entries[i].el.parentNode) {
            w.entries[i].el.parentNode.removeChild(w.entries[i].el);
            w.entries.splice(i, 1);
          }
        }
      }

      // Keep max 5 entries
      while (w.entries.length > 5) {
        var old = w.entries.pop();
        if (old.el.parentNode) old.el.parentNode.removeChild(old.el);
      }

      // Hide the widget entirely when there are no entries
      if (w.entries.length === 0) {
        w.el.classList.remove('sp-vis');
      }
    },

    _updateBoostMeterContent: function () {
      var w = _widgets.boostMeter;
      if (!w) return;

      var GameAPI = SP.GameAPI;
      var player = GameAPI.getPlayerSnake();
      if (!player) return;

      var isBoosting = !!(window.slither && typeof window.slither === 'object' && window.slither.sp > 6);
      var len = player.length || 10;
      // Show relative length as % (cap at 500 for display)
      var pct = Math.min(100, (len / 500) * 100);

      if (Math.abs(pct - w.lastPct) > 0.5 || isBoosting) {
        w.fillEl.style.width = pct.toFixed(1) + '%';
        w.lastPct = pct;
      }

      if (isBoosting) {
        w.fillEl.classList.add('sp-bm-boost');
      } else {
        w.fillEl.classList.remove('sp-bm-boost');
      }
    },

    _updateThreatRadarContent: function () {
      var w = _widgets.radar;
      if (!w || !w.ctx) return;

      var GameAPI = SP.GameAPI;
      var MathUtil = SP.MathUtil;
      if (!GameAPI || !MathUtil) return;

      var pp = GameAPI.getPlayerPosition();
      var player = GameAPI.getPlayerSnake();
      if (!pp || !player) return;

      var ctx = w.ctx;
      var size = 80;
      var cx = size / 2;
      var cy = size / 2;

      ctx.clearRect(0, 0, size, size);

      // Background circle
      ctx.globalAlpha = 0.15;
      ctx.fillStyle = '#0a0a1e';
      ctx.beginPath();
      ctx.arc(cx, cy, 38, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;

      // Crosshair
      ctx.strokeStyle = 'rgba(255,255,255,.1)';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(cx, 5); ctx.lineTo(cx, size - 5);
      ctx.moveTo(5, cy); ctx.lineTo(size - 5, cy);
      ctx.stroke();

      // Range ring
      ctx.beginPath();
      ctx.arc(cx, cy, 28, 0, Math.PI * 2);
      ctx.stroke();

      // Show nearest 3 threats as directional arrows
      var nearby = GameAPI.getNearbySnakes();
      var threats = [];
      for (var i = 0; i < nearby.length; i++) {
        var s = nearby[i];
        var dist = MathUtil.distance(pp.x, pp.y, s.x, s.y);
        if (dist < 600) {
          threats.push({ x: s.x, y: s.y, dist: dist, length: s.length || 10 });
        }
      }
      threats.sort(function (a, b) { return a.dist - b.dist; });

      var maxShow = Math.min(3, threats.length);
      for (var t = 0; t < maxShow; t++) {
        var threat = threats[t];
        var angle = Math.atan2(threat.y - pp.y, threat.x - pp.x);
        var closeness = 1 - (threat.dist / 600);
        var r = 12 + closeness * 20;

        var arrowX = cx + Math.cos(angle) * r;
        var arrowY = cy + Math.sin(angle) * r;

        // Color by proximity: green > yellow > red
        if (closeness > 0.7) {
          ctx.fillStyle = '#ff4757';
        } else if (closeness > 0.4) {
          ctx.fillStyle = '#ffa502';
        } else {
          ctx.fillStyle = '#2ed573';
        }

        ctx.globalAlpha = 0.6 + closeness * 0.4;
        ctx.beginPath();
        ctx.arc(arrowX, arrowY, 3 + closeness * 2, 0, Math.PI * 2);
        ctx.fill();

        // Direction line from center
        ctx.strokeStyle = ctx.fillStyle;
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.3;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(arrowX, arrowY);
        ctx.stroke();
      }

      ctx.globalAlpha = 1;

      // Center player dot
      ctx.fillStyle = '#39ff14';
      ctx.beginPath();
      ctx.arc(cx, cy, 3, 0, Math.PI * 2);
      ctx.fill();
    },

    // ══════════════════════════════════════════════════════════
    //  Data Tracking
    // ══════════════════════════════════════════════════════════

    _updateFps: function () {
      _frameCount++;
      var now = performance.now();
      if (now - _lastFpsTime >= 1000) {
        _currentFps = _frameCount;
        _frameCount = 0;
        _lastFpsTime = now;
        _fpsHistory.push(_currentFps);
        if (_fpsHistory.length > FPS_HISTORY_LEN) _fpsHistory.shift();
      }
    },

    _trackKills: function () {
      var GameAPI = SP.GameAPI;
      var MathUtil = SP.MathUtil;
      if (!GameAPI || !MathUtil) return;

      var nearby = GameAPI.getNearbySnakes() || [];
      var currentIds = {};
      for (var i = 0; i < nearby.length; i++) currentIds[nearby[i].id] = true;

      var pp = GameAPI.getPlayerPosition();
      if (pp) {
        for (var id in _lastNearbyIds) {
          if (_lastNearbyIds.hasOwnProperty(id) && !currentIds[id]) {
            if (_lastNearbyIds[id].dist < 80 && _lastNearbyIds[id].frames >= 2) {
              _kills++;
            }
          }
        }
      }

      var _prevNearbyIds = _lastNearbyIds;
      _lastNearbyIds = {};
      if (pp) {
        for (var j = 0; j < nearby.length; j++) {
          var s = nearby[j];
          var prevEntry = _prevNearbyIds[s.id];
          _lastNearbyIds[s.id] = {
            dist: MathUtil.distance(pp.x, pp.y, s.x, s.y),
            frames: prevEntry ? prevEntry.frames + 1 : 1
          };
        }
      }
    },

    // ══════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════

    _txt: function (el, t) { if (el && el.textContent !== t) el.textContent = t; },

    _fmtNum: function (n) {
      if (!n && n !== 0) return '0';
      return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },

    _fmtTime: function (ms) {
      var s = Math.floor(ms / 1000);
      var m = Math.floor(s / 60);
      s = s % 60;
      return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.HudManager = HudManager;
})();
