/**
 * Slither Pro — Frontier Warning Augmenter.
 *
 * When Frontier is installed alongside Slither Pro, it shows a warning
 * dialog on page load that tells the user to disable other mods. That
 * framing is misleading: Slither Pro and Frontier actually cooperate
 * on several features (chat, skins, HUD stats) — it's only the bot
 * and a handful of game-state-dependent widgets that can't work under
 * Frontier's client replacement.
 *
 * Rather than fighting the dialog, we enrich it: when Frontier's
 * warning appears and names "Slither Pro: Game Mods" as the detected
 * mod, we replace the generic text with a specific compatibility
 * breakdown. The dialog's OK button and dismiss behaviour stay intact.
 *
 * Strategy:
 *   - MutationObserver on document watches for new DOM subtrees
 *   - On each mutation, scan for a container holding a <p> with our
 *     extension name
 *   - If found and not yet augmented, replace its children with our
 *     compatibility message and mark the container so we don't loop
 */
(function () {
  'use strict';

  var SP = window.SlitherPro = window.SlitherPro || {};
  if (SP._FrontierNoticeInstalled) return;
  SP._FrontierNoticeInstalled = true;

  var EXT_NAME = 'Slither Pro: Game Mods';

  // Only list features we've verified end-to-end with Frontier active.
  // Adding untested ones here would be dishonest — visual mods like
  // skins and auras draw onto Frontier's canvas in ways we haven't
  // confirmed render correctly.
  var WORKS = [
    'Live in-game chat',
    'HUD stats (Length, Kills, Score, Session timer)'
  ];

  // Confirmed incompatible — both require game-state reads that
  // Frontier's client replacement doesn't expose.
  var BROKEN = [
    'AI Bot',
    'Auto-play'
  ];

  function findContainer() {
    // The Frontier warning renders each line as a <p> inside a flex
    // column. The one that names our extension is the stable anchor.
    var ps = document.querySelectorAll('p');
    for (var i = 0; i < ps.length; i++) {
      if (ps[i].textContent && ps[i].textContent.indexOf(EXT_NAME) !== -1) {
        return ps[i].parentElement;
      }
    }
    return null;
  }

  function augment(container) {
    if (!container || container.__spAugmented) return;
    container.__spAugmented = true;

    // Preserve the column class but replace the children with our
    // own content.
    while (container.firstChild) container.removeChild(container.firstChild);

    container.appendChild(para(
      'Slither Pro is running alongside Frontier. Here\u2019s what we\u2019ve tested so far.'
    ));

    container.appendChild(header('Confirmed working', '#39ff14'));
    container.appendChild(list(WORKS));

    container.appendChild(header('Known not working', '#ffa502'));
    container.appendChild(list(BROKEN));

    container.appendChild(para(
      'Other Slither Pro features may work partially or not at all \u2014 we haven\u2019t fully verified them with Frontier. Dismiss to keep playing; disable Frontier at chrome://extensions if you need the bot.'
    ));
  }

  function para(text) {
    var p = document.createElement('p');
    p.className = 'text-left leading-relaxed';
    p.textContent = text;
    return p;
  }

  function header(text, color) {
    var p = document.createElement('p');
    p.className = 'text-left leading-relaxed';
    var strong = document.createElement('strong');
    strong.style.color = color;
    strong.textContent = text + ':';
    p.appendChild(strong);
    return p;
  }

  function list(items) {
    var p = document.createElement('p');
    p.className = 'text-left leading-relaxed';
    p.style.paddingLeft = '4px';
    p.textContent = items.map(function (s) { return '• ' + s; }).join('   ');
    return p;
  }

  var _obs = null;

  function scan() {
    var container = findContainer();
    if (container) {
      augment(container);
      // Frontier only shows the warning once per page load, so once
      // we've patched it there's no point watching for more mutations.
      // Disconnecting here avoids a per-mutation DOM scan that would
      // otherwise run for the entire session (noticeable cost when
      // chat is active and adds ~50 nodes/sec).
      if (_obs) { _obs.disconnect(); _obs = null; }
    }
  }

  // Dialog might already be mounted when our script runs, or may
  // appear later. Cover both with an initial scan and an observer
  // that self-disconnects the moment the augment succeeds.
  if (document.body) scan();

  if (!_obs) {
    _obs = new MutationObserver(function () { scan(); });
    _obs.observe(document.documentElement, { childList: true, subtree: true });
  }
})();
