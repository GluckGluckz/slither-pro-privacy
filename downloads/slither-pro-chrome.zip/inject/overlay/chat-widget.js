/**
 * Slither Pro — Chat Widget (v2)
 * Global / Team chat overlay with persistent hybrid identity.
 *
 * Features:
 *   - Auto-generated snake-themed nickname (stored in localStorage)
 *   - /nick command to change name
 *   - Persistent message history from server (SQLite-backed)
 *   - No join/leave spam — silent online count updates
 *   - Global and private team rooms
 *   - Fade after inactivity, un-fade on hover or new message
 *   - Press Enter to open, Escape to close
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  var CHAT_WS_URL = 'wss://slither-pro-api.anthany2024.workers.dev/chat/ws';
  var Z_INDEX = 1000010;
  var STORAGE_KEY_NICK = 'sp_chat_nick';
  var STORAGE_KEY_TEAM = 'sp_chat_team';

  var MAX_MESSAGES = 80;
  var FADE_AFTER_MS = 12000;
  var RECONNECT_BASE = 2000;
  var RECONNECT_MAX = 30000;
  var PING_INTERVAL = 45000;

  // ── Identity Generator ─────────────────────────────────────
  var ADJECTIVES = [
    'Cosmic', 'Shadow', 'Neon', 'Toxic', 'Phantom',
    'Swift', 'Blazing', 'Crystal', 'Thunder', 'Silent',
    'Golden', 'Frost', 'Crimson', 'Venom', 'Mystic',
    'Iron', 'Emerald', 'Storm', 'Lunar', 'Savage',
    'Stealth', 'Apex', 'Atomic', 'Hyper', 'Obsidian',
    'Turbo', 'Royal', 'Plasma', 'Cyber', 'Rogue'
  ];

  var NOUNS = [
    'Viper', 'Cobra', 'Python', 'Mamba', 'Serpent',
    'Basilisk', 'Sidewinder', 'Anaconda', 'Taipan', 'Rattler',
    'Slither', 'Fang', 'Coiler', 'Striker', 'Glider',
    'Crawler', 'Predator', 'Hunter', 'Devourer', 'Wraith'
  ];

  function _generateNick() {
    var adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
    var noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
    var num = Math.floor(Math.random() * 90) + 10; // 10-99
    return adj + noun + num;
  }

  function _loadIdentity() {
    try {
      var stored = localStorage.getItem(STORAGE_KEY_NICK);
      if (stored && stored.length > 0 && stored.length <= 24) {
        // Validate stored nick: alphanumeric + basic punctuation only
        if (/^[a-zA-Z0-9_\-. ]+$/.test(stored)) {
          var trimmed = stored.trim();
          if (trimmed.length > 0) return trimmed;
        }
      }
    } catch (e) { /* private browsing */ }
    var nick = _generateNick();
    _saveIdentity(nick);
    return nick;
  }

  function _saveIdentity(nick) {
    try {
      localStorage.setItem(STORAGE_KEY_NICK, nick);
    } catch (e) { /* ignore */ }
  }

  function _displayNick() {
    return _clanTag ? '[' + _clanTag + '] ' + _nick : _nick;
  }

  /** Strip any [TAG] prefix to get the base identity for matching. */
  function _baseNick(nick) {
    return nick.replace(/^\[[^\]]*\]\s*/, '').trim();
  }

  /** Hide all visible messages from a nick (called after blocking). */
  function _hideBlockedMessages(nick) {
    if (!_messagesEl) return;
    var key = _baseNick(nick).toLowerCase();
    var msgs = _messagesEl.querySelectorAll('.sp-chat-msg[data-nick]');
    for (var i = 0; i < msgs.length; i++) {
      if (msgs[i].getAttribute('data-nick').toLowerCase() === key) {
        msgs[i].style.display = 'none';
      }
    }
  }

  /** Show all hidden messages from a nick (called after unblocking). */
  function _showUnblockedMessages(nick) {
    if (!_messagesEl) return;
    var key = _baseNick(nick).toLowerCase();
    var msgs = _messagesEl.querySelectorAll('.sp-chat-msg[data-nick]');
    for (var i = 0; i < msgs.length; i++) {
      if (msgs[i].getAttribute('data-nick').toLowerCase() === key) {
        msgs[i].style.display = '';
      }
    }
  }

  // ── State ──────────────────────────────────────────────────
  var _initialized = false;
  var _ws = null;
  var _connected = false;
  var _reconnectTimer = null;
  var _reconnectDelay = RECONNECT_BASE;
  var _pingTimer = null;
  var _nick = '';
  var _clanTag = '';
  var _room = 'global';
  var _teamCode = '';
  var _onlineCount = 0;
  var _messages = [];
  var _chatOpen = false;
  var _chatVisible = true;
  var _fadeTimer = null;
  var _firstConnect = true;
  var _chatMuted = false;
  var _outboundTimestamps = [];   // local sender rate limiting

  // ── DOM Elements ───────────────────────────────────────────
  var _container = null;
  var _messagesEl = null;
  var _inputEl = null;
  var _headerEl = null;
  var _tabGlobalEl = null;
  var _tabTeamEl = null;
  var _onlineEl = null;
  var _nickDisplayEl = null;
  var _teamInputWrap = null;
  var _teamCodeInput = null;
  var _ctxMenuEl = null;
  var _muteBannerEl = null;
  var _chatMinimized = false;
  var _serverPanelOpen = false;
  var _serverPanelEl = null;
  var _serverBtnEl = null;

  function _loadMuteState() {
    try { return localStorage.getItem('sp_chat_muted') === 'true'; } catch (e) { return false; }
  }

  function _saveMuteState(val) {
    try { localStorage.setItem('sp_chat_muted', val ? 'true' : 'false'); } catch (e) { /* ignore */ }
  }

  // ── Profanity / Hate Filter ───────────────────────────────
  var _ProfanityFilter = {
    _re: null,

    init: function () {
      // Only base forms needed — the leet map auto-generates variant
      // patterns (e.g. 'fuck' also matches 'fvck', 'f_u_c_k', etc.)
      var stems = [
        // Racial / ethnic slurs
        'nigg', 'fagg', 'retard', 'tranny', 'dyke',
        'spic', 'chink', 'gook', 'kike', 'wetback', 'beaner',
        'coon', 'darkie', 'raghead', 'towelhead', 'zipperhead',
        'gringo',
        // Gendered / sexual slurs
        'cunt', 'twat', 'bitch', 'whore', 'shemale', 'slut',
        // Core profanity
        'fuck', 'shit',
        // Compound profanity
        'cocksucker', 'motherfuck', 'assfuck', 'asshole',
        'fucktard', 'fuckface', 'shithead', 'bullshit', 'dickhead',
        // Hate identifiers
        'nigga', 'negro',
        'jihadi', 'rapist', 'pedo', 'pedophile',
        'nazi', 'hitler', 'sieg heil',
        // Toxic directives
        'kys', 'stfu'
      ];

      var leetMap = {
        'a': '[@4a]',
        'e': '[3e]',
        'i': '[1!|i]',
        'o': '[0o]',
        's': '[$5s]',
        't': '[7+t]',
        'u': '[uv\u00fc]'
      };

      var patterns = [];
      for (var i = 0; i < stems.length; i++) {
        var stem = stems[i].toLowerCase();
        var pat = '';
        for (var j = 0; j < stem.length; j++) {
          var ch = stem[j];
          if (ch === ' ') {
            pat += '[-_.\\s]+';
          } else if (leetMap[ch]) {
            pat += leetMap[ch] + '[-_.\\s]?';
          } else {
            pat += ch + '[-_.\\s]?';
          }
        }
        // trim trailing optional separator
        pat = pat.replace(/\[-_\.\\\s\]\?$/, '');
        patterns.push(pat);
      }

      try {
        this._re = new RegExp('(' + patterns.join('|') + ')', 'gi');
      } catch (e) {
        this._re = null;
      }
    },

    filter: function (text) {
      if (!this._re) return text;
      this._re.lastIndex = 0;
      return text.replace(this._re, function (match) {
        var stars = '';
        for (var k = 0; k < match.length; k++) stars += '*';
        return stars;
      });
    },

    /** Returns true if text contains any prohibited language. */
    test: function (text) {
      if (!this._re) return false;
      this._re.lastIndex = 0;
      return this._re.test(text);
    }
  };

  // ── Spam Protection ───────────────────────────────────────
  var _SpamGuard = {
    _history: {},        // nick -> [{text, ts}]
    _lastMsgByNick: {},  // nick -> DOM element
    _counterMap: {},     // nick+'|||'+text -> {el, count}
    _cleanTimer: null,

    _startCleaner: function () {
      var self = this;
      if (this._cleanTimer) return;
      this._cleanTimer = setInterval(function () {
        var now = Date.now();
        var nicks = Object.keys(self._history);
        for (var i = 0; i < nicks.length; i++) {
          var nick = nicks[i];
          var arr = self._history[nick];
          var fresh = [];
          for (var j = 0; j < arr.length; j++) {
            if (now - arr[j].ts < 30000) fresh.push(arr[j]);
          }
          if (fresh.length === 0) {
            delete self._history[nick];
            delete self._lastMsgByNick[nick];
          } else {
            self._history[nick] = fresh;
          }
        }
        // Clean counter map entries older than 30s
        var keys = Object.keys(self._counterMap);
        for (var k = 0; k < keys.length; k++) {
          var entry = self._counterMap[keys[k]];
          if (now - entry.lastTs > 30000) {
            delete self._counterMap[keys[k]];
          }
        }
      }, 10000);
    },

    process: function (nick, text, ts) {
      this._startCleaner();
      var now = ts || Date.now();
      if (!this._history[nick]) this._history[nick] = [];
      var hist = this._history[nick];
      hist.push({ text: text, ts: now });

      // Duplicate text detection
      var cKey = nick + '|||' + text;
      if (this._counterMap[cKey]) {
        var ce = this._counterMap[cKey];
        ce.count++;
        ce.lastTs = now;
        return { action: 'collapse', count: ce.count, counterEntry: ce };
      }

      // Rate limit: >3 msgs in 5s
      var recent = 0;
      for (var i = 0; i < hist.length; i++) {
        if (now - hist[i].ts < 5000) recent++;
      }
      if (recent > 3) {
        // Collapse into last message
        if (this._lastMsgByNick[nick]) {
          return { action: 'collapse', count: recent, counterEntry: null, rateLimit: true };
        }
        return { action: 'hide', count: recent };
      }

      // Normal message — register for future duplicate detection
      this._counterMap[cKey] = { el: null, count: 1, lastTs: now };
      return { action: 'show', count: 1, counterKey: cKey };
    },

    setElement: function (cKey, el) {
      if (cKey && this._counterMap[cKey]) {
        this._counterMap[cKey].el = el;
      }
    },

    setLastElement: function (nick, el) {
      this._lastMsgByNick[nick] = el;
    },

    getLastElement: function (nick) {
      return this._lastMsgByNick[nick] || null;
    },

    reset: function () {
      this._history = {};
      this._lastMsgByNick = {};
      this._counterMap = {};
    }
  };

  // ── User Blocking ─────────────────────────────────────────
  var _BlockList = {
    _set: {},

    init: function () {
      try {
        var raw = localStorage.getItem('sp_chat_blocks');
        if (raw) {
          var arr = JSON.parse(raw);
          if (arr && arr.length) {
            for (var i = 0; i < arr.length; i++) {
              this._set[arr[i].toLowerCase()] = arr[i];
            }
          }
        }
      } catch (e) { /* ignore */ }
    },

    _save: function () {
      try {
        var list = this.getList();
        localStorage.setItem('sp_chat_blocks', JSON.stringify(list));
      } catch (e) { /* ignore */ }
    },

    block: function (nick) {
      var base = _baseNick(nick);
      if (!base) return;
      this._set[base.toLowerCase()] = base;
      this._save();
    },

    unblock: function (nick) {
      delete this._set[_baseNick(nick).toLowerCase()];
      this._save();
    },

    isBlocked: function (nick) {
      return !!this._set[_baseNick(nick).toLowerCase()];
    },

    getList: function () {
      var out = [];
      var keys = Object.keys(this._set);
      for (var i = 0; i < keys.length; i++) {
        out.push(this._set[keys[i]]);
      }
      return out;
    }
  };

  // ── Context Menu ──────────────────────────────────────────
  var _ContextMenu = {
    _el: null,
    _dismissHandler: null,

    show: function (x, y, nick, msgText) {
      this.hide();

      var menu = document.createElement('div');
      menu.className = 'sp-chat-ctx';
      menu.style.left = x + 'px';
      menu.style.top = y + 'px';

      var baseName = _baseNick(nick);
      var isSelf = baseName.toLowerCase() === _nick.toLowerCase();
      var isBlocked = _BlockList.isBlocked(nick);

      // Block/Unblock option (hidden for self)
      if (!isSelf) {
        var blockItem = document.createElement('div');
        blockItem.className = 'sp-chat-ctx-item';
        blockItem.textContent = isBlocked ? 'Unblock ' + baseName : 'Block ' + baseName;
        blockItem.addEventListener('click', function (e) {
          e.stopPropagation();
          if (isBlocked) {
            _BlockList.unblock(nick);
            _showUnblockedMessages(nick);
            ChatWidget._addSystemMsg(baseName + ' has been unblocked.');
          } else {
            _BlockList.block(nick);
            _hideBlockedMessages(nick);
            ChatWidget._addSystemMsg(baseName + ' has been blocked.');
          }
          _ContextMenu.hide();
        });
        menu.appendChild(blockItem);
      }

      // Report option
      var reportItem = document.createElement('div');
      reportItem.className = 'sp-chat-ctx-item sp-chat-ctx-report';
      reportItem.textContent = 'Report Message';
      reportItem.addEventListener('click', function (e) {
        e.stopPropagation();
        if (_ws && _connected) {
          try {
            _ws.send(JSON.stringify({ type: 'report', targetNick: nick, messageText: msgText }));
            ChatWidget._addSystemMsg('Report sent for ' + nick + '.');
          } catch (err) { /* ignore */ }
        } else {
          ChatWidget._addSystemMsg('Cannot report \u2014 not connected.');
        }
        _ContextMenu.hide();
      });
      menu.appendChild(reportItem);

      document.body.appendChild(menu);
      this._el = menu;

      // Clamp to viewport
      var rect = menu.getBoundingClientRect();
      if (rect.right > window.innerWidth) {
        menu.style.left = (window.innerWidth - rect.width - 4) + 'px';
      }
      if (rect.bottom > window.innerHeight) {
        menu.style.top = (window.innerHeight - rect.height - 4) + 'px';
      }

      var self = this;
      this._dismissHandler = function () { self.hide(); };
      setTimeout(function () {
        document.addEventListener('click', self._dismissHandler);
        document.addEventListener('contextmenu', self._dismissHandler);
      }, 0);
    },

    hide: function () {
      if (this._el && this._el.parentNode) {
        this._el.parentNode.removeChild(this._el);
      }
      this._el = null;
      if (this._dismissHandler) {
        document.removeEventListener('click', this._dismissHandler);
        document.removeEventListener('contextmenu', this._dismissHandler);
        this._dismissHandler = null;
      }
    }
  };

  var ChatWidget = {

    init: function () {
      if (_initialized) return;
      _initialized = true;
      _nick = _loadIdentity();
      _ProfanityFilter.init();
      _BlockList.init();
      _chatMuted = _loadMuteState();
      try { _teamCode = localStorage.getItem(STORAGE_KEY_TEAM) || ''; } catch (e) { /* ignore */ }
      this._injectCSS();
      this._createDOM();
      this._setupKeys();
      if (_teamCode && _teamCodeInput) _teamCodeInput.value = _teamCode;
      if (_chatMuted) this._showMuteBanner();

      // Reconnect when tab becomes visible (browser may kill WS in background)
      var selfWidget = this;
      document.addEventListener('visibilitychange', function () {
        if (!document.hidden && !_firstConnect && !_connected && !_ws && !_reconnectTimer) {
          selfWidget._doConnect();
        }
      });
    },

    /** Update nickname (called from game nick sync). */
    setNick: function (nick) {
      // Don't override persistent identity with game nick
      // Game nick is separate from chat identity
    },

    /** Set clan tag prefix (shown before nick in chat and game). */
    setClanTag: function (tag) {
      tag = (tag || '').trim();
      if (tag === _clanTag) return;
      _clanTag = tag;
      this._updateNickDisplay();
      // Notify server of display name change
      if (_ws && _connected) {
        try { _ws.send(JSON.stringify({ type: 'nick', nick: _displayNick() })); } catch (e) { /* connection lost */ }
      }
    },

    /** Connect to the chat server. */
    connect: function () {
      if (_ws) return;
      this._doConnect();
    },

    /** Disconnect from chat. */
    disconnect: function () {
      this._stopPing();
      if (_reconnectTimer) {
        clearTimeout(_reconnectTimer);
        _reconnectTimer = null;
      }
      if (_ws) {
        _ws.close(1000, 'user disconnect');
        _ws = null;
      }
      _connected = false;
      this._updateStatus();
    },

    /** Toggle chat visibility. */
    toggleVisibility: function () {
      _chatVisible = !_chatVisible;
      if (_container) {
        _container.style.display = _chatVisible ? '' : 'none';
      }
    },

    isOpen: function () { return _chatOpen; },

    // ═════════════════════════════════════════════════════════
    //  CSS
    // ═════════════════════════════════════════════════════════

    _injectCSS: function () {
      if (document.getElementById('sp-chat-css')) return;
      var s = document.createElement('style');
      s.id = 'sp-chat-css';
      s.textContent = [
        // Container
        '#sp-chat{position:fixed;bottom:60px;left:14px;width:400px;z-index:' + Z_INDEX + ';font-family:"Segoe UI",-apple-system,sans-serif;pointer-events:auto;display:flex;flex-direction:column;transition:opacity .3s}',
        '#sp-chat.sp-chat-faded .sp-chat-msgs{opacity:.25}',
        '#sp-chat.sp-chat-faded .sp-chat-head{opacity:.35}',
        '#sp-chat:hover .sp-chat-msgs,#sp-chat:hover .sp-chat-head{opacity:1!important}',

        // Header
        '.sp-chat-head{display:flex;align-items:center;gap:6px;padding:5px 8px;background:rgba(8,8,24,.85);border:1px solid rgba(57,255,20,.18);border-bottom:none;border-radius:8px 8px 0 0;user-select:none;transition:opacity .3s}',
        '.sp-chat-tab{font-size:10px;text-transform:uppercase;letter-spacing:.5px;padding:3px 8px;border-radius:4px;cursor:pointer;color:rgba(255,255,255,.4);transition:all .15s}',
        '.sp-chat-tab:hover{color:rgba(255,255,255,.7)}',
        '.sp-chat-tab.active{background:rgba(57,255,20,.15);color:#39ff14}',
        '.sp-chat-online{margin-left:auto;font-size:9px;color:rgba(255,255,255,.3)}',
        '.sp-chat-dot{display:inline-block;width:6px;height:6px;border-radius:50%;margin-right:3px;vertical-align:middle}',
        '.sp-chat-dot.on{background:#39ff14;box-shadow:0 0 4px rgba(57,255,20,.5)}',
        '.sp-chat-dot.off{background:#ff4757}',

        // Nick display in header
        '.sp-chat-nick-display{font-size:9px;color:rgba(57,255,20,.6);max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;border-bottom:1px dotted rgba(57,255,20,.25);transition:color .15s}',
        '.sp-chat-nick-display:hover{color:#39ff14}',

        // Messages area
        '.sp-chat-msgs{max-height:180px;overflow-y:auto;overflow-x:hidden;padding:6px 8px;background:rgba(8,8,24,.72);border-left:1px solid rgba(57,255,20,.1);border-right:1px solid rgba(57,255,20,.1);transition:opacity .3s;scrollbar-width:thin;scrollbar-color:rgba(57,255,20,.2) transparent}',
        '.sp-chat-msgs::-webkit-scrollbar{width:4px}',
        '.sp-chat-msgs::-webkit-scrollbar-thumb{background:rgba(57,255,20,.2);border-radius:2px}',

        // Message line
        '.sp-chat-msg{font-size:12px;line-height:1.4;padding:1px 0;word-wrap:break-word}',
        '.sp-chat-msg .cn{font-weight:700;margin-right:4px}',
        '.sp-chat-msg .ct{color:rgba(255,255,255,.85)}',
        '.sp-chat-msg.sys{font-size:10px;color:rgba(255,255,255,.35);font-style:italic;padding:2px 0}',
        '.sp-chat-msg.sys .cn{color:rgba(57,255,20,.4)}',
        '.sp-chat-msg.welcome{background:rgba(57,255,20,.04);border-radius:4px;padding:4px 6px;margin:3px 0}',
        '.sp-chat-msg.welcome .ct{color:rgba(57,255,20,.7);font-size:11px}',

        // Timestamp on hover
        '.sp-chat-ts{display:none;font-size:8px;color:rgba(255,255,255,.15);margin-left:4px}',
        '.sp-chat-msg:hover .sp-chat-ts{display:inline}',

        // History separator
        '.sp-chat-sep{text-align:center;font-size:9px;color:rgba(255,255,255,.15);padding:4px 0;border-top:1px solid rgba(255,255,255,.04);margin:2px 0}',

        // Input
        '.sp-chat-input-wrap{display:flex;background:rgba(8,8,24,.88);border:1px solid rgba(57,255,20,.2);border-radius:0 0 8px 8px;overflow:hidden}',
        '.sp-chat-input-wrap.sp-chat-closed{border-radius:8px;border:1px solid rgba(255,255,255,.06)}',
        '#sp-chat-input{flex:1;background:transparent;border:none;outline:none;color:#fff;font-size:12px;padding:6px 8px;font-family:inherit}',
        '#sp-chat-input::placeholder{color:rgba(255,255,255,.25)}',

        // Team code input
        '.sp-chat-team-wrap{display:none;padding:4px 8px;background:rgba(8,8,24,.75);border-left:1px solid rgba(57,255,20,.1);border-right:1px solid rgba(57,255,20,.1)}',
        '.sp-chat-team-wrap.active{display:flex;align-items:center;gap:6px}',
        '.sp-chat-team-label{font-size:9px;color:rgba(255,255,255,.3);text-transform:uppercase;letter-spacing:.5px}',
        '#sp-chat-team-code{background:rgba(255,255,255,.06);border:1px solid rgba(57,255,20,.15);border-radius:4px;color:#39ff14;font-size:11px;padding:2px 6px;width:80px;outline:none;font-family:"Consolas","SF Mono",monospace;text-transform:uppercase}',
        '#sp-chat-team-code::placeholder{color:rgba(57,255,20,.2)}',

        '/* Context menu */',
        '.sp-chat-ctx{position:fixed;background:rgba(15,15,35,.95);border:1px solid rgba(57,255,20,.2);border-radius:6px;padding:4px 0;z-index:1000020;min-width:140px;box-shadow:0 4px 16px rgba(0,0,0,.5)}',
        '.sp-chat-ctx-item{padding:6px 12px;font-size:11px;color:rgba(255,255,255,.8);cursor:pointer;transition:background .1s}',
        '.sp-chat-ctx-item:hover{background:rgba(57,255,20,.1);color:#39ff14}',
        '.sp-chat-ctx-report{color:rgba(255,165,2,.8)}',
        '.sp-chat-ctx-report:hover{background:rgba(255,165,2,.1);color:#ffa502}',
        '/* Blocked */',
        '.sp-chat-blocked{font-size:9px!important;color:rgba(255,255,255,.12)!important;font-style:italic;cursor:pointer}',
        '.sp-chat-blocked:hover{color:rgba(255,255,255,.25)!important}',
        '/* Link warn */',
        '.sp-chat-link-warn{font-size:9px;color:#ffa502;margin-left:4px;opacity:.6}',
        '/* Muted banner */',
        '.sp-chat-muted-banner{text-align:center;padding:12px;font-size:10px;color:rgba(255,255,255,.2)}',
        '/* Spam counter */',
        '.sp-chat-count{font-size:9px;color:rgba(57,255,20,.5);margin-left:4px;font-weight:400}',
        '/* Help command chips */',
        '.sp-chat-help-row{display:flex;flex-wrap:wrap;gap:4px;margin:3px 0}',
        '.sp-chat-help-chip{display:inline-block;padding:3px 8px;border-radius:4px;font-size:10px;font-family:inherit;cursor:pointer;border:1px solid rgba(57,255,20,.2);background:rgba(57,255,20,.06);color:rgba(57,255,20,.7);transition:all .15s;white-space:nowrap}',
        '.sp-chat-help-chip:hover{background:rgba(57,255,20,.15);color:#39ff14;border-color:rgba(57,255,20,.4)}',
        '/* Minimize button */',
        '.sp-chat-minimize{margin-left:6px;cursor:pointer;font-size:14px;color:rgba(255,255,255,.3);width:18px;height:18px;display:flex;align-items:center;justify-content:center;border-radius:3px;transition:all .15s;user-select:none;flex-shrink:0}',
        '.sp-chat-minimize:hover{color:rgba(255,255,255,.7);background:rgba(255,255,255,.06)}',
        '/* Minimized state */',
        '#sp-chat.sp-chat-minimized .sp-chat-msgs,#sp-chat.sp-chat-minimized .sp-chat-team-wrap,#sp-chat.sp-chat-minimized .sp-chat-input-wrap,#sp-chat.sp-chat-minimized .sp-chat-srv-panel{display:none}',
        '#sp-chat.sp-chat-minimized .sp-chat-head{border-radius:8px;border-bottom:1px solid rgba(57,255,20,.18)}',
        '/* Server selector */',
        '.sp-chat-srv-btn{font-size:10px;cursor:pointer;color:rgba(57,255,20,.55);height:22px;padding:0 8px;display:flex;align-items:center;justify-content:center;gap:4px;border-radius:4px;transition:all .15s;user-select:none;flex-shrink:0;border:1px solid rgba(57,255,20,.15);background:rgba(57,255,20,.04);margin:0 2px;letter-spacing:.3px}',
        '.sp-chat-srv-btn:hover{color:#39ff14;background:rgba(57,255,20,.12);border-color:rgba(57,255,20,.3)}',
        '.sp-chat-srv-btn.active{color:#39ff14;background:rgba(57,255,20,.15);border-color:rgba(57,255,20,.4);box-shadow:0 0 6px rgba(57,255,20,.15)}',
        '.sp-chat-srv-panel{position:absolute;bottom:100%;left:0;right:0;background:rgba(8,8,24,.92);border:1px solid rgba(57,255,20,.2);border-radius:8px 8px 0 0;margin-bottom:-1px;z-index:1;display:none;flex-direction:column}',
        '.sp-chat-srv-panel.open{display:flex}',
        '.sp-chat-srv-title{display:flex;align-items:center;justify-content:space-between;padding:6px 10px;font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:rgba(57,255,20,.6);border-bottom:1px solid rgba(57,255,20,.1)}',
        '.sp-chat-srv-close{cursor:pointer;color:rgba(255,255,255,.3);font-size:14px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;border-radius:3px;transition:all .15s}',
        '.sp-chat-srv-close:hover{color:rgba(255,255,255,.7);background:rgba(255,255,255,.06)}',
        '.sp-chat-srv-list{max-height:240px;overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:rgba(57,255,20,.2) transparent}',
        '.sp-chat-srv-list::-webkit-scrollbar{width:4px}',
        '.sp-chat-srv-list::-webkit-scrollbar-thumb{background:rgba(57,255,20,.2);border-radius:2px}',
        '.sp-chat-srv-item{display:flex;align-items:center;padding:5px 10px;font-size:11px;color:rgba(255,255,255,.65);cursor:pointer;transition:background .12s;gap:6px;border-left:3px solid transparent}',
        '.sp-chat-srv-item:hover{background:rgba(57,255,20,.06);color:rgba(255,255,255,.9)}',
        '.sp-chat-srv-item.active{border-left-color:#39ff14;background:rgba(57,255,20,.05)}',
        '.sp-chat-srv-item .srv-ip{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:"Consolas","SF Mono",monospace;font-size:10px}',
        '.sp-chat-srv-item .srv-players{font-size:9px;color:rgba(57,255,20,.5);white-space:nowrap}',
        '.sp-chat-srv-item .srv-go{font-size:9px;padding:2px 6px;border-radius:3px;background:rgba(57,255,20,.1);color:rgba(57,255,20,.7);border:1px solid rgba(57,255,20,.15);cursor:pointer;transition:all .12s;white-space:nowrap}',
        '.sp-chat-srv-item .srv-go:hover{background:rgba(57,255,20,.2);color:#39ff14;border-color:rgba(57,255,20,.3)}',
        '.sp-chat-srv-empty{padding:12px;text-align:center;font-size:10px;color:rgba(255,255,255,.25);font-style:italic}',
        '/* Server search */',
        '.sp-chat-srv-search-wrap{padding:5px 8px;border-bottom:1px solid rgba(57,255,20,.08)}',
        '.sp-chat-srv-search{width:100%;background:rgba(255,255,255,.05);border:1px solid rgba(57,255,20,.12);border-radius:4px;color:#fff;font-size:11px;padding:5px 8px;outline:none;font-family:inherit;box-sizing:border-box}',
        '.sp-chat-srv-search::placeholder{color:rgba(255,255,255,.2)}',
        '.sp-chat-srv-search:focus{border-color:rgba(57,255,20,.3);background:rgba(255,255,255,.07)}',
        '.sp-chat-srv-count{padding:2px 10px 4px;font-size:9px;color:rgba(255,255,255,.2);border-bottom:1px solid rgba(57,255,20,.05)}'
      ].join('\n');
      document.head.appendChild(s);
    },

    // ═════════════════════════════════════════════════════════
    //  DOM
    // ═════════════════════════════════════════════════════════

    _createDOM: function () {
      var self = this;

      _container = document.createElement('div');
      _container.id = 'sp-chat';

      // ── Header ────────────────────────────────────────────
      _headerEl = document.createElement('div');
      _headerEl.className = 'sp-chat-head';

      _tabGlobalEl = document.createElement('span');
      _tabGlobalEl.className = 'sp-chat-tab active';
      _tabGlobalEl.textContent = 'Global';
      _tabGlobalEl.addEventListener('click', function () { self._switchRoom('global'); });

      _tabTeamEl = document.createElement('span');
      _tabTeamEl.className = 'sp-chat-tab';
      _tabTeamEl.textContent = 'Team';
      _tabTeamEl.addEventListener('click', function () { self._switchRoom('team'); });

      // Nick display (clickable to edit)
      _nickDisplayEl = document.createElement('span');
      _nickDisplayEl.className = 'sp-chat-nick-display';
      _nickDisplayEl.textContent = _displayNick();
      _nickDisplayEl.title = 'Click to change nickname (or type /nick Name)';
      _nickDisplayEl.addEventListener('click', function () {
        self._openChat();
        _inputEl.value = '/nick ';
      });

      // Server selector button
      _serverBtnEl = document.createElement('span');
      _serverBtnEl.className = 'sp-chat-srv-btn';
      _serverBtnEl.innerHTML = '&#x26A1; Servers';
      _serverBtnEl.title = 'Browse & switch servers';
      _serverBtnEl.addEventListener('click', function (e) {
        e.stopPropagation();
        self._toggleServerPanel();
      });

      _onlineEl = document.createElement('span');
      _onlineEl.className = 'sp-chat-online';
      _onlineEl.innerHTML = '<span class="sp-chat-dot off"></span>...';

      // Minimize / expand button
      var minimizeBtn = document.createElement('span');
      minimizeBtn.className = 'sp-chat-minimize';
      minimizeBtn.textContent = '\u2013';  // en-dash as minus icon
      minimizeBtn.title = 'Minimize chat';
      minimizeBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        _chatMinimized = !_chatMinimized;
        if (_chatMinimized) {
          _container.classList.add('sp-chat-minimized');
          minimizeBtn.textContent = '+';
          minimizeBtn.title = 'Expand chat';
        } else {
          _container.classList.remove('sp-chat-minimized');
          minimizeBtn.textContent = '\u2013';
          minimizeBtn.title = 'Minimize chat';
        }
        // Notify HUD to reposition widgets above chat
        var hud = window.SlitherPro && window.SlitherPro.HudManager;
        if (hud && hud._clampAllPositions) {
          setTimeout(function () { hud._clampAllPositions(); }, 50);
        }
      });

      _headerEl.appendChild(_tabGlobalEl);
      _headerEl.appendChild(_tabTeamEl);
      _headerEl.appendChild(_nickDisplayEl);
      _headerEl.appendChild(_serverBtnEl);
      _headerEl.appendChild(_onlineEl);
      _headerEl.appendChild(minimizeBtn);

      // ── Server Panel (hidden by default, above header) ────
      _serverPanelEl = document.createElement('div');
      _serverPanelEl.className = 'sp-chat-srv-panel';

      var srvTitle = document.createElement('div');
      srvTitle.className = 'sp-chat-srv-title';

      var srvLabel = document.createElement('span');
      srvLabel.textContent = 'SERVERS';

      var srvClose = document.createElement('span');
      srvClose.className = 'sp-chat-srv-close';
      srvClose.textContent = '\u00D7'; // multiplication sign as X
      srvClose.addEventListener('click', function (e) {
        e.stopPropagation();
        self._closeServerPanel();
      });

      srvTitle.appendChild(srvLabel);
      srvTitle.appendChild(srvClose);
      _serverPanelEl.appendChild(srvTitle);

      // Search input — aggressive event isolation so game keyboard
      // handlers (both capture and bubble phase) can't steal keys
      var srvSearchWrap = document.createElement('div');
      srvSearchWrap.className = 'sp-chat-srv-search-wrap';
      var srvSearchInput = document.createElement('input');
      srvSearchInput.className = 'sp-chat-srv-search';
      srvSearchInput.type = 'text';
      srvSearchInput.placeholder = 'Search servers...';
      srvSearchInput.autocomplete = 'off';
      var _stopKey = function (e) { e.stopPropagation(); e.stopImmediatePropagation(); };
      srvSearchInput.addEventListener('keydown', _stopKey, true);
      srvSearchInput.addEventListener('keydown', _stopKey, false);
      srvSearchInput.addEventListener('keyup', _stopKey, true);
      srvSearchInput.addEventListener('keyup', _stopKey, false);
      srvSearchInput.addEventListener('keypress', _stopKey, true);
      srvSearchInput.addEventListener('keypress', _stopKey, false);
      srvSearchInput.addEventListener('mousedown', function (e) { e.stopPropagation(); });
      srvSearchInput.addEventListener('input', function () { self._filterServerList(); });
      srvSearchWrap.appendChild(srvSearchInput);
      _serverPanelEl.appendChild(srvSearchWrap);

      // Server count
      var srvCountEl = document.createElement('div');
      srvCountEl.className = 'sp-chat-srv-count';
      _serverPanelEl.appendChild(srvCountEl);

      var srvList = document.createElement('div');
      srvList.className = 'sp-chat-srv-list';
      _serverPanelEl.appendChild(srvList);

      _container.appendChild(_serverPanelEl);
      _container.appendChild(_headerEl);

      // ── Messages (click to open chat) ─────────────────────
      _messagesEl = document.createElement('div');
      _messagesEl.className = 'sp-chat-msgs';
      _messagesEl.style.cursor = 'pointer';
      _messagesEl.addEventListener('click', function () {
        self._openChat();
      });
      _container.appendChild(_messagesEl);

      // ── Team code input ───────────────────────────────────
      _teamInputWrap = document.createElement('div');
      _teamInputWrap.className = 'sp-chat-team-wrap';

      var teamLabel = document.createElement('span');
      teamLabel.className = 'sp-chat-team-label';
      teamLabel.textContent = 'Room:';

      _teamCodeInput = document.createElement('input');
      _teamCodeInput.id = 'sp-chat-team-code';
      _teamCodeInput.type = 'text';
      _teamCodeInput.maxLength = 12;
      _teamCodeInput.placeholder = 'CODE';
      _teamCodeInput.addEventListener('keydown', function (e) {
        e.stopPropagation();
        if (e.key === 'Enter') {
          var code = _teamCodeInput.value.trim().toUpperCase();
          if (code && code !== _teamCode) {
            _teamCode = code;
            try { localStorage.setItem(STORAGE_KEY_TEAM, code); } catch (e2) { /* ignore */ }
            self._reconnectToRoom('team:' + code);
          }
          _teamCodeInput.blur();
        }
      });
      _teamCodeInput.addEventListener('change', function () {
        var code = _teamCodeInput.value.trim().toUpperCase();
        if (code && code !== _teamCode) {
          _teamCode = code;
          try { localStorage.setItem(STORAGE_KEY_TEAM, code); } catch (err) { /* ignore */ }
          self._reconnectToRoom('team:' + code);
        }
      });

      _teamInputWrap.appendChild(teamLabel);
      _teamInputWrap.appendChild(_teamCodeInput);
      _container.appendChild(_teamInputWrap);

      // ── Input ─────────────────────────────────────────────
      var inputWrap = document.createElement('div');
      inputWrap.className = 'sp-chat-input-wrap';
      inputWrap.style.cursor = 'text';
      inputWrap.addEventListener('click', function () {
        self._openChat();
      });

      _inputEl = document.createElement('input');
      _inputEl.id = 'sp-chat-input';
      _inputEl.type = 'text';
      _inputEl.maxLength = 200;
      _inputEl.placeholder = 'Click or press Enter to chat...';
      _inputEl.autocomplete = 'off';

      _inputEl.addEventListener('keydown', function (e) {
        e.stopPropagation();
        if (e.key === 'Enter') {
          e.preventDefault();
          self._sendMessage();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          self._closeChat();
        }
      });

      _inputEl.addEventListener('focus', function () {
        _chatOpen = true;
        _container.classList.remove('sp-chat-faded');
        self._resetFadeTimer();
      });

      _inputEl.addEventListener('blur', function () {
        _chatOpen = false;
        self._resetFadeTimer();
      });

      inputWrap.appendChild(_inputEl);
      _container.appendChild(inputWrap);

      document.body.appendChild(_container);
    },

    // ═════════════════════════════════════════════════════════
    //  Keyboard
    // ═════════════════════════════════════════════════════════

    _setupKeys: function () {
      var self = this;
      document.addEventListener('keydown', function (e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        if (e.key === 'Enter') {
          e.preventDefault();
          self._openChat();
        }
      });
    },

    _openChat: function () {
      if (!_chatVisible) return;
      _chatOpen = true;
      _container.classList.remove('sp-chat-faded');
      _inputEl.focus();
      this._scrollToBottom();
    },

    _closeChat: function () {
      _chatOpen = false;
      _inputEl.blur();
      _inputEl.value = '';
      this._resetFadeTimer();
    },

    // ═════════════════════════════════════════════════════════
    //  Messaging
    // ═════════════════════════════════════════════════════════

    _sendMessage: function () {
      var text = _inputEl.value.trim();
      if (!text) {
        this._closeChat();
        return;
      }

      // ── /nick command ────────────────────────────────────
      if (text.indexOf('/nick ') === 0 || text === '/nick') {
        var newNick = text.substring(6).trim();
        if (!newNick) {
          this._addSystemMsg('Usage: /nick YourName (max 24 chars)');
          _inputEl.value = '';
          return;
        }
        if (newNick.length > 24) {
          newNick = newNick.substring(0, 24);
        }
        // Validate: alphanumeric + basic punctuation only
        if (!/^[a-zA-Z0-9_\-. ]+$/.test(newNick)) {
          this._addSystemMsg('Name can only contain letters, numbers, spaces, _ - .');
          _inputEl.value = '';
          return;
        }
        if (_ProfanityFilter.test(newNick)) {
          this._addSystemMsg('That nickname contains prohibited language.');
          _inputEl.value = '';
          return;
        }
        var oldNick = _nick;
        _nick = newNick;
        _saveIdentity(_nick);
        this._updateNickDisplay();
        if (_ws && _connected) {
          try { _ws.send(JSON.stringify({ type: 'nick', nick: _displayNick() })); } catch (e) { /* connection lost */ }
        }
        this._addSystemMsg('Nickname changed: ' + oldNick + ' -> ' + _nick);
        _inputEl.value = '';
        return;
      }

      // ── /block command ─────────────────────────────────
      if (text.indexOf('/block ') === 0) {
        var blockTarget = text.substring(7).trim();
        if (!blockTarget) {
          this._addSystemMsg('Usage: /block username');
        } else if (_baseNick(blockTarget).toLowerCase() === _nick.toLowerCase()) {
          this._addSystemMsg('You cannot block yourself.');
        } else {
          _BlockList.block(blockTarget);
          _hideBlockedMessages(blockTarget);
          this._addSystemMsg(_baseNick(blockTarget) + ' has been blocked.');
        }
        _inputEl.value = '';
        return;
      }

      // ── /unblock command ────────────────────────────────
      if (text.indexOf('/unblock ') === 0) {
        var unblockTarget = text.substring(9).trim();
        if (!unblockTarget) {
          this._addSystemMsg('Usage: /unblock username');
        } else {
          _BlockList.unblock(unblockTarget);
          _showUnblockedMessages(unblockTarget);
          this._addSystemMsg(_baseNick(unblockTarget) + ' has been unblocked.');
        }
        _inputEl.value = '';
        return;
      }

      // ── /blocklist command ──────────────────────────────
      if (text === '/blocklist') {
        var list = _BlockList.getList();
        if (list.length === 0) {
          this._addSystemMsg('No blocked users.');
        } else {
          this._addSystemMsg('Blocked: ' + list.join(', '));
        }
        _inputEl.value = '';
        return;
      }

      // ── /clear command ──────────────────────────────────
      if (text === '/clear') {
        _messagesEl.innerHTML = '';
        _messages = [];
        _muteBannerEl = null;                     // DOM reference destroyed by innerHTML clear
        this._addSystemMsg('Chat cleared.');
        if (_chatMuted) this._showMuteBanner();   // restore mute banner
        _inputEl.value = '';
        return;
      }

      // ── /mute command ───────────────────────────────────
      if (text === '/mute') {
        _chatMuted = true;
        _saveMuteState(true);
        this._showMuteBanner();
        this._addSystemMsg('Chat muted. Type /unmute to restore.');
        _inputEl.value = '';
        return;
      }

      // ── /unmute command ─────────────────────────────────
      if (text === '/unmute') {
        _chatMuted = false;
        _saveMuteState(false);
        this._hideMuteBanner();
        this._addSystemMsg('Chat unmuted.');
        _inputEl.value = '';
        return;
      }

      // ── /help command ────────────────────────────────────
      if (text === '/help') {
        this._showHelpPanel();
        _inputEl.value = '';
        return;
      }

      // ── Regular message ──────────────────────────────────
      if (!_connected || !_ws) {
        this._addSystemMsg('Not connected. Reconnecting...');
        this._doConnect();
        return;
      }

      // Local rate limit: max 3 messages per 5 seconds
      var nowSend = Date.now();
      while (_outboundTimestamps.length > 0 && nowSend - _outboundTimestamps[0] > 5000) {
        _outboundTimestamps.shift();
      }
      if (_outboundTimestamps.length >= 3) {
        this._addSystemMsg('Slow down \u2014 max 3 messages per 5 seconds.');
        _inputEl.value = '';
        return;
      }

      // Outbound profanity check
      if (_ProfanityFilter.test(text)) {
        this._addSystemMsg('Message blocked \u2014 contains prohibited language.');
        _inputEl.value = '';
        return;
      }

      // Message length guard (backup for maxLength attribute)
      if (text.length > 200) text = text.substring(0, 200);

      _outboundTimestamps.push(nowSend);
      try { _ws.send(JSON.stringify({ type: 'msg', text: text })); } catch (e) { /* connection lost */ }
      _inputEl.value = '';
      this._resetFadeTimer();
    },

    // ═════════════════════════════════════════════════════════
    //  Nick Colors (deterministic per name)
    // ═════════════════════════════════════════════════════════

    _nickColor: function (nick) {
      var colors = [
        '#39ff14', '#00e5ff', '#ff6b9d', '#ffd93d', '#c084fc',
        '#ff8a50', '#69f0ae', '#40c4ff', '#ff80ab', '#b2ff59',
        '#ea80fc', '#84ffff', '#ffab40', '#a7ffeb', '#f48fb1',
        '#80d8ff', '#ccff90', '#ff9e80', '#b388ff', '#ffe57f'
      ];
      var hash = 0;
      for (var i = 0; i < nick.length; i++) {
        hash = ((hash << 5) - hash) + nick.charCodeAt(i);
        hash = hash & hash; // to 32bit int
      }
      return colors[Math.abs(hash) % colors.length];
    },

    _addMessage: function (nick, text, ts, isHistory) {
      var self = this;

      // 1. Mute check
      if (_chatMuted) return null;

      // 2. Block check — silently hide messages from blocked users
      if (_BlockList.isBlocked(nick)) return null;

      // 2b. Filter profane nicknames
      nick = _ProfanityFilter.filter(nick);

      // 3. Profanity filter
      text = _ProfanityFilter.filter(text);

      // 3b. Incoming message length cap
      if (text.length > 300) text = text.substring(0, 300) + '\u2026';

      // 4. All-caps auto-lowercase
      if (text.length > 6) {
        var upper = 0;
        var letters = 0;
        for (var ci = 0; ci < text.length; ci++) {
          var cc = text[ci];
          if (cc >= 'A' && cc <= 'Z') { upper++; letters++; }
          else if (cc >= 'a' && cc <= 'z') { letters++; }
        }
        if (letters > 0 && (upper / letters) > 0.8) {
          text = text.toLowerCase();
        }
      }

      // 5. Spam guard (skip for history messages)
      var spamResult = null;
      var counterKey = null;
      if (!isHistory) {
        spamResult = _SpamGuard.process(nick, text, ts ? new Date(ts).getTime() : Date.now());
        if (spamResult.action === 'hide') return null;

        if (spamResult.action === 'collapse') {
          // Duplicate text collapse
          if (spamResult.counterEntry && spamResult.counterEntry.el) {
            var badge = spamResult.counterEntry.el.querySelector('.sp-chat-count');
            if (badge) {
              badge.textContent = '(x' + spamResult.count + ')';
            } else {
              badge = document.createElement('span');
              badge.className = 'sp-chat-count';
              badge.textContent = '(x' + spamResult.count + ')';
              spamResult.counterEntry.el.appendChild(badge);
            }
            this._scrollToBottom();
            return spamResult.counterEntry.el;
          }
          // Rate limit collapse — update last msg from this nick
          if (spamResult.rateLimit) {
            var lastEl = _SpamGuard.getLastElement(nick);
            if (lastEl) {
              var rlBadge = lastEl.querySelector('.sp-chat-count');
              if (rlBadge) {
                rlBadge.textContent = '(x' + spamResult.count + ')';
              } else {
                rlBadge = document.createElement('span');
                rlBadge.className = 'sp-chat-count';
                rlBadge.textContent = '(x' + spamResult.count + ')';
                lastEl.appendChild(rlBadge);
              }
              this._scrollToBottom();
              return lastEl;
            }
          }
        }

        if (spamResult.counterKey) {
          counterKey = spamResult.counterKey;
        }
      }

      // 6. Build DOM
      var msgEl = document.createElement('div');
      msgEl.className = 'sp-chat-msg';
      msgEl.setAttribute('data-nick', _baseNick(nick));

      var nickSpan = document.createElement('span');
      nickSpan.className = 'cn';
      nickSpan.textContent = nick + ':';
      nickSpan.style.color = this._nickColor(nick);

      var textSpan = document.createElement('span');
      textSpan.className = 'ct';
      textSpan.textContent = ' ' + text;

      msgEl.appendChild(nickSpan);
      msgEl.appendChild(textSpan);

      // 7. Context menu on nick
      nickSpan.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        e.stopPropagation();
        _ContextMenu.show(e.clientX, e.clientY, nick, text);
      });

      // 8. Link safety — detect URLs
      if (/https?:\/\/|www\./i.test(text)) {
        var warnSpan = document.createElement('span');
        warnSpan.className = 'sp-chat-link-warn';
        warnSpan.textContent = '[link]';
        msgEl.appendChild(warnSpan);
      }

      // Hover timestamp
      if (ts) {
        var tsSpan = document.createElement('span');
        tsSpan.className = 'sp-chat-ts';
        var d = new Date(ts);
        var h = d.getHours();
        var m = d.getMinutes();
        tsSpan.textContent = (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
        msgEl.appendChild(tsSpan);
      }

      _messagesEl.appendChild(msgEl);
      _messages.push(msgEl);
      this._pruneMessages();
      this._scrollToBottom();
      this._resetFadeTimer();
      _container.classList.remove('sp-chat-faded');

      // 9. Register element with spam guard
      if (counterKey) {
        _SpamGuard.setElement(counterKey, msgEl);
      }
      if (!isHistory) {
        _SpamGuard.setLastElement(nick, msgEl);
      }

      return msgEl;
    },

    _addSystemMsg: function (text) {
      var msgEl = document.createElement('div');
      msgEl.className = 'sp-chat-msg sys';
      msgEl.textContent = text;
      _messagesEl.appendChild(msgEl);
      _messages.push(msgEl);
      this._pruneMessages();
      this._scrollToBottom();
    },

    _showHelpPanel: function () {
      var self = this;
      var commands = [
        { label: '/nick',      prefill: '/nick ',      desc: 'Change nickname' },
        { label: '/block',     prefill: '/block ',     desc: 'Block a user' },
        { label: '/unblock',   prefill: '/unblock ',   desc: 'Unblock a user' },
        { label: '/blocklist', run: '/blocklist',      desc: 'Show blocked' },
        { label: '/clear',     run: '/clear',          desc: 'Clear chat' },
        { label: '/mute',      run: _chatMuted ? '/unmute' : '/mute',
                                                       desc: _chatMuted ? 'Unmute chat' : 'Mute chat' }
      ];

      this._addSystemMsg('Available commands:');

      var row = document.createElement('div');
      row.className = 'sp-chat-help-row';

      for (var i = 0; i < commands.length; i++) {
        (function (cmd) {
          var chip = document.createElement('span');
          chip.className = 'sp-chat-help-chip';
          chip.textContent = cmd.label;
          chip.title = cmd.desc;
          chip.addEventListener('click', function () {
            if (cmd.run) {
              // Execute immediately
              _inputEl.value = cmd.run;
              self._sendMessage();
            } else if (cmd.prefill) {
              // Prefill input for user to complete
              self._openChat();
              _inputEl.value = cmd.prefill;
              _inputEl.focus();
            }
          });
          row.appendChild(chip);
        })(commands[i]);
      }

      var wrapEl = document.createElement('div');
      wrapEl.className = 'sp-chat-msg sys';
      wrapEl.appendChild(row);
      _messagesEl.appendChild(wrapEl);
      _messages.push(wrapEl);

      this._addSystemMsg('Right-click a name to block/report.');
      this._scrollToBottom();
    },

    _addWelcome: function () {
      var msgEl = document.createElement('div');
      msgEl.className = 'sp-chat-msg welcome';

      var line1 = document.createElement('span');
      line1.className = 'ct';
      line1.textContent = 'You are ' + _displayNick() + ' \u2014 type /nick to change';
      msgEl.appendChild(line1);
      msgEl.appendChild(document.createElement('br'));

      var line2 = document.createElement('span');
      line2.className = 'ct';
      line2.style.opacity = '0.5';
      line2.style.fontSize = '10px';
      line2.textContent = 'Right-click a name to block/report \u2022 /help for commands';
      msgEl.appendChild(line2);

      _messagesEl.appendChild(msgEl);
      _messages.push(msgEl);
    },

    _addHistorySeparator: function () {
      var sep = document.createElement('div');
      sep.className = 'sp-chat-sep';
      sep.textContent = '\u2014 recent messages \u2014';
      _messagesEl.appendChild(sep);
    },

    _pruneMessages: function () {
      while (_messages.length > MAX_MESSAGES) {
        var old = _messages.shift();
        if (old && old.parentNode) old.parentNode.removeChild(old);
      }
    },

    _scrollToBottom: function () {
      if (_messagesEl) {
        _messagesEl.scrollTop = _messagesEl.scrollHeight;
      }
    },

    // ═════════════════════════════════════════════════════════
    //  Nick Display
    // ═════════════════════════════════════════════════════════

    _updateNickDisplay: function () {
      if (_nickDisplayEl) {
        _nickDisplayEl.textContent = _displayNick();
        _nickDisplayEl.style.color = this._nickColor(_nick);
      }
    },

    // ═════════════════════════════════════════════════════════
    //  Server Panel
    // ═════════════════════════════════════════════════════════

    _toggleServerPanel: function () {
      if (_serverPanelOpen) {
        this._closeServerPanel();
      } else {
        _serverPanelOpen = true;
        _serverPanelEl.classList.add('open');
        _serverBtnEl.classList.add('active');
        this._buildServerList();
      }
    },

    _closeServerPanel: function () {
      _serverPanelOpen = false;
      _serverPanelEl.classList.remove('open');
      _serverBtnEl.classList.remove('active');
    },

    _buildServerList: function () {
      var self = this;
      var listEl = _serverPanelEl.querySelector('.sp-chat-srv-list');
      var countEl = _serverPanelEl.querySelector('.sp-chat-srv-count');
      var searchEl = _serverPanelEl.querySelector('.sp-chat-srv-search');
      if (!listEl) return;
      listEl.innerHTML = '';

      // Clear search on rebuild
      if (searchEl) searchEl.value = '';

      var GameAPI = window.SlitherPro && window.SlitherPro.GameAPI;
      if (!GameAPI) {
        if (countEl) countEl.textContent = '';
        var emptyEl = document.createElement('div');
        emptyEl.className = 'sp-chat-srv-empty';
        emptyEl.textContent = 'Servers not available yet';
        listEl.appendChild(emptyEl);
        return;
      }

      var servers = GameAPI.getServers();
      if (!servers || servers.length === 0) {
        if (countEl) countEl.textContent = '';
        var emptyEl2 = document.createElement('div');
        emptyEl2.className = 'sp-chat-srv-empty';
        emptyEl2.textContent = 'No servers found \u2014 game may still be loading';
        listEl.appendChild(emptyEl2);
        return;
      }

      var current = GameAPI.getCurrentServer();
      var currentSid = current ? current.sid : 0;
      if (countEl) countEl.textContent = servers.length + ' servers \u2022 current: #' + (currentSid || '?');

      for (var i = 0; i < servers.length; i++) {
        (function (srv) {
          var row = document.createElement('div');
          row.className = 'sp-chat-srv-item';
          row.setAttribute('data-sid', srv.sid);
          row.setAttribute('data-search', srv.sid + ' ' + srv.ip);
          if (srv.sid === currentSid) {
            row.classList.add('active');
          }

          var idSpan = document.createElement('span');
          idSpan.className = 'srv-ip';
          idSpan.textContent = '#' + srv.sid;
          idSpan.title = srv.ip + ':' + srv.port;
          row.appendChild(idSpan);

          var playersSpan = document.createElement('span');
          playersSpan.className = 'srv-players';
          playersSpan.textContent = (srv.active || 0) + 'p';
          row.appendChild(playersSpan);

          var goBtn = document.createElement('span');
          goBtn.className = 'srv-go';
          goBtn.textContent = srv.sid === currentSid ? 'current' : 'connect';
          if (srv.sid !== currentSid) {
            goBtn.addEventListener('click', function (e) {
              e.stopPropagation();
              GameAPI.connectToServer(srv.sid);
              self._closeServerPanel();
            });
          }
          row.appendChild(goBtn);

          if (srv.sid !== currentSid) {
            row.addEventListener('click', function () {
              GameAPI.connectToServer(srv.sid);
              self._closeServerPanel();
            });
          }

          listEl.appendChild(row);
        })(servers[i]);
      }
    },

    _filterServerList: function () {
      var searchEl = _serverPanelEl.querySelector('.sp-chat-srv-search');
      var listEl = _serverPanelEl.querySelector('.sp-chat-srv-list');
      var countEl = _serverPanelEl.querySelector('.sp-chat-srv-count');
      if (!searchEl || !listEl) return;

      var query = searchEl.value.trim().toLowerCase();
      var items = listEl.querySelectorAll('.sp-chat-srv-item');
      var shown = 0;

      for (var i = 0; i < items.length; i++) {
        var searchText = (items[i].getAttribute('data-search') || '').toLowerCase();
        if (!query || searchText.indexOf(query) !== -1) {
          items[i].style.display = '';
          shown++;
        } else {
          items[i].style.display = 'none';
        }
      }

      if (countEl) {
        if (query) {
          countEl.textContent = shown + ' of ' + items.length + ' matching "' + searchEl.value.trim() + '"';
        } else {
          countEl.textContent = items.length + ' servers';
        }
      }
    },

    // ═════════════════════════════════════════════════════════
    //  Mute Banner
    // ═════════════════════════════════════════════════════════

    _showMuteBanner: function () {
      if (_muteBannerEl) return;
      _muteBannerEl = document.createElement('div');
      _muteBannerEl.className = 'sp-chat-muted-banner';
      _muteBannerEl.textContent = 'Chat muted \u2014 type /unmute to restore';
      _messagesEl.appendChild(_muteBannerEl);
    },

    _hideMuteBanner: function () {
      if (_muteBannerEl && _muteBannerEl.parentNode) {
        _muteBannerEl.parentNode.removeChild(_muteBannerEl);
      }
      _muteBannerEl = null;
    },

    // ═════════════════════════════════════════════════════════
    //  Fade Timer
    // ═════════════════════════════════════════════════════════

    _resetFadeTimer: function () {
      var self = this;
      if (_fadeTimer) clearTimeout(_fadeTimer);
      _container.classList.remove('sp-chat-faded');

      if (!_chatOpen) {
        _fadeTimer = setTimeout(function () {
          _container.classList.add('sp-chat-faded');
        }, FADE_AFTER_MS);
      }
    },

    // ═════════════════════════════════════════════════════════
    //  Room Switching
    // ═════════════════════════════════════════════════════════

    _switchRoom: function (tab) {
      if (tab === 'team') {
        _tabGlobalEl.classList.remove('active');
        _tabTeamEl.classList.add('active');
        _teamInputWrap.classList.add('active');
        if (_teamCode) {
          this._reconnectToRoom('team:' + _teamCode);
        } else {
          this._addSystemMsg('Enter a team code to join a private room.');
          _teamCodeInput.focus();
        }
      } else {
        _tabTeamEl.classList.remove('active');
        _tabGlobalEl.classList.add('active');
        _teamInputWrap.classList.remove('active');
        this._reconnectToRoom('global');
      }
    },

    _reconnectToRoom: function (newRoom) {
      if (newRoom === _room && _connected) return;
      _room = newRoom;

      _messagesEl.innerHTML = '';
      _messages = [];
      _muteBannerEl = null;
      _SpamGuard.reset();
      if (_chatMuted) { var self = this; setTimeout(function() { self._showMuteBanner(); }, 100); }

      if (_ws) {
        _ws.close(1000, 'room switch');
        _ws = null;
      }
      _connected = false;
      _reconnectDelay = RECONNECT_BASE;
      this._doConnect();
    },

    // ═════════════════════════════════════════════════════════
    //  WebSocket
    // ═════════════════════════════════════════════════════════

    _doConnect: function () {
      var self = this;
      if (_ws) return;

      var url = CHAT_WS_URL + '?room=' + encodeURIComponent(_room) + '&nick=' + encodeURIComponent(_displayNick());

      try {
        _ws = new WebSocket(url);
      } catch (e) {
        console.error('[SlitherPro Chat] WebSocket creation failed:', e);
        self._scheduleReconnect();
        return;
      }

      _ws.onopen = function () {
        _connected = true;
        _reconnectDelay = RECONNECT_BASE;
        self._updateStatus();
        self._startPing();

        if (_firstConnect) {
          _firstConnect = false;
          self._addWelcome();
        } else {
          self._addSystemMsg('Reconnected.');
        }
      };

      _ws.onmessage = function (event) {
        var data;
        try {
          data = JSON.parse(event.data);
        } catch (e) { return; }

        switch (data.type) {
          case 'msg':
            self._addMessage(data.nick || 'Anon', data.text || '', data.ts, false);
            break;

          case 'history':
            if (data.messages && data.messages.length > 0) {
              var sepEl = null;
              var rendered = 0;
              for (var i = 0; i < data.messages.length; i++) {
                var m = data.messages[i];
                if (m.type === 'msg') {
                  if (!sepEl) {
                    self._addHistorySeparator();
                    sepEl = _messagesEl.lastChild;
                  }
                  if (self._addMessage(m.nick || 'Anon', m.text || '', m.ts, true)) {
                    rendered++;
                  }
                }
              }
              // Remove orphan separator if no messages actually rendered
              if (sepEl && rendered === 0 && sepEl.parentNode) {
                sepEl.parentNode.removeChild(sepEl);
              }
            }
            break;

          case 'online':
            _onlineCount = data.online || 0;
            self._updateStatus();
            break;

          case 'nick_ok':
            // Server confirmed nick change — already handled locally
            break;

          case 'error':
            self._addSystemMsg(data.message || 'Unknown error');
            break;

          case 'pong':
            // heartbeat response
            break;
        }
      };

      _ws.onclose = function (event) {
        _ws = null;
        _connected = false;
        self._stopPing();
        self._updateStatus();
        if (event.code !== 1000) {
          self._scheduleReconnect();
        }
      };

      _ws.onerror = function () {
        // onclose fires after this
      };
    },

    _scheduleReconnect: function () {
      var self = this;
      if (_reconnectTimer) return;
      _reconnectTimer = setTimeout(function () {
        _reconnectTimer = null;
        self._doConnect();
      }, _reconnectDelay);
      _reconnectDelay = Math.min(_reconnectDelay * 1.5, RECONNECT_MAX);
    },

    _startPing: function () {
      var self = this;
      this._stopPing();
      _pingTimer = setInterval(function () {
        if (_ws && _connected) {
          try { _ws.send(JSON.stringify({ type: 'ping' })); } catch (e) { /* ignore */ }
        }
      }, PING_INTERVAL);
    },

    _stopPing: function () {
      if (_pingTimer) {
        clearInterval(_pingTimer);
        _pingTimer = null;
      }
    },

    _updateStatus: function () {
      if (!_onlineEl) return;
      _onlineEl.textContent = '';
      var dot = document.createElement('span');
      dot.className = 'sp-chat-dot ' + (_connected ? 'on' : 'off');
      _onlineEl.appendChild(dot);
      _onlineEl.appendChild(document.createTextNode(
        _connected ? ((_onlineCount | 0) + ' online') : 'connecting...'
      ));
      this._updateNickDisplay();
    },

    /**
     * Debug: test server selector integration.
     * Call from console: SlitherPro.ChatWidget.debugServerSelector()
     */
    debugServerSelector: function () {
      var log = function (label, val) {
        console.log('%c[ServerSelector] %c' + label + ':', 'color:#39ff14;font-weight:bold', 'color:#00e5ff', val);
      };
      var warn = function (label, val) {
        console.warn('%c[ServerSelector] %c' + label + ':', 'color:#ffa502;font-weight:bold', 'color:#ff6b9d', val);
      };
      var ok = function (msg) {
        console.log('%c[ServerSelector] \u2713 ' + msg, 'color:#39ff14');
      };
      var fail = function (msg) {
        console.error('%c[ServerSelector] \u2717 ' + msg, 'color:#ff4757');
      };

      console.group('%c\u26A1 Server Selector Debug Report', 'color:#39ff14;font-size:14px;font-weight:bold');

      // 1. Check game globals
      console.group('Game Globals');
      log('window.sos (server list)', window.sos);
      log('window.bso (current server)', window.bso);
      log('window.forcing', window.forcing);
      log('window.connect', typeof window.connect);

      if (window.sos && window.sos.length > 0) {
        ok('Server list exists (' + window.sos.length + ' servers)');
        log('Sample server [0]', window.sos[0]);
        // Check structure
        var s0 = window.sos[0];
        if (s0 && s0.ip) ok('Server has .ip field');
        else fail('Server missing .ip field');
        if (s0 && s0.po !== undefined) ok('Server has .po (port) field');
        else warn('Server missing .po field', s0);
        if (s0 && s0.ac !== undefined) ok('Server has .ac (active players) field');
        else warn('Server missing .ac field', s0);
      } else {
        fail('window.sos is empty or missing — game not fully loaded?');
      }

      if (window.bso) {
        ok('Current server exists: ' + (window.bso.ip || '?') + ':' + (window.bso.po || '?'));
      } else {
        warn('No current server', 'window.bso is null/undefined');
      }

      if (typeof window.connect === 'function') {
        ok('window.connect() is a function');
      } else {
        fail('window.connect is not a function — cannot switch servers');
      }
      console.groupEnd();

      // 2. Check GameAPI methods
      console.group('GameAPI Integration');
      var GameAPI = window.SlitherPro && window.SlitherPro.GameAPI;
      if (!GameAPI) {
        fail('GameAPI not found on SlitherPro');
        console.groupEnd();
        console.groupEnd();
        return;
      }
      ok('GameAPI found');

      var servers = GameAPI.getServers();
      log('getServers() returned', servers);
      log('getServers() count', servers ? servers.length : 0);
      if (servers && servers.length > 0) {
        ok('getServers() returns data (' + servers.length + ' servers)');
        log('First server', servers[0]);
      } else {
        fail('getServers() returned empty — check window.sos');
      }

      var current = GameAPI.getCurrentServer();
      log('getCurrentServer()', current);
      if (current && current.ip) {
        ok('getCurrentServer() returns: ' + current.ip);
      } else {
        warn('getCurrentServer() returned null', 'not connected yet?');
      }

      // Check if connectToServer would work (don't actually call it)
      if (typeof GameAPI.connectToServer === 'function') {
        ok('connectToServer() method exists');
      } else {
        fail('connectToServer() method missing');
      }
      console.groupEnd();

      // 3. Check UI state
      console.group('UI State');
      log('Server panel element', _serverPanelEl ? 'exists' : 'MISSING');
      log('Server button element', _serverBtnEl ? 'exists' : 'MISSING');
      log('Panel open?', _serverPanelOpen);

      var listEl = _serverPanelEl ? _serverPanelEl.querySelector('.sp-chat-srv-list') : null;
      var items = listEl ? listEl.querySelectorAll('.sp-chat-srv-item') : [];
      log('Server items rendered', items.length);
      var activeItems = listEl ? listEl.querySelectorAll('.sp-chat-srv-item.active') : [];
      log('Active (current) items', activeItems.length);
      console.groupEnd();

      // 4. Summary
      console.group('Summary');
      var issues = 0;
      if (!window.sos || window.sos.length === 0) { fail('No server list'); issues++; }
      if (typeof window.connect !== 'function') { fail('Cannot connect'); issues++; }
      if (!GameAPI) { fail('No GameAPI'); issues++; }
      if (issues === 0) {
        ok('All checks passed \u2014 server selector should work!');
      } else {
        warn('Issues found', issues + ' problem(s)');
      }
      console.groupEnd();

      console.groupEnd();
      return { servers: servers, current: current, globals: { sos: !!window.sos, bso: !!window.bso, connect: typeof window.connect } };
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.ChatWidget = ChatWidget;
})();
