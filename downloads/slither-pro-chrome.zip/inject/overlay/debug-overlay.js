/**
 * Slither Pro -- Debug Overlay & Control Panel (v1).
 *
 * Provides:
 *   1. On-screen toggle buttons (Bot, Grid, Minimap, AutoPlay, Debug)
 *   2. Active module status list
 *   3. Real-time bot telemetry panel (goal scores, edge dist, coil, food, etc.)
 *   4. JS-queryable debug API: SlitherPro.Debug.getSnapshot() / getDeathLog()
 *   5. Canvas debug drawing (goal arrow, edge vector, food line)
 *   6. Automatic death recording with cause analysis
 *
 * Toggle: F3 key or click the debug button.
 * All ES5 -- var only, no const/let/arrow/for-of.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;

  /* ── Config ────────────────────────────────────────────── */
  var MAX_HISTORY   = 300;   // state snapshots kept
  var MAX_DEATHS    = 20;    // death records kept
  var SAMPLE_RATE   = 10;    // capture every N frames
  var PANEL_WIDTH   = 320;

  /* ── State ─────────────────────────────────────────────── */
  var _enabled       = false;  // debug panel visible
  var _panelEl       = null;
  var _toggleBarEl   = null;
  var _telemetryEl   = null;
  var _history       = [];
  var _deathLog      = [];
  var _frameCount    = 0;
  var _lastSnapshot  = null;
  var _settings      = null;
  var _injectedCSS   = false;

  /* ── Snapshot of last goal scores (captured by hook) ──── */
  var _goalScores    = null;
  var _chosenGoal    = null;
  var _edgeResult    = null;
  var _boostResult   = null;
  var _coilResult    = null;
  var _foodTarget    = null;

  /* ── Hooks installed flag ──────────────────────────────── */
  var _hooked = false;

  /* ══════════════════════════════════════════════════════════
   *  CSS Injection
   * ══════════════════════════════════════════════════════════ */
  function injectCSS() {
    if (_injectedCSS) return;
    _injectedCSS = true;

    var css = [
      /* Toggle bar — always visible top-center */
      '.sp-toggle-bar{position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:999999;',
      'display:flex;gap:6px;padding:4px 10px;background:rgba(0,0,0,0.75);border-radius:20px;',
      'font-family:monospace;font-size:11px;user-select:none;pointer-events:auto}',

      '.sp-toggle-btn{padding:3px 10px;border-radius:12px;cursor:pointer;color:#aaa;',
      'background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);transition:all .15s}',
      '.sp-toggle-btn:hover{background:rgba(255,255,255,0.12)}',
      '.sp-toggle-btn.sp-on{color:#0f0;border-color:rgba(0,255,0,0.3);background:rgba(0,255,0,0.1)}',
      '.sp-toggle-btn.sp-on-warn{color:#fa0;border-color:rgba(255,170,0,0.3);background:rgba(255,170,0,0.1)}',

      /* Debug telemetry panel — left side */
      '.sp-debug-panel{position:fixed;top:80px;left:8px;z-index:999998;width:' + PANEL_WIDTH + 'px;',
      'max-height:calc(100vh - 100px);overflow-y:auto;background:rgba(0,0,0,0.82);',
      'border:1px solid rgba(0,255,0,0.2);border-radius:8px;padding:8px 10px;',
      'font-family:"Consolas","Courier New",monospace;font-size:11px;color:#ccc;',
      'pointer-events:auto;user-select:text;line-height:1.45}',

      '.sp-debug-panel::-webkit-scrollbar{width:4px}',
      '.sp-debug-panel::-webkit-scrollbar-thumb{background:rgba(0,255,0,0.3);border-radius:2px}',

      '.sp-dbg-section{margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid rgba(255,255,255,0.08)}',
      '.sp-dbg-title{color:#0f0;font-weight:bold;font-size:12px;margin-bottom:3px}',
      '.sp-dbg-row{display:flex;justify-content:space-between;padding:1px 0}',
      '.sp-dbg-label{color:#888}',
      '.sp-dbg-val{color:#eee;text-align:right}',
      '.sp-dbg-val.sp-red{color:#f44}',
      '.sp-dbg-val.sp-green{color:#4f4}',
      '.sp-dbg-val.sp-yellow{color:#ff0}',
      '.sp-dbg-val.sp-cyan{color:#0ff}',
      '.sp-dbg-val.sp-purple{color:#c4f}'
    ].join('\n');

    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  /* ══════════════════════════════════════════════════════════
   *  Toggle Bar (always visible)
   * ══════════════════════════════════════════════════════════ */
  function createToggleBar() {
    if (_toggleBarEl) return;
    injectCSS();

    _toggleBarEl = document.createElement('div');
    _toggleBarEl.className = 'sp-toggle-bar';

    // AutoPlay is a Pro-only bot feature and already surfaces on its
    // own widget; the top bar stays free-tier friendly and instead
    // exposes Auto-Respawn (QoL, free). Grid was removed — the G
    // keybind remains for users who still want it. "Skins" opens the
    // in-game skin picker modal (see inject/overlay/skin-picker.js).
    var buttons = [
      { id: 'bot',      label: 'Bot',      key: 'bot.enabled' },
      { id: 'skins',    label: 'Skins',    key: '_skins' },
      { id: 'minimap',  label: 'Map',      key: 'hud.minimapEnabled' },
      { id: 'respawn',  label: 'Respawn',  key: 'gameplay.autoRespawn' },
      { id: 'debug',    label: 'Debug',    key: '_debug' },
      { id: 'inputlock',label: 'Lock',     key: 'bot.inputLock' }
    ];

    for (var i = 0; i < buttons.length; i++) {
      var btn = document.createElement('span');
      btn.className = 'sp-toggle-btn';
      btn.textContent = buttons[i].label;
      btn.dataset.spKey = buttons[i].key;
      btn.dataset.spId = buttons[i].id;
      btn.addEventListener('click', onToggleClick);
      _toggleBarEl.appendChild(btn);
    }

    SP.HudRoot.append(_toggleBarEl);
  }

  /** Show subscription CTA via toast + chat system message */
  function _showSubCTA() {
    // Toast
    var toastContainer = document.querySelector('.slither-pro-toast');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'slither-pro-toast';
      SP.HudRoot.append(toastContainer);
    }
    var toast = document.createElement('div');
    toast.className = 'slither-pro-toast-item';
    toast.textContent = 'Pro subscription required';
    toastContainer.appendChild(toast);
    setTimeout(function () {
      toast.classList.add('sp-toast-fade-out');
      toast.style.opacity = '0';  // fallback if CSS class missing
      toast.style.transition = 'opacity .3s ease';
      setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 400);
    }, 2000);

    // Chat CTA
    if (SP.ChatWidget && SP.ChatWidget._addSystemMsg) {
      SP.ChatWidget._addSystemMsg('AI Bot requires a Pro subscription ($2.99/mo). Open the extension popup to subscribe.');
    }
  }

  function onToggleClick(e) {
    var key = e.target.dataset.spKey;
    if (!key || !_settings) return;

    if (key === '_debug') {
      _enabled = !_enabled;
      if (_enabled) showPanel(); else hidePanel();
      syncToggles();
      return;
    }

    // Launcher for the in-game skin picker modal — not a toggle.
    if (key === '_skins') {
      if (SP.SkinPicker && SP.SkinPicker.open) SP.SkinPicker.open();
      return;
    }

    // Navigate settings path (e.g. 'bot.enabled')
    var parts = key.split('.');
    var obj = _settings;
    for (var i = 0; i < parts.length - 1; i++) {
      if (!obj[parts[i]]) return;
      obj = obj[parts[i]];
    }
    var prop = parts[parts.length - 1];
    obj[prop] = !obj[prop];

    // Special handling for bot toggle — subscription gate
    if (key === 'bot.enabled') {
      if (obj[prop]) {
        // Trying to turn ON — check subscription first
        if (!_settings.subscription || !_settings.subscription.active) {
          obj[prop] = false; // revert toggle
          _showSubCTA();
          syncToggles();
          return;
        }
        if (SP.BotController) {
          var started = SP.BotController.start();
          if (!started) {
            obj[prop] = false; // revert toggle
            _showSubCTA();
            syncToggles();
            return;
          }
        }
      } else if (SP.BotController) {
        SP.BotController.stop();
      }
      // Notify popup of bot state change
      if (SP.MessageBus && SP.EVENTS) {
        SP.MessageBus.send(SP.EVENTS.BOT_TOGGLE, { enabled: !!obj[prop] });
      }
    }

    // Special handling for input lock
    if (key === 'bot.inputLock' && SP.GameAPI) {
      if (obj[prop]) {
        SP.GameAPI.blockUserInput();
      } else {
        SP.GameAPI.unblockUserInput();
      }
    }

    // Broadcast so chrome.storage + popup stay in sync. Skipped for
    // the ephemeral _debug toggle which is session-local.
    if (key !== '_debug' && SP.MessageBus && SP.EVENTS) {
      var topKey = parts[0];
      var payload = {};
      payload[topKey] = _settings[topKey];
      SP.MessageBus.send(SP.EVENTS.SETTINGS_UPDATE, payload);
    }

    syncToggles();
  }

  function syncToggles() {
    if (!_toggleBarEl || !_settings) return;
    var btns = _toggleBarEl.querySelectorAll('.sp-toggle-btn');
    for (var i = 0; i < btns.length; i++) {
      var btn = btns[i];
      var key = btn.dataset.spKey;
      var active = false;

      if (key === '_debug') {
        active = _enabled;
      } else {
        var parts = key.split('.');
        var obj = _settings;
        for (var j = 0; j < parts.length; j++) {
          obj = obj ? obj[parts[j]] : undefined;
        }
        active = !!obj;
      }

      btn.classList.toggle('sp-on', active);
      btn.classList.remove('sp-on-warn');
    }
  }

  /* ══════════════════════════════════════════════════════════
   *  Telemetry Panel
   * ══════════════════════════════════════════════════════════ */
  function showPanel() {
    if (_panelEl) { _panelEl.style.display = 'block'; return; }
    _panelEl = document.createElement('div');
    _panelEl.className = 'sp-debug-panel';
    _panelEl.innerHTML = '<div class="sp-dbg-title">DEBUG TELEMETRY</div><div id="sp-dbg-body">Waiting for data...</div>';
    SP.HudRoot.append(_panelEl);
  }

  function hidePanel() {
    if (_panelEl) _panelEl.style.display = 'none';
  }

  function updatePanel() {
    if (!_enabled || !_panelEl) return;

    var snap = _lastSnapshot;
    if (!snap) return;

    var html = [];

    // ── Player ──
    html.push(section('PLAYER', [
      row('State', stateColor(snap.state)),
      row('Length', snap.length),
      row('Position', snap.x + ', ' + snap.y),
      row('Speed', snap.speed),
      row('Angle', snap.angle + ' rad'),
      row('Boosting', snap.boosting ? colorVal('YES', 'sp-yellow') : 'no'),
      row('Phase', snap.phase || '?'),
      row('Rank', snap.serverRank > 0 ? ('#' + snap.serverRank + ' (x' + snap.serverScale.toFixed(1) + ')') : 'n/a'),
      row('Frame', snap.frame)
    ]));

    // ── Edge ──
    var edgeClass = snap.edgeDist < 350 ? 'sp-red' : (snap.edgeDist < 700 ? 'sp-yellow' : 'sp-green');
    html.push(section('EDGE', [
      row('Dist to edge', colorVal(snap.edgeDist, edgeClass)),
      row('Frames to wall', (snap.framesToWall === Infinity || snap.framesToWall === -1) ? 'safe' : colorVal(snap.framesToWall, snap.framesToWall < 30 ? 'sp-red' : 'sp-yellow')),
      row('Edge zone', snap.edgeZone || 'none')
    ]));

    // ── Goal Scores ──
    if (snap.goals) {
      var goalRows = [];
      var goalOrder = ['border', 'safety', 'kill', 'deathFood', 'food', 'coil'];
      for (var gi = 0; gi < goalOrder.length; gi++) {
        var tag = goalOrder[gi];
        var g = snap.goals[tag];
        if (g) {
          var isWinner = (snap.chosenTag === tag);
          var scoreStr = g.score.toFixed(2);
          if (isWinner) scoreStr = '>> ' + scoreStr + ' <<';
          goalRows.push(row(tag, colorVal(scoreStr, isWinner ? 'sp-green' : (g.score > 0 ? 'sp-cyan' : ''))));
        }
      }
      html.push(section('GOAL SCORES', goalRows));
    }

    // ── Commitment ──
    html.push(section('COMMITMENT', [
      row('Locked tag', snap.lockedTag || 'none'),
      row('Ticks left', snap.commitLeft || 0),
      row('Chosen tag', snap.chosenTag || 'none')
    ]));

    // ── Boost ──
    if (snap.boost) {
      html.push(section('BOOST', [
        row('Active', snap.boost.active ? colorVal('YES', 'sp-yellow') : 'no'),
        row('Reason', snap.boost.reason || '?')
      ]));
    }

    // ── Coil ──
    if (snap.coil) {
      var coilRows = [];
      if (snap.coil.offensive) {
        coilRows.push(row('Offensive', colorVal('ACTIVE', 'sp-purple')));
        coilRows.push(row('Target ID', snap.coil.offensive.targetId || '?'));
        coilRows.push(row('Orbit R', snap.coil.offensive.orbitRadius || '?'));
      }
      if (snap.coil.defensive) {
        var sev = snap.coil.defensive.severity || 0;
        coilRows.push(row('Defensive', colorVal('SEV ' + sev, sev >= 3 ? 'sp-red' : 'sp-yellow')));
        coilRows.push(row('Tightness', snap.coil.defensive.tightness || '?'));
        coilRows.push(row('Tight Rate', snap.coil.defensive.tightnessRate || 0));
        coilRows.push(row('Survival', snap.coil.defensive.survivalMode ? colorVal('YES', 'sp-red') : 'no'));
      }
      if (coilRows.length === 0) coilRows.push(row('Status', 'none'));
      html.push(section('COIL', coilRows));
    }

    // ── Food Target ──
    if (snap.food) {
      html.push(section('FOOD TARGET', [
        row('Score', snap.food.score ? snap.food.score.toFixed(2) : '0'),
        row('Dist', snap.food.dist ? Math.round(snap.food.dist) : '?'),
        row('Safety', snap.food.safety ? snap.food.safety.toFixed(2) : '?'),
        row('Large food', snap.food.hasLargeFood ? 'YES' : 'no'),
        row('Waypoint', snap.food.isWaypoint ? 'YES' : 'no')
      ]));
    }

    // ── Nearby Snakes ──
    html.push(section('ENVIRONMENT', [
      row('Nearby snakes', snap.nearbyCount || 0),
      row('Collision mag', snap.avoidMag ? snap.avoidMag.toFixed(2) : '0'),
      row('Norm. mag', snap.avoidMag ? (Math.min(1.5, Math.log(1 + snap.avoidMag) / 1.79)).toFixed(3) : '0'),
      row('Emergency', snap.emergency ? colorVal('YES', 'sp-red') : 'no'),
      row('Turn rate', snap.turnRate ? snap.turnRate.toFixed(4) : '?'),
      row('Min turn R', snap.minTurnR ? Math.round(snap.minTurnR) : '?'),
      row('Game score', snap.gameScore || '?')
    ]));

    // ── Death Log ──
    if (_deathLog.length > 0) {
      var deathRows = [];
      var showDeaths = Math.min(5, _deathLog.length);
      for (var di = _deathLog.length - 1; di >= _deathLog.length - showDeaths; di--) {
        var d = _deathLog[di];
        deathRows.push(row('#' + (di + 1) + ' L=' + d.length,
          colorVal(d.cause + ' @' + d.edgeDist, d.cause === 'WALL' ? 'sp-red' : 'sp-yellow')));
      }
      html.push(section('DEATH LOG (' + _deathLog.length + ')', deathRows));
    }

    var body = _panelEl.querySelector('#sp-dbg-body') || _panelEl;
    body.innerHTML = html.join('');
  }

  function section(title, rows) {
    return '<div class="sp-dbg-section"><div class="sp-dbg-title">' + title + '</div>' + rows.join('') + '</div>';
  }

  function _escHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function row(label, value) {
    return '<div class="sp-dbg-row"><span class="sp-dbg-label">' + _escHtml(label) + '</span><span class="sp-dbg-val">' + value + '</span></div>';
  }

  function colorVal(text, cls) {
    var safe = _escHtml(text);
    if (!cls) return safe;
    return '<span class="' + cls + '">' + safe + '</span>';
  }

  function stateColor(state) {
    var colors = {
      IDLE: '', FOOD: 'sp-cyan', KILL: 'sp-red', SAFETY: 'sp-red',
      BORDER: 'sp-red', DEATH_FOOD: 'sp-yellow', COIL: 'sp-purple', WANDER: 'sp-cyan'
    };
    return colorVal(state || 'IDLE', colors[state] || '');
  }

  /* ══════════════════════════════════════════════════════════
   *  Data Capture (called each frame from inject.js)
   * ══════════════════════════════════════════════════════════ */
  function captureSnapshot() {
    _frameCount++;
    if (_frameCount % SAMPLE_RATE !== 0) return;

    var GameAPI = SP.GameAPI;
    var BC = SP.BotController;
    var MathUtil = SP.MathUtil;
    if (!GameAPI || !BC) return;

    var snake = GameAPI.getPlayerSnake();
    var pos = GameAPI.getPlayerPosition();
    var mapR = GameAPI.getMapRadius ? GameAPI.getMapRadius() : 0;
    if (!snake || !pos) return;

    var distCenter = mapR > 0 ? Math.sqrt(
      (pos.x - mapR) * (pos.x - mapR) + (pos.y - mapR) * (pos.y - mapR)
    ) : 0;
    var edgeDist = mapR > 0 ? Math.round(mapR - distCenter) : 9999;

    // Frames to wall
    var framesToWall = Infinity;
    if (MathUtil && MathUtil.framesToWallCollision && mapR > 0) {
      framesToWall = MathUtil.framesToWallCollision(
        pos.x, pos.y, snake.angle || 0, snake.speed || 8, mapR, !!snake.boosting
      );
      if (framesToWall !== Infinity) framesToWall = Math.round(framesToWall);
    }

    // Edge zone
    var edgeZone = 'safe';
    if (edgeDist < 350) edgeZone = 'EMERGENCY';
    else if (edgeDist < 700) edgeZone = 'STRONG';
    else if (edgeDist < 1400) edgeZone = 'GENTLE';

    // Turn rate
    var turnRate = 0;
    var minTurnR = 0;
    if (MathUtil && MathUtil.maxTurnRate) {
      turnRate = MathUtil.maxTurnRate(snake.length || 10);
      minTurnR = MathUtil.minTurningRadius(snake.speed || 8, snake.length || 10);
    }

    // Phase from strategy manager
    var phase = '?';
    var serverRank = 0;
    var serverScale = 1.0;
    if (SP.StrategyManager && SP.StrategyManager.getPhase) {
      phase = SP.StrategyManager.getPhase() || '?';
      serverRank = SP.StrategyManager.getServerRank ? SP.StrategyManager.getServerRank() : 0;
      serverScale = SP.StrategyManager.getServerScale ? SP.StrategyManager.getServerScale() : 1.0;
    }

    // Nearby snakes count
    var nearby = GameAPI.getNearbySnakes ? GameAPI.getNearbySnakes() : [];
    var nearbyCount = nearby ? nearby.length : 0;

    // Build snapshot
    var snap = {
      frame: _frameCount,
      time: Date.now(),
      state: BC.getState(),
      active: BC.isActive(),
      length: snake.length || 0,
      gameScore: snake.score || snake.length || 0,
      sct: snake.sct || 0,
      x: Math.round(pos.x),
      y: Math.round(pos.y),
      speed: snake.speed || 0,
      angle: +(snake.angle || 0).toFixed(2),
      boosting: !!snake.boosting,
      edgeDist: edgeDist,
      framesToWall: framesToWall === Infinity ? -1 : framesToWall,
      edgeZone: edgeZone,
      turnRate: turnRate,
      minTurnR: minTurnR,
      phase: phase,
      serverRank: serverRank,
      serverScale: serverScale,
      nearbyCount: nearbyCount,
      goals: _goalScores,
      chosenTag: _chosenGoal ? _chosenGoal.tag : '',
      lockedTag: _chosenGoal ? (_chosenGoal.lockedTag || '') : '',
      commitLeft: _chosenGoal ? (_chosenGoal.commitLeft || 0) : 0,
      boost: _boostResult,
      coil: _coilResult,
      food: _foodTarget,
      avoidMag: _chosenGoal ? (_chosenGoal.avoidMag || 0) : 0,
      emergency: _chosenGoal ? !!_chosenGoal.emergency : false
    };

    _lastSnapshot = snap;
    _history.push(snap);
    if (_history.length > MAX_HISTORY) _history.shift();
  }

  /* ══════════════════════════════════════════════════════════
   *  Death Recording
   * ══════════════════════════════════════════════════════════ */
  function recordDeath() {
    var lastSnap = _lastSnapshot;
    if (!lastSnap) return;

    var cause = 'UNKNOWN';
    if (lastSnap.edgeDist < 100) {
      cause = 'WALL';
    } else if (lastSnap.state === 'KILL') {
      cause = 'KILL_ATTEMPT';
    } else if (lastSnap.state === 'COIL') {
      cause = 'COIL_ATTEMPT';
    } else if (lastSnap.avoidMag > 0.5) {
      cause = 'COLLISION';
    } else if (lastSnap.emergency) {
      cause = 'EMERGENCY';
    } else {
      cause = 'HEAD_ON';
    }

    // Look at last 5 snapshots for more context
    var lastStates = [];
    var start = Math.max(0, _history.length - 5);
    for (var i = start; i < _history.length; i++) {
      lastStates.push(_history[i].state);
    }

    _deathLog.push({
      time: Date.now(),
      frame: lastSnap.frame,
      length: lastSnap.length,
      cause: cause,
      edgeDist: lastSnap.edgeDist,
      framesToWall: lastSnap.framesToWall,
      state: lastSnap.state,
      chosenTag: lastSnap.chosenTag,
      boosting: lastSnap.boosting,
      lastStates: lastStates,
      x: lastSnap.x,
      y: lastSnap.y
    });

    if (_deathLog.length > MAX_DEATHS) _deathLog.shift();
  }

  /* ══════════════════════════════════════════════════════════
   *  Data Injection Hooks
   *  (Called from bot-controller via Debug.reportGoals() etc.)
   * ══════════════════════════════════════════════════════════ */
  function reportGoals(scores, chosen) {
    _goalScores = scores;
    _chosenGoal = chosen;
  }

  function reportBoost(result) {
    _boostResult = result;
  }

  function reportCoil(result) {
    _coilResult = result;
  }

  function reportFood(target) {
    _foodTarget = target;
  }

  function reportEdge(result) {
    _edgeResult = result;
  }

  /* ══════════════════════════════════════════════════════════
   *  Trajectory Renderer (v10) — visual debug lines on canvas
   *  Draws: goal arrow, food target, avoidance vector
   * ══════════════════════════════════════════════════════════ */
  var STATE_COLORS = {
    food: '#00ff00', safety: '#ffcc00', kill: '#ff3333',
    deathFood: '#00ffff', coil: '#ff00ff', border: '#ffffff', wander: '#666666'
  };

  var TrajectoryRenderer = {
    render: function (ctx, canvas, s) {
      if (!_enabled) return;
      var GameAPI = SP.GameAPI;
      if (!GameAPI || !GameAPI.isPlaying()) return;

      var scale = GameAPI.getScale();
      var view = GameAPI.getViewPosition();
      var player = GameAPI.getPlayerPosition();
      if (!player) return;

      var w = canvas.width;
      var h = canvas.height;
      var px = (player.x - view.x) * scale + w / 2;
      var py = (player.y - view.y) * scale + h / 2;

      ctx.save();

      // ── 1. Goal direction arrow (color = current state) ────
      if (_chosenGoal && (_chosenGoal.dirX || _chosenGoal.dirY)) {
        var color = STATE_COLORS[_chosenGoal.tag] || '#888';
        var arrowLen = 120;
        var ex = px + _chosenGoal.dirX * arrowLen;
        var ey = py + _chosenGoal.dirY * arrowLen;
        var ang = Math.atan2(_chosenGoal.dirY, _chosenGoal.dirX);

        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.globalAlpha = 0.8;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(ex, ey);
        // Arrowhead
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex - 12 * Math.cos(ang - 0.4), ey - 12 * Math.sin(ang - 0.4));
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex - 12 * Math.cos(ang + 0.4), ey - 12 * Math.sin(ang + 0.4));
        ctx.stroke();

        // State label
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.9;
        ctx.font = 'bold 11px monospace';
        ctx.fillText(_chosenGoal.tag.toUpperCase(), ex + 8, ey - 4);
      }

      // ── 2. Avoidance push vector (thin yellow, when active) ──
      if (_chosenGoal && _chosenGoal.avoidMag > 0.5) {
        var ax = _chosenGoal.avoidX || 0;
        var ay = _chosenGoal.avoidY || 0;
        var aMag = Math.sqrt(ax * ax + ay * ay);
        if (aMag > 0) {
          var avoidLen = Math.min(80, 30 + _chosenGoal.avoidMag * 3);
          var aex = px + (ax / aMag) * avoidLen;
          var aey = py + (ay / aMag) * avoidLen;
          ctx.strokeStyle = _chosenGoal.emergency ? '#ff4444' : '#ffaa00';
          ctx.lineWidth = 1.5;
          ctx.globalAlpha = 0.6;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(aex, aey);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }

      // ── 3. Food target marker (dashed green line + circle) ──
      if (_foodTarget && _foodTarget.x && _foodTarget.y) {
        var fx = (_foodTarget.x - view.x) * scale + w / 2;
        var fy = (_foodTarget.y - view.y) * scale + h / 2;
        ctx.strokeStyle = '#00ff00';
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.35;
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(fx, fy);
        ctx.stroke();
        ctx.setLineDash([]);
        // Target circle
        ctx.globalAlpha = 0.6;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(fx, fy, 8, 0, Math.PI * 2);
        ctx.stroke();
      }

      // ── 4. Edge push vector (white, when active) ────────────
      if (_edgeResult && _edgeResult.strength > 0.1) {
        var emag = Math.sqrt((_edgeResult.x || 0) * (_edgeResult.x || 0) + (_edgeResult.y || 0) * (_edgeResult.y || 0));
        if (emag > 0) {
          var edgeLen = 60 * _edgeResult.strength;
          var eex = px + (_edgeResult.x / emag) * edgeLen;
          var eey = py + (_edgeResult.y / emag) * edgeLen;
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.globalAlpha = 0.3 + _edgeResult.strength * 0.5;
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(eex, eey);
          ctx.stroke();
        }
      }

      ctx.restore();
    }
  };

  /* ══════════════════════════════════════════════════════════
   *  Public Debug API (queryable from console / JS tools)
   * ══════════════════════════════════════════════════════════ */
  var DebugOverlay = {

    init: function (s) {
      _settings = s;
      createToggleBar();

      // Listen for death events
      if (SP.GameAPI && SP.GameAPI.onDeath) {
        SP.GameAPI.onDeath(function () {
          recordDeath();
        });
      }
    },

    updateSettings: function (s) {
      _settings = s;
      syncToggles();
    },

    /**
     * Called every frame from inject.js main loop.
     */
    update: function () {
      captureSnapshot();
      syncToggles();
      if (_enabled) updatePanel();
    },

    /**
     * Toggle debug panel visibility.
     */
    toggle: function () {
      _enabled = !_enabled;
      if (_enabled) showPanel(); else hidePanel();
      syncToggles();
    },

    isEnabled: function () {
      return _enabled;
    },

    /* ── Data injection hooks (called from BotController) ── */
    reportGoals: reportGoals,
    reportBoost: reportBoost,
    reportCoil:  reportCoil,
    reportFood:  reportFood,
    reportEdge:  reportEdge,

    /* ── Canvas trajectory renderer (registered with OverlayManager) ── */
    TrajectoryRenderer: TrajectoryRenderer,

    /* ── JS-queryable API ─────────────────────────────────── */

    /**
     * Full snapshot of current bot state. Call from Chrome console:
     *   JSON.stringify(SlitherPro.Debug.getSnapshot(), null, 2)
     */
    getSnapshot: function () {
      return _lastSnapshot;
    },

    /**
     * Last N state snapshots.
     */
    getHistory: function (n) {
      n = n || 20;
      return _history.slice(-n);
    },

    /**
     * All recorded deaths with cause analysis.
     */
    getDeathLog: function () {
      return _deathLog;
    },

    /**
     * Compact summary string for quick JS queries.
     * Usage: SlitherPro.Debug.status()
     */
    status: function () {
      var s = _lastSnapshot;
      if (!s) return 'No data yet';
      return [
        'State=' + s.state,
        'Len=' + s.length,
        'Edge=' + s.edgeDist,
        'WallF=' + ((s.framesToWall === Infinity || s.framesToWall === -1) ? 'safe' : s.framesToWall),
        'Goal=' + s.chosenTag,
        'Boost=' + (s.boosting ? 'Y' : 'N'),
        'Snakes=' + s.nearbyCount,
        'Phase=' + s.phase
      ].join(' | ');
    },

    /**
     * Compact death summary for quick review.
     */
    deathSummary: function () {
      if (_deathLog.length === 0) return 'No deaths recorded';
      var lines = [];
      for (var i = 0; i < _deathLog.length; i++) {
        var d = _deathLog[i];
        lines.push('#' + (i + 1) + ': ' + d.cause + ' len=' + d.length +
          ' edge=' + d.edgeDist + ' state=' + d.state +
          ' tag=' + d.chosenTag + ' boost=' + (d.boosting ? 'Y' : 'N'));
      }
      return lines.join('\n');
    },

    /**
     * Goal score breakdown for current frame.
     */
    goalBreakdown: function () {
      if (!_goalScores) return 'No goal data';
      var lines = [];
      var tags = ['border', 'safety', 'kill', 'deathFood', 'food', 'coil'];
      for (var i = 0; i < tags.length; i++) {
        var g = _goalScores[tags[i]];
        if (g) {
          lines.push(tags[i] + ': ' + g.score.toFixed(3) +
            (g.tag === (_chosenGoal ? _chosenGoal.tag : '') ? ' << WINNER' : ''));
        }
      }
      return lines.join('\n');
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.Debug = DebugOverlay;
})();
