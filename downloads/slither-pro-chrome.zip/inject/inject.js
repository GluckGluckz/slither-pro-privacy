/**
 * Slither Pro — Main entry point (runs in page MAIN world).
 * Orchestrates all modules: overlay, mods, bot, and messaging.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP) { console.error('[SlitherPro] Namespace not found. Scripts may have loaded out of order.'); return; }

  var GameAPI = SP.GameAPI;
  var MessageBus = SP.MessageBus;
  var EVENTS = SP.EVENTS;
  var SETTINGS_DEFAULTS = SP.SETTINGS_DEFAULTS;

  if (!GameAPI) { console.error('[SlitherPro] GameAPI not found.'); return; }
  if (!MessageBus) { console.error('[SlitherPro] MessageBus not found.'); return; }
  if (!EVENTS) { console.error('[SlitherPro] EVENTS not found.'); return; }
  if (!SETTINGS_DEFAULTS) { console.error('[SlitherPro] SETTINGS_DEFAULTS not found.'); return; }

  // ─── State ──────────────────────────────────────────────────
  var settings = JSON.parse(JSON.stringify(SETTINGS_DEFAULTS));
  var initialized = false;
  var overlayManager = null;
  var _lastScore = 0;
  var _lastLength = 0;

  // Initialize message bus IMMEDIATELY so we don't miss early messages
  MessageBus.init();

  // Listen for settings updates right away (before canvas detection)
  MessageBus.on(EVENTS.SETTINGS_UPDATE, function (payload) {
    // Security: NEVER allow subscription changes via SETTINGS_UPDATE.
    // Subscription status uses a dedicated channel (SUB_STATUS) that's
    // harder for page-level scripts to spoof.
    if (payload) delete payload.subscription;
    mergeSettings(payload);
    if (initialized) applySettings();
  });

  // SETTINGS_RESPONSE is the trusted initial load from chrome.storage via content.js
  MessageBus.on(EVENTS.SETTINGS_RESPONSE, function (payload) {
    mergeSettings(payload);
    if (initialized) applySettings();
  });

  // Dedicated subscription channel — only content.js storage listener emits this
  MessageBus.on(EVENTS.SUB_STATUS, function (payload) {
    if (!payload) return;
    if (!settings.subscription) settings.subscription = {};
    settings.subscription.active = !!payload.active;
    settings.subscription.lastVerifiedAt = payload.lastVerifiedAt || 0;
    // If subscription was revoked while bot is running, stop it immediately
    if (!settings.subscription.active && SP.BotController && SP.BotController.isActive()) {
      settings.bot.enabled = false;
      SP.BotController.stop();
      showToast('Subscription expired — Bot stopped');
    }
    if (initialized) applySettings();
  });

  // Custom food image update (too large for chrome.storage.sync, sent directly)
  MessageBus.on('FOOD_IMAGE_UPDATE', function (payload) {
    if (!payload) return;
    if (!settings.food) settings.food = {};
    settings.food.customImage = payload.customImage || '';
    if (SP.FoodRenderer) SP.FoodRenderer.setCustomImage(settings.food.customImage);
  });

  // Request current settings from content script immediately
  MessageBus.send(EVENTS.SETTINGS_REQUEST, {});

  // ─── Wait for Game ──────────────────────────────────────────
  function waitForGame(callback) {
    var attempts = 0;
    var maxAttempts = 120;
    var pollInterval = (SP.CONSTANTS && SP.CONSTANTS.GAME_POLL_INTERVAL) || 500;
    var timer = setInterval(function () {
      attempts++;
      var canvas = GameAPI.getGameCanvas();
      if (canvas) {
        clearInterval(timer);
        callback(canvas);
      } else if (attempts >= maxAttempts) {
        clearInterval(timer);
        console.warn('[SlitherPro] Timed out waiting for game canvas.');
      }
    }, pollInterval);
  }

  // ─── Initialization ────────────────────────────────────────
  function init(canvas) {
    if (initialized) return;
    initialized = true;

    // Initialize overlay (used only for grid and death-recap now)
    overlayManager = SP.OverlayManager;
    if (overlayManager) {
      overlayManager.init(canvas);
      if (SP.GridRenderer) overlayManager.register('grid', SP.GridRenderer, 5);
      if (SP.VisualEffects) overlayManager.register('visual-effects', SP.VisualEffects, 10);
      if (SP.AurasMod) overlayManager.register('auras', SP.AurasMod, 8);
      if (SP.DeathRecap) overlayManager.register('death-recap', SP.DeathRecap, 30);
      if (SP.Debug && SP.Debug.TrajectoryRenderer) overlayManager.register('debug-trajectories', SP.Debug.TrajectoryRenderer, 25);
    }

    // Initialize mods
    if (SP.ZoomMod) SP.ZoomMod.init(settings);
    if (SP.SkinsMod) SP.SkinsMod.init(settings);
    if (SP.SkinPicker) SP.SkinPicker.init(settings);
    if (SP.AurasMod) SP.AurasMod.init(settings);
    if (SP.VisualEffects) SP.VisualEffects.init(settings);
    if (SP.FoodRenderer) SP.FoodRenderer.init(settings);
    if (SP.NativeMinimapHider) SP.NativeMinimapHider.init(settings);

    // Set initial nickname from saved settings or chat identity
    setInitialNickname();

    // Initialize bot
    if (SP.BotController) SP.BotController.init(settings);

    // Initialize HUD widget system (HTML-based, draggable)
    if (SP.HudManager) SP.HudManager.init(settings);

    // Initialize Chat widget and connect (identity is self-managed via localStorage)
    if (SP.ChatWidget) {
      SP.ChatWidget.init();
      if (settings.gameplay && settings.gameplay.clanTag) {
        SP.ChatWidget.setClanTag(settings.gameplay.clanTag);
      }
      SP.ChatWidget.connect();
    }

    // Initialize debug overlay (toggle bar + telemetry panel)
    if (SP.Debug) SP.Debug.init(settings);

    // Initialize legacy components (shims for death-recap compat)
    if (SP.GridRenderer) SP.GridRenderer.init(settings);
    if (SP.DeathRecap) SP.DeathRecap.init(settings);

    // Apply settings that arrived before init
    applySettings();

    // Game lifecycle hooks
    GameAPI.onGameStart(function () {
      saveCurrentNickname();
      // Belt-and-suspenders: the polling restore in prependThenRestore
      // should already have fired by the time onGameStart runs, but
      // if it somehow hasn't, strip the tag now — we're definitely
      // in-game so the setup packet is done.
      stripNickFieldTag();
      if (SP.HudManager) SP.HudManager.resetSession();
      if (SP.DeathRecap) SP.DeathRecap.hide();
      if (SP.FoodSeeker && SP.FoodSeeker.resetWaypoints) SP.FoodSeeker.resetWaypoints();
    });

    GameAPI.onDeath(function () {
      hideNameTag();
      stripNickFieldTag();
      if (SP.DeathRecap) SP.DeathRecap.show();
      if (SP.BotController && SP.BotController.isActive()) {
        if (!settings.bot.autoPlay) {
          SP.BotController.stop();
        }
      }
      sendStats();

      // Auto-respawn: re-click the Play button after a short delay so
      // the user sees their death recap but doesn't have to touch the
      // mouse to keep playing. Bot auto-play has its own respawn path;
      // we skip here to avoid double-clicking.
      if (settings.gameplay && settings.gameplay.autoRespawn
          && !(settings.bot && settings.bot.autoPlay)) {
        setTimeout(function () {
          var playh = document.getElementById('playh');
          if (playh && playh.offsetParent !== null) {
            playh.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, button: 0 }));
            playh.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, button: 0 }));
            playh.dispatchEvent(new MouseEvent('click',     { bubbles: true, button: 0 }));
          }
        }, 1500);
      }
    });

    setupKeyboardShortcuts();
    startMainLoop();
    MessageBus.send(EVENTS.MOD_READY, { version: '1.2.3' });
  }

  // ─── Nickname Management ────────────────────────────────────

  /** Format clan tag for display: "PRO" → "[PRO]" */
  function formatClanTag(tag) {
    tag = (tag || '').trim();
    return tag ? '[' + tag + ']' : '';
  }

  /**
   * Strip any clan-tag prefix from a name string.
   * Handles both "[TAG] name" and bare "TAG name" (legacy pre-bracket data).
   */
  function stripTagPrefix(name, rawTag) {
    if (!rawTag || !name) return name;
    // Bracketed: "[TAG] name" or "[TAG]name"
    var br = '[' + rawTag + ']';
    if (name.indexOf(br + ' ') === 0) return name.substring(br.length + 1);
    if (name.indexOf(br) === 0)       return name.substring(br.length);
    // Bare: "TAG name" (legacy)
    if (name.indexOf(rawTag + ' ') === 0) return name.substring(rawTag.length + 1);
    return name;
  }

  /**
   * On init, pre-fill the game's nickname field and inject clan tag UI.
   * Priority: saved nickname > chat-generated name > leave empty.
   */
  function setInitialNickname() {
    // Inject clan tag input on the game's main screen
    injectClanTagUI();
    // Keep the game's nick input free of [TAG] prefixes
    installNickTagStripper();

    if (!settings.gameplay || settings.gameplay.saveNickname === false) return;
    var nickEl = document.getElementById('nick');
    if (!nickEl) return;

    var clanTag = formatClanTag(settings.gameplay.clanTag);
    var rawTag = (settings.gameplay.clanTag || '').trim();
    var savedNick = settings.gameplay.nickname || '';

    // Clean any stale tag prefix from saved nick (migration from pre-bracket era)
    if (rawTag && savedNick) {
      var cleaned = stripTagPrefix(savedNick, rawTag).trim();
      if (cleaned !== savedNick) {
        savedNick = cleaned;
        settings.gameplay.nickname = cleaned;
        MessageBus.send(EVENTS.SETTINGS_UPDATE, { gameplay: settings.gameplay });
      }
    }

    // If no saved nick, fall back to chat-generated identity
    if (!savedNick) {
      try {
        var chatNick = localStorage.getItem('sp_chat_nick');
        if (chatNick && chatNick.length > 0 && chatNick.length <= 24) {
          savedNick = chatNick;
        }
      } catch (e) { /* private browsing */ }
    }

    if (savedNick) {
      // Only show base name — the clan tag is displayed in the separate [TAG] box
      nickEl.value = savedNick;
    }

    hookPlayButton();
  }

  /**
   * On Play mousedown (capture phase) prepend "[TAG] " to the nick
   * input so the game serialises the tagged name when it sends the
   * setup packet. The moment slither's own mousedown handler returns,
   * we restore the clean base value via a microtask so the user
   * never sees the tagged string sitting in the lobby input.
   *
   * The lobby input strippers (installNickTagStripper) handle any
   * stray tag that slips through, e.g. from slither's own localStorage
   * restoration on page reload.
   */
  function hookPlayButton() {
    var playh = document.getElementById('playh');
    if (!playh || playh._spHooked) return;
    playh._spHooked = true;

    function prependThenRestore() {
      var nickEl = document.getElementById('nick');
      if (!nickEl) return;
      var tag = settings.gameplay ? settings.gameplay.clanTag : '';
      if (!tag) return;
      var formatted = formatClanTag(tag);
      var originalVal = (nickEl.value || '').trim();
      if (originalVal.indexOf(formatted) === 0) return;
      nickEl.value = formatted + (originalVal ? ' ' + originalVal : '');

      // Restore the clean display value only AFTER slither has
      // definitely serialised and sent the setup packet. Polling runs
      // at display refresh (~16 ms at 60 Hz) via requestAnimationFrame
      // so the restore lands on the next frame after window.playing
      // flips true — effectively instant from the user's perspective.
      // A 2.5 s hard cap covers Frontier / other clients where
      // window.playing isn't exposed; the setup packet always goes
      // out well within that window.
      var startedAt = Date.now();
      function restore() {
        if (nickEl.value.indexOf(formatted) === 0) {
          nickEl.value = originalVal;
        }
      }
      function tick() {
        if (window.playing || (Date.now() - startedAt) >= 2500) {
          restore();
          return;
        }
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    }

    playh.addEventListener('mousedown', prependThenRestore, true);
    playh.addEventListener('touchstart', prependThenRestore, true);
  }

  /**
   * Keep the visible nick field free of any clan-tag prefix.
   * Strips on input, on blur, and once immediately so that any saved
   * value loaded from slither's own localStorage is cleaned.
   */
  function installNickTagStripper() {
    var nickEl = document.getElementById('nick');
    if (!nickEl || nickEl._spStripperInstalled) return;
    nickEl._spStripperInstalled = true;

    function strip() {
      var rawTag = settings.gameplay ? (settings.gameplay.clanTag || '').trim() : '';
      if (!rawTag) return;
      var val = (nickEl.value || '');
      var cleaned = stripTagPrefix(val, rawTag);
      if (cleaned !== val) nickEl.value = cleaned;
    }

    nickEl.addEventListener('blur', strip);
    nickEl.addEventListener('input', strip);
    nickEl.addEventListener('change', strip);
    strip();
  }

  /**
   * After death, strip the clan tag prefix from the nick field so the
   * main screen shows just the editable base name again.
   */
  function stripNickFieldTag() {
    var nickEl = document.getElementById('nick');
    if (!nickEl) return;
    var rawTag = settings.gameplay ? (settings.gameplay.clanTag || '').trim() : '';
    if (!rawTag) return;
    var val = (nickEl.value || '').trim();
    var stripped = stripTagPrefix(val, rawTag).trim();
    if (stripped !== val) nickEl.value = stripped;
  }

  /**
   * On game start, persist the current nickname (without clan tag prefix).
   */
  function saveCurrentNickname() {
    if (!settings.gameplay || settings.gameplay.saveNickname === false) return;
    var nickEl = document.getElementById('nick');
    if (!nickEl) return;

    var raw = (nickEl.value || '').trim();
    if (!raw) return;

    // Strip any form of tag prefix before saving (bracket or bare)
    var rawTag = (settings.gameplay.clanTag || '').trim();
    var baseName = stripTagPrefix(raw, rawTag).trim();

    if (!baseName) return;
    if (baseName === settings.gameplay.nickname) return;

    settings.gameplay.nickname = baseName;
    MessageBus.send(EVENTS.SETTINGS_UPDATE, { gameplay: settings.gameplay });
  }

  /**
   * Inject a clan tag input directly onto slither.io's main/login screen,
   * placed to the left of the existing nickname input.
   *
   * Layout: nick_holder is inline-block (centered by parent text-align:center).
   * The game's nick input is position:absolute inside it. We must NOT change
   * the holder to flex/grid — that breaks centering. Instead we position our
   * clan wrap absolutely too, widen the holder, and shift the nick input right.
   */
  function injectClanTagUI() {
    var nickHolder = document.getElementById('nick_holder');
    var nickEl = document.getElementById('nick');
    if (!nickHolder || !nickEl) return;
    if (document.getElementById('sp-clan-input')) return; // already injected

    // Measure originals before we touch anything. Width covers
    // [+bracket, 84px input (fits 4-char tags comfortably), +bracket, gap.
    var CLAN_WIDTH = 108;
    var nickLeft = parseInt(getComputedStyle(nickEl).left, 10);
    if (isNaN(nickLeft)) nickLeft = 0;
    var origNickLeft = nickLeft || 12;
    var origHolderW = nickHolder.offsetWidth;

    // Widen the holder to make room — stays inline-block so centering works
    nickHolder.style.width = (origHolderW + CLAN_WIDTH) + 'px';

    // Shift the game's nick input right
    nickEl.style.left = (origNickLeft + CLAN_WIDTH) + 'px';

    // Build: [  INPUT  ]  — positioned absolutely inside the holder
    var wrap = document.createElement('div');
    wrap.className = 'sp-clan-wrap';

    var bracketL = document.createElement('span');
    bracketL.className = 'sp-clan-bracket';
    bracketL.textContent = '[';

    var input = document.createElement('input');
    input.type = 'text';
    input.id = 'sp-clan-input';
    input.className = 'sp-clan-input';
    input.maxLength = 4;
    input.placeholder = 'TAG';
    input.value = settings.gameplay ? (settings.gameplay.clanTag || '') : '';

    var bracketR = document.createElement('span');
    bracketR.className = 'sp-clan-bracket';
    bracketR.textContent = ']';

    wrap.appendChild(bracketL);
    wrap.appendChild(input);
    wrap.appendChild(bracketR);
    nickHolder.appendChild(wrap);

    // Sync on change
    input.addEventListener('change', function () {
      var tag = input.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
      input.value = tag;
      if (!settings.gameplay) settings.gameplay = {};
      settings.gameplay.clanTag = tag;
      MessageBus.send(EVENTS.SETTINGS_UPDATE, { gameplay: settings.gameplay });
      if (SP.ChatWidget && SP.ChatWidget.setClanTag) SP.ChatWidget.setClanTag(tag);
      // Nick field shows base name only — tag is in the [TAG] box
      // No need to rebuild nick with tag prefix
    });
  }

  // ─── Player Name Always Visible (Canvas-based) ─────────────
  //
  // Draws the name tag directly on a transparent canvas that is
  // pixel-aligned with the game canvas.  No HTML overlay, no
  // screen-coordinate conversion — uses game canvas coords directly.
  //
  var _nameCanvas = null;
  var _nameCtx = null;
  var _nameAnimStart = 0;
  var _nameSyncKey = '';
  var _savedNick = '';      // original nk value (game clears it to suppress vanilla render)

  /** Create / sync a transparent canvas aligned with the game canvas. */
  function _ensureNameCanvas() {
    var gc = GameAPI.getGameCanvas();
    if (!gc) return null;

    if (!_nameCanvas) {
      _nameCanvas = document.createElement('canvas');
      _nameCanvas.id = 'sp-name-canvas';
      _nameCanvas.style.pointerEvents = 'none';
      _nameCanvas.style.position = 'fixed';
      SP.HudRoot.append(_nameCanvas);
      _nameCtx = _nameCanvas.getContext('2d');
      _nameAnimStart = Date.now();
    }

    // Sync position / size with game canvas every frame (game resizes dynamically)
    var syncKey = gc.width + ':' + gc.height + ':' + (gc.style.top || '') + ':' + (gc.style.left || '') + ':' + (gc.style.width || '') + ':' + (gc.style.height || '');
    if (_nameSyncKey !== syncKey) {
      _nameSyncKey = syncKey;
      _nameCanvas.width = gc.width;
      _nameCanvas.height = gc.height;
      _nameCanvas.style.top = gc.style.top;
      _nameCanvas.style.left = gc.style.left;
      _nameCanvas.style.width = gc.style.width || (gc.width + 'px');
      _nameCanvas.style.height = gc.style.height || (gc.height + 'px');
      _nameCanvas.style.zIndex = String((parseInt(gc.style.zIndex, 10) || 5) + 1);
    }

    return _nameCtx;
  }

  function keepNameVisible() {
    var snake = window.slither;
    if (!snake) return;

    // Capture the original name before blanking (game sets nk on spawn)
    if (snake.nk && snake.nk.length > 0) _savedNick = snake.nk;

    // Blank nk to suppress the vanilla canvas name render.
    // (eo=0 alone does NOT hide it — the game ignores eo for the player.)
    snake.nk = '';

    var ntSettings = settings.nameTag;
    if (!ntSettings || !ntSettings.enabled) {
      // Restore vanilla: put name back so the game draws it normally
      snake.nk = _savedNick;
      if (_nameCanvas) _nameCanvas.style.display = 'none';
      return;
    }

    var ctx = _ensureNameCanvas();
    if (!ctx) return;
    _nameCanvas.style.display = '';

    // Clear previous frame
    ctx.clearRect(0, 0, _nameCanvas.width, _nameCanvas.height);

    var nick = _savedNick;
    if (!nick) return;

    if (snake.xx === undefined || snake.yy === undefined) return;

    // ── Prepend clan tag ────────────────────────────────
    // Strip any existing tag from nick first — the game's nk already
    // includes it from the play-button hook, so without this we'd double it.
    var clanTag = (settings.gameplay && settings.gameplay.clanTag) ? settings.gameplay.clanTag.trim() : '';
    if (clanTag) nick = stripTagPrefix(nick, clanTag).trim();
    var displayName = clanTag ? '[' + clanTag.toUpperCase() + '] ' + nick : nick;

    // ── Resolve colors ──────────────────────────────────
    var color1 = ntSettings.color1 || '#39ff14';
    var color2 = ntSettings.color2 || '#00cc00';
    if (ntSettings.useSnakeColors !== false) {
      var skinColors = (SP.SkinsMod && SP.SkinsMod.getCurrentColors) ? SP.SkinsMod.getCurrentColors() : null;
      if (skinColors && skinColors.length >= 2) {
        color1 = skinColors[0];
        color2 = skinColors[1];
      } else if (settings.visual && settings.visual.customColors && settings.visual.customColors.length >= 2) {
        color1 = settings.visual.customColors[0];
        color2 = settings.visual.customColors[1];
      }
    }

    // ── Position in canvas coords (no screen conversion needed) ─
    var gsc = window.gsc || 0.9;
    var vx = window.view_xx || 0;
    var vy = window.view_yy || 0;
    var canvasX = (snake.xx - vx) * gsc + _nameCanvas.width / 2;
    var headOffset = 29 * (snake.sc || 1) * gsc + 8;
    var canvasY = (snake.yy - vy) * gsc + _nameCanvas.height / 2 + headOffset;

    // ── Animation params ────────────────────────────────
    var styleName = ntSettings.style || 'rainbow';
    var speedVal = ntSettings.animationSpeed || 'normal';
    var glowVal = ntSettings.glowIntensity || 'medium';
    var sizeVal = ntSettings.fontSize || 'normal';

    var speedMult = 1.0;
    if (speedVal === 'slow') speedMult = 0.5;
    else if (speedVal === 'fast') speedMult = 2.0;

    var glowBase = 6, glowRange = 6;
    if (glowVal === 'low') { glowBase = 3; glowRange = 3; }
    else if (glowVal === 'high') { glowBase = 10; glowRange = 12; }

    var t = (Date.now() - _nameAnimStart) / 1000.0 * speedMult;

    // ── Font ────────────────────────────────────────────
    var fontSize = 15;
    if (sizeVal === 'small') fontSize = 12;
    else if (sizeVal === 'large') fontSize = 19;

    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.font = '800 ' + fontSize + 'px Arial, "Segoe UI", sans-serif';

    var textW = ctx.measureText(displayName).width;

    // ── Fill style (gradient) ───────────────────────────
    if (styleName === 'rainbow') {
      var rGrad = ctx.createLinearGradient(canvasX - textW / 2, canvasY, canvasX + textW / 2, canvasY);
      var hueOff = (t * 0.25) % 1.0;
      for (var si = 0; si <= 10; si++) {
        var hue = (((si / 10) + hueOff) * 360) % 360;
        rGrad.addColorStop(si / 10, 'hsl(' + Math.round(hue) + ',100%,60%)');
      }
      ctx.fillStyle = rGrad;
    } else {
      var cGrad = ctx.createLinearGradient(canvasX - textW / 2, canvasY, canvasX + textW / 2, canvasY);
      cGrad.addColorStop(0, color1);
      cGrad.addColorStop(1, color2);
      ctx.fillStyle = cGrad;
    }

    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;

    // ── Style-specific effects ──────────────────────────
    if (styleName === 'glow' || styleName === 'rainbow') {
      // Neon breath: shadow pulses between base and base+range
      var breathe = Math.sin(t * 2.6) * 0.5 + 0.5;
      var blur = glowBase + glowRange * breathe;
      ctx.shadowColor = (styleName === 'rainbow') ? 'rgba(255,255,255,0.6)' : color1;
      ctx.shadowBlur = blur;
      ctx.fillText(displayName, canvasX, canvasY);
      // Second pass for layered bloom
      ctx.shadowBlur = blur * 0.5;
      ctx.fillText(displayName, canvasX, canvasY);

    } else if (styleName === 'pulse') {
      // Scale throb + glow swell
      var pulse = Math.sin(t * 3.5) * 0.5 + 0.5;
      var scale = 1.0 + 0.12 * pulse;
      ctx.translate(canvasX, canvasY);
      ctx.scale(scale, scale);
      ctx.translate(-canvasX, -canvasY);
      ctx.shadowColor = color1;
      ctx.shadowBlur = glowBase + glowRange * pulse;
      ctx.fillText(displayName, canvasX, canvasY);
      ctx.shadowBlur = (glowBase + glowRange * pulse) * 0.5;
      ctx.fillText(displayName, canvasX, canvasY);

    } else if (styleName === 'flicker') {
      // Electric neon stutter
      var ft = (t * 1.0) % 3.0;
      var flick = 1.0;
      if ((ft > 0.18 && ft < 0.21) || (ft > 0.30 && ft < 0.33) ||
          (ft > 0.90 && ft < 0.96) || (ft > 1.65 && ft < 1.68)) {
        flick = 0.3;
      }
      ctx.globalAlpha = flick;
      ctx.shadowColor = color1;
      ctx.shadowBlur = flick > 0.5 ? (glowBase + glowRange * 0.7) : (glowBase * 0.4);
      ctx.fillText(displayName, canvasX, canvasY);
      if (flick > 0.5) {
        ctx.shadowBlur = glowBase * 0.5;
        ctx.fillText(displayName, canvasX, canvasY);
      }

    } else {
      // 'none' — subtle static glow for readability
      ctx.shadowColor = color1;
      ctx.shadowBlur = glowBase;
      ctx.fillText(displayName, canvasX, canvasY);
    }

    ctx.restore();
  }

  function hideNameTag() {
    if (_nameCanvas && _nameCtx) {
      _nameCtx.clearRect(0, 0, _nameCanvas.width, _nameCanvas.height);
    }
    // Restore the vanilla nk so the game can render it on death screen etc.
    var snake = window.slither;
    if (snake && _savedNick) snake.nk = _savedNick;
  }

  // ─── Main Loop ─────────────────────────────────────────────
  function startMainLoop() {
    function loop() {
      try {
        GameAPI.pollStateTransitions();

        // Food renderer builds spatial hash before game renders
        if (SP.FoodRenderer) SP.FoodRenderer.update();

        // v8: Bot subscription check moved INTO BotController.update()
        // so the toggle works immediately regardless of subscription timing.
        if (GameAPI.isPlaying()) {
          // Keep player name always visible
          keepNameVisible();

          // Cache player stats for sendStats() (snake is null by death callback)
          var _livePlayer = GameAPI.getPlayerSnake();
          if (_livePlayer) {
            _lastScore = _livePlayer.score || 0;
            _lastLength = _livePlayer.length || 0;
            // Expose for DeathRecap (it reads window._sp_lastScore)
            window._sp_lastScore = _lastScore;
          }

          if (settings.bot.enabled && SP.BotController) {
            SP.BotController.update();
          }
          if (settings.zoom.enabled && SP.ZoomMod) {
            SP.ZoomMod.update();
          }
          if (SP.SkinsMod) {
            SP.SkinsMod.update();
          }
          // v7: Boost trail particles (skin-matched colors)
          if (SP.VisualEffects && SP.VisualEffects.spawnBoostTrail) {
            var _player = GameAPI.getPlayerSnake();
            if (_player && window.setAcceleration && window.slither && window.slither.sp > 6) {
              var _trailColor = (SP.SkinsMod && SP.SkinsMod.getTrailColor) ? SP.SkinsMod.getTrailColor() : null;
              SP.VisualEffects.spawnBoostTrail(_player.x, _player.y, _player.angle || 0, _trailColor);
            }
          }
        } else {
          if (settings.bot.enabled && settings.bot.autoPlay && SP.BotController && SP.BotController.isActive()) {
            SP.BotController.update();
          }
        }

        // Overlay canvas (grid, death recap)
        if (overlayManager) {
          overlayManager.render(settings);
        }

        // HTML HUD widgets
        if (SP.HudManager) {
          SP.HudManager.update();
        }

        // Debug overlay telemetry
        if (SP.Debug) {
          SP.Debug.update();
        }

        // Pre-death history for the recap analyzer — captures player
        // state + nearby snakes each frame so cause attribution still
        // works after window.slither has been nulled on death.
        if (SP.DeathRecap && SP.DeathRecap.update) {
          SP.DeathRecap.update();
        }
      } catch (err) {
        console.error('[SlitherPro] Main loop error:', err);
      }

      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
  }

  // ─── Settings ──────────────────────────────────────────────
  function mergeSettings(incoming) {
    if (!incoming) return;
    for (var category in incoming) {
      if (incoming.hasOwnProperty(category) && settings[category] && typeof incoming[category] === 'object' && incoming[category] !== null) {
        for (var key in incoming[category]) {
          if (incoming[category].hasOwnProperty(key)) {
            settings[category][key] = incoming[category][key];
          }
        }
      }
    }
  }

  function applySettings() {
    if (SP.ZoomMod) SP.ZoomMod.updateSettings(settings);
    if (SP.SkinsMod) SP.SkinsMod.updateSettings(settings);
    if (SP.SkinPicker) SP.SkinPicker.updateSettings(settings);
    if (SP.AurasMod) SP.AurasMod.updateSettings(settings);
    if (SP.VisualEffects) SP.VisualEffects.updateSettings(settings);
    if (SP.FoodRenderer) SP.FoodRenderer.updateSettings(settings);
    if (SP.NativeMinimapHider) SP.NativeMinimapHider.updateSettings(settings);
    if (SP.BotController) SP.BotController.updateSettings(settings);
    if (SP.HudManager) SP.HudManager.updateSettings(settings);
    if (SP.Debug) SP.Debug.updateSettings(settings);
    if (SP.GridRenderer) SP.GridRenderer.updateSettings(settings);
    if (SP.DeathRecap) SP.DeathRecap.updateSettings(settings);
    // Sync clan tag to chat widget
    if (SP.ChatWidget && SP.ChatWidget.setClanTag) {
      SP.ChatWidget.setClanTag(settings.gameplay ? settings.gameplay.clanTag : '');
    }
    // Update game nick field when clan tag changes from popup
    updateNickField();
  }

  /**
   * Rebuild the game nick field from clan tag + saved name.
   * Called when settings change (e.g., user edits clan tag in popup).
   */
  function updateNickField() {
    if (!settings.gameplay || settings.gameplay.saveNickname === false) return;
    var nickEl = document.getElementById('nick');
    if (!nickEl) return;
    // Only update if not currently playing (don't change mid-game)
    if (GameAPI.isPlaying && GameAPI.isPlaying()) return;

    var clanTag = settings.gameplay.clanTag || '';
    var baseName = settings.gameplay.nickname || '';
    if (!baseName) return; // don't overwrite if no saved name

    // Only show base name — clan tag is in the separate [TAG] box
    nickEl.value = baseName;
  }

  function sendStats() {
    MessageBus.send(EVENTS.STATS_UPDATE, {
      score: _lastScore,
      length: _lastLength,
      kills: SP.HudManager ? SP.HudManager.getKills() : 0,
      sessionTime: SP.HudManager ? SP.HudManager.getSessionTime() : 0
    });
  }

  // ─── Toast Notifications ───────────────────────────────────
  var toastContainer = null;

  function showToast(message, duration) {
    duration = duration || 2000;
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'slither-pro-toast';
      SP.HudRoot.append(toastContainer);
    }
    var toast = document.createElement('div');
    toast.className = 'slither-pro-toast-item';
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(function () {
      toast.classList.add('sp-toast-fade-out');
      setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, duration);
  }

  // ─── Keyboard Shortcuts ────────────────────────────────────
  function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function (e) {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      // Don't trigger game shortcuts while chat is focused
      if (SP.ChatWidget && SP.ChatWidget.isOpen()) return;

      switch (e.key.toLowerCase()) {
        // 'b' (Bot) — deliberately distinct from Frontier's 't' toggle so
        // users running both extensions don't fire two bots at once.
        case 'b':
          if (!settings.bot.enabled) {
            // Trying to turn bot ON — check subscription first
            if (!settings.subscription || !settings.subscription.active) {
              showToast('Pro subscription required');
              if (SP.ChatWidget) {
                SP.ChatWidget.init();
                // Use system-level message via internal method
                if (SP.ChatWidget._addSystemMsg) {
                  SP.ChatWidget._addSystemMsg('AI Bot requires a Pro subscription ($2.99/mo). Open the extension popup to subscribe.');
                }
              }
              break;
            }
            settings.bot.enabled = true;
            if (SP.BotController) {
              var started = SP.BotController.start();
              if (!started) {
                settings.bot.enabled = false;
                showToast('Pro subscription required');
                if (SP.ChatWidget && SP.ChatWidget._addSystemMsg) {
                  SP.ChatWidget._addSystemMsg('AI Bot requires a Pro subscription ($2.99/mo). Open the extension popup to subscribe.');
                }
                break;
              }
              showToast('Bot: ON');
            }
          } else {
            settings.bot.enabled = false;
            if (SP.BotController) {
              SP.BotController.stop();
              showToast('Bot: OFF');
            }
          }
          MessageBus.send(EVENTS.BOT_TOGGLE, { enabled: settings.bot.enabled });
          break;
        case 'g':
          settings.visual.gridEnabled = !settings.visual.gridEnabled;
          showToast('Grid: ' + (settings.visual.gridEnabled ? 'ON' : 'OFF'));
          break;
        case 'm':
          settings.hud.minimapEnabled = !settings.hud.minimapEnabled;
          showToast('Minimap: ' + (settings.hud.minimapEnabled ? 'ON' : 'OFF'));
          break;
        case 'h':
          if (SP.HudManager) {
            SP.HudManager.toggleKeybinds();
            showToast('Keybinds toggled');
          }
          break;
        case 'f3':
          if (SP.Debug) SP.Debug.toggle();
          e.preventDefault();
          break;
        case 'l':
          settings.bot.inputLock = !settings.bot.inputLock;
          if (settings.bot.enabled && SP.BotController && SP.BotController.isActive()) {
            if (settings.bot.inputLock) {
              GameAPI.blockUserInput();
            } else {
              GameAPI.unblockUserInput();
            }
          }
          showToast('Input Lock: ' + (settings.bot.inputLock ? 'ON' : 'OFF'));
          break;
        case '0':
          if (SP.ZoomMod) {
            SP.ZoomMod.resetZoom();
            showToast('Zoom: Reset');
          }
          break;
      }
    });
  }

  // ─── Start ─────────────────────────────────────────────────
  waitForGame(init);

})();
