/**
 * Slither Pro — Math utility functions.
 */
(function () {
  'use strict';

  /* ── Turn rate model constants ─────────────────────────── */
  var TURN_BASE_RATE = 0.12;    // base turn rate (rad/frame) for tiny snakes
  var TURN_SCALE     = 0.0004;  // how much each unit of length reduces turn rate
  var TURN_MIN_RATE  = 0.015;   // floor: even huge snakes can turn this fast
  var BOOST_SPEED_MULT = 2.0;   // boost doubles effective speed
  var BASE_SPEED       = 8;     // default snake speed (units/frame)

  var MathUtil = {
    distance: function (x1, y1, x2, y2) {
      var dx = x2 - x1;
      var dy = y2 - y1;
      return Math.sqrt(dx * dx + dy * dy);
    },

    distanceSq: function (x1, y1, x2, y2) {
      var dx = x2 - x1;
      var dy = y2 - y1;
      return dx * dx + dy * dy;
    },

    angle: function (x1, y1, x2, y2) {
      return Math.atan2(y2 - y1, x2 - x1);
    },

    normalizeAngle: function (a) {
      a = a % (2 * Math.PI);
      return a < 0 ? a + 2 * Math.PI : a;
    },

    lerp: function (a, b, t) {
      return a + (b - a) * t;
    },

    clamp: function (value, min, max) {
      return Math.max(min, Math.min(max, value));
    },

    /**
     * Convert game-world coordinates to screen pixel coordinates.
     */
    gameToScreen: function (gameX, gameY, viewX, viewY, scale, canvasW, canvasH) {
      return {
        x: (gameX - viewX) * scale + canvasW / 2,
        y: (gameY - viewY) * scale + canvasH / 2
      };
    },

    /**
     * Convert screen pixel coordinates to game-world coordinates.
     */
    screenToGame: function (screenX, screenY, viewX, viewY, scale, canvasW, canvasH) {
      return {
        x: (screenX - canvasW / 2) / scale + viewX,
        y: (screenY - canvasH / 2) / scale + viewY
      };
    },

    /**
     * Pick the point from an array that is closest to (x, y).
     */
    nearest: function (x, y, points) {
      var best = null;
      var bestDist = Infinity;
      for (var i = 0; i < points.length; i++) {
        var p = points[i];
        var d = this.distanceSq(x, y, p.x, p.y);
        if (d < bestDist) {
          bestDist = d;
          best = p;
        }
      }
      return best;
    },

    /* ── TOD (Time over Distance) utilities ───────────────── */

    /**
     * Frames needed to travel a given distance at current speed.
     */
    framesToReach: function (distance, speed, isBoosting) {
      var effectiveSpeed = (speed || BASE_SPEED) * (isBoosting ? BOOST_SPEED_MULT : 1.0);
      if (effectiveSpeed <= 0) return Infinity;
      return distance / effectiveSpeed;
    },

    /**
     * Frames until the snake hits the arena wall given current heading.
     * Returns Infinity if heading away from or parallel to the wall.
     */
    framesToWallCollision: function (px, py, angle, speed, mapRadius, isBoosting) {
      var effectiveSpeed = (speed || BASE_SPEED) * (isBoosting ? BOOST_SPEED_MULT : 1.0);
      if (effectiveSpeed <= 0) return Infinity;
      var centerX = mapRadius;
      var centerY = mapRadius;
      var dx = px - centerX;
      var dy = py - centerY;
      var distFromCenter = Math.sqrt(dx * dx + dy * dy);
      if (distFromCenter <= 0) return Infinity;
      // radial outward unit vector
      var radialX = dx / distFromCenter;
      var radialY = dy / distFromCenter;
      // velocity vector
      var vx = Math.cos(angle) * effectiveSpeed;
      var vy = Math.sin(angle) * effectiveSpeed;
      // component of velocity heading outward (positive = toward wall)
      var radialSpeed = vx * radialX + vy * radialY;
      if (radialSpeed <= 0) return Infinity; // moving toward center
      var distToEdge = mapRadius - distFromCenter;
      return distToEdge / radialSpeed;
    },

    /* ── Turning radius model ─────────────────────────────── */

    /**
     * Max turn rate (rad/frame) at a given snake length.
     * Larger snakes turn more slowly.
     */
    maxTurnRate: function (snakeLength) {
      var rate = TURN_BASE_RATE / (1 + (snakeLength || 10) * TURN_SCALE);
      return Math.max(TURN_MIN_RATE, rate);
    },

    /**
     * Minimum turning radius at given speed and snake length.
     */
    minTurningRadius: function (speed, snakeLength) {
      var turnRate = this.maxTurnRate(snakeLength);
      return (speed || BASE_SPEED) / turnRate;
    },

    /**
     * Frames needed to turn a given angle at the snake's max turn rate.
     */
    framesToTurn: function (angleRadians, snakeLength) {
      var turnRate = this.maxTurnRate(snakeLength);
      return Math.abs(angleRadians) / turnRate;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.MathUtil = MathUtil;
})();
