/**
 * Slither Pro — WebSocket protocol interception.
 *
 * slither.io's game state used to live on window globals (window.slither,
 * window.playing, etc). Frontier — a third-party CWS extension that
 * replaces slither.io's entire client — does not expose those globals;
 * its state is trapped inside ES module scope.
 *
 * But every slither.io client, whether vanilla or modded, still talks
 * the same protocol-11 WebSocket to slither.io's servers. Hooking at the
 * WebSocket layer gives us one authoritative observation point that
 * works across vanilla, Frontier, NTL, and any future fork.
 *
 * This file is the *infrastructure*. It:
 *   - wraps WebSocket.prototype.send to capture outbound binary frames
 *   - wraps EventTarget.prototype.addEventListener to capture inbound
 *   - tracks the most recently active WebSocket so mutations (boost,
 *     direction, server-switch) can send back through it
 *   - exposes SP.WSHook with onSend / onRecv / send / isConnected / stats
 *
 * It does NOT decode protocol 11 — that lives in a separate module
 * (protocol/protocol-11.js) so hook infrastructure can ship independently.
 *
 * Load order: MUST run before any game client code creates a WebSocket.
 * content.js injects this as an inline <script> at document_start, ahead
 * of any deferred module tag. It is also listed in the async-loaded
 * SCRIPTS array to populate SP.WSHook for late consumers — this second
 * load is a no-op because of the _installed guard.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro = window.SlitherPro || {};
  if (SP._WSHookInstalled) return;
  SP._WSHookInstalled = true;

  var _sendListeners = [];
  var _recvListeners = [];
  var _lastRecvAt = 0;
  var _lastSendAt = 0;
  var _recvCount = 0;
  var _sendCount = 0;
  var _activeSocket = null;
  var _allSockets = [];

  // Ping measurement state. slither.io sends a 1-byte ping (opcode 251
  // / 252 in different versions) and the server pongs back with an
  // inbound frame whose opcode byte (position 2 in the 3-byte header
  // format) equals 'p' (112). We record the most recent 1-byte send
  // timestamp and, on receiving a pong, treat the elapsed time as a
  // round-trip estimate smoothed with an exponential moving average.
  var _pingLastSendAt = 0;
  var _pingSmoothed = null;

  // ─── Outbound intercept ────────────────────────────────
  var origSend = WebSocket.prototype.send;
  WebSocket.prototype.send = function (data) {
    try {
      _lastSendAt = Date.now();
      _sendCount++;
      _activeSocket = this;
      if (_allSockets.indexOf(this) === -1) _allSockets.push(this);
      // Ping: 1-byte outbound is either a direction update or a ping.
      // We stamp the timestamp either way — the corresponding inbound
      // pong (opcode 'p') will land within tens of ms on a healthy
      // connection, before any direction change would meaningfully
      // affect the latency estimate.
      if (data && typeof data !== 'string' && data.byteLength === 1) {
        _pingLastSendAt = performance.now();
      }
      for (var i = 0; i < _sendListeners.length; i++) {
        try { _sendListeners[i](data, this); } catch (e) {}
      }
    } catch (e) {}
    return origSend.call(this, data);
  };

  // ─── Inbound intercept ─────────────────────────────────
  // EventTarget.prototype.addEventListener is always configurable. We
  // intercept message events specifically so non-WS listeners are
  // unaffected. The onmessage property setter is also wrapped for
  // clients that use assignment rather than addEventListener.
  var origAdd = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, listener, opts) {
    if (type === 'message' && this instanceof WebSocket) {
      var self = this;
      var wrapped = function (ev) {
        try {
          _lastRecvAt = Date.now();
          _recvCount++;
          _activeSocket = self;
          // Detect pong and update smoothed ping.
          if (_pingLastSendAt && ev.data && ev.data.byteLength >= 3) {
            var u8 = new Uint8Array(ev.data);
            if (u8[2] === 112 /* 'p' */) {
              var rtt = performance.now() - _pingLastSendAt;
              _pingLastSendAt = 0;
              if (rtt >= 0 && rtt < 2000) {
                _pingSmoothed = _pingSmoothed === null
                  ? rtt
                  : _pingSmoothed * 0.7 + rtt * 0.3;
              }
            }
          }
          for (var i = 0; i < _recvListeners.length; i++) {
            try { _recvListeners[i](ev.data, self); } catch (e) {}
          }
        } catch (e) {}
        return listener.call(this, ev);
      };
      return origAdd.call(this, type, wrapped, opts);
    }
    return origAdd.call(this, type, listener, opts);
  };

  // Wrap onmessage setter — some clients use ws.onmessage = fn
  // Slither.io uses THIS path in current builds, which is why the
  // ping detector in the addEventListener wrapper above never saw
  // any pongs. Mirror the pong-sniffing here so getPing() works.
  var origOnMessageDesc = Object.getOwnPropertyDescriptor(WebSocket.prototype, 'onmessage');
  if (origOnMessageDesc && origOnMessageDesc.configurable) {
    Object.defineProperty(WebSocket.prototype, 'onmessage', {
      configurable: true,
      enumerable: true,
      get: function () { return this.__spOrigOnMessage; },
      set: function (fn) {
        var self = this;
        this.__spOrigOnMessage = fn;
        origOnMessageDesc.set.call(this, function (ev) {
          try {
            _lastRecvAt = Date.now();
            _recvCount++;
            _activeSocket = self;
            // Pong detection — mirrors the addEventListener path.
            if (_pingLastSendAt && ev.data && ev.data.byteLength >= 3) {
              var u8 = new Uint8Array(ev.data);
              if (u8[2] === 112 /* 'p' */) {
                var rtt = performance.now() - _pingLastSendAt;
                _pingLastSendAt = 0;
                if (rtt >= 0 && rtt < 2000) {
                  _pingSmoothed = _pingSmoothed === null
                    ? rtt
                    : _pingSmoothed * 0.7 + rtt * 0.3;
                }
              }
            }
            for (var i = 0; i < _recvListeners.length; i++) {
              try { _recvListeners[i](ev.data, self); } catch (e) {}
            }
          } catch (e) {}
          if (typeof fn === 'function') return fn.call(self, ev);
        });
      }
    });
  }

  SP.WSHook = {
    /** Register a callback fired on each outbound frame. cb(data, socket). */
    onSend: function (cb) { if (typeof cb === 'function') _sendListeners.push(cb); },

    /** Register a callback fired on each inbound frame. cb(data, socket). */
    onRecv: function (cb) { if (typeof cb === 'function') _recvListeners.push(cb); },

    /**
     * Send binary data through the currently active game WebSocket.
     * Returns true if sent, false if no open socket available.
     */
    send: function (data) {
      if (_activeSocket && _activeSocket.readyState === 1 /* OPEN */) {
        try { _activeSocket.send(data); return true; } catch (e) { return false; }
      }
      return false;
    },

    /** True iff there's an open WebSocket we can send through. */
    isConnected: function () {
      return !!(_activeSocket && _activeSocket.readyState === 1);
    },

    /**
     * Heuristic: "are we in an active game?" — true if inbound traffic
     * arrived recently. Independent of window globals so it works in
     * Frontier/NTL where those are absent.
     */
    isActive: function () {
      if (!_activeSocket || _activeSocket.readyState !== 1) return false;
      if (_recvCount < 5) return false;
      return (Date.now() - _lastRecvAt) < 5000;
    },

    getActiveSocket: function () { return _activeSocket; },

    getStats: function () {
      return {
        sentCount: _sendCount,
        recvCount: _recvCount,
        lastSendAt: _lastSendAt,
        lastRecvAt: _lastRecvAt,
        url: _activeSocket && _activeSocket.url,
        socketCount: _allSockets.length
      };
    },

    /**
     * Smoothed round-trip ping in milliseconds, or null if we haven't
     * yet observed a send/recv pair. Updated each time the server's
     * pong echoes back after a 1-byte outbound.
     */
    getPing: function () {
      return _pingSmoothed === null ? null : Math.round(_pingSmoothed);
    }
  };
})();
