/**
 * Slither Pro — postMessage wrapper for communication
 * between injected script (MAIN world) and content script (isolated world).
 *
 * Two channels:
 *   1. UNTRUSTED (window.postMessage) — general settings, game events, chat.
 *      Anyone on the page can post these; they must be treated as untrusted
 *      input and not used for privilege decisions.
 *   2. TRUSTED (MessagePort) — privileged events only. Content script
 *      transfers a MessagePort to the MAIN world via a handshake immediately
 *      after script injection. SUB_STATUS (subscription state) flows through
 *      this port and is paired with a per-session nonce that's generated
 *      inside the extension context and never exposed via window.postMessage.
 *
 * A page-world attacker who wants to spoof subscription state would have to
 * race the handshake AND steal the nonce, not just postMessage a string.
 */
(function () {
  'use strict';

  var SOURCE_TAG = 'slither-pro';
  var HANDSHAKE_TYPE = 'SP_PRIV_HS_a1b7';
  var PRIVILEGED_TYPES = { 'SP_SUB_7f3a': true };

  var listeners = {};
  var privilegedPort = null;
  var privilegedNonce = null;

  function dispatch(type, payload) {
    if (!listeners[type]) return;
    for (var i = 0; i < listeners[type].length; i++) {
      try {
        listeners[type][i](payload);
      } catch (err) {
        console.error('[SlitherPro] MessageBus handler error:', err);
      }
    }
  }

  // Register the handshake listener synchronously at module load so the
  // content script's port transfer is captured as early as possible.
  // The handshake window.postMessage carries NO secret — only the transferred
  // port. The session nonce is sent over the port itself as the first
  // message, so a page script that only sniffs window messages can't learn
  // it. A page script would need to race both port capture AND install a
  // port.onmessage before us — much harder than posting a plain message.
  window.addEventListener('message', function (event) {
    if (event.source !== window) return;
    if (!event.data || event.data.source !== SOURCE_TAG) return;
    if (event.data.type !== HANDSHAKE_TYPE) return;
    if (privilegedPort) return; // first handshake wins

    var port = event.ports && event.ports[0];
    if (!port) return;

    privilegedPort = port;

    port.onmessage = function (e) {
      var data = e.data;
      if (!data) return;
      // First port message must be the nonce setup. Subsequent messages
      // are rejected if the nonce doesn't match what we captured.
      if (data.type === '__init' && !privilegedNonce && typeof data.nonce === 'string') {
        privilegedNonce = data.nonce;
        return;
      }
      if (!privilegedNonce || data.nonce !== privilegedNonce) return;
      if (!PRIVILEGED_TYPES[data.type]) return;
      dispatch(data.type, data.payload);
    };
  }, true); // capture phase — try to beat page listeners

  var MessageBus = {
    /**
     * Send a typed (untrusted) message to the content script.
     */
    send: function (type, payload) {
      window.postMessage({ source: SOURCE_TAG, type: type, payload: payload }, '*');
    },

    /**
     * Listen for a specific message type.
     * Privileged types (SUB_STATUS) are ONLY delivered via the trusted port.
     * Untrusted types come through the general window listener below.
     */
    on: function (type, callback) {
      if (!listeners[type]) {
        listeners[type] = [];
      }
      listeners[type].push(callback);
    },

    off: function (type, callback) {
      if (!listeners[type]) return;
      listeners[type] = listeners[type].filter(function (cb) { return cb !== callback; });
    },

    init: function () {
      window.addEventListener('message', function (event) {
        if (!event.data || event.data.source !== SOURCE_TAG) return;
        if (event.source !== window) return;
        var type = event.data.type;
        if (type === HANDSHAKE_TYPE) return; // handled by capture-phase listener
        // Block privileged types from the untrusted window channel. These are
        // only valid through the MessageChannel port.
        if (PRIVILEGED_TYPES[type]) return;
        dispatch(type, event.data.payload);
      });
    },

    /**
     * For diagnostics only: whether the privileged channel is alive.
     */
    hasPrivilegedChannel: function () {
      return !!privilegedPort;
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.MessageBus = MessageBus;
})();
