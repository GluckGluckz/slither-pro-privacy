/**
 * Slither Pro — postMessage wrapper for communication
 * between injected script (MAIN world) and content script (isolated world).
 */
(function () {
  'use strict';

  var SOURCE_TAG = 'slither-pro';
  var listeners = {};

  var MessageBus = {
    /**
     * Send a typed message to the content script.
     */
    send: function (type, payload) {
      window.postMessage({ source: SOURCE_TAG, type: type, payload: payload }, '*');
    },

    /**
     * Listen for a specific message type from the content script.
     */
    on: function (type, callback) {
      if (!listeners[type]) {
        listeners[type] = [];
      }
      listeners[type].push(callback);
    },

    /**
     * Remove a listener.
     */
    off: function (type, callback) {
      if (!listeners[type]) return;
      listeners[type] = listeners[type].filter(function (cb) { return cb !== callback; });
    },

    /**
     * Initialize the global message listener. Called once at startup.
     */
    init: function () {
      window.addEventListener('message', function (event) {
        if (!event.data || event.data.source !== SOURCE_TAG) return;
        if (event.source !== window) return;
        var type = event.data.type;
        var payload = event.data.payload;
        if (listeners[type]) {
          for (var i = 0; i < listeners[type].length; i++) {
            try {
              listeners[type][i](payload);
            } catch (err) {
              console.error('[SlitherPro] MessageBus handler error:', err);
            }
          }
        }
      });
    }
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.MessageBus = MessageBus;
})();
