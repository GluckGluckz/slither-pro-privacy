/**
 * Slither Pro — HUD Root.
 * A persistent container that survives full <body> replacements by other
 * Slither.io mods (Frontier, NTL, etc). Those mods commonly do
 * `document.body.innerHTML = ...` or replace the body node; any widgets
 * we appended directly to <body> get orphaned.
 *
 * This utility gives every overlay a single parent node attached to
 * <html> (never to <body>), with a MutationObserver watching
 * documentElement for its removal. If the container is ever detached,
 * we re-append it immediately. Children use position:fixed already, so
 * being one level closer to <html> changes nothing about layout.
 *
 * All extension UI (HUD widgets, chat widget, overlay canvas, toasts,
 * context menus, name tags) should mount here instead of document.body.
 */
(function () {
  'use strict';

  var SP = window.SlitherPro;
  if (!SP) return;

  var ROOT_ID = 'sp-hud-root';

  var _root = null;
  var _observer = null;

  function build() {
    var el = document.createElement('div');
    el.id = ROOT_ID;
    // 0×0 footprint — children are position:fixed so they paint themselves.
    // pointer-events:none so stray hit-testing on the root can't absorb
    // clicks meant for the game canvas; individual widgets re-enable it.
    el.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;pointer-events:none;z-index:2147483646';
    return el;
  }

  function attach() {
    if (!_root) return;
    if (_root.isConnected) return;
    var parent = document.documentElement || document.body;
    if (!parent) return;
    parent.appendChild(_root);
  }

  function startObserver() {
    if (_observer) return;
    var target = document.documentElement;
    if (!target || typeof MutationObserver !== 'function') return;
    _observer = new MutationObserver(function () {
      // Any documentElement mutation — cheap enough to re-check connection.
      if (_root && !_root.isConnected) attach();
    });
    _observer.observe(target, { childList: true });
  }

  var HudRoot = {
    /**
     * Returns the persistent root element, creating and attaching it on
     * first call. Safe to call before document.body exists.
     */
    get: function () {
      if (!_root) {
        _root = build();
        attach();
        startObserver();
      } else if (!_root.isConnected) {
        attach();
      }
      return _root;
    },

    /**
     * Convenience: append a node to the persistent root.
     */
    append: function (node) {
      this.get().appendChild(node);
      return node;
    }
  };

  SP.HudRoot = HudRoot;
})();
