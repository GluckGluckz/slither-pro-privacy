/**
 * Slither Pro — Game constants and configuration values.
 */
(function () {
  'use strict';

  var CONSTANTS = {
    MAP_RADIUS: 16384,
    DEFAULT_SCALE: 0.9,
    MIN_SCALE: 0.2,
    MAX_SCALE: 2.0,
    MINIMAP_DEFAULT_SIZE: 200,
    OVERLAY_Z_INDEX: 999999,
    MESSAGE_SOURCE: 'slither-pro',
    GAME_POLL_INTERVAL: 500,
    HUD_FONT: '14px "Segoe UI", Consolas, monospace',
    HUD_FONT_LARGE: '18px "Segoe UI", Consolas, monospace',
    HUD_FONT_TITLE: 'bold 22px "Segoe UI", Consolas, monospace'
  };

  window.SlitherPro = window.SlitherPro || {};
  window.SlitherPro.CONSTANTS = CONSTANTS;
})();
