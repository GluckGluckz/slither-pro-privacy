/**
 * Slither Pro — Service worker (background script).
 * Handles extension lifecycle, message routing, and storage.
 */

var DEFAULTS = {
  visual: {
    skin: 'default',
    customColors: ['#39ff14', '#006600'],
    aura: 'none',
    background: 'default',
    backgroundColor: '#111111',
    gameBackgroundEnabled: false,
    gameBackgroundColor: '#0a0a2e',
    gridEnabled: false,
    gridColor: '#333333',
    gridOpacity: 0.3
  },
  food: {
    style: 'default',
    glowEnabled: true,
    scaleCorrection: true,
    customImage: ''
  },
  zoom: {
    enabled: true,
    level: 0.9,
    sensitivity: 0.05,
    smoothing: true
  },
  hud: {
    enabled: true,
    minimapEnabled: true,
    minimapSize: 200,
    minimapPosition: 'bottom-right',
    hideNativeMinimap: true,
    fpsCounter: true,
    pingDisplay: true,
    scoreDisplay: true,
    killCounter: true,
    sessionTimer: true,
    coordinates: false,
    serverInfo: false,
    deathRecap: true
  },
  bot: {
    enabled: false,
    foodSeeker: true,
    collisionAvoidance: true,
    autoBoost: true,
    autoPlay: false,
    inputLock: false,
    mode: 'balanced',
    killAttempts: true,
    smartWander: true,
    coilDetection: true,
  },
  gameplay: {
    graphicsQuality: 'normal',
    autoRespawn: false,
    saveNickname: true,
    nickname: '',
    clanTag: ''
  },
  nameTag: {
    enabled: true,
    style: 'rainbow',
    animationSpeed: 'normal',
    glowIntensity: 'medium',
    fontSize: 'normal',
    useSnakeColors: true,
    color1: '#39ff14',
    color2: '#00cc00'
  },
  subscription: {
    active: false
  }
};

// ─── Install Handler ─────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason === 'install') {
    chrome.storage.sync.set(DEFAULTS);
    // v8: Clear any stale subscription from Chrome Sync restore.
    // Forces re-verification on fresh install / reinstall.
    chrome.storage.sync.remove('sp_subscription');
  } else if (details.reason === 'update') {
    // Migrate: remove deprecated performance category and foodGlow settings
    chrome.storage.sync.remove('performance');
    chrome.storage.sync.get(['visual', 'bot', 'nameTag'], function (data) {
      if (data.visual) {
        var changed = false;
        if (data.visual.foodGlow !== undefined) { delete data.visual.foodGlow; changed = true; }
        if (data.visual.foodGlowIntensity !== undefined) { delete data.visual.foodGlowIntensity; changed = true; }
        if (data.visual.snakeOutlines !== undefined) { delete data.visual.snakeOutlines; changed = true; }
        if (data.visual.snakeOutlineColor !== undefined) { delete data.visual.snakeOutlineColor; changed = true; }
        if (changed) chrome.storage.sync.set({ visual: data.visual });
      }
      // v2: Migrate deprecated bot tuning sliders → mode system
      if (data.bot) {
        var botChanged = false;
        if (data.bot.avoidanceRadius !== undefined) { delete data.bot.avoidanceRadius; botChanged = true; }
        if (data.bot.foodSearchRadius !== undefined) { delete data.bot.foodSearchRadius; botChanged = true; }
        if (data.bot.aggressiveness !== undefined) { delete data.bot.aggressiveness; botChanged = true; }
        if (data.bot.mode === undefined) { data.bot.mode = 'balanced'; botChanged = true; }
        if (botChanged) chrome.storage.sync.set({ bot: data.bot });
      }
      // v3: Migrate nameTag — add new customization properties
      if (data.nameTag) {
        var ntChanged = false;
        if (data.nameTag.animationSpeed === undefined) { data.nameTag.animationSpeed = 'normal'; ntChanged = true; }
        if (data.nameTag.glowIntensity === undefined) { data.nameTag.glowIntensity = 'medium'; ntChanged = true; }
        if (data.nameTag.fontSize === undefined) { data.nameTag.fontSize = 'normal'; ntChanged = true; }
        if (ntChanged) chrome.storage.sync.set({ nameTag: data.nameTag });
      }
    });
  }
});

// ─── Message Routing ─────────────────────────────────────────
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || !message.type) return;

  switch (message.type) {
    case 'SETTINGS_UPDATE':
      // Save updated settings and broadcast to all slither.io tabs
      if (message.payload) {
        chrome.storage.sync.set(message.payload, function () {
          broadcastToSlitherTabs({
            type: 'SETTINGS_UPDATE',
            payload: message.payload
          }, sender.tab ? sender.tab.id : null);
        });
      }
      break;

    case 'RESET_DEFAULTS':
      // Re-install defaults
      chrome.storage.sync.set(DEFAULTS, function () {
        broadcastToSlitherTabs({
          type: 'SETTINGS_UPDATE',
          payload: DEFAULTS
        });
      });
      break;

    case 'STATS_UPDATE':
      storeSessionStats(message.payload);
      break;

    case 'DEATH_EVENT':
      storeDeathEvent(message.payload);
      break;

    case 'FOOD_IMAGE_UPDATE':
      // Forward custom food image data to all slither.io tabs
      broadcastToSlitherTabs({
        type: 'FOOD_IMAGE_UPDATE',
        payload: message.payload
      }, sender.tab ? sender.tab.id : null);
      break;

    case 'MOD_READY':
      /* mod ready */
      break;

    case 'VERIFY_SUBSCRIPTION':
      verifySubscription(sender.tab ? sender.tab.id : null);
      break;

  }
});

// ─── Storage Change Listener ─────────────────────────────────
// Disabled: the popup already sends SETTINGS_UPDATE messages.
// Having this listener too causes duplicate broadcasts.
// chrome.storage.onChanged.addListener(...)

// ─── Helpers ─────────────────────────────────────────────────
function broadcastToSlitherTabs(message, excludeTabId) {
  chrome.tabs.query({ url: ['*://slither.io/*', '*://slither.com/*'] }, function (tabs) {
    tabs.forEach(function (tab) {
      if (tab.id !== excludeTabId) {
        try {
          var result = chrome.tabs.sendMessage(tab.id, message);
          if (result && typeof result.catch === 'function') {
            result.catch(function () { /* tab may not have content script */ });
          }
        } catch (e) { /* cross-browser safety */ }
      }
    });
  });
}

function storeSessionStats(stats) {
  chrome.storage.local.get({ sessionHistory: [] }, function (data) {
    var history = data.sessionHistory;
    history.push({
      timestamp: Date.now(),
      score: stats.score,
      length: stats.length,
      kills: stats.kills,
      sessionTime: stats.sessionTime
    });
    if (history.length > 100) history = history.slice(-100);
    chrome.storage.local.set({ sessionHistory: history });
  });
}

// ─── Subscription Verification (moved from content.js to avoid page CSP) ─────
var VALIDATION_API = 'https://slither-pro-api.anthany2024.workers.dev/verify';

function verifySubscription(tabId) {
  chrome.storage.sync.get('sp_subscription', function (data) {
    var subData = data.sp_subscription;
    if (!subData || !subData.email || !subData.active) return;

    // Check local expiry first
    if (subData.expiresAt && Date.now() > subData.expiresAt) {
      sendVerifyResult(tabId, false);
      revokeSubscription();
      return;
    }

    // Verify with server
    fetch(VALIDATION_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: subData.email })
    })
    .then(function (res) {
      if (res.status === 401 || res.status === 403) {
        sendVerifyResult(tabId, false);
        revokeSubscription();
        return null;
      }
      return res.json();
    })
    .then(function (result) {
      if (!result) return;
      if (!result.valid) {
        sendVerifyResult(tabId, false);
        revokeSubscription();
      } else {
        sendVerifyResult(tabId, true);
      }
    })
    .catch(function () {
      // Network failure — 3 consecutive failures = revoke
      chrome.storage.local.get({ sp_sub_fail_count: 0 }, function (d) {
        var count = (d.sp_sub_fail_count || 0) + 1;
        if (count >= 3) {
          chrome.storage.local.remove('sp_sub_fail_count');
          sendVerifyResult(tabId, false);
          revokeSubscription();
        } else {
          chrome.storage.local.set({ sp_sub_fail_count: count });
        }
      });
    });
  });
}

function sendVerifyResult(tabId, valid) {
  if (!tabId) return;
  try {
    var result = chrome.tabs.sendMessage(tabId, { type: 'VERIFY_SUB_RESULT', valid: valid });
    if (result && typeof result.catch === 'function') {
      result.catch(function () { /* tab may not have content script */ });
    }
  } catch (e) { /* cross-browser safety */ }
}

function revokeSubscription() {
  chrome.storage.sync.get('sp_subscription', function (data) {
    var subData = data.sp_subscription;
    if (subData) {
      subData.active = false;
      chrome.storage.sync.set({ sp_subscription: subData });
    }
  });
}

function storeDeathEvent(deathData) {
  chrome.storage.local.get({ deathHistory: [] }, function (data) {
    var history = data.deathHistory;
    history.push({
      timestamp: Date.now(),
      data: deathData
    });
    if (history.length > 50) history = history.slice(-50);
    chrome.storage.local.set({ deathHistory: history });
  });
}
